# QIAOMI AI v0.2.0 验证记录

2026-11-10（北京时间）。环境为 Linux、Python 3.12.14、Qt 6.8.3、HTTPX 0.28.1。

- 146 项自动化测试通过，包含原有功能回归与新增 Ollama 测试。
- 新增验证：本机固定地址、无认证头、中文多轮载荷、流式分段、模型缺失、连接失败、空回复、错误数据、提前断流、取消和超时后的传输关闭。
- 使用真实本机 HTTP 测试服务器验证 `/api/tags` 和 `/api/chat`；其回复为测试数据，不是 Qwen3 实际生成。
- Qt 整合验证：流式预览、完整回复单次落库、取消不保存未完成内容、检测结果不写入聊天、配置迁移及重启持久化。
- 原有桌宠、托盘回退、记忆管理、OpenAI 模拟传输、打包工具与启动脚本测试仍通过。
- 启动自检 22 项通过，使用隔离目录和离线模式，不接触真实用户数据库。
- `pip check` 无依赖冲突，源码编译检查通过。

命令：

```bash
QT_QPA_PLATFORM=offscreen python -m pytest -q --junitxml=docs/validation/tests-v0.2.0.xml
QT_QPA_PLATFORM=offscreen python -m qiaomi --smoke-test --smoke-report docs/validation/startup-v0.2.0.json
python -m compileall -q qiaomi scripts tests
python -m pip check
```

未验证：真实 Windows 11、RTX 4070 Ti、真实 Ollama/Qwen3:8b 推理、真实 OpenAI 调用、Windows EXE 构建。
Qt offscreen 不支持 raise 的提示属于该测试平台行为，不能代替 Windows 置顶验证。
原版测试记录保留在 `docs/validation/TEST_REPORT-v0.1.1.md`。Windows 验收见 `docs/UPGRADE_V0.2.0.md`。
