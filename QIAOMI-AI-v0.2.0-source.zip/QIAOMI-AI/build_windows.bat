@echo off
setlocal
cd /d "%~dp0"
call "%~dp0start.bat" --prepare-only
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m pip install -r requirements-build.txt
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m PyInstaller --clean --noconfirm qiaomi.spec
if errorlevel 1 goto failed
copy /y "%~dp0docs\WINDOWS_RELEASE.md" "%~dp0dist\QIAOMI-AI\WINDOWS_RELEASE.md" >nul
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" "%~dp0scripts\build_release.py"
if errorlevel 1 goto failed
echo.
echo Build finished: dist\QIAOMI-AI-Windows-x64.zip
echo Checksum: dist\QIAOMI-AI-Windows-x64.zip.sha256
echo Extract the ENTIRE ZIP before running QIAOMI-AI.exe.
echo This local build still needs Windows GUI validation; see docs\WINDOWS_RELEASE.md.
pause
exit /b 0
:failed
echo Build failed. Read the error above.
pause
exit /b 1
