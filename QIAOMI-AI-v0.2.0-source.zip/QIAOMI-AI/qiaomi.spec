# Build with PyInstaller on Windows; output is a complete, portable folder.
from pathlib import Path

from PyInstaller.utils.hooks import collect_submodules

project = Path(SPECPATH)
analysis = Analysis(
    [str(project / "scripts" / "frozen_entry.py")],
    pathex=[str(project)],
    binaries=[],
    datas=[(str(project / "assets"), "assets")],
    hiddenimports=collect_submodules("qiaomi"),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets"],
    noarchive=False,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz,
    analysis.scripts,
    [],
    exclude_binaries=True,
    name="QIAOMI-AI",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
)
collection = COLLECT(
    exe,
    analysis.binaries,
    analysis.datas,
    strip=False,
    upx=False,
    name="QIAOMI-AI",
)
