"""Local-only SQLite history and explicit, reviewed preference storage."""

from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3
import tempfile
from typing import Any, Iterable


MAX_IMPORT_BYTES = 16 * 1024 * 1024
MAX_MEMORIES = 1000
MAX_KEY_CHARS = 120
MAX_VALUE_CHARS = 4000
MAX_MESSAGE_CHARS = 32000


class ValidationError(ValueError):
    """A user-editable value is invalid. Messages contain no imported data."""


def _validate_utf8(value: str) -> None:
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        raise ValidationError("文本包含无效的 Unicode 字符，请重新输入或修复 JSON 文件。") from None


def _memory(key: Any, value: Any) -> dict[str, str]:
    if not isinstance(key, str) or not isinstance(value, str):
        raise ValidationError("记忆名称和内容必须是文字。")
    for text in (key, value):
        _validate_utf8(text)
        if any(ord(char) < 32 and char not in "\t\n\r" for char in text):
            raise ValidationError("记忆包含不支持的控制字符，请仅保留正常文字、换行或制表符。")
    key, value = key.strip(), value.strip()
    if not key or len(key) > MAX_KEY_CHARS:
        raise ValidationError(f"记忆名称需为 1–{MAX_KEY_CHARS} 个字符。")
    if not value or len(value) > MAX_VALUE_CHARS:
        raise ValidationError(f"记忆内容需为 1–{MAX_VALUE_CHARS} 个字符。")
    return {"key": key, "value": value}


def validate_memories(items: Iterable[dict[str, str]]) -> list[dict[str, str]]:
    """Validate a complete batch before any database mutation."""
    result: list[dict[str, str]] = []
    keys: set[str] = set()
    for item in items:
        if len(result) >= MAX_MEMORIES:
            raise ValidationError(f"每次最多导入 {MAX_MEMORIES} 条记忆。")
        if not isinstance(item, dict) or set(item) != {"key", "value"}:
            raise ValidationError("每条记忆只能包含 key 和 value 两个字段。")
        entry = _memory(item["key"], item["value"])
        if entry["key"] in keys:
            raise ValidationError("导入文件含重复的记忆名称，请先合并后再导入。")
        keys.add(entry["key"])
        result.append(entry)
    return result


def parse_import(path: str | Path) -> list[dict[str, str]]:
    """Read and validate only. The UI must review before import_memories()."""
    with Path(path).open("rb") as handle:
        raw = handle.read(MAX_IMPORT_BYTES + 1)
    if len(raw) > MAX_IMPORT_BYTES:
        raise ValidationError("JSON 文件超过 16 MB，请拆分后导入。")
    try:
        document = json.loads(raw.decode("utf-8-sig"))
    except (UnicodeError, json.JSONDecodeError, RecursionError) as exc:
        raise ValidationError("无法读取 JSON，请使用 UTF-8 编码的有效备份文件。") from exc
    if not isinstance(document, dict) or set(document) != {"version", "memories"}:
        raise ValidationError("JSON 应包含 version 和 memories 字段。")
    if type(document["version"]) is not int or document["version"] != 1:
        raise ValidationError("仅支持 version 为 1 的记忆备份。")
    if not isinstance(document["memories"], list):
        raise ValidationError("memories 必须是数组。")
    return validate_memories(document["memories"])


class Store:
    """Use on the creating thread; workers receive plain-data snapshots."""

    parse_import = staticmethod(parse_import)

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self.path, timeout=5.0)
        self._connection.row_factory = sqlite3.Row
        try:
            version = self._connection.execute("PRAGMA user_version").fetchone()[0]
            if version > 1:
                raise ValidationError("数据库由更新版本的敲咪创建，请升级程序后再打开，原数据未修改。")
            self._connection.execute("PRAGMA journal_mode=WAL")
            self._connection.execute("PRAGMA synchronous=NORMAL")
            self._connection.execute("PRAGMA secure_delete=ON")
            self._connection.executescript("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                role TEXT NOT NULL CHECK(role IN ('user', 'assistant')),
                content TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                key TEXT NOT NULL UNIQUE,
                value TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
                updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
            );
            PRAGMA user_version=1;
            """)
        except Exception:
            self._connection.close()
            raise

    def add_message(self, role: str, content: str) -> int:
        if role not in {"user", "assistant"}:
            raise ValidationError("不支持的聊天角色。")
        if not isinstance(content, str) or not content.strip() or len(content) > MAX_MESSAGE_CHARS:
            raise ValidationError(f"消息需为 1–{MAX_MESSAGE_CHARS} 个字符。")
        _validate_utf8(content)
        with self._connection:
            cursor = self._connection.execute(
                "INSERT INTO messages(role, content) VALUES (?, ?)", (role, content)
            )
        return int(cursor.lastrowid)

    def messages(self, limit: int = 100) -> list[dict[str, Any]]:
        if type(limit) is not int or not 1 <= limit <= 10000:
            raise ValidationError("聊天读取数量需为 1–10000。")
        rows = self._connection.execute(
            "SELECT * FROM (SELECT * FROM messages ORDER BY id DESC LIMIT ?) ORDER BY id",
            (limit,),
        ).fetchall()
        return [dict(row) for row in rows]

    def clear_messages(self) -> None:
        with self._connection:
            self._connection.execute("DELETE FROM messages")
        self._connection.execute("PRAGMA wal_checkpoint(TRUNCATE)")

    def list_memories(self) -> list[dict[str, Any]]:
        rows = self._connection.execute("SELECT * FROM memories ORDER BY id DESC").fetchall()
        return [dict(row) for row in rows]

    def upsert_memory(self, key: str, value: str) -> int:
        entry = _memory(key, value)
        with self._connection:
            self._upsert(entry)
            row = self._connection.execute("SELECT id FROM memories WHERE key=?", (entry["key"],)).fetchone()
        return int(row["id"])

    def _upsert(self, entry: dict[str, str]) -> None:
        exists = self._connection.execute("SELECT 1 FROM memories WHERE key=?", (entry["key"],)).fetchone()
        if exists is None and self._connection.execute("SELECT count(*) FROM memories").fetchone()[0] >= MAX_MEMORIES:
            raise ValidationError(f"记忆库最多保存 {MAX_MEMORIES} 条，请先删除不需要的记忆。")
        self._connection.execute("""
            INSERT INTO memories(key,value) VALUES (?,?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value,
            updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')
        """, (entry["key"], entry["value"]))

    def update_memory(self, memory_id: int, key: str, value: str) -> None:
        entry = _memory(key, value)
        try:
            with self._connection:
                cursor = self._connection.execute("""
                    UPDATE memories SET key=?,value=?,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now')
                    WHERE id=?
                """, (entry["key"], entry["value"], memory_id))
                if not cursor.rowcount:
                    raise ValidationError("这条记忆已不存在，请刷新列表。")
        except sqlite3.IntegrityError as exc:
            raise ValidationError("同名记忆已存在，请换一个名称。") from exc

    def delete_memory(self, memory_id: int) -> None:
        with self._connection:
            self._connection.execute("DELETE FROM memories WHERE id=?", (memory_id,))

    def import_memories(self, items: Iterable[dict[str, str]]) -> int:
        entries = validate_memories(items)
        with self._connection:
            for entry in entries:
                self._upsert(entry)
        return len(entries)

    def export_memories(self, path: str | Path) -> None:
        destination = Path(path)
        protected_paths = {self.path.resolve(), Path(str(self.path) + "-wal").resolve(), Path(str(self.path) + "-shm").resolve()}
        if destination.resolve() in protected_paths:
            raise ValidationError("备份不能覆盖正在使用的数据库，请选择另一个 JSON 文件。")
        memories = [{"key": row["key"], "value": row["value"]} for row in self.list_memories()]
        document = json.dumps({"version": 1, "memories": memories}, ensure_ascii=False, indent=2) + "\n"
        temporary: str | None = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent, delete=False) as handle:
                temporary = handle.name
                handle.write(document)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary, destination)
            temporary = None
        finally:
            if temporary is not None:
                Path(temporary).unlink(missing_ok=True)

    def close(self) -> None:
        self._connection.close()
