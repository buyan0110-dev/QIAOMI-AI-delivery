"""Jarvis-inspired control surface. Business logic stays in the controller."""
from __future__ import annotations
import html
import math
from PySide6.QtCore import Qt, QTimer, Signal, QPointF
from PySide6.QtGui import QColor, QPainter, QPen, QKeyEvent
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QStackedWidget, QTextBrowser, QPlainTextEdit, QLineEdit,
    QComboBox, QCheckBox, QFormLayout, QScrollArea, QSizeGrip, QApplication,
)
from qiaomi import __version__
from .memories import MemoryPage
from .pet import clamp_window_position


def label(text, name=None, wrap=False):
    item = QLabel(text)
    item.setTextFormat(Qt.TextFormat.PlainText)
    if name:
        item.setObjectName(name)
    item.setWordWrap(wrap)
    return item


def button(text, name=None):
    item = QPushButton(text)
    if name:
        item.setObjectName(name)
    item.setCursor(Qt.CursorShape.PointingHandCursor)
    return item


class StatusOrb(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(54, 54)
        self.phase = 0.0
        self.busy = False
        self.timer = QTimer(self)
        self.timer.setInterval(70)
        self.timer.timeout.connect(self.tick)

    def tick(self):
        self.phase += .13
        self.update()

    def showEvent(self, event):
        self.timer.start()
        super().showEvent(event)

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor('#6ddcfa' if self.busy else '#77e7cb')
        for radius in (22, 16):
            painter.setPen(QPen(QColor('#27455b'), 1))
            painter.drawEllipse(QPointF(27, 27), radius, radius)
        painter.setPen(QPen(color, 2.5))
        angle = int(self.phase * 80) if self.busy else 35
        painter.drawArc(5, 5, 44, 44, angle * 16, 110 * 16)
        color.setAlpha(int(150 + 60 * math.sin(self.phase)))
        painter.setBrush(color)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(27, 27), 6, 6)


class MessageInput(QPlainTextEdit):
    submitted = Signal()

    def __init__(self):
        super().__init__()
        self._composing = False

    def inputMethodEvent(self, event):
        self._composing = bool(event.preeditString())
        super().inputMethodEvent(event)

    def keyPressEvent(self, event: QKeyEvent):
        if not self._composing and event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.submitted.emit()
            event.accept()
        else:
            super().keyPressEvent(event)


class AssistantWindow(QWidget):
    send_requested = Signal(str)
    pet_requested = Signal()
    hide_requested = Signal()
    quit_requested = Signal()
    clear_requested = Signal()
    cancel_requested = Signal()
    settings_requested = Signal(str, str, bool, bool)
    connection_requested = Signal()
    demo_requested = Signal()
    demo_confirmed = Signal()
    demo_cancelled = Signal()

    def __init__(self, store, config, api_key=''):
        super().__init__()
        self.setWindowTitle('QIAOMI AI · 敲咪智能管家')
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._drag_offset = None
        self._watched_screens = []
        self._watching_screens = False
        self._screen_timer = QTimer(self)
        self._screen_timer.setSingleShot(True)
        self._screen_timer.timeout.connect(self.ensure_on_screen)
        self.resize(1080, 780)
        self.setMinimumSize(850, 650)
        self._allow_close = False
        self._rows = []
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        shell = QWidget()
        shell.setObjectName('shell')
        outer.addWidget(shell)
        layout = QHBoxLayout(shell)
        layout.setContentsMargins(12, 12, 18, 12)
        layout.setSpacing(22)

        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        sidebar.setFixedWidth(200)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(17, 23, 17, 18)
        side.setSpacing(12)
        side.addWidget(label('QIAOMI', 'brand'))
        side.addWidget(label('PERSONAL AI COMPANION', 'eyebrow'))
        side.addSpacing(30)
        self.nav_buttons = []
        for index, text in enumerate(('◈   对话中心', '▤   长期记忆', '⚙   偏好设置')):
            nav = button(text, 'nav')
            nav.setCheckable(True)
            nav.clicked.connect(lambda checked=False, i=index: self.navigate(i))
            side.addWidget(nav)
            self.nav_buttons.append(nav)
        side.addStretch()
        side.addWidget(label('始终由你掌控', 'eyebrow'))
        side.addWidget(label('记忆留在本机。\n操作先确认，再执行。', 'muted', True))
        side.addSpacing(14)
        pet = button('↗  回到桌面猫咪')
        pet.clicked.connect(self.pet_requested)
        side.addWidget(pet)
        hide = button('收起到系统托盘', 'quiet')
        hide.clicked.connect(self.hide_requested)
        side.addWidget(hide)
        side.addWidget(label(f'敲咪  /  MVP {__version__}', 'muted'))
        layout.addWidget(sidebar)

        main = QVBoxLayout()
        main.setContentsMargins(0, 14, 0, 0)
        main.setSpacing(17)
        header = QHBoxLayout()
        titles = QVBoxLayout()
        titles.addWidget(label('YOUR DESKTOP, A LITTLE SMARTER', 'eyebrow'))
        self.title = label('你好，我是敲咪。', 'title')
        titles.addWidget(self.title)
        self.subtitle = label('陪你聊天，也帮你记住重要的小事。', 'subtitle')
        titles.addWidget(self.subtitle)
        header.addLayout(titles)
        header.addStretch()
        self.orb = StatusOrb()
        header.addWidget(self.orb)
        window_buttons = QVBoxLayout()
        close_button = button('×', 'quiet')
        close_button.setToolTip('关闭管家，回到猫咪')
        close_button.setFixedWidth(36)
        close_button.clicked.connect(self.pet_requested)
        tray_button = button('−', 'quiet')
        tray_button.setToolTip('收起到系统托盘')
        tray_button.setFixedWidth(36)
        tray_button.clicked.connect(self.hide_requested)
        window_buttons.addWidget(close_button)
        window_buttons.addWidget(tray_button)
        header.addLayout(window_buttons)
        main.addLayout(header)

        status = QFrame()
        status.setObjectName('card')
        sl = QHBoxLayout(status)
        self.mode_label = label('●  本地陪伴', 'status')
        self.task_label = label('准备就绪', 'muted', True)
        sl.addWidget(self.mode_label)
        sl.addStretch()
        sl.addWidget(self.task_label)
        main.addWidget(status)
        self.pages = QStackedWidget()
        self.pages.addWidget(self._chat_page())
        self.memories = MemoryPage(store)
        self.pages.addWidget(self.memories)
        self.pages.addWidget(self._settings_page(config, api_key))
        main.addWidget(self.pages, 1)
        footer = QHBoxLayout()
        footer.addWidget(label('QIAOMI AI  ·  你的私人桌面搭档', 'muted'))
        footer.addStretch()
        quit_btn = button('退出程序', 'quiet')
        quit_btn.clicked.connect(self.quit_requested)
        footer.addWidget(quit_btn)
        footer.addWidget(QSizeGrip(self))
        main.addLayout(footer)
        layout.addLayout(main, 1)
        self.navigate(0)
        self.set_connected(bool(api_key))

    def _chat_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        self.chat = QTextBrowser()
        self.chat.setOpenLinks(False)
        self.chat.setOpenExternalLinks(False)
        self.chat.setAccessibleName('聊天记录')
        layout.addWidget(self.chat, 1)
        starters = QHBoxLayout()
        for text in ('你好，敲咪', '记住：称呼=主人', '演示任务'):
            b = button(text)
            b.clicked.connect(lambda checked=False, t=text: self.send_requested.emit(t))
            starters.addWidget(b)
        starters.addStretch()
        self.starters = []
        for i in range(3):
            self.starters.append(starters.itemAt(i).widget())
        layout.addLayout(starters)
        self.confirm_card = QFrame()
        self.confirm_card.setObjectName('card')
        confirm_layout = QVBoxLayout(self.confirm_card)
        self.confirm_text = label('', wrap=True)
        confirm_layout.addWidget(self.confirm_text)
        actions = QHBoxLayout()
        yes = button('确认执行演示', 'primary')
        yes.clicked.connect(self.demo_confirmed)
        no = button('取消')
        no.clicked.connect(self.demo_cancelled)
        actions.addWidget(yes)
        actions.addWidget(no)
        actions.addStretch()
        confirm_layout.addLayout(actions)
        self.confirm_card.hide()
        layout.addWidget(self.confirm_card)
        compose = QFrame()
        compose.setObjectName('card')
        cl = QVBoxLayout(compose)
        self.input = MessageInput()
        self.input.setPlaceholderText('和敲咪说点什么…  例如：记住：饮品=少糖拿铁')
        self.input.setFixedHeight(76)
        self.input.setAccessibleName('消息输入框')
        self.input.submitted.connect(self.submit)
        cl.addWidget(self.input)
        controls = QHBoxLayout()
        controls.addWidget(label('Enter 发送 · Shift + Enter 换行', 'muted'))
        controls.addStretch()
        self.clear_button = button('清空记录', 'quiet')
        self.clear_button.clicked.connect(self.clear_requested)
        controls.addWidget(self.clear_button)
        self.stop_button = button('取消请求')
        self.stop_button.clicked.connect(self.cancel_requested)
        self.stop_button.hide()
        controls.addWidget(self.stop_button)
        self.send_button = button('发送  ↗', 'primary')
        self.send_button.clicked.connect(self.submit)
        controls.addWidget(self.send_button)
        cl.addLayout(controls)
        layout.addWidget(compose)
        return page

    def _settings_page(self, config, api_key):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        body.setObjectName('settingsBody')
        form = QVBoxLayout(body)
        form.setSpacing(13)
        form.addWidget(label('让敲咪更懂你', 'title'))
        form.addWidget(label('默认连接本机 Ollama + Qwen3 8B，无需 API Key 或 ChatGPT。', 'muted', True))
        card = QFrame()
        card.setObjectName('card')
        f = QFormLayout(card)
        f.setVerticalSpacing(15)
        self.provider_input = QComboBox()
        for title, value in [('本机 Ollama（推荐）', 'ollama'), ('本地基础回复', 'offline'), ('OpenAI（原有可选服务）', 'openai')]:
            self.provider_input.addItem(title, value)
        self.provider_input.setCurrentIndex(self.provider_input.findData(config.provider))
        f.addRow('对话服务', self.provider_input)
        f.addRow('Ollama 地址', label('http://127.0.0.1:11434'))
        self.connection_status = label('尚未检测', wrap=True)
        f.addRow('本机状态', self.connection_status)
        self.check_button = button('重新检测 Ollama')
        self.check_button.clicked.connect(self.connection_requested)
        f.addRow('', self.check_button)
        self.key_input = QLineEdit(api_key)
        self.key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_input.setPlaceholderText('输入 OpenAI API Key（仅保留在本次运行内存）')
        self.key_input.setMaxLength(512)
        self.model_input = QLineEdit(config.model)
        self.model_input.setMaxLength(120)
        f.addRow('API Key', self.key_input)
        f.addRow('模型名称', self.model_input)
        self.provider_input.currentIndexChanged.connect(self._provider_changed)
        self._provider_changed()
        form.addWidget(card)
        form.addWidget(label('仅 OpenAI 模式使用密钥，且只请求其官方 API，可能产生费用。Ollama 模式不使用密钥；本地请求绕过环境代理。', 'muted', True))
        self.share_box = QCheckBox('允许将本地记忆用于 AI 对话')
        self.share_box.setChecked(config.share_memories)
        form.addWidget(self.share_box)
        form.addWidget(label('Ollama 仅向本机发送消息与最近聊天上下文；勾选后也会使用部分长期记忆。选择 OpenAI 时，这些内容会发送到其官方 API。', 'muted', True))
        self.top_box = QCheckBox('桌面猫咪始终置顶')
        self.top_box.setChecked(config.always_on_top)
        form.addWidget(self.top_box)
        actions = QHBoxLayout()
        self.save_settings = button('应用设置', 'primary')
        self.save_settings.clicked.connect(lambda: self.settings_requested.emit(self.key_input.text().strip(), self.model_input.text().strip(), self.share_box.isChecked(), self.top_box.isChecked()))
        forget = button('清除密钥输入')
        forget.clicked.connect(self.key_input.clear)
        actions.addWidget(self.save_settings)
        actions.addWidget(forget)
        actions.addStretch()
        form.addLayout(actions)
        form.addWidget(label('修改密钥后请点击「应用设置」。不自动读取浏览器、账号凭据或 ChatGPT 数据。麦克风和电脑自动操作未启用。', 'muted', True))
        form.addStretch()
        scroll.setWidget(body)
        layout.addWidget(scroll)
        return page

    def _provider_changed(self, *_):
        provider = self.provider_input.currentData()
        self.key_input.setEnabled(provider == 'openai')
        self.model_input.setEnabled(provider != 'offline')
        if provider == 'ollama' and self.model_input.text().startswith('gpt-'):
            self.model_input.setText('qwen3:8b')
        elif provider == 'openai' and self.model_input.text() == 'qwen3:8b':
            self.model_input.setText('gpt-4o-mini')

    def submit(self):
        text = self.input.toPlainText().strip()
        if text and self.send_button.isEnabled():
            self.send_requested.emit(text)

    def navigate(self, index):
        self.pages.setCurrentIndex(index)
        for i, b in enumerate(self.nav_buttons):
            b.setChecked(i == index)
        if index == 1:
            self.memories.refresh()
        self.title.setText(('你好，我是敲咪。', '重要的小事，我记得。', '按你的习惯来。')[index])
        self.subtitle.setText(('陪你聊天，也帮你记住重要的小事。', '只保存你主动提供和审核的偏好。', '选择连接方式，让陪伴更自在。')[index])

    def set_connected(self, connected):
        provider = self.provider_input.currentData()
        self.mode_label.setText('●  Ollama · 本机 AI' if provider == 'ollama' else ('●  OpenAI 已配置' if provider == 'openai' and connected else '●  本地基础陪伴'))

    def set_busy(self, busy):
        self.check_button.setEnabled(not busy)
        self.provider_input.setEnabled(not busy)
        self.orb.busy = busy
        self.send_button.setEnabled(not busy)
        self.clear_button.setEnabled(not busy)
        self.save_settings.setEnabled(not busy)
        self.stop_button.setVisible(busy)
        self.stop_button.setEnabled(busy)
        for b in self.starters:
            b.setEnabled(not busy)

    def set_task(self, text):
        self.task_label.setText(text)

    def render_messages(self, rows):
        self._rows = list(rows)
        if not rows:
            self.chat.setHtml('<div style="margin:24px 16px;color:#9cb2ca"><p style="font-size:42px">✦</p><p style="font-size:23px;color:#eaf3fc"><b>随时待命，也随时陪你。</b></p><p style="line-height:170%">我是敲咪，你的桌面小管家。<br>摸摸我的脑袋，或在这里开始一段对话。</p><p style="color:#6ddcfa">试试「记住：饮品=少糖拿铁」</p><p>启动 Ollama 并安装 qwen3:8b 后即可本机 AI 对话；也可在设置中选择本地基础回复。</p></div>')
        else:
            blocks = []
            for row in rows:
                user = row['role'] == 'user'
                name = '你' if user else '敲咪'
                color = '#f6ba7d' if user else '#79dcf7'
                content = html.escape(row['content']).replace('\n', '<br>')
                blocks.append(f'<p style="margin-top:18px;color:{color};font-size:12px"><b>{name}</b></p><p style="color:#dce7f5;line-height:155%;margin-bottom:20px">{content}</p><hr style="color:#253448">')
            self.chat.setHtml(''.join(blocks))
        self.chat.verticalScrollBar().setValue(self.chat.verticalScrollBar().maximum())

    def show_confirmation(self, description):
        self.confirm_text.setText(description)
        self.confirm_card.show()
        self.navigate(0)

    def closeEvent(self, event):
        if self._allow_close:
            event.accept()
        else:
            event.ignore()
            self.pet_requested.emit()

    def ensure_on_screen(self):
        if not self.isVisible():
            return
        areas = [screen.availableGeometry() for screen in QApplication.screens()]
        if not areas:
            return
        target_position = clamp_window_position(self.frameGeometry(), areas)
        area = next((rect for rect in areas if rect.contains(target_position)), areas[0])
        self.setMinimumSize(min(850, area.width()), min(650, area.height()))
        if self.width() > area.width() or self.height() > area.height():
            self.resize(min(self.width(), area.width()), min(self.height(), area.height()))
        self.move(clamp_window_position(self.frameGeometry(), areas))

    def _screen_changed(self, *_):
        self._screen_timer.start(0)

    def _topology_changed(self, *_):
        self._stop_screen_watch()
        if self.isVisible():
            self._start_screen_watch()
            self._screen_changed()

    def _start_screen_watch(self):
        if self._watching_screens:
            return
        app = QApplication.instance()
        app.screenAdded.connect(self._topology_changed)
        app.screenRemoved.connect(self._topology_changed)
        self._watched_screens = list(app.screens())
        for screen in self._watched_screens:
            screen.availableGeometryChanged.connect(self._screen_changed)
        self._watching_screens = True

    def _stop_screen_watch(self):
        if not self._watching_screens:
            return
        app = QApplication.instance()
        app.screenAdded.disconnect(self._topology_changed)
        app.screenRemoved.disconnect(self._topology_changed)
        for screen in self._watched_screens:
            try:
                screen.availableGeometryChanged.disconnect(self._screen_changed)
            except (RuntimeError, TypeError):
                pass  # Qt may already have deleted a disconnected monitor.
        self._watched_screens = []
        self._watching_screens = False
        self._screen_timer.stop()

    def showEvent(self, event):
        self._start_screen_watch()
        self._screen_changed()
        super().showEvent(event)

    def hideEvent(self, event):
        self._stop_screen_watch()
        super().hideEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() < 140:
            handle = self.windowHandle()
            if handle is None or not handle.startSystemMove():
                self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_offset = None
        super().mouseReleaseEvent(event)
