"""PyInstaller entry point. Build on the target Windows platform."""

import runpy

runpy.run_module("qiaomi", run_name="__main__")
