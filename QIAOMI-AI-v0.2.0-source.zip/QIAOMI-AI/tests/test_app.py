"""Controller integration tests using Qt offscreen; no remote API calls."""

import json
import os
import time
from threading import Event

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QSystemTrayIcon

from qiaomi import app as application


@pytest.fixture(scope="module")
def qapp():
    instance = QApplication.instance() or QApplication([])
    instance.setQuitOnLastWindowClosed(False)
    return instance


def wait_until(predicate, timeout_ms=2000):
    deadline = time.monotonic() + timeout_ms / 1000
    while not predicate() and time.monotonic() < deadline:
        QTest.qWait(5)
    assert predicate(), "Qt event did not complete within the test deadline"


@pytest.fixture
def controller(qapp, tmp_path, monkeypatch):
    monkeypatch.setattr(QSystemTrayIcon, "isSystemTrayAvailable", staticmethod(lambda: False))
    instance = application.Controller(qapp, tmp_path, smoke=True)
    instance.config.provider = 'openai'
    instance.config.model = 'gpt-4o-mini'
    instance.window.provider_input.setCurrentIndex(instance.window.provider_input.findData('openai'))
    instance.test_errors = []
    monkeypatch.setattr(instance, "error", instance.test_errors.append)
    yield instance
    if instance.worker is not None:
        instance.cancel_chat()
        wait_until(lambda: instance.worker is None)
    qapp.aboutToQuit.disconnect(instance.cleanup)
    instance.cleanup()
    instance.window._allow_close = True
    instance.window.close()
    instance.pet.hide()
    instance.tray.hide()
    instance.window.deleteLater()
    instance.pet.deleteLater()
    instance.deleteLater()
    qapp.processEvents()


def test_switch_commands_and_no_tray_fallback_keep_app_reachable(controller):
    controller.show_pet()
    assert controller.pet.isVisible()
    assert not controller.window.isVisible()
    controller.show_assistant()
    assert controller.window.isVisible()
    assert not controller.pet.isVisible()
    controller.send("/宠物")
    assert controller.pet.isVisible()
    controller.send("/管家")
    assert controller.window.isVisible()
    controller.send("/记忆")
    assert controller.window.pages.currentIndex() == 1
    assert controller.store.messages() == []
    controller.hide_to_tray()
    assert controller.pet.isVisible()


def test_offline_reply_persists_and_worker_releases_secrets(controller):
    controller.send("你好，敲咪")
    worker = controller.worker
    assert not controller.window.send_button.isEnabled()
    wait_until(lambda: controller.worker is None)
    rows = controller.store.messages()
    assert [row["role"] for row in rows] == ["user", "assistant"]
    assert rows[1]["content"].startswith("【离线模式】")
    assert controller.window.send_button.isEnabled()
    assert worker.api_key == ""
    assert worker.messages == []
    assert worker.memories == []
    assert not controller.test_errors


def test_remember_command_requires_explicit_yes_and_cancel_is_non_mutating(controller, monkeypatch):
    monkeypatch.setattr(controller, "ask", lambda *args: False)
    controller.send("记住：饮品=少糖拿铁")
    assert controller.store.list_memories() == []
    assert controller.store.messages() == []
    monkeypatch.setattr(controller, "ask", lambda *args: True)
    controller.send("记住：饮品=少糖拿铁")
    assert controller.store.list_memories()[0]["value"] == "少糖拿铁"
    assert len(controller.store.messages()) == 2
    assert controller.worker is None
    monkeypatch.setattr(controller, "ask", lambda *args: False)
    controller.send("记住：饮品=黑咖啡")
    assert controller.store.list_memories()[0]["value"] == "少糖拿铁"
    assert len(controller.store.messages()) == 2


def test_demo_cannot_complete_until_confirmed_and_cancellation_invalidates_it(controller):
    controller.confirm_demo()
    assert controller.store.messages() == []
    controller.propose_demo()
    assert controller.pending_demo is not None
    assert controller.store.messages() == []
    controller.cancel_demo()
    controller.confirm_demo()
    assert controller.store.messages() == []
    controller.propose_demo()
    controller.confirm_demo()
    assert controller.pending_demo is None
    assert "没有执行任何系统操作" in controller.store.messages()[0]["content"]
    controller.confirm_demo()
    assert len(controller.store.messages()) == 1


def test_clear_requires_confirmation_and_preserves_memories(controller, monkeypatch):
    controller.store.add_message("user", "历史记录")
    controller.store.upsert_memory("语言", "中文")
    monkeypatch.setattr(controller, "ask", lambda *args: False)
    controller.clear_chat()
    assert len(controller.store.messages()) == 1
    controller.propose_demo()
    monkeypatch.setattr(controller, "ask", lambda *args: True)
    controller.clear_chat()
    assert controller.store.messages() == []
    assert controller.store.list_memories()[0]["value"] == "中文"
    assert controller.pending_demo is None


def test_settings_never_persist_key_and_memory_sharing_requires_opt_in(controller, monkeypatch):
    captured = []
    def reply(key, model, messages, memories, stop_event=None):
        captured.append((key, model, memories))
        return "测试回应"
    monkeypatch.setattr(application, "chat_reply", reply)
    controller.store.upsert_memory("饮品", "茶")
    controller.apply_settings("fake-session-secret", "gpt-4o-mini", False, True)
    raw = controller.config_path.read_text(encoding="utf-8")
    assert "fake-session-secret" not in raw
    assert set(json.loads(raw)) == {"model", "share_memories", "always_on_top", "provider"}
    controller.send("第一条")
    wait_until(lambda: controller.worker is None)
    assert captured[0][0] == "fake-session-secret"
    assert captured[0][2] == []
    controller.apply_settings("fake-session-secret", "gpt-4o-mini", True, True)
    controller.send("第二条")
    wait_until(lambda: controller.worker is None)
    assert captured[1][2][0]["value"] == "茶"


def test_cancel_discards_late_answer_and_busy_guards_clear_and_settings(controller, monkeypatch):
    entered = Event()
    def delayed(key, model, messages, memories, stop_event=None):
        entered.set()
        assert stop_event.wait(1)
        return "不应显示或保存的迟到回复"
    monkeypatch.setattr(application, "chat_reply", delayed)
    monkeypatch.setattr(controller, "ask", lambda *args: pytest.fail("Clear must be blocked during an active request"))
    controller.send("保留用户消息")
    wait_until(entered.is_set)
    controller.clear_chat()
    controller.apply_settings("new-key", "new-model", True, False)
    assert controller.api_key == ""
    assert controller.config.model == "gpt-4o-mini"
    controller.cancel_chat()
    wait_until(lambda: controller.worker is None)
    assert [row["content"] for row in controller.store.messages()] == ["保留用户消息"]
    assert controller.window.send_button.isEnabled()
    assert "已取消" in controller.window.task_label.text()


def test_quit_waits_for_worker_and_closes_store_without_saving_late_reply(controller, qapp, monkeypatch):
    entered = Event()
    allow_finish = Event()
    cancelled = Event()
    quit_calls = []
    monkeypatch.setattr(qapp, "quit", lambda: quit_calls.append(True))
    def delayed(key, model, messages, memories, stop_event=None):
        entered.set()
        assert stop_event.wait(1)
        cancelled.set()
        assert allow_finish.wait(1)
        return "迟到的回复"
    monkeypatch.setattr(application, "chat_reply", delayed)
    controller.send("准备退出")
    wait_until(entered.is_set)
    controller.request_quit()
    wait_until(cancelled.is_set)
    assert controller.shutting_down
    assert not controller.closed
    assert not quit_calls
    allow_finish.set()
    wait_until(lambda: controller.closed)
    assert quit_calls == [True]
    assert controller.worker is None
    assert controller.api_key == ""
    assert controller.window.key_input.text() == ""
    reopened = application.Store(controller.folder / "qiaomi.db")
    assert [row["content"] for row in reopened.messages()] == ["准备退出"]
    reopened.close()


def test_chat_renders_markup_as_literal_text_and_disables_link_navigation(controller):
    dangerous_text = '<img src="file:///private/data"> <a href="https://invalid.example">网页</a>'
    controller.store.add_message("assistant", dangerous_text)
    controller.refresh_chat()
    assert dangerous_text in controller.window.chat.toPlainText()
    assert not controller.window.chat.openLinks()
    assert not controller.window.chat.openExternalLinks()


def test_external_cleanup_discards_already_queued_reply(controller, qapp, monkeypatch):
    monkeypatch.setattr(qapp, "quit", lambda: None)
    monkeypatch.setattr(application, "chat_reply", lambda *args, **kwargs: "已排队但不应落盘的回复")
    controller.send("关闭前的消息")
    # Join without processing GUI events, leaving reply/finished signals queued.
    assert controller.worker.wait(1000)
    controller.cleanup()
    qapp.processEvents()
    assert controller.closed
    assert not controller.test_errors
    reopened = application.Store(controller.folder / "qiaomi.db")
    assert [row["content"] for row in reopened.messages()] == ["关闭前的消息"]
    reopened.close()


def test_assistant_recovery_keeps_window_reachable_and_stops_screen_watch(controller, qapp):
    controller.window.move(-20000, -20000)
    controller.show_assistant()
    qapp.processEvents()
    areas = [screen.availableGeometry() for screen in qapp.screens()]
    assert any(area.contains(controller.window.frameGeometry().topLeft()) for area in areas)
    assert controller.window._watching_screens
    controller.show_pet()
    assert not controller.window._watching_screens
    assert not controller.window._screen_timer.isActive()
    for _ in range(3):
        controller.show_assistant()
        controller.show_pet()
    assert not controller.window._watched_screens


def test_pet_keeps_busy_state_during_interaction_until_request_finishes(controller, monkeypatch):
    entered = Event()
    finish = Event()
    def delayed(*args, **kwargs):
        entered.set()
        assert finish.wait(1)
        return '完成'
    monkeypatch.setattr(application, 'chat_reply', delayed)
    controller.send('稍等一下')
    wait_until(entered.is_set)
    assert controller.pet._busy
    controller.pet.set_state('pet_head', 20)
    wait_until(lambda: controller.pet.state == 'thinking')
    finish.set()
    wait_until(lambda: controller.worker is None)
    assert not controller.pet._busy
    assert controller.pet.state == 'happy'


def test_ollama_stream_preview_commits_only_completed_reply(controller, monkeypatch):
    controller.config.provider = 'ollama'
    controller.config.model = 'qwen3:8b'
    def generate(model, messages, memories, stopped, chunk):
        assert model == 'qwen3:8b'
        chunk('<b>中文</b>')
        chunk('回复')
        return '<b>中文</b>回复'
    monkeypatch.setattr(application, 'ollama_reply', generate)
    controller.send('你好')
    wait_until(lambda: controller.worker is None)
    assert controller.store.messages()[-1]['content'] == '<b>中文</b>回复'
    assert controller.window.chat.toPlainText().count('<b>中文</b>回复') == 1


def test_ollama_cancel_removes_partial_preview(controller, monkeypatch):
    controller.config.provider = 'ollama'
    emitted = Event()
    def generate(model, messages, memories, stopped, chunk):
        chunk('未完成的内容')
        emitted.set()
        stopped.wait(1)
        return '未完成的内容'
    monkeypatch.setattr(application, 'ollama_reply', generate)
    controller.send('取消测试')
    wait_until(emitted.is_set)
    wait_until(lambda: '未完成的内容' in controller.window.chat.toPlainText())
    assert len(controller.store.messages()) == 1
    controller.cancel_chat()
    wait_until(lambda: controller.worker is None)
    assert '未完成的内容' not in controller.window.chat.toPlainText()
    assert len(controller.store.messages()) == 1


def test_probe_is_background_and_never_saved_as_chat(controller, monkeypatch):
    monkeypatch.setattr(application, 'check_ollama', lambda *args: 'Ollama 已连接 · qwen3:8b 已安装')
    controller.check_connection()
    wait_until(lambda: controller.worker is None)
    assert '已安装' in controller.window.connection_status.text()
    assert controller.store.messages() == []
