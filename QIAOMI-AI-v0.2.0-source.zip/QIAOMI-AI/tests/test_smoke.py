"""Run the actual entry point in a separate process, including failure paths."""
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]


def smoke_process(tmp_path, *, fail=False):
    report = tmp_path / '中文 自检' / 'report.json'
    data = tmp_path / 'existing-user-data'
    data.mkdir()
    sentinel = data / 'do-not-touch.txt'
    sentinel.write_text('keep', encoding='utf-8')
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', QIAOMI_DATA_DIR=str(data),
               OPENAI_API_KEY='fake-environment-key-that-must-never-be-used')
    args = ['--smoke-test', '--smoke-report', str(report)]
    if fail:
        command = [sys.executable, '-c',
                   'from qiaomi import app; app.chat_reply = lambda *a, **k: "bad reply"; '
                   'raise SystemExit(app.main())', *args]
    else:
        command = [sys.executable, '-m', 'qiaomi', *args]
    result = subprocess.run(command, env=env, cwd=ROOT, text=True, capture_output=True, timeout=20)
    assert sentinel.read_text(encoding='utf-8') == 'keep'
    assert list(data.iterdir()) == [sentinel]
    assert 'fake-environment-key' not in result.stdout + result.stderr + report.read_text(encoding='utf-8')
    return result, json.loads(report.read_text(encoding='utf-8'))


def test_real_startup_reports_checks_and_uses_no_user_data(tmp_path):
    result, report = smoke_process(tmp_path)
    assert result.returncode == 0, result.stderr
    assert report['passed']
    assert not report['errors']
    assert report['checks']['offline_reply_saved']
    assert report['checks']['sqlite_persistence']
    assert report['checks']['clean_shutdown']
    assert len([key for key in report['checks'] if key.startswith('render_')]) == 10


def test_failed_reply_is_nonzero_and_writes_failure_without_dialog(tmp_path):
    result, report = smoke_process(tmp_path, fail=True)
    assert result.returncode == 1, result.stderr
    assert not report['passed']
    assert report['checks']['offline_reply_saved'] is False
    assert report['checks']['clean_shutdown']
    assert report['errors']
