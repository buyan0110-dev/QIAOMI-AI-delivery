# Windows 便携版与发布验证

## 使用已构建的便携版

将 `QIAOMI-AI-Windows-x64.zip` **完整解压**到自己可以写入的位置，然后双击其中的 `QIAOMI-AI\QIAOMI-AI.exe`。便携版通常无需另行安装 Python；必须保留同目录下的 `_internal` 文件夹，不能只复制 EXE。

猫咪右键菜单可打开管家界面、收起到托盘或退出。首次使用不需要 API Key；在线聊天需在偏好设置中输入自己的密钥。程序数据独立保存在 `%LOCALAPPDATA%\QIAOMI AI`，更新程序文件夹不会自动删除聊天和记忆。

本项目尚未提供代码签名、安装向导或自动更新。SHA-256 用于核对下载文件是否发生变化，不等于代码签名、可信发行者认证或杀毒检测结论。

## 在自己的 Windows 电脑构建

前提：Windows 11 x64，已安装 64 位 Python 3.11–3.13，推荐 3.12。完整解压源码后双击 `build_windows.bat`。该脚本沿用 `start.bat` 的解释器检查，创建本地虚拟环境，安装固定版本的构建依赖，再运行 PyInstaller。

成功后得到：

```text
dist/
├── QIAOMI-AI/                         # 完整可运行文件夹
│   ├── QIAOMI-AI.exe
│   ├── _internal/
│   └── WINDOWS_RELEASE.md
├── QIAOMI-AI-Windows-x64.zip           # 可分发的完整文件夹压缩包
└── QIAOMI-AI-Windows-x64.zip.sha256    # 压缩包 SHA-256
```

构建依赖由 `requirements-build.txt` 固定，当前使用 PyInstaller 6.16.0。首次安装依赖需要联网；脚本不会下载或安装 Python，也不会发布到任何外部服务。重复构建会更新 `build/`、`dist/` 中的构建输出，请将需要保留的旧版本移至其他目录。

终端中手动执行的等价步骤：

```bat
start.bat --prepare-only
.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.venv\Scripts\python.exe -m PyInstaller --clean --noconfirm qiaomi.spec
copy /y docs\WINDOWS_RELEASE.md dist\QIAOMI-AI\WINDOWS_RELEASE.md
.venv\Scripts\python.exe scripts\build_release.py
```

`scripts/build_release.py` 只负责验证并压缩已存在的 Windows 构建目录，不能把 Linux 程序转换成 Windows EXE。它要求存在带 Windows `MZ` 头的入口与非空 `_internal` 目录，拒绝符号链接、Windows 重解析点和可能逃逸的归档路径；写入后检查 ZIP CRC 并生成校验文件。它检查包的结构与完整性，不能代替运行 EXE。

可选择输入输出路径：

```bat
.venv\Scripts\python.exe scripts\build_release.py --source dist\QIAOMI-AI --output dist\QIAOMI-AI-Windows-x64.zip
```

输出 ZIP 必须位于输入目录之外，避免把压缩包自身递归打入。工具不会把源代码、虚拟环境、用户数据目录或 API Key 自动加入压缩包；只有所选构建目录内的文件会被打包。

## 校验下载文件

在 PowerShell 中进入 ZIP 所在目录，运行：

```powershell
$actual = (Get-FileHash .\QIAOMI-AI-Windows-x64.zip -Algorithm SHA256).Hash
$expected = (Get-Content .\QIAOMI-AI-Windows-x64.zip.sha256 -Raw).Split(' ')[0]
if ($actual -ne $expected) { throw "校验失败，请重新获取文件" }
"SHA-256 校验一致"
```

应从你信任的同一交付来源获取 ZIP 和校验文件。修改、重新压缩 ZIP 后，原校验值会失效。

## GitHub Actions 验证流程

项目附带 `.github/workflows/windows.yml`。将项目提交到自己的 GitHub 仓库后，可在 **Actions → Windows validation and portable build → Run workflow** 手动运行；向 `main` / `master` 推送或创建拉取请求也会触发。

流程使用只读 `contents` 权限，不创建 Release、不推送代码、不部署网站：

1. 在 `windows-latest` 上分别使用 Python 3.11、3.12、3.13 x64 安装依赖并运行测试，保存 JUnit 测试报告。
2. 每个版本执行源码入口的冒烟检查，等待最多 30 秒，要求正常退出且 JSON 报告中的 `passed` 为 `true`，保存检查项及错误报告。
3. 只有三个版本的测试全部通过，才在 Python 3.12 x64 下构建便携版。
4. 生成完整 ZIP 与 SHA-256，重新解压 ZIP，从实际分发内容启动 EXE，等待最多 30 秒，同时检查退出码及 JSON 报告的 `passed` 值。
5. 成功后上传 `QIAOMI-AI-Windows-x64` 工作流产物；测试报告和构建日志另行保存，方便排查失败。

下载 GitHub 工作流产物时，平台可能会再套一层 ZIP。先解压平台产物，即可得到项目自己的 Windows ZIP 和 `.sha256` 文件。

## 仍需人工验收的项目

GitHub 的 `windows-latest` 托管运行器使用 **Windows Server 镜像，不是 Windows 11 桌面**。CI 同时使用 `QT_QPA_PLATFORM=offscreen`，能发现导入、资源缺失、异常退出及部分生命周期问题，**不验证实际 Windows 11 桌面的透明合成、托盘显示、鼠标拖动、多显示器、中文输入法、DPI 缩放或 SmartScreen 行为**。即使矩阵测试和 EXE 冒烟检查全部通过，也不能据此声称完成 Windows 11 GUI 验收。发布前请在 Windows 11 实机完成这些项目，并使用自己的 API Key 检查真实服务调用和断网提示。

提供工作流文件不表示它已在 GitHub 执行成功。当前云开发环境为 Linux；若交付记录没有附 Windows 工作流运行链接或实机测试结果，则 Windows 构建与桌面验收仍属待验证，不能称为已发布、已签名或已验证的 Windows 安装包。
