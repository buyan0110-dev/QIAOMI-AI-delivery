Option Explicit
Dim shell, fso, root, link
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
Set link = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\QIAOMI AI.lnk")
link.TargetPath = fso.BuildPath(fso.GetSpecialFolder(0), "System32\wscript.exe")
link.Arguments = """" & fso.BuildPath(root, "start.vbs") & """"
link.WorkingDirectory = root
link.Description = "QIAOMI AI v0.3.0"
link.WindowStyle = 7
link.Save
MsgBox "Desktop shortcut created. Keep this project folder at its current location.", 64, "QIAOMI AI"
