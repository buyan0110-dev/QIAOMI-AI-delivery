import sys
if '--voice-worker' in sys.argv:
    from qiaomi.voice_worker import main
else:
    from qiaomi.app import main
if __name__ == '__main__':
    raise SystemExit(main())
