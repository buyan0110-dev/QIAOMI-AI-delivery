"""Qt voice coordinator: child-process ASR + installed offline Qt/SAPI voices."""
from __future__ import annotations
import json
import logging
import sys
import time
import secrets
from pathlib import Path
from PySide6.QtCore import QObject, QProcess, QTimer, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QCheckBox, QLabel, QComboBox, QSlider, QLineEdit, QFileDialog)
from PySide6.QtNetwork import QTcpServer, QHostAddress
from PySide6.QtCore import Qt

log = logging.getLogger('qiaomi')

class TranscriptWakeDetector:
    """Replaceable fallback, NOT a dedicated keyword spotting model."""
    label = '实验：本地转写匹配（非专用唤醒词检测）'
    def matches(self, text):
        import re
        return re.sub(r'[\s，。！？,.!?]', '', text).startswith('敲咪')

class VoiceService(QObject):
    cancel_requested = Signal()
    text = Signal(str)
    status = Signal(str)
    animation = Signal(str)
    wake_detected = Signal()

    def __init__(self, folder, parent=None):
        super().__init__(parent)
        self.path = Path(folder) / 'voice.json'
        self.settings = dict(model_path='', device=None, compute='cpu', threshold=.012,
                             volume=80, rate=0, voice='', tts=False, memory_enabled=True)
        try:
            saved = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(saved, dict):
                for key in self.settings:
                    value = saved.get(key)
                    if type(value) is type(self.settings[key]):
                        self.settings[key] = value
                if type(saved.get('device')) is int:
                    self.settings['device'] = saved['device']
        except (OSError, ValueError):
            pass
        self.settings['compute'] = 'cuda' if self.settings['compute'] == 'cuda' else 'cpu'
        self.settings['threshold'] = max(.001, min(.1, self.settings['threshold']))
        self.settings['volume'] = max(0, min(100, self.settings['volume']))
        self.settings['rate'] = max(-80, min(80, self.settings['rate']))
        self.wake = False  # Never restore continuous listening after restart.
        self.muted = False
        self.busy = False
        self.listening = False
        self.closing = False
        self.mode = 'manual'
        self.stopping = False
        self.buffer = b''
        self.pending_commands = []
        self.socket = None
        self.authenticated = False
        self.token = secrets.token_hex(32)
        self.server = QTcpServer(self)
        self.server.listen(QHostAddress.SpecialAddress.LocalHost, 0)
        self.server.newConnection.connect(self._connected)
        self.tts = None
        self.awaiting_command = False
        self.speaking = False
        self.retry = QTimer(self)
        self.retry.setSingleShot(True)
        self.retry.timeout.connect(self._wake_listen)
        self.follow = QTimer(self)
        self.follow.setSingleShot(True)
        self.follow.timeout.connect(self._follow_listen)
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(lambda: self.process.readAllStandardOutput())
        self.process.readyReadStandardError.connect(lambda: self.process.readAllStandardError())
        self.process.finished.connect(self._process_finished)
        self.process.errorOccurred.connect(self._process_error)
        self.detector = TranscriptWakeDetector()
        self.panel = self._panel()
        try:
            from PySide6.QtTextToSpeech import QTextToSpeech
            # Explicit Windows SAPI is offline and uses installed system voices.
            engines = QTextToSpeech.availableEngines()
            engine = next((e for e in ('sapi', 'winrt') if e in engines), '') if sys.platform=='win32' else 'speechd'
            self.tts = QTextToSpeech(engine, self) if engine else None
            if self.tts is None:
                return
            self.tts.stateChanged.connect(self._tts_state)
            self.tts.errorOccurred.connect(lambda *_: self.status.emit('本地 TTS 不可用，请安装 Windows 中文语音包。'))
            self._load_voices()
        except (ImportError, RuntimeError):
            self.status.emit('本地 TTS 组件不可用。')

    def _panel(self):
        panel = QDialog()
        panel.setWindowTitle('敲咪 · 本地语音设置')
        panel.resize(620, 490)
        layout = QVBoxLayout(panel)
        layout.addWidget(QLabel('录音仅驻留内存；默认不监听。识别模型必须事先下载到本地。'))
        self.label = QLabel('麦克风未开启')
        self.status.connect(self.label.setText)
        self.label.setWordWrap(True)
        layout.addWidget(self.label)
        row = QHBoxLayout()
        self.mic = QComboBox()
        self.mic.addItem('系统默认麦克风', None)
        self.mic.currentIndexChanged.connect(lambda _: self._set('device', self.mic.currentData()))
        row.addWidget(self.mic)
        refresh = QPushButton('刷新设备')
        refresh.clicked.connect(lambda: self._command({'op':'devices'}))
        row.addWidget(refresh)
        layout.addLayout(row)
        self.model = QLineEdit(self.settings['model_path'])
        self.model.setPlaceholderText('本地 faster-whisper 模型目录')
        self.model.editingFinished.connect(lambda: self._set('model_path', self.model.text().strip()))
        layout.addWidget(self.model)
        choose = QPushButton('选择模型目录')
        choose.clicked.connect(self._choose)
        layout.addWidget(choose)
        compute = QComboBox()
        compute.addItem('CPU int8（推荐，给 Qwen3 留出显存）', 'cpu')
        compute.addItem('CUDA float16（需要 CUDA 12 / cuDNN 9，失败回退 CPU）', 'cuda')
        compute.setCurrentIndex(1 if self.settings['compute']=='cuda' else 0)
        compute.currentIndexChanged.connect(lambda _: self._set('compute', compute.currentData()))
        layout.addWidget(compute)
        layout.addWidget(QLabel('麦克风灵敏度（越高越容易触发语音活动）'))
        sensitivity = QSlider(Qt.Orientation.Horizontal)
        sensitivity.setRange(1, 100)
        sensitivity.setValue(round(101-self.settings['threshold']*1000))
        sensitivity.valueChanged.connect(lambda v: self._set('threshold', (101-v)/1000))
        layout.addWidget(sensitivity)
        self.wake_box = QCheckBox(self.detector.label + '；启用后持续使用麦克风')
        self.wake_box.toggled.connect(self.set_wake)
        layout.addWidget(self.wake_box)
        self.tts_box = QCheckBox('本地中文语音播报')
        self.tts_box.setChecked(self.settings['tts'])
        self.tts_box.toggled.connect(self._toggle_tts)
        layout.addWidget(self.tts_box)
        self.voices = QComboBox()
        self.voices.currentIndexChanged.connect(self._voice_changed)
        layout.addWidget(self.voices)
        for title, key, low, high in [('音量', 'volume', 0, 100), ('语速', 'rate', -80, 80)]:
            layout.addWidget(QLabel(title))
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(low, high)
            slider.setValue(self.settings[key])
            slider.valueChanged.connect(lambda v, k=key: self._set(k, v))
            layout.addWidget(slider)
        memory = QCheckBox('启用长期记忆命令（对话引用仍由原设置中的记忆共享开关控制）')
        memory.setChecked(self.settings['memory_enabled'])
        memory.toggled.connect(lambda v: self._set('memory_enabled', v))
        layout.addWidget(memory)
        actions = QHBoxLayout()
        for title, callback in [('开始说话', self.listen), ('取消 / 打断', self.cancel_requested.emit)]:
            b = QPushButton(title)
            b.clicked.connect(callback)
            actions.addWidget(b)
        self.mute_box = QCheckBox('麦克风静音')
        self.mute_box.toggled.connect(self.set_muted)
        actions.addWidget(self.mute_box)
        layout.addLayout(actions)
        self.transcript = QLabel('识别结果显示在这里')
        self.transcript.setWordWrap(True)
        layout.addWidget(self.transcript)
        return panel

    def _set(self, key, value):
        self.settings[key] = value
        try:
            temp = self.path.with_suffix('.tmp')
            temp.write_text(json.dumps(self.settings, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(self.path)
        except OSError:
            self.status.emit('语音设置保存失败，请检查数据目录权限。')
        if key == 'memory_enabled' and not value:
            self.status.emit('长期记忆已关闭；原有数据保留。')

    def _choose(self):
        path = QFileDialog.getExistingDirectory(self.panel, '选择本地 faster-whisper 模型')
        if path:
            self.model.setText(path)
            self._set('model_path', path)

    def _load_voices(self):
        self.voices.blockSignals(True)
        self.voices.clear()
        # Only offer Chinese installed voices for this Chinese assistant.
        for voice in self.tts.availableVoices():
            if voice.locale().name().startswith('zh'):
                self.voices.addItem(voice.name(), voice)
        index = self.voices.findText(self.settings['voice'])
        if index >= 0:
            self.voices.setCurrentIndex(index)
        self.voices.blockSignals(False)
        if not self.voices.count():
            self.status.emit('未发现中文本地声音，请在 Windows 设置中安装中文语音包。')
        else:
            self.tts.setVoice(self.voices.currentData())

    def _voice_changed(self, _):
        if self.tts and self.voices.currentData() is not None:
            self.tts.setVoice(self.voices.currentData())
            self._set('voice', self.voices.currentText())

    def _toggle_tts(self, enabled):
        self._set('tts', enabled)
        if not enabled:
            self.stop_speech()

    def show(self):
        self.panel.showNormal()
        self.panel.raise_()

    def _connected(self):
        incoming = self.server.nextPendingConnection()
        if self.socket is not None:
            incoming.abort()
            incoming.deleteLater()
            return
        self.socket = incoming
        self.authenticated = False
        self.buffer = b''
        incoming.readyRead.connect(self._read)
        incoming.disconnected.connect(self._disconnected)

    def _disconnected(self):
        if self.socket:
            self.socket.deleteLater()
        self.socket = None
        self.authenticated = False

    def _write(self, command):
        self.socket.write((json.dumps(command)+'\n').encode())

    def _command(self, command):
        if self.closing:
            return
        if self.process.state() == QProcess.ProcessState.NotRunning:
            self.pending_commands.clear()
            if not self.server.isListening():
                self.status.emit('无法创建本机语音控制通道。')
                self.listening = False
                return
            self.token = secrets.token_hex(32)
            args = ['--voice-worker'] if getattr(sys, 'frozen', False) else ['-m', 'qiaomi.voice_worker']
            args += [str(self.server.serverPort()), self.token]
            self.process.start(sys.executable, args)
        if self.authenticated and self.socket:
            self._write(command)
        else:
            self.pending_commands.append(command)

    def _read(self):
        if not self.socket:
            return
        self.buffer += bytes(self.socket.readAll())
        if len(self.buffer) > 128000:
            self.socket.abort()
            return
        while b'\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\n', 1)
            try:
                data = json.loads(line)
            except ValueError:
                continue
            if not self.authenticated:
                if not secrets.compare_digest(str(data.get('token','')), self.token):
                    self.socket.abort()
                    return
                self.authenticated = True
                for command in self.pending_commands:
                    self._write(command)
                self.pending_commands.clear()
            else:
                self._event(data)

    def _event(self, data):
        event, value = data.get('event'), data.get('value', '')
        if self.closing:
            return
        if event == 'devices':
            selected = self.settings['device']
            self.mic.blockSignals(True)
            self.mic.clear()
            self.mic.addItem('系统默认麦克风', None)
            for device in value:
                self.mic.addItem(device['name'], device['id'])
            self.mic.setCurrentIndex(max(0, self.mic.findData(selected)))
            self.mic.blockSignals(False)
            self.status.emit(f'检测到 {len(value)} 个输入设备；请选择可用麦克风。')
        elif event in ('warning', 'error'):
            self.status.emit(value)
            if event == 'error':
                self.animation.emit('error')
                # Prevent an infinite error/reload loop during background wake.
                self.wake_box.setChecked(False)
        elif event == 'state' and self.listening:
            self.status.emit('麦克风监听中' if value=='listening' else '本地转写中…')
            self.animation.emit('listening' if value=='listening' else 'thinking')
        elif event == 'text' and self.listening and not self.muted:
            self.transcript.setText('识别结果：'+value)
            if self.mode == 'wake':
                if self.detector.matches(value):
                    self.awaiting_command = True
                    self.animation.emit('awake')
                    self.wake_detected.emit()
            elif value:
                self.listening = False  # Capture already released; retain cached ASR model.
                self.text.emit(value)
        elif event == 'metric':
            log.info('Voice operation seconds=%s', data.get('seconds'))
        elif event == 'done':
            self.listening = False
            self.status.emit('麦克风已释放')
            if self.awaiting_command:
                self.awaiting_command = False
                self.speak('妈妈，我在！', follow=True)
            else:
                self._schedule()

    def listen(self, _checked=False, mode='manual'):
        if self.closing or self.muted or self.busy or self.listening or self.speaking or self.stopping:
            return
        self.retry.stop()
        self.mode = mode
        self.listening = True
        settings = dict(self.settings)
        settings['max_seconds'] = 7 if mode=='wake' else 20
        settings['wait_seconds'] = 5 if mode=='wake' else 8
        self.status.emit('正在打开麦克风…')
        self._command({'op':'listen', 'settings':settings})

    def _wake_listen(self):
        if self.wake:
            self.listen(mode='wake')

    def _follow_listen(self):
        self.listen(mode='command')

    def _schedule(self):
        if not (self.closing or self.busy or self.listening or self.speaking):
            self.animation.emit('idle')
            if self.wake and not self.muted:
                self.retry.start(700)  # Release mic during TTS and echo cooldown.

    def set_wake(self, enabled):
        self.wake = enabled
        if enabled:
            self._schedule()
        else:
            self.retry.stop()
            if self.mode=='wake':
                self.cancel_capture()

    def set_muted(self, muted):
        self.muted = muted
        if muted:
            self.retry.stop()
            self.follow.stop()
            self.cancel_capture()
            self.status.emit('麦克风已静音')
        else:
            self._schedule()

    def cancel_capture(self):
        self.listening = False
        self.awaiting_command = False
        if self.process.state() != QProcess.ProcessState.NotRunning:
            self.stopping = True
            self.process.kill()
        self.status.emit('已取消识别并请求释放麦克风')

    def set_busy(self, busy):
        self.busy = busy
        if busy:
            self.retry.stop()
            self.follow.stop()
            if self.listening:
                self.cancel_capture()
        else:
            self._schedule()

    def speak(self, text, follow=False):
        self.retry.stop()
        if self.listening:
            self.cancel_capture()
        self.stop_speech()
        self._after_speech = follow
        if not self.settings['tts'] or not self.tts or not self.voices.count():
            if follow:
                self.follow.start(700)
            else:
                self._schedule()
            return
        self.tts.setVolume(self.settings['volume']/100)
        self.tts.setRate(self.settings['rate']/100)
        self.speaking = True
        self.animation.emit('speaking')
        self.status.emit('本地语音播报中（麦克风暂停）')
        self.tts.say(text[:8000])

    def _tts_state(self, state):
        from PySide6.QtTextToSpeech import QTextToSpeech
        if state == QTextToSpeech.State.Ready and not self.voices.count():
            self._load_voices()
        if state in (QTextToSpeech.State.Ready, QTextToSpeech.State.Error) and self.speaking:
            self.speaking = False
            if getattr(self, '_after_speech', False):
                self._after_speech = False
                self.follow.start(700)
            else:
                self._schedule()

    def stop_speech(self):
        self.speaking = False
        self._after_speech = False
        self.follow.stop()
        if self.tts:
            self.tts.stop()

    def interrupt(self):
        self.retry.stop()
        self.cancel_capture()
        self.stop_speech()
        self.animation.emit('idle')
        self._schedule()

    def _process_error(self, error):
        if self.closing or self.stopping:
            return
        self.listening = False
        self.stopping = False
        self.pending_commands.clear()
        self.wake_box.setChecked(False)
        self.status.emit('语音子进程无法启动或意外终止，请检查 Python 和语音依赖。')

    def _process_finished(self, *_):
        self.stopping = False
        self.pending_commands.clear()
        if self.socket:
            self.socket.abort()
        unexpected = self.listening and not self.closing
        self.listening = False
        if unexpected:
            self.wake_box.setChecked(False)
            self.status.emit('语音进程意外退出，请检查依赖后手动重试。')
        elif not self.closing:
            self._schedule()

    def close(self):
        self.closing = True
        self.retry.stop()
        self.follow.stop()
        self.stop_speech()
        self.panel.close()
        self.server.close()
        if self.process.state() != QProcess.ProcessState.NotRunning:
            if self.socket and self.authenticated:
                self._write({'op':'quit'})
            self.process.terminate()
            if not self.process.waitForFinished(1000):
                self.process.kill()
                self.process.waitForFinished(1000)
