"""Isolated local microphone/ASR process. JSON protocol; no audio files or network.

RMS endpoint detection is energy based, not a neural VAD. Whisper is loaded from
an existing local directory only. CPU int8 is the default. Cached model is
released after 120 idle seconds. Parent can terminate this process on shutdown.
"""
import json
import sys
import threading
import queue
import time
import gc
import logging

commands = queue.Queue()
cancel = threading.Event()

def emit(**data):
    print(json.dumps(data, ensure_ascii=False), flush=True)

def reader():
    for line in sys.stdin:
        try:
            command = json.loads(line)
            if command.get('op') in ('cancel', 'quit'):
                cancel.set()
            commands.put(command)
        except ValueError:
            pass
    cancel.set()
    commands.put({'op':'quit'})

def capture(settings):
    import numpy as np
    import sounddevice as sd
    frames = []
    spoken = False
    quiet = 0
    started = time.monotonic()
    threshold = float(settings.get('threshold', .012))
    # PortAudio performs format conversion; 16 kHz mono is passed to Whisper.
    device = settings.get('device')
    with sd.InputStream(samplerate=16000, channels=1, dtype='float32',
                        device=device, blocksize=1600) as stream:
        emit(event='state', value='listening')
        while not cancel.is_set() and time.monotonic() - started < settings.get('max_seconds', 15):
            audio, overflow = stream.read(1600)
            if overflow:
                emit(event='warning', value='麦克风采集溢出，请减少后台负载。')
            rms = float(np.sqrt(np.mean(audio * audio)))
            if rms >= threshold:
                spoken = True
                quiet = 0
            else:
                quiet += 1
            frames.append(audio.copy())
            if not spoken and time.monotonic() - started >= settings.get('wait_seconds', 7):
                break
            if spoken and quiet >= 9:
                break
    if cancel.is_set() or not spoken:
        return None
    return np.concatenate(frames).flatten()

def main():
    # An authenticated loopback control channel also works in a windowed EXE,
    # where Python's standard streams may be None. Audio never leaves the child.
    import socket
    args = [a for a in sys.argv[1:] if a != '--voice-worker']
    if len(args) != 2:
        return 2
    connection = socket.create_connection(('127.0.0.1', int(args[0])), timeout=5)
    connection.settimeout(None)
    sys.stdin = connection.makefile('r', encoding='utf-8')
    sys.stdout = connection.makefile('w', encoding='utf-8')
    emit(token=args[1])
    logging.getLogger('faster_whisper').setLevel(logging.ERROR)
    threading.Thread(target=reader, daemon=True).start()
    model = None
    model_key = None
    gpu_failed_path = None
    while True:
        try:
            command = commands.get(timeout=120)
        except queue.Empty:
            model = None
            model_key = None
            gc.collect()
            continue
        op = command.get('op')
        if op == 'quit':
            break
        if op == 'cancel':
            continue
        if op == 'devices':
            try:
                import sounddevice as sd
                emit(event='devices', value=[{'id':i,'name':d['name']} for i,d in enumerate(sd.query_devices()) if d['max_input_channels'] > 0])
            except Exception:
                emit(event='error', value='无法枚举麦克风。请安装语音依赖并检查 Windows 麦克风权限。')
            continue
        if op != 'listen':
            continue
        cancel.clear()
        started = time.monotonic()
        try:
            settings = command['settings']
            from pathlib import Path
            path = Path(settings.get('model_path', ''))
            if not (path / 'model.bin').is_file():
                raise ValueError('请先选择已下载的本地 faster-whisper 模型目录（包含 model.bin）。')
            audio = capture(settings)
            if audio is not None and not cancel.is_set():
                emit(event='state', value='transcribing')
                from faster_whisper import WhisperModel
                resolved = str(path.resolve())
                compute = settings.get('compute', 'cpu')
                if gpu_failed_path == resolved:
                    compute = 'cpu'
                key = (resolved, compute)
                if model_key != key:
                    model = None
                    gc.collect()
                    try:
                        model = WhisperModel(key[0], device=key[1], compute_type='int8' if key[1]=='cpu' else 'float16', local_files_only=True, cpu_threads=4)
                        model_key = key
                    except RuntimeError:
                        if key[1] != 'cuda':
                            raise
                        model = WhisperModel(key[0], device='cpu', compute_type='int8', local_files_only=True, cpu_threads=4)
                        model_key = (key[0], 'cpu')
                        gpu_failed_path = key[0]
                        emit(event='warning', value='GPU 加载失败，已回退 CPU int8。')
                try:
                    segments, info = model.transcribe(audio, language='zh', beam_size=1, vad_filter=True, condition_on_previous_text=False)
                    text = ''.join(segment.text for segment in segments if not cancel.is_set()).strip()
                except RuntimeError:
                    if model_key[1] != 'cuda':
                        raise
                    model = None
                    gc.collect()
                    model = WhisperModel(key[0], device='cpu', compute_type='int8', local_files_only=True, cpu_threads=4)
                    model_key = (key[0], 'cpu')
                    gpu_failed_path = key[0]
                    emit(event='warning', value='GPU 推理失败，已回退 CPU int8。')
                    segments, info = model.transcribe(audio, language='zh', beam_size=1, vad_filter=True, condition_on_previous_text=False)
                    text = ''.join(segment.text for segment in segments if not cancel.is_set()).strip()
                if not cancel.is_set():
                    emit(event='text', value=text)
            emit(event='metric', seconds=round(time.monotonic()-started, 2))
        except ValueError as exc:
            emit(event='error', value=str(exc))
        except Exception:
            emit(event='error', value='本地语音失败。请检查语音依赖、模型目录、音频设备和 Windows 隐私权限；未上传录音。')
        finally:
            emit(event='done')

if __name__ == '__main__':
    main()
