"""Windowless source entry; catches dependency/import errors before Qt starts."""
import ctypes
import datetime
import os
from pathlib import Path
import sys
import traceback

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)
try:
    # pythonw has no standard streams. Third-party libraries may still use them.
    if sys.stdout is None:
        sys.stdout = open(os.devnull, 'w', encoding='utf-8')
    if sys.stderr is None:
        sys.stderr = open(os.devnull, 'w', encoding='utf-8')
    from qiaomi.app import main
    raise SystemExit(main())
except Exception as exc:
    folder = Path(os.environ.get('QIAOMI_DATA_DIR') or Path(os.environ.get('LOCALAPPDATA', str(ROOT))) / 'QIAOMI AI') / 'logs'
    try:
        folder.mkdir(parents=True, exist_ok=True)
        # Avoid exception text, which could contain private values.
        with (folder / 'startup.log').open('a', encoding='utf-8') as handle:
            frames = ' > '.join(f'{Path(f.filename).name}:{f.lineno}' for f in traceback.extract_tb(exc.__traceback__))
            handle.write(f'{datetime.datetime.now().isoformat()} {type(exc).__name__} {frames}\n')
    except OSError:
        pass
    ctypes.windll.user32.MessageBoxW(None, f'QIAOMI AI could not start ({type(exc).__name__}).\nUse start.bat to repair dependencies.\nLogs: {folder}', 'QIAOMI AI', 16)
    raise SystemExit(1)
