Option Explicit
Dim shell, fso, root, pythonw, entry
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
pythonw = fso.BuildPath(root, ".venv\Scripts\pythonw.exe")
entry = fso.BuildPath(root, "scripts\gui_entry.pyw")
If Not fso.FileExists(pythonw) Then
    MsgBox "First run: use start.bat to install the local Python environment. Then use start.vbs for a console-free launch.", 48, "QIAOMI AI"
    WScript.Quit 1
End If
shell.CurrentDirectory = root
shell.Run """" & pythonw & """ """ & entry & """", 0, False
