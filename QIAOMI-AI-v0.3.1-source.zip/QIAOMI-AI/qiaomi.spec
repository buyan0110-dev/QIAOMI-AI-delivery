# Build with PyInstaller on Windows; output is a complete, portable folder.
from pathlib import Path

from PyInstaller.utils.hooks import collect_submodules, collect_data_files

project = Path(SPECPATH)
analysis = Analysis(
    [str(project / "scripts" / "frozen_entry.py")],
    pathex=[str(project)],
    binaries=[],
    datas=[(str(project / "assets"), "assets")] + collect_data_files("faster_whisper"),
    hiddenimports=collect_submodules("qiaomi") + collect_submodules("faster_whisper") + ["sounddevice", "numpy", "scipy.signal", "PySide6.QtTextToSpeech"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["PySide6.QtWebEngineCore", "PySide6.QtWebEngineWidgets"],
    noarchive=False,
)
pyz = PYZ(analysis.pure)
exe = EXE(
    pyz,
    analysis.scripts,
    [],
    exclude_binaries=True,
    name="QIAOMI-AI",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
)
collection = COLLECT(
    exe,
    analysis.binaries,
    analysis.datas,
    strip=False,
    upx=False,
    name="QIAOMI-AI",
)
