"""QIAOMI AI — 敲咪桌面管家。"""
__version__ = "0.3.1"
