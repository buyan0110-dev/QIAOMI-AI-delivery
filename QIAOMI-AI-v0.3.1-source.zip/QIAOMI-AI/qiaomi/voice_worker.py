"""Local voice worker: shared manual/auto/test capture; cancellable IPC control."""
import gc
import json
import logging
from pathlib import Path
import queue
import sys
import threading
import time

from .voice_logging import configure_relay

commands = queue.Queue()
shutdown = threading.Event()
finished_ids = set()
cancelled_ids = set()
log = logging.getLogger('qiaomi.voice')
emit_lock = threading.Lock()

class RequestEvent:
    def __init__(self, request_id, ids):
        self.request_id, self.ids = request_id, ids
    def is_set(self):
        return shutdown.is_set() or self.request_id in self.ids


def emit(**data):
    with emit_lock:
        print(json.dumps(data, ensure_ascii=False, allow_nan=False), flush=True)


def reader():
    try:
        for line in sys.stdin:
            try:
                command = json.loads(line)
                if not isinstance(command, dict):
                    raise ValueError('invalid command shape')
                op, request_id = command.get('op'), command.get('request_id')
                if op=='finish':
                    finished_ids.add(request_id)
                elif op=='cancel':
                    cancelled_ids.add(request_id)
                elif op=='quit':
                    shutdown.set()
                    commands.put(command)
                else:
                    commands.put(command)
            except Exception:
                # Do not log the command payload (it contains authentication/data).
                log.exception('Invalid voice control message')
    except Exception:
        log.exception('Voice control reader failed')
    finally:
        shutdown.set()
        commands.put({'op':'quit'})


def validate_model(path):
    path = Path(path)
    required = ['model.bin', 'config.json', 'tokenizer.json']
    missing = [name for name in required if not (path/name).is_file() or (path/name).stat().st_size==0]
    if not any((path/name).is_file() and (path/name).stat().st_size>0 for name in ('vocabulary.json', 'vocabulary.txt')):
        missing.append('vocabulary.json 或 vocabulary.txt')
    if missing:
        raise ValueError('本地语音模型目录不完整，缺少：'+ '、'.join(missing)+'。请选择完整的 faster-whisper 模型目录。')
    return path.resolve()


class LocalTranscriber:
    def __init__(self):
        self.model = None
        self.key = None
        self.gpu_failed_path = None

    def unload(self):
        self.model = None
        self.key = None
        gc.collect()
        log.info('Idle ASR model unloaded')

    def transcribe(self, recording, settings, cancelled, notify):
        from .audio_capture import prepare_audio
        path = validate_model(settings.get('model_path', ''))
        audio, channel = prepare_audio(recording.audio, recording.samplerate)
        log.info('ASR prepared input_frames=%s rate=%s selected_channel=%s output_frames=%s output_rate=16000 dtype=float32',
                 recording.frames, recording.samplerate, channel, len(audio))
        notify(event='prepared', value={'selected_channel':channel,'asr_frames':len(audio),'asr_samplerate':16000})
        if cancelled.is_set():
            return None
        from faster_whisper import WhisperModel
        compute = settings.get('compute','cpu')
        if compute not in ('cpu','cuda'):
            raise ValueError('请选择 CPU int8 或 CUDA 模式。')
        if self.gpu_failed_path==str(path):
            compute='cpu'
        key=(str(path),compute)
        if self.key!=key:
            notify(event='state', value='loading')
            self.unload()
            started=time.monotonic()
            try:
                self.model=WhisperModel(str(path),device=compute,compute_type='int8' if compute=='cpu' else 'float16',local_files_only=True,cpu_threads=4)
                self.key=key
            except RuntimeError:
                log.exception('ASR model load failed device=%s', compute)
                if compute!='cuda':
                    raise
                self.model=WhisperModel(str(path),device='cpu',compute_type='int8',local_files_only=True,cpu_threads=4)
                self.key=(str(path),'cpu')
                self.gpu_failed_path=str(path)
                notify(event='warning',value='CUDA 模型加载失败，已回退 CPU int8。')
            log.info('ASR model loaded device=%s seconds=%.3f',self.key[1],time.monotonic()-started)
        if cancelled.is_set():
            return None
        notify(event='state',value='transcribing')
        started=time.monotonic()
        # Manual capture bypasses BOTH energy gating and Silero trimming.
        # Auto capture retains optional Silero VAD in addition to endpoint logic.
        kwargs=dict(language='zh',beam_size=1,vad_filter=settings.get('record_mode','manual')=='auto',condition_on_previous_text=False)
        try:
            segments, _ = self.model.transcribe(audio,**kwargs)
            parts=[]
            for segment in segments:
                if cancelled.is_set():
                    return None
                parts.append(segment.text)
            text=''.join(parts).strip()
        except RuntimeError:
            log.exception('ASR inference failed device=%s',self.key[1])
            if self.key[1]!='cuda':
                raise
            self.unload()
            self.model=WhisperModel(str(path),device='cpu',compute_type='int8',local_files_only=True,cpu_threads=4)
            self.key=(str(path),'cpu')
            self.gpu_failed_path=str(path)
            notify(event='warning',value='CUDA 推理失败，已回退 CPU int8。')
            segments,_=self.model.transcribe(audio,**kwargs)
            parts=[]
            for segment in segments:
                if cancelled.is_set():
                    return None
                parts.append(segment.text)
            text=''.join(parts).strip()
        log.info('ASR completed seconds=%.3f empty=%s',time.monotonic()-started,not bool(text))
        return text


def execute_listen(command, transcriber, notify):
    request_id=command.get('request_id')
    cancelled=RequestEvent(request_id,cancelled_ids)
    finished=RequestEvent(request_id,finished_ids)
    settings=command['settings']
    outcome='error'
    started=time.monotonic()
    stage='音频采集'
    try:
        from .audio_capture import record
        recording=record(settings,cancelled,finished,notify)
        if cancelled.is_set() or recording is None:
            outcome='cancelled'
            return
        if settings.get('record_mode')=='test':
            result=recording.diagnostics()
            # A diagnostic floor, not a VAD acceptance rule for manual ASR.
            result['has_audio']=recording.frames>0
            result['has_sound']=recording.rms>=.0001 and recording.peak>.0003
            notify(event='test_result',value=result)
            notify(event='state',value='tested')
            outcome='test_complete'
            return
        if settings.get('record_mode')=='auto' and not recording.speech:
            notify(event='state',value='timeout')
            notify(event='notice',value='自动监听超时：能量未达到语音阈值。请查看 RMS，或切换手动录音。')
            outcome='timeout'
            return
        if recording.reason=='limit':
            notify(event='state',value='timeout')
            notify(event='notice',value='已达到本次录音时长上限；麦克风已释放，正在识别已录制音频。')
        notify(event='state',value='stopping')
        stage='模型加载或语音转写'
        text=transcriber.transcribe(recording,settings,cancelled,notify)
        if cancelled.is_set() or text is None:
            outcome='cancelled'
            return
        if text:
            notify(event='text',value=text)
        else:
            notify(event='notice',value='未识别到有效语音。音频已采集，但模型未返回文字；请查看诊断与日志。')
        notify(event='state',value='completed')
        outcome='completed'
    except Exception as exc:
        log.exception('Voice operation failed stage=%s request=%s',stage,request_id)
        # These exceptions originate only from local capture/model operations,
        # never from the transcript, command dictionary, API key or token.
        message=f'{stage}失败：{type(exc).__name__}: {exc}'
        notify(event='error',value=message+'。详情见 voice.log。',fatal=type(exc).__name__=='DeviceReleaseError')
        notify(event='state',value='failed')
    finally:
        log.info('Voice request ended id=%s outcome=%s seconds=%.3f',request_id,outcome,time.monotonic()-started)
        notify(event='done',outcome=outcome)
        finished_ids.discard(request_id)
        cancelled_ids.discard(request_id)


def main():
    import socket
    args=[a for a in sys.argv[1:] if a!='--voice-worker']
    if len(args) not in (2,3):
        return 2
    if len(args)==3:
        folder=Path(args[2])
    else:
        from .config import data_dir
        folder=data_dir()
    global log
    connection=socket.create_connection(('127.0.0.1',int(args[0])),timeout=5)
    connection.settimeout(None)
    sys.stdin=connection.makefile('r',encoding='utf-8')
    sys.stdout=connection.makefile('w',encoding='utf-8')
    emit(token=args[1])
    log=configure_relay(emit)
    threading.Thread(target=reader,daemon=True).start()
    logging.getLogger('faster_whisper').setLevel(logging.ERROR)
    transcriber=LocalTranscriber()
    try:
        while not shutdown.is_set():
            try:
                command=commands.get(timeout=120)
            except queue.Empty:
                transcriber.unload()
                continue
            op=command.get('op')
            if op=='quit':
                break
            if op=='devices':
                try:
                    import sounddevice as sd
                    from .audio_capture import enumerate_inputs
                    devices=enumerate_inputs(sd)
                    log.info('Input enumeration completed count=%s',len(devices))
                    for device in devices:
                        log.info('Input device id=%s name=%s hostapi=%s default_rate=%s input_channels=%s',device['id'],device['name'],device['hostapi'],device['samplerate'],device['channels'])
                    emit(event='devices',value=devices)
                except Exception as exc:
                    log.exception('Input enumeration failed')
                    emit(event='error',value=f'枚举输入设备失败：{type(exc).__name__}: {exc}。详情见 voice.log。')
            elif op=='listen':
                rid=command.get('request_id')
                execute_listen(command,transcriber,lambda **data:emit(request_id=rid,**data))
            else:
                log.error('Unsupported voice command operation')
    finally:
        transcriber.unload()
        log.info('Voice worker stopped; microphone streams released')
        try:
            connection.close()
        except Exception:
            log.exception('Voice control socket close failed')

if __name__=='__main__':
    main()
