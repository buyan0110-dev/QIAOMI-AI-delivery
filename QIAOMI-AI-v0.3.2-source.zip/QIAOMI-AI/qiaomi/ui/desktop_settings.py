"""Optional desktop settings without changing the established chat layout."""
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QCheckBox,QPushButton,QHBoxLayout

class DesktopSettings(QDialog):
    game_changed=Signal(bool)
    autostart_changed=Signal(bool)
    choose_pet=Signal()
    reset_pet=Signal()
    def __init__(self):
        super().__init__()
        self.setWindowTitle('敲咪 · 桌面与启动设置')
        self.resize(560,330)
        layout=QVBoxLayout(self)
        intro=QLabel('关闭聊天窗口会保留小猫与托盘。完全退出请使用托盘“退出敲咪”。')
        intro.setWordWrap(True);layout.addWidget(intro)
        self.game=QCheckBox('游戏模式：隐藏小猫、静止动画、关闭自动唤醒并取消当前任务')
        self.game.toggled.connect(self.game_changed);layout.addWidget(self.game)
        game_tip=QLabel('手动聊天和语音仍可使用；不检测游戏进程，不安装全局钩子。退出游戏模式后，语音唤醒保持关闭。')
        game_tip.setWordWrap(True);layout.addWidget(game_tip)
        self.autostart=QCheckBox('登录 Windows 后自动启动敲咪（当前用户，无管理员权限）')
        self.autostart.toggled.connect(self.autostart_changed);layout.addWidget(self.autostart)
        self.status=QLabel('');self.status.setWordWrap(True);self.status.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.status)
        self.manifest=QLabel('内置小橘猫');self.manifest.setWordWrap(True);self.manifest.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.manifest)
        actions=QHBoxLayout()
        choose=QPushButton('选择本地宠物形象清单');choose.clicked.connect(self.choose_pet);actions.addWidget(choose)
        reset=QPushButton('使用内置小橘猫');reset.clicked.connect(self.reset_pet);actions.addWidget(reset)
        layout.addLayout(actions)
        self.note=QLabel('');self.note.setWordWrap(True);self.note.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.note)
