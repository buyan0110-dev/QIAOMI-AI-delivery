"""Transparent, interactive cat window and replaceable animation renderer.

The default cat is drawn entirely with Qt: no image downloads or microphone use.
Art can replace individual states through assets/cat/manifest.json.
"""
from __future__ import annotations

import json
from collections import OrderedDict
import logging
import math
from pathlib import Path

from PySide6.QtCore import (QElapsedTimer, QObject, QPoint, QPointF, QRect, QRectF,
                            Qt, QTimer, Signal, Slot)
from PySide6.QtGui import (QColor, QFont, QIcon, QImageReader, QLinearGradient,
                           QMouseEvent, QPainter, QPainterPath, QPen, QPixmap,
                           QRadialGradient)
from PySide6.QtWidgets import QApplication, QMenu, QPushButton, QWidget

LOG = logging.getLogger(__name__)
STATES = {
    "awake": "妈妈，我在！", "speaking": "正在说话", "error": "需要检查语音设置",
    "idle": "陪在你身边", "sleep": "呼噜…休息一下", "walk": "散步时间",
    "stretch": "伸个懒腰", "happy": "今天也很开心", "pet_head": "被摸头啦",
    "pet_belly": "只给你摸一下", "listening": "敲咪在听", "thinking": "认真思考中",
    "working": "正在处理任务",
}
STATE_NAMES = {
    "idle": "待机", "sleep": "睡觉", "walk": "行走", "stretch": "伸懒腰",
    "happy": "开心", "pet_head": "摸摸头", "pet_belly": "摸肚子",
    "listening": "聆听（动画）", "thinking": "思考", "working": "执行任务（动画）",
}


def clamp_window_position(window_rect: QRect, available_rects: list[QRect],
                          preferred_point: QPoint | None = None) -> QPoint:
    """Keep a window in a current work area, using Qt logical pixel coordinates.

    During dragging, the pointer chooses the destination monitor. Otherwise the
    monitor with the largest overlap wins; when entirely offscreen, choose the
    work area requiring the smallest move. This works with negative monitor
    coordinates and gaps without relying on an obsolete QWidget.screen().
    Areas smaller than the window anchor it at their top left.
    """
    areas = [area for area in available_rects if area.isValid() and not area.isEmpty()]
    if not areas:
        return window_rect.topLeft()

    def candidate(area: QRect) -> QPoint:
        return QPoint(
            min(max(window_rect.x(), area.left()),
                max(area.left(), area.right() - window_rect.width() + 1)),
            min(max(window_rect.y(), area.top()),
                max(area.top(), area.bottom() - window_rect.height() + 1)),
        )

    def distance(area: QRect) -> int:
        delta = candidate(area) - window_rect.topLeft()
        return delta.x() ** 2 + delta.y() ** 2

    if preferred_point is not None:
        preferred = [area for area in areas if area.contains(preferred_point)]
        if preferred:
            return candidate(min(preferred, key=distance))

    def rank(area: QRect) -> tuple[int, int]:
        intersection = area.intersected(window_rect)
        overlap = max(0, intersection.width()) * max(0, intersection.height())
        return (-overlap, distance(area))

    return candidate(min(areas, key=rank))


class SpriteLibrary:
    """Load bounded, local animation frames; bad art never prevents startup."""

    def __init__(self, manifest: Path | None = None, *, builtin=False):
        self.animations: dict[str, tuple[list[QPixmap], float]] = {}
        self.error: str | None = None
        if builtin:return
        explicit_manifest = manifest is not None
        if manifest is None:
            manifest = Path(__file__).resolve().parents[2] / "assets" / "cat" / "manifest.json"
        if not manifest.is_file():
            if explicit_manifest:
                self.error="宠物形象清单不存在，已使用内置猫咪。"
                LOG.warning("Custom pet manifest missing")
            return
        try:
            if manifest.stat().st_size > 128_000:
                raise ValueError("资源清单过大")
            data = json.loads(manifest.read_text(encoding="utf-8"))
            if type(data.get("version")) is not int or data["version"] != 1:
                raise ValueError("资源版本无效")
            states = data.get("states")
            if not isinstance(states, dict) or not states or any(s not in STATES for s in states):
                raise ValueError("动画状态无效")
            root = manifest.parent.resolve()
            staged = {}
            total_pixels = 0
            for state, animation in states.items():
                if not isinstance(animation, dict):
                    raise ValueError("动画格式无效")
                fps = animation.get("fps", 12)
                paths = animation.get("frames")
                if (type(fps) not in (float, int) or not 1 <= fps <= 24
                        or not isinstance(paths, list) or not 1 <= len(paths) <= 30):
                    raise ValueError("动画帧数或帧率无效")
                frames = []
                for name in paths:
                    if not isinstance(name, str):
                        raise ValueError("帧路径无效")
                    path = (root / name).resolve()
                    if (not path.is_relative_to(root) or path.suffix.lower() not in {".png", ".webp"}
                            or not path.is_file() or path.stat().st_size > 8_000_000):
                        raise ValueError("帧文件不合法")
                    reader = QImageReader(str(path))
                    size = reader.size()
                    if not size.isValid() or max(size.width(), size.height()) > 2048:
                        raise ValueError("帧尺寸无效")
                    total_pixels += size.width() * size.height()
                    if total_pixels > 16_000_000:
                        raise ValueError("动画资源超过内存限制")
                    frame = QPixmap.fromImage(reader.read())
                    if frame.isNull():
                        raise ValueError("无法读取动画帧")
                    frames.append(frame)
                staged[state] = (frames, float(fps))
            self.animations = staged
        except (OSError, ValueError, TypeError, AttributeError, RecursionError):
            self.error = "美术资源未能加载，已使用内置猫咪。"
            LOG.warning("Cat assets rejected; procedural renderer enabled")

    def frame(self, state: str, seconds: float) -> QPixmap | None:
        if state not in self.animations:
            return None
        frames, fps = self.animations[state]
        return frames[int(seconds * fps) % len(frames)]


def _path(points: list[tuple[float, float]]) -> QPainterPath:
    path = QPainterPath(QPointF(*points[0]))
    for x, y in points[1:]:
        path.lineTo(x, y)
    path.closeSubpath()
    return path


def _ellipse(p: QPainter, rect: tuple[float, float, float, float], color):
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(color)
    p.drawEllipse(QRectF(*rect))


def _line(p: QPainter, color: str, width: float, points: list[tuple[float, float]]):
    p.setPen(QPen(QColor(color), width, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                  Qt.PenJoinStyle.RoundJoin))
    p.setBrush(Qt.BrushStyle.NoBrush)
    path = QPainterPath(QPointF(*points[0]))
    if len(points) == 4:
        path.cubicTo(*points[1], *points[2], *points[3])
    else:
        for point in points[1:]:
            path.lineTo(*point)
    p.drawPath(path)


def draw_cat(p: QPainter, state: str = "idle", seconds: float = 0.0):
    """Draw into a 300×350 logical canvas. Shared by the window and tray icon."""
    wave = math.sin(seconds * 3.0)
    breathing = math.sin(seconds * 2.0)
    p.save()
    if state == "sleep":
        p.translate(0, 30)
        p.translate(150, 260)
        p.scale(1.07, .84 + breathing * .008)
        p.translate(-150, -260)
    elif state == "stretch":
        p.translate(150, 270)
        p.scale(1.04, 1.04 + .035 * wave)
        p.translate(-150, -270)
    elif state in {"happy", "pet_head"}:
        p.translate(0, -abs(wave) * 5)
    elif state == "walk":
        p.translate(wave * 8, -abs(wave) * 3)
    else:
        p.translate(0, breathing * 1.2)

    # Soft grounded shadow, fluffy curved tail, and warm rounded body.
    _ellipse(p, (61, 268, 186, 18), QColor(19, 26, 35, 32))
    tail = QPainterPath(QPointF(204, 249))
    tail.cubicTo(270, 264, 266 + wave * 4, 173, 244 + wave * 6, 176)
    p.setPen(QPen(QColor("#bb682b"), 46, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawPath(tail)
    p.setPen(QPen(QColor("#efa248"), 40, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
    p.drawPath(tail)
    _line(p, "#bc6d2f", 8, [(246, 219), (257, 219)])
    _line(p, "#bc6d2f", 8, [(247, 238), (257, 238)])
    _ellipse(p, (228 + wave * 6, 160, 32, 31), QColor("#ffe5b4"))

    body_gradient = QRadialGradient(QPointF(129, 194), 105)
    body_gradient.setColorAt(0, QColor("#ffca73"))
    body_gradient.setColorAt(.65, QColor("#f7ac4f"))
    body_gradient.setColorAt(1, QColor("#d78438"))
    _ellipse(p, (83, 167, 131, 109), body_gradient)
    _ellipse(p, (108, 188, 85, 81), QColor("#ffe4b8"))
    _ellipse(p, (123, 200, 56, 56), QColor("#ffebcc"))
    # Side tiger stripes.
    for left in (True, False):
        x = 91 if left else 204
        step = 12 if left else -12
        _line(p, "#bd702d", 5, [(x, 203), (x + step, 208)])
        _line(p, "#bd702d", 5, [(x - (3 if left else -3), 222), (x + step, 226)])
    # White mitten feet move independently during walking.
    left_y = 255 + (wave * 5 if state == "walk" else 0)
    right_y = 255 - (wave * 5 if state == "walk" else 0)
    for x, y in ((94, left_y), (163, right_y)):
        _ellipse(p, (x - 4, y - 12, 44, 33), QColor("#e3913b"))
        _ellipse(p, (x - 4, y, 46, 27), QColor("#fff1d9"))
        _line(p, "#e6d0ae", 1.5, [(x + 10, y + 15), (x + 10, y + 21)])
        _line(p, "#e6d0ae", 1.5, [(x + 23, y + 15), (x + 23, y + 22)])

    p.save()
    if state in {"pet_head", "listening", "thinking"}:
        p.translate(148, 153)
        p.rotate(5 * wave if state == "pet_head" else -6)
        p.translate(-148, -153)
    # Rounded pointed ears with peach inner fur.
    p.setPen(QPen(QColor("#c77935"), 3, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap,
                  Qt.PenJoinStyle.RoundJoin))
    p.setBrush(QColor("#ef9b44"))
    p.drawPath(_path([(91, 120), (84, 65), (124, 92)]))
    p.drawPath(_path([(173, 93), (211, 65), (208, 123)]))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#eaaa8a"))
    p.drawPath(_path([(96, 105), (94, 79), (114, 96)]))
    p.drawPath(_path([(184, 97), (202, 79), (201, 108)]))

    head_gradient = QRadialGradient(QPointF(127, 112), 95)
    head_gradient.setColorAt(0, QColor("#ffd88c"))
    head_gradient.setColorAt(.66, QColor("#f9b55a"))
    head_gradient.setColorAt(1, QColor("#e49844"))
    _ellipse(p, (75, 88, 148, 121), head_gradient)
    # Cheek tufts make the silhouette fluffy without heavy outlines.
    p.setBrush(QColor("#f0a651"))
    p.drawPath(_path([(79, 146), (67, 153), (77, 159), (65, 165), (80, 172), (86, 181)]))
    p.drawPath(_path([(218, 146), (230, 153), (220, 159), (232, 165), (217, 173), (212, 183)]))
    # Forehead tabby M and cheek stripes.
    _line(p, "#b87536", 5, [(127, 94), (133, 110), (147, 100), (159, 111)])
    _line(p, "#b87536", 5, [(166, 94), (161, 110)])
    _line(p, "#c17c38", 4, [(80, 135), (97, 141)])
    _line(p, "#c17c38", 4, [(79, 151), (94, 154)])
    _line(p, "#c17c38", 4, [(218, 135), (201, 141)])
    _line(p, "#c17c38", 4, [(220, 151), (204, 154)])

    # Plush cream muzzle and cheeks.
    _ellipse(p, (91, 160, 56, 34), QColor("#ffdfb1"))
    _ellipse(p, (150, 160, 56, 34), QColor("#ffdfb1"))
    _ellipse(p, (121, 158, 55, 36), QColor("#fff0d8"))
    _ellipse(p, (92, 157, 20, 10), QColor(229, 130, 112, 100))
    _ellipse(p, (184, 157, 20, 10), QColor(229, 130, 112, 100))
    blink = (seconds % 5.8) < .13
    closed = state in {"sleep", "happy", "pet_head", "pet_belly"} or blink
    for x in (112, 183):
        if closed:
            if state == "sleep":
                _line(p, "#604530", 3, [(x - 10, 149), (x - 4, 157), (x + 4, 157), (x + 10, 149)])
            else:
                _line(p, "#604530", 3, [(x - 10, 151), (x - 4, 140), (x + 4, 140), (x + 10, 151)])
        else:
            _ellipse(p, (x - 10, 132, 21, 28), QColor("#624a32"))
            _ellipse(p, (x - 6, 137, 13, 22), QColor("#333d34"))
            _ellipse(p, (x - 3, 148, 9, 8), QColor("#b5bb72"))
            _ellipse(p, (x - 5, 136, 7, 8), QColor("#fffcef"))
            _ellipse(p, (x + 3, 145, 3, 4), QColor("#ffffff"))

    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor("#bc7865"))
    nose = QPainterPath(QPointF(143, 164))
    nose.cubicTo(147, 161, 154, 162, 154, 165)
    nose.cubicTo(151, 173, 146, 172, 143, 164)
    p.drawPath(nose)
    _line(p, "#95684c", 1.7, [(149, 170), (149, 175)])
    _line(p, "#95684c", 1.7, [(136, 175), (140, 181), (145, 181), (149, 175)])
    _line(p, "#95684c", 1.7, [(149, 175), (153, 181), (158, 181), (162, 175)])
    for y in (167, 175):
        _line(p, "#a87d50", 1.2, [(94, y), (62, y - 5 if y == 167 else y + 4)])
        _line(p, "#a87d50", 1.2, [(205, y), (237, y - 5 if y == 167 else y + 4)])
    if state == "speaking":
        _ellipse(p, (141, 176, 15, 5 + 9 * abs(wave)), QColor("#95684c"))
    if state == "awake":
        _line(p, "#79c5d5", 3, [(83, 90), (80, 73)])
        _line(p, "#79c5d5", 3, [(216, 90), (220, 73)])
    if state == "error":
        _line(p, "#d47e65", 3, [(235, 105), (235, 125)])
        _ellipse(p, (233, 132, 4, 4), QColor("#d47e65"))
    # Small collar with a blue bell ties the cat to the assistant palette.
    _line(p, "#558c9b", 6, [(125, 201), (139, 207), (159, 207), (174, 201)])
    _ellipse(p, (143, 204, 13, 14), QColor("#79c5d5"))
    _ellipse(p, (147, 208, 4, 4), QColor("#defaff"))
    p.restore()

    if state == "pet_belly":
        # Raised white mittens, blushing and trusting.
        _ellipse(p, (96, 215 + wave * 2, 32, 26), QColor("#fff2db"))
        _ellipse(p, (173, 215 - wave * 2, 32, 26), QColor("#fff2db"))
    if state in {"happy", "pet_head", "pet_belly"}:
        p.setPen(QColor("#ed8b87"))
        p.setFont(QFont("Segoe UI", 19))
        p.drawText(QRectF(219, 92 - abs(wave) * 8, 35, 35), Qt.AlignmentFlag.AlignCenter, "♥")
    elif state == "sleep":
        p.setPen(QColor("#8da8bd"))
        p.setFont(QFont("Segoe UI", 17, QFont.Weight.Bold))
        p.drawText(QPointF(226, 104 - wave * 4), "z")
        p.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        p.drawText(QPointF(247, 82 - wave * 4), "z")
    elif state in {"thinking", "working", "listening"}:
        for i in range(3):
            alpha = int(125 + 110 * math.sin(seconds * 5 + i) ** 2)
            _ellipse(p, (220 + i * 11, 100 - 4 * math.sin(seconds * 4 + i), 6, 6),
                     QColor(107, 200, 229, alpha))
    p.restore()


def make_cat_icon() -> QIcon:
    pixmap = QPixmap(96, 96)
    pixmap.fill(Qt.GlobalColor.transparent)
    p = QPainter(pixmap)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.scale(.55, .55)
    p.translate(-62, -54)
    draw_cat(p, "idle", 1.0)
    p.end()
    return QIcon(pixmap)


class PetWindow(QWidget):
    voice_requested = Signal()
    open_assistant = Signal()
    request_hide = Signal()
    request_quit = Signal()
    position_changed = Signal(int, int)
    top_changed = Signal(bool)

    def __init__(self):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.Tool
                         | Qt.WindowType.WindowStaysOnTopHint)
        self.setWindowTitle("敲咪 · QIAOMI AI")
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.setFixedSize(300, 350)
        self.setWindowIcon(make_cat_icon())
        self.setMouseTracking(True)
        self.state = "idle"
        self._frame_cache=OrderedDict()
        self._cached_sprites=None
        self._cache_ratio=None
        self.low_power = False
        self._always_on_top = True
        self._busy = False
        self._pressed_at: QPoint | None = None
        self._drag_origin: QPoint | None = None
        self._dragged = False
        self._bubble = "你好呀，我是敲咪。\n摸摸我，或一起开始工作。"
        self.sprites = SpriteLibrary()
        self.elapsed = QElapsedTimer()
        self.elapsed.start()
        self._state_started = 0.0
        self.timer = QTimer(self)
        self.timer.setInterval(125)
        self.timer.timeout.connect(self.update)
        self.state_timer = QTimer(self)
        self.state_timer.setSingleShot(True)
        self.state_timer.timeout.connect(lambda: self.set_state("thinking" if self._busy else "idle"))
        self.bubble_timer = QTimer(self)
        self.bubble_timer.setSingleShot(True)
        self.bubble_timer.timeout.connect(self._clear_bubble)
        # Work-area notifications are event-driven, never polled per frame.
        # Coalesce display-change bursts until Qt has updated its screen list.
        self.screen_recovery_timer = QTimer(self)
        self.screen_recovery_timer.setSingleShot(True)
        self.screen_recovery_timer.setInterval(0)
        self.screen_recovery_timer.timeout.connect(self._recover_screens)
        self._application_screen_connections = []
        self._screen_connections = []
        self.enter_button = QPushButton("进入管家  ↗", self)
        self.enter_button.setGeometry(88, 317, 124, 30)
        self.enter_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.enter_button.setStyleSheet("""
            QPushButton {background: #172632; color: #d3ebf4; border: 1px solid #476172;
                border-radius: 15px; font: 12px 'Microsoft YaHei'; padding: 3px 13px;}
            QPushButton:hover {background: #254658; border-color: #7fbdcf;}
            QPushButton:pressed {background: #3c5c6e;}
        """)
        self.enter_button.clicked.connect(self.open_assistant.emit)
        self.setToolTip("拖动猫咪移动 · 摸头或肚子互动 · 右键打开菜单")
        screen = QApplication.primaryScreen()
        if screen:
            rect = screen.availableGeometry()
            self.move(rect.right() - self.width() - 35, rect.bottom() - self.height() - 35)

    def set_state(self, state: str, duration_ms: int = 0):
        if state not in STATES:
            raise ValueError(f"Unknown pet state: {state}")
        self.state_timer.stop()
        self.state = state
        self._state_started = self.elapsed.elapsed() / 1000
        self.timer.setInterval(250 if state == "sleep" else (125 if state=="idle" else 83))
        if self.low_power:self.timer.stop()
        if duration_ms > 0:
            self.state_timer.start(duration_ms)
        self.update()

    def set_low_power(self, enabled):
        self.low_power=bool(enabled)
        self._frame_cache.clear()
        if enabled:
            self.timer.stop()
            self.state_timer.stop()
            self.bubble_timer.stop()
            self._bubble=''
        elif self.isVisible():
            self.timer.start()
        self.update()

    def moveEvent(self, event):
        super().moveEvent(event)
        self.position_changed.emit(self.x(),self.y())

    def set_busy(self, busy: bool):
        self._busy = busy
        self.set_state("thinking" if busy else "idle")

    def set_always_on_top(self, enabled: bool):
        enabled = bool(enabled)
        if enabled == self._always_on_top:
            return
        visible = self.isVisible()
        self._always_on_top = enabled
        self.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, enabled)
        if visible:
            self.show()
        self.top_changed.emit(enabled)

    def show_bubble(self, text: str):
        self._bubble = str(text)[:100]
        self.bubble_timer.start(6000)
        self.update()

    def _clear_bubble(self):
        self._bubble = ""
        self.update()

    def showEvent(self, event):
        self._connect_screen_tracking()
        if not self.low_power:self.timer.start()
        self._keep_on_screen()
        super().showEvent(event)

    def hideEvent(self, event):
        self.timer.stop()
        self._disconnect_screen_tracking()
        self._pressed_at = None
        self._drag_origin = None
        self._dragged = False
        super().hideEvent(event)

    def _connect_screen_tracking(self):
        if self._application_screen_connections:
            return
        app = QApplication.instance()
        if app is None:
            return
        # QObject receiver slots are disconnected automatically on destruction.
        # Explicit hide cleanup also avoids keeping hidden windows subscribed.
        for signal in (app.screenAdded, app.screenRemoved, app.primaryScreenChanged):
            self._application_screen_connections.append(
                signal.connect(self._schedule_screen_recovery))
        self._refresh_screen_connections()

    def _refresh_screen_connections(self):
        for connection in self._screen_connections:
            QObject.disconnect(connection)
        self._screen_connections.clear()
        for screen in QApplication.screens():
            for signal in (screen.availableGeometryChanged, screen.geometryChanged):
                self._screen_connections.append(signal.connect(self._schedule_screen_recovery))

    def _disconnect_screen_tracking(self):
        self.screen_recovery_timer.stop()
        for connection in self._screen_connections + self._application_screen_connections:
            QObject.disconnect(connection)
        self._screen_connections.clear()
        self._application_screen_connections.clear()

    @Slot()
    def _schedule_screen_recovery(self):
        if self.isVisible():
            self.screen_recovery_timer.start()

    @Slot()
    def _recover_screens(self):
        if not self.isVisible():
            return
        self._refresh_screen_connections()
        # A display rearrangement invalidates the original global drag anchor.
        self._pressed_at = None
        self._drag_origin = None
        self._dragged = False
        self._keep_on_screen()

    def paintEvent(self, event):
        # Cache complete procedural frames (including stable text) on the GUI
        # thread. Cap pixel memory and adapt frame count for high-DPI displays.
        ratio=self.devicePixelRatioF()
        cost=max(1,round(self.width()*ratio)*round(self.height()*ratio)*4)
        max_entries=max(1,min(32,32_000_000//cost))
        frames=min(16 if self.state in ('idle','sleep') else 24,max_entries)
        period=2*math.pi/3
        animation=self.sprites.animations.get(self.state)
        if animation:
            period=len(animation[0])/animation[1]
            frames=min(len(animation[0]),max_entries)
        seconds=1.0 if self.low_power else self.elapsed.elapsed()/1000
        index=int((seconds%period)/period*frames)
        phase=index*period/frames
        if self._cached_sprites is not self.sprites or self._cache_ratio!=ratio:
            self._frame_cache.clear();self._cached_sprites=self.sprites;self._cache_ratio=ratio
        key=(self.state,index,self._bubble,ratio)
        frame=self._frame_cache.get(key)
        if frame is None:
            frame=QPixmap(round(self.width()*ratio),round(self.height()*ratio))
            frame.setDevicePixelRatio(ratio);frame.fill(Qt.GlobalColor.transparent)
            painter=QPainter(frame)
            self._paint_frame(painter,phase)
            self._frame_cache[key]=frame
            while len(self._frame_cache)>max_entries:self._frame_cache.popitem(last=False)
        else:self._frame_cache.move_to_end(key)
        painter=QPainter(self);painter.drawPixmap(0,0,frame);painter.end()

    def _paint_frame(self, p, seconds):
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        if self._bubble:
            p.setPen(QPen(QColor(123, 160, 177, 145), 1))
            p.setBrush(QColor(19, 35, 47, 238))
            p.drawRoundedRect(QRectF(27, 7, 246, 53), 15, 15)
            p.setPen(Qt.PenStyle.NoPen)
            p.drawPath(_path([(140, 59), (150, 68), (159, 59)]))
            p.setFont(QFont("Microsoft YaHei", 9))
            p.setPen(QColor("#e1edf0"))
            text = self._bubble
            if len(text) > 43:
                text = text[:42] + "…"
            p.drawText(QRectF(39, 14, 222, 39),
                       Qt.AlignmentFlag.AlignCenter | Qt.TextFlag.TextWordWrap, text)
        frame = self.sprites.frame(self.state, seconds)
        if frame:
            target = QRectF(25, 66, 250, 223)
            size = frame.size().scaled(target.size().toSize(), Qt.AspectRatioMode.KeepAspectRatio)
            destination = QRectF(150 - size.width() / 2, 286 - size.height(), size.width(), size.height())
            p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
            p.drawPixmap(destination, frame, QRectF(frame.rect()))
        else:
            draw_cat(p, self.state, seconds)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(21, 34, 44, 224))
        p.drawRoundedRect(QRectF(84, 290, 132, 21), 10, 10)
        _ellipse(p, (94, 298, 5, 5), QColor("#e0aa64" if self.state == "sleep" else "#84d8c4"))
        p.setFont(QFont("Microsoft YaHei", 8))
        p.setPen(QColor("#d4e0e7"))
        p.drawText(QRectF(104, 290, 104, 21), Qt.AlignmentFlag.AlignCenter, STATES[self.state])
        p.end()

    def mousePressEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed_at = event.globalPosition().toPoint()
            self._drag_origin = self.pos()
            self._dragged = False
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event: QMouseEvent):
        if self._pressed_at is not None and event.buttons() & Qt.MouseButton.LeftButton:
            delta = event.globalPosition().toPoint() - self._pressed_at
            if delta.manhattanLength() >= QApplication.startDragDistance():
                self._dragged = True
            if self._dragged and self._drag_origin is not None:
                self.move(self._drag_origin + delta)
                self._keep_on_screen(event.globalPosition().toPoint())
            event.accept()
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton and self._pressed_at is not None:
            if not self._dragged:
                point = event.position()
                if QRectF(67, 65, 167, 145).contains(point):
                    self.set_state("pet_head", 2800)
                    self.show_bubble("唔…手法还不错嘛。再摸一下也可以。")
                elif QRectF(81, 199, 135, 88).contains(point):
                    self.set_state("pet_belly", 2800)
                    self.show_bubble("肚皮可是特别通行证，只给你哦。")
            self._pressed_at = None
            self._drag_origin = None
            event.accept()
        else:
            super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QMouseEvent):
        if event.button() == Qt.MouseButton.LeftButton:
            self._pressed_at = None
            self.open_assistant.emit()
            event.accept()
        else:
            super().mouseDoubleClickEvent(event)

    def _keep_on_screen(self, preferred_point: QPoint | None = None):
        position = clamp_window_position(
            QRect(self.pos(), self.size()),
            [screen.availableGeometry() for screen in QApplication.screens()],
            preferred_point,
        )
        if self.pos() != position:
            self.move(position)

    def contextMenuEvent(self, event):
        menu = QMenu(self)
        menu.setStyleSheet("QMenu {background:#142430;color:#e3eef3;border:1px solid #3d596d;padding:5px;}"
                           "QMenu::item {padding:7px 25px 7px 12px;}"
                           "QMenu::item:selected {background:#2d4c61;border-radius:4px;}")
        menu.addAction("打开敲咪管家", self.open_assistant.emit)
        menu.addAction("语音设置 / 开始说话", self.voice_requested.emit)
        top = menu.addAction("始终置顶")
        top.setCheckable(True)
        top.setChecked(self._always_on_top)
        top.setEnabled(not self.low_power)
        top.toggled.connect(self.set_always_on_top)
        animations = menu.addMenu("和敲咪互动")
        for state, name in STATE_NAMES.items():
            action = animations.addAction(name)
            action.triggered.connect(lambda _checked=False, s=state: self.set_state(
                s, 0 if s in {"idle", "sleep"} else 4000))
        menu.addSeparator()
        menu.addAction("收起到托盘", self.request_hide.emit)
        menu.addAction("退出 QIAOMI AI", self.request_quit.emit)
        try:
            menu.exec(event.globalPos())
        finally:
            # A parented temporary menu otherwise survives every right click.
            menu.deleteLater()

    def closeEvent(self, event):
        event.ignore()
        self.request_hide.emit()
