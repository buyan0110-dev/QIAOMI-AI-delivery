"""Measure this app's actual idle CPU/RSS in isolated offline data (no models).

Run Windows without QT_QPA_PLATFORM=offscreen for a meaningful desktop sample.
Linux offscreen results are explicitly labelled, not Windows performance claims.
"""
import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import sys
import tempfile
import time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from qiaomi.app import Controller
from qiaomi.ui.theme import STYLE


def rss_bytes():
    if sys.platform.startswith('linux'):
        return int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    if sys.platform=='win32':
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_=[('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD)]+[(name,ctypes.c_size_t) for name in
                ('PeakWorkingSetSize','WorkingSetSize','QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage','QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]
        counters=Counters();counters.cb=ctypes.sizeof(counters)
        ctypes.windll.kernel32.GetCurrentProcess.restype=wintypes.HANDLE
        query=ctypes.windll.psapi.GetProcessMemoryInfo
        query.argtypes=[wintypes.HANDLE,ctypes.POINTER(Counters),wintypes.DWORD]
        if not query(ctypes.windll.kernel32.GetCurrentProcess(),ctypes.byref(counters),counters.cb):raise OSError('GetProcessMemoryInfo failed')
        return counters.WorkingSetSize
    return None


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--seconds',type=int,default=8)
    args=parser.parse_args()
    if not 2<=args.seconds<=60:parser.error('--seconds must be 2..60')
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);app.setStyleSheet(STYLE)
    simulated=sys.platform!='win32' and not QSystemTrayIcon.isSystemTrayAvailable()
    if simulated:QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
    report=dict(version='0.3.2',platform=platform.platform(),python=platform.python_version(),qt_platform=os.environ.get('QT_QPA_PLATFORM','native'),
        tray_simulated=simulated,provider='offline',models_loaded=False,gpu='not measured',metrics=[],
        limitations='Single process idle only; no ASR/LLM/game workload; offscreen software painting is not Windows desktop performance.')
    with tempfile.TemporaryDirectory(prefix='qiaomi-idle-') as temp:
        c=Controller(app,Path(temp),smoke=True)
        c.tray.showMessage=lambda *a:None
        phases=['pet_idle','game_mode','hidden_idle']
        started=[0.0,0.0]
        def begin():
            mode=phases[len(report['metrics'])]
            if mode=='pet_idle':c.show_pet()
            elif mode=='game_mode':c.set_game_mode(True)
            else:c.set_game_mode(False);c.hide_to_tray()
            started[:]=[time.perf_counter(),time.process_time()]
            QTimer.singleShot(args.seconds*1000,finish)
        def finish():
            elapsed=time.perf_counter()-started[0];cpu=time.process_time()-started[1]
            rss=rss_bytes()
            report['metrics'].append(dict(mode=phases[len(report['metrics'])],elapsed_seconds=round(elapsed,3),cpu_seconds=round(cpu,4),
                cpu_percent_of_one_core=round(100*cpu/elapsed,3),rss_mib=round(rss/1024**2,2) if rss is not None else None,
                pet_timer_active=c.pet.timer.isActive(),microphone_active=c.voice.listening,voice_worker_pid=c.voice.process.processId()))
            if len(report['metrics'])<len(phases):begin()
            else:
                args.output.parent.mkdir(parents=True,exist_ok=True)
                args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                c.request_quit()
        QTimer.singleShot(250,begin)
        result=app.exec();c.cleanup()
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return result
if __name__=='__main__':raise SystemExit(main())
