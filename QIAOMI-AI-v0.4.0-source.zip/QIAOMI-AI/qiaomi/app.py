"""Application orchestration and background AI requests."""
from __future__ import annotations
import argparse
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sys
import tempfile
import threading
import time
import traceback

from PySide6.QtCore import QObject, QLockFile, QThread, QTimer, Signal, Qt
from PySide6.QtGui import QAction, QFont
from PySide6.QtWidgets import QApplication, QMessageBox, QMenu, QSystemTrayIcon, QFileDialog

from .memory_intent import extract_memory, has_memory_intent
from .voice import VoiceService
from .ai import AIError, chat_reply
from .ollama import ollama_reply, check_ollama
from .config import Config, data_dir, load_config, save_config, validate_config
from .extensions import AutomationService
from .storage import Store, ValidationError
from .ui.assistant import AssistantWindow
from .ui.pet import PetWindow, make_cat_icon, SpriteLibrary
from .desktop import DesktopPreferences
from .windows import AutoStartManager, ExplorerRestartFilter
from .instance import InstanceGuard
from .ui.desktop_settings import DesktopSettings
from .ui.personality_settings import PersonalitySettings
from .personality import PersonalityPreferences, PersonalityEngine
from .personality_assets import LazySkin, load_custom_skin
from .ui.theme import STYLE

log = logging.getLogger('qiaomi')


def configure_logging(folder: Path):
    logs = folder / 'logs'
    logs.mkdir(parents=True, exist_ok=True)
    for old_handler in log.handlers[:]:
        log.removeHandler(old_handler)
        old_handler.close()
    handler = RotatingFileHandler(logs / 'qiaomi.log', maxBytes=512_000, backupCount=2, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(name)s %(message)s'))
    log.setLevel(logging.INFO)
    log.addHandler(handler)
    log.propagate = False
    # SDK/HTTP payloads and credentials must never enter application logs.
    for name in ('openai', 'httpx', 'httpcore'):
        logging.getLogger(name).setLevel(logging.CRITICAL)


class ChatWorker(QThread):
    chunk = Signal(str)
    reply = Signal(str)
    failure = Signal(str)

    def __init__(self, api_key, model, messages, memories, parent=None, *, provider="openai", probe=False):
        super().__init__(parent)
        self.provider = provider
        self.probe = probe
        self.api_key = api_key
        self.model = model
        self.messages = messages
        self.memories = memories
        self.cancel_event = threading.Event()

    def cancel(self):
        self.cancel_event.set()
        self.requestInterruption()

    def run(self):
        started = time.monotonic()
        try:
            if self.probe:
                answer = check_ollama(self.model, self.cancel_event)
            elif self.provider == 'ollama':
                answer = ollama_reply(self.model, self.messages, self.memories,
                                      self.cancel_event, self.chunk.emit)
            else:
                answer = chat_reply(self.api_key if self.provider == 'openai' else '', self.model,
                                    self.messages, self.memories, stop_event=self.cancel_event)
            if not self.cancel_event.is_set():
                self.reply.emit(answer)
        except AIError as exc:
            if not self.cancel_event.is_set():
                self.failure.emit(str(exc))
        except Exception as exc:
            log.error('Chat worker failed (%s)', type(exc).__name__)
            if not self.cancel_event.is_set():
                self.failure.emit('这次请求未完成，请检查设置后重试。')
        finally:
            log.info('AI task seconds=%.2f provider=%s probe=%s', time.monotonic()-started, self.provider, self.probe)
            self.api_key = ''
            self.messages = []
            self.memories = []


class MemoryWorker(QThread):
    proposal = Signal(object)
    failure = Signal(str)
    def __init__(self, model, text, parent=None):
        super().__init__(parent)
        self.model, self.text = model, text
        self.cancel_event = threading.Event()
    def cancel(self):
        self.cancel_event.set()
    def run(self):
        started = time.monotonic()
        try:
            result = extract_memory(self.model, self.text, self.cancel_event)
            if not self.cancel_event.is_set():
                self.proposal.emit(result)
        except Exception:
            if not self.cancel_event.is_set():
                self.failure.emit('记忆解析未完成；未保存任何内容。请重试或使用「记住：名称=内容」。')
        finally:
            log.info('Memory extraction seconds=%.2f', time.monotonic()-started)
            self.text = ''


class Controller(QObject):
    def __init__(self, app, folder: Path, *, smoke=False):
        super().__init__()
        self.app = app
        self.folder = folder
        self.config_path = folder / 'config.json'
        self.desktop=DesktopPreferences(folder)
        self.personality_preferences=PersonalityPreferences(folder)
        self.game_mode=self.personality_preferences.values['deep_sleep']
        self._game_pet_visible=True
        self.position_timer=QTimer(self)
        self.position_timer.setSingleShot(True)
        self.position_timer.timeout.connect(self.save_desktop)
        self.autostart=AutoStartManager(folder)
        self.config = load_config(self.config_path)
        if smoke:
            self.config.provider = 'offline'
        self.store = Store(folder / 'qiaomi.db')
        self.api_key = '' if smoke else os.environ.get('OPENAI_API_KEY', '').strip()
        self.worker = None
        self.pending_memory = None
        self.memory_timer = QTimer(self)
        self.memory_timer.setSingleShot(True)
        self.memory_timer.timeout.connect(self.reject_memory)
        self.shutting_down = False
        self.closed = False
        self.smoke_mode = smoke
        self.runtime_errors = []
        self._cancelled = False
        self._stream_text = ''
        self.automation = AutomationService()
        self.pending_demo = None
        self.pet = PetWindow(dormant=self.game_mode)
        self.pet.set_always_on_top(self.config.always_on_top and not self.game_mode)
        self.window = AssistantWindow(self.store, self.config, self.api_key)
        self.desktop_window=DesktopSettings()
        self.personality_window=PersonalitySettings()
        self.personality_window.edited.connect(self.apply_personality_settings)
        self.personality_window.wake_requested.connect(self.wake_qiaomi)
        self.personality_window.skip_requested.connect(lambda:self.personality.skip())
        self.desktop_window.wake_requested.connect(self.wake_qiaomi)
        self.desktop_window.personality_requested.connect(self.show_personality_settings)
        self.desktop_window.game_changed.connect(self.set_game_mode)
        self.desktop_window.autostart_changed.connect(self.set_autostart)
        self.desktop_window.choose_pet.connect(self.choose_pet_manifest)
        self.desktop_window.reset_pet.connect(self.reset_pet_manifest)
        self.window.desktop_requested.connect(self.show_desktop_settings)
        self.window.chat_closed.connect(self.chat_closed)
        self.voice = VoiceService(folder, self)
        self.voice.activity_started.connect(self.personality_task_started)
        self.voice.activity_finished.connect(self.personality_resume)
        if self.game_mode:self.voice.set_deep_sleep(True)
        self.voice.text.connect(self.send_voice)
        self.voice.cancel_requested.connect(self.cancel_chat)
        self.voice.status.connect(self.window.set_task)
        self.voice.animation.connect(self.pet.set_state)
        self.voice.wake_detected.connect(lambda: self.pet.show_bubble('妈妈，我在！'))
        self.window.voice_requested.connect(self.voice.show)
        self.window.listen_requested.connect(self.voice.listen)
        self.pet.voice_requested.connect(self.voice.show)
        self.window.memory_accept.connect(self.accept_memory)
        self.window.memory_reject.connect(self.reject_memory)
        icon = make_cat_icon()
        self.app.setWindowIcon(icon)
        self.window.setWindowIcon(icon)
        self.pet.setWindowIcon(icon)
        self.pet.open_assistant.connect(self.show_assistant)
        self.pet.request_hide.connect(self.hide_to_tray)
        self.pet.request_quit.connect(self.request_quit)
        self.pet.top_changed.connect(self.update_top)
        self.window.pet_requested.connect(self.show_pet)
        self.window.hide_requested.connect(self.hide_to_tray)
        self.window.quit_requested.connect(self.request_quit)
        self.window.send_requested.connect(self.send)
        self.window.clear_requested.connect(self.clear_chat)
        self.window.cancel_requested.connect(self.cancel_chat)
        self.window.settings_requested.connect(self.apply_settings)
        self.window.connection_requested.connect(self.check_connection)
        self.window.demo_requested.connect(self.propose_demo)
        self.window.demo_confirmed.connect(self.confirm_demo)
        self.window.demo_cancelled.connect(self.cancel_demo)
        self.tray = QSystemTrayIcon(icon, self)
        self.tray.setToolTip('QIAOMI AI · 敲咪')
        self.tray_menu = QMenu()
        self.tray_open=self.tray_menu.addAction('打开敲咪',self.show_assistant)
        self.tray_pet=self.tray_menu.addAction('显示 / 隐藏桌面小猫',self.toggle_pet)
        self.tray_menu.addAction('语音设置',self.voice.show)
        self.tray_game=self.tray_menu.addAction('游戏深度休眠')
        self.tray_game.setCheckable(True)
        self.tray_game.toggled.connect(self.set_game_mode)
        self.tray_wake=self.tray_menu.addAction('唤醒敲咪',self.wake_qiaomi)
        self.tray_menu.addAction('性格与形象',self.show_personality_settings)
        self.tray_autostart=self.tray_menu.addAction('开机自启动')
        self.tray_autostart.setCheckable(True)
        self.tray_autostart.toggled.connect(self.set_autostart)
        self.tray_menu.addAction('桌面与启动设置',self.show_desktop_settings)
        self.tray_menu.addAction('长期记忆',self.show_memories)
        self.tray_menu.addAction('收起到托盘',self.hide_to_tray)
        self.tray_menu.addSeparator()
        self.tray_menu.addAction('退出敲咪',self.request_quit)
        self.tray_menu.aboutToShow.connect(self.sync_desktop_controls)
        self.tray.setContextMenu(self.tray_menu)
        self.tray.activated.connect(self.tray_activated)
        self.tray_monitor=QTimer(self)
        self.tray_monitor.setInterval(10000)
        self.tray_monitor.timeout.connect(self.ensure_tray)
        self.tray_monitor.start()
        self.explorer_filter=ExplorerRestartFilter(self.restore_tray)
        self.app.installNativeEventFilter(self.explorer_filter)
        self.ensure_tray()
        self.sync_desktop_controls()
        self.refresh_chat()
        screen = self.app.primaryScreen()
        if screen:
            area = screen.availableGeometry()
            self.pet.move(area.right() - self.pet.width() - 32, area.bottom() - self.pet.height() - 16)
            # Respect smaller screens and DPI-scaled desktops on first launch.
            self.window.setMinimumSize(min(850, area.width()), min(650, area.height()))
            self.window.resize(min(1080, area.width() - 20), min(780, area.height() - 40))
            self.window.move(area.center() - self.window.rect().center())
        position=self.desktop.values['position']
        if position is not None:
            self.pet.move(position['x'],position['y'])
            self.pet._keep_on_screen()
        self.pet.position_changed.connect(self.pet_moved)
        self._asset_error=None
        manifest=self.desktop.values['pet_manifest']
        if not self.game_mode and manifest and not self.desktop.values['use_builtin_pet']:
            self.pet.sprites=load_custom_skin(manifest)
        if self.pet.sprites.error:self._asset_error=self.pet.sprites.error
        self.desktop_window.manifest.setText(manifest or '内置粉色睡衣敲咪')
        self.personality=PersonalityEngine(self.pet,self.personality_preferences,self.load_personality_skin,
            busy=lambda:self.worker is not None or self.voice.listening or self.voice.speaking or self.pending_memory is not None,parent=self)
        if self.personality.last_resource_message:self._asset_error=self.personality.last_resource_message
        self.personality.resource_notice.connect(self.personality_resource_notice)
        self.personality.changed.connect(lambda _:self.sync_personality_controls())
        self.sync_personality_controls()
        self.sync_deep_sleep_controls()
        self.app.aboutToQuit.connect(self.cleanup)
        if not smoke and (self._asset_error or self.desktop.read_error):
            QTimer.singleShot(0,self.report_desktop_error)
        # Do not load/probe AI models automatically on startup or at logon.
        self.window.set_task('准备就绪 · 可直接聊天或在设置中检测本机 Ollama')
        log.info('Application initialized')

    def error(self, message):
        self.window.set_task(message)
        if self.smoke_mode:
            self.runtime_errors.append('application_error')
        elif not self.game_mode:
            QMessageBox.warning(self.window if self.window.isVisible() else self.pet, '敲咪提示', message)

    def refresh_chat(self):
        self.window.render_messages(self.store.messages(limit=100))

    def show_assistant(self):
        if self.shutting_down:
            return
        self.window.showNormal()
        self.window.raise_()
        self.window.activateWindow()
        self.window.input.setFocus()
        if self.game_mode:self.window.set_task("深度休眠中：可查看界面，聊天与语音需先选择“唤醒敲咪”。")

    def show_pet(self):
        if self.game_mode:
            self.window.set_task("敲咪在深度休眠，请从托盘选择“唤醒敲咪”。");return
        if self.shutting_down:
            return
        self.window.hide()
        self.pet.show()
        self.pet.raise_()

    def show_memories(self):
        self.show_assistant()
        self.window.navigate(1)

    def hide_to_tray(self):
        if self.shutting_down:
            return
        if not QSystemTrayIcon.isSystemTrayAvailable():
            if self.game_mode:
                self.window.hide();self.pet.hide();return
            self.show_pet()
            self.pet.show_bubble('当前桌面没有系统托盘，敲咪留在这里陪你。')
            return
        self.tray.show()
        self.window.hide()
        self.pet.hide()
        if not self.game_mode:self.tray.showMessage('QIAOMI AI', '敲咪已收起。点击托盘图标即可回来。', QSystemTrayIcon.MessageIcon.Information, 2500)

    def tray_activated(self, reason):
        if reason in (QSystemTrayIcon.ActivationReason.Trigger, QSystemTrayIcon.ActivationReason.DoubleClick):
            self.show_assistant()

    def chat_closed(self):
        if self.shutting_down:return
        # Closing chat preserves the independently visible/hidden pet.
        self.window.hide()
        if not self.game_mode and not QSystemTrayIcon.isSystemTrayAvailable() and not self.pet.isVisible():
            self.show_pet()

    def toggle_pet(self):
        if self.game_mode:
            self.window.set_task("深度休眠不会被显示按钮解除，请选择“唤醒敲咪”。");return
        if self.shutting_down:return
        if self.pet.isVisible():
            if not self.game_mode and not QSystemTrayIcon.isSystemTrayAvailable() and not self.window.isVisible():
                self.window.set_task('当前没有系统托盘，保留桌面小猫作为入口。')
                return
            self.pet.hide()
        else:
            self.pet.show()
            if not self.game_mode:self.pet.raise_()
        self.sync_desktop_controls()

    def ensure_tray(self):
        if self.shutting_down:return
        if QSystemTrayIcon.isSystemTrayAvailable():
            if not self.tray.isVisible():self.tray.show()
        elif not self.game_mode and not self.pet.isVisible() and not self.window.isVisible():
            self.pet.show()  # Reachability fallback, static in game mode.

    def restore_tray(self):
        if self.shutting_down:return
        log.info('Restoring tray after Explorer restart')
        self.tray.hide()
        self.ensure_tray()

    def sync_desktop_controls(self):
        self.tray_pet.setText('隐藏桌面小猫' if self.pet.isVisible() else '显示桌面小猫')
        self.tray_pet.setEnabled(not self.game_mode)
        self.tray_wake.setEnabled(self.game_mode)
        self.desktop_window.wake.setEnabled(self.game_mode)
        for control in (self.tray_game,self.desktop_window.game):
            control.blockSignals(True);control.setChecked(self.game_mode);control.blockSignals(False)
        enabled=False
        note='Windows 当前用户登录启动；默认关闭。'
        if self.autostart.supported:
            try:
                enabled=self.autostart.enabled()
                if enabled and self.autostart.current_command()!=self.autostart.command():
                    note='自启动指向旧版或其他目录；取消后重新勾选可更新到当前 GUI 入口。'
            except Exception:
                log.exception('Autostart state read failed')
                note='无法读取 Windows 自启动设置，请检查当前用户权限。'
        else:note='当前不是 Windows；开机自启动设置不可用。'
        for control in (self.tray_autostart,self.desktop_window.autostart):
            control.blockSignals(True);control.setChecked(enabled);control.setEnabled(self.autostart.supported);control.blockSignals(False)
        self.desktop_window.status.setText(note)

    def show_desktop_settings(self):
        if self.shutting_down:return
        self.sync_desktop_controls()
        self.desktop_window.manifest.setText(self.desktop.values['pet_manifest'] or '内置小橘猫')
        self.desktop_window.showNormal();self.desktop_window.raise_();self.desktop_window.activateWindow()

    def set_autostart(self, enabled):
        if self.shutting_down:return
        try:
            self.autostart.set_enabled(enabled)
            self.desktop_window.note.setText('已启用当前用户登录自启动。' if enabled else '已移除敲咪的自启动条目。')
            log.info('User changed autostart enabled=%s',enabled)
        except Exception:
            log.exception('Autostart update failed')
            self.error('开机自启动设置失败，请检查 GUI 入口与当前用户注册表权限；未要求管理员权限。')
        self.sync_desktop_controls()

    def set_game_mode(self, enabled):
        if self.shutting_down:return
        if not enabled:
            # Unchecking a box or other legacy path must not implicitly wake.
            if self.game_mode:self.window.set_task('请明确点击“唤醒敲咪”退出深度休眠。')
            self.sync_desktop_controls();return
        if self.game_mode:return
        self.game_mode=True
        self._game_pet_visible=self.pet.isVisible()
        self.personality.enter_sleep()
        self.position_timer.stop()
        self.voice.set_deep_sleep(True)
        self.cancel_chat();self.reject_memory();self.cancel_demo()
        self.pet.blockSignals(True);self.pet.set_always_on_top(False);self.pet.blockSignals(False)
        self.window.hide();self.desktop_window.hide();self.personality_window.hide();self.voice.panel.hide()
        self.save_personality()
        self.sync_deep_sleep_controls();self.sync_desktop_controls()
        self.window.set_task('游戏深度休眠：只可通过“唤醒敲咪”恢复，不自动监听或推理。')
        log.info('Entered deep sleep; personality and animation timers stopped')

    def wake_qiaomi(self):
        if self.shutting_down or not self.game_mode:return False
        self.game_mode=False  # Must precede any skin initialization/decoding.
        self.personality_preferences.values['deep_sleep']=False
        self.voice.set_deep_sleep(False)
        self.pet.blockSignals(True);self.pet.set_always_on_top(self.config.always_on_top);self.pet.blockSignals(False)
        self.personality.wake()
        self.save_personality();self.sync_deep_sleep_controls();self.sync_desktop_controls()
        self.window.set_task('敲咪已手动唤醒；自动语音唤醒仍保持关闭。')
        log.info('Explicit user wake; finite reunion requested')
        return True

    def sync_deep_sleep_controls(self):
        self.window.input.setReadOnly(self.game_mode)
        self.window.send_button.setEnabled(not self.game_mode and self.worker is None)
        self.window.check_button.setEnabled(not self.game_mode and self.worker is None)

    def load_personality_skin(self):
        if self.game_mode:raise RuntimeError('Animation initialization forbidden during deep sleep')
        manifest=self.desktop.values['pet_manifest']
        if manifest and not self.desktop.values['use_builtin_pet']:
            return load_custom_skin(manifest)
        return LazySkin()

    def personality_task_started(self):
        if hasattr(self,'personality'):self.personality.interrupt_for_task()

    def personality_resume(self):
        if hasattr(self,'personality') and not self.game_mode:self.personality.schedule()

    def personality_resource_notice(self,message):
        self.window.set_task(message)
        if not self.game_mode:self.pet.show_bubble(message)
        self.sync_personality_controls()

    def sync_personality_controls(self):
        if not hasattr(self,'personality'):return
        missing=self.personality.missing_resources
        if self.game_mode:status='休眠中未加载动画；唤醒后再校验资源。'
        elif self.personality.last_resource_message:status=self.personality.last_resource_message
        elif missing:status='当前形象缺少重逢帧：'+', '.join(missing)
        else:
            roles=[s for s in ('working','game_preview') if s not in self.pet.sprites.animations]
            status=('重逢帧已提供；当前自定义形象缺少眼镜造型：'+', '.join(roles)) if roles else '已提供 8 组重逢帧及金丝眼镜工作/游戏造型；AI 初版素材，边缘与肢体仍待美术精修。'
        self.personality_window.load(self.personality_preferences.values,self.game_mode,self.personality.phase,status)

    def show_personality_settings(self):
        self.sync_personality_controls();self.personality_window.showNormal();self.personality_window.raise_()

    def save_personality(self):
        try:self.personality_preferences.save()
        except OSError:
            log.exception('Personality preferences write failed')
            self.window.set_task('性格设置保存失败，原记忆库未修改。')

    def apply_personality_settings(self):
        self.personality_preferences.values.update(self.personality_window.values())
        self.save_personality();self.personality.settings_changed();self.sync_personality_controls()

    def pet_moved(self, x, y):
        self.desktop.values['position']={'x':x,'y':y}
        self.position_timer.start(700)

    def save_desktop(self):
        self.position_timer.stop()
        try:self.desktop.save()
        except OSError:
            log.exception('Desktop preferences write failed')
            self.window.set_task('桌面位置/形象保存失败，请检查数据目录权限。')

    def choose_pet_manifest(self):
        if self.game_mode:
            self.desktop_window.note.setText("休眠中不初始化形象，请先点击“唤醒敲咪”。");return
        path,_=QFileDialog.getOpenFileName(self.desktop_window,'选择本地宠物形象清单','','JSON (*.json)')
        if not path:return
        sprites=load_custom_skin(path)
        if sprites.error:
            self.desktop_window.note.setText(sprites.error)
            return
        self.pet.install_skin(sprites)
        self.desktop.values['pet_manifest']=str(Path(path).resolve())
        self.desktop.values['use_builtin_pet']=False
        self.save_desktop();self.personality.refresh_skin();self.sync_personality_controls()
        self.desktop_window.manifest.setText(self.desktop.values['pet_manifest'])

    def reset_pet_manifest(self):
        if self.game_mode:
            self.desktop_window.note.setText("请先唤醒敲咪，再更换形象。");return
        self.desktop.values['pet_manifest']=''
        self.desktop.values['use_builtin_pet']=True
        self.save_desktop();self.personality.refresh_skin();self.sync_personality_controls()
        self.desktop_window.manifest.setText('内置粉色睡衣敲咪')

    def report_desktop_error(self):
        message=self._asset_error or '桌面设置无法读取，已使用默认位置；原文件保留。'
        self.window.set_task(message)
        if not self.game_mode:self.pet.show_bubble(message)

    def update_top(self, checked):
        if self.game_mode:
            self.pet.blockSignals(True);self.pet.set_always_on_top(False);self.pet.blockSignals(False)
            return
        self.apply_settings(self.api_key, self.config.model, self.config.share_memories, checked, announce=False)

    def apply_settings(self, api_key, model, share, top, *, announce=True):
        if self.shutting_down:
            return
        if self.worker is not None:
            self.window.set_task('请等待当前请求结束后再修改设置。')
            self.pet.set_always_on_top(self.config.always_on_top)
            return
        config = Config(model=model, always_on_top=top, share_memories=share,
                        provider=self.window.provider_input.currentData())
        try:
            config = validate_config(config)
            save_config(self.config_path, config)
        except ValueError as exc:
            self.error(str(exc))
            return
        except OSError:
            log.error('Preferences write failed')
            self.error('设置保存失败，请检查数据目录的写入权限。')
            return
        self.config = config
        self.api_key = api_key
        self.pet.set_always_on_top(top and not self.game_mode)
        self.window.top_box.setChecked(top)
        self.window.set_connected(bool(api_key))
        if announce:
            self.window.set_task('设置已应用')
            if self.config.provider == 'ollama':
                self.check_connection()

    def add_reply(self, content):
        self.store.add_message('assistant', content)
        self.refresh_chat()

    def send_voice(self, text):
        if self.config.provider == 'openai':
            self.window.set_task('语音输入仅允许本地模式。请切换到 Ollama 后再使用语音。')
            return
        self.send(text)

    def send(self, text):
        if self.game_mode:
            self.window.set_task("深度休眠中不会开始推理或写入记忆，请先选择“唤醒敲咪”。");return
        self.personality_task_started()
        if self.pending_memory is not None:
            confirmation = text.strip().rstrip('。！!')
            if confirmation in ('确认', '确认保存', '是', '是的', '保存', '好的', '可以'):
                self.accept_memory()
                return
            if confirmation in ('取消', '不要', '不保存', '拒绝', '否', '算了'):
                self.reject_memory()
                return
            self.window.set_task('请先确认或取消待保存的记忆，也可以说「确认保存」或「不保存」。')
            return
        if self.worker is not None or self.shutting_down:
            return
        text = text.strip()
        if not text:
            return
        if len(text) > 8000:
            self.error('单条消息请控制在 8000 字以内。')
            return
        if text in ('/宠物', '宠物模式', '切换宠物模式'):
            self.window.input.clear()
            self.show_pet()
            return
        if text in ('/管家', '管家模式', '切换管家模式'):
            self.window.input.clear()
            self.show_assistant()
            return
        if text in ('/记忆', '查看记忆'):
            self.window.input.clear()
            self.show_memories()
            return
        try:
            if text.startswith(('记住：', '记住:', '/记住 ')) and '=' in text:
                payload = text[4:] if text.startswith('/记住 ') else text[3:]
                if '=' not in payload:
                    self.error('请使用「记住：偏好名称=内容」，例如：记住：饮品=少糖拿铁。')
                    return
                key, value = (part.strip() for part in payload.split('=', 1))
                if not key or not value or len(key) > 120 or len(value) > 4000:
                    self.error('记忆名称需为 1–120 字，内容需为 1–4000 字。')
                    return
                if not self.voice.settings['memory_enabled']:
                    self.window.set_task('长期记忆功能已关闭。')
                    return
                self.propose_memory({'type':'用户指定', 'key':key, 'value':value})
                return
            if has_memory_intent(text):
                if not self.voice.settings['memory_enabled']:
                    self.window.set_task('长期记忆功能已关闭，未解析或保存。')
                    return
                self.window.input.clear()
                self._cancelled = False
                self.worker = MemoryWorker(self.config.model if self.config.provider=='ollama' else 'qwen3:8b', text, self)
                self.worker.proposal.connect(self.propose_memory)
                self.worker.failure.connect(self.on_failure)
                self.worker.finished.connect(self.worker_finished)
                self.window.set_busy(True)
                self.voice.set_busy(True)
                self.pet.set_busy(True)
                self.window.set_task('正在使用本机 Qwen3 解析待确认记忆…')
                self.worker.start()
                return
            self.store.add_message('user', text)
            self.window.input.clear()
            self.refresh_chat()
            if text in ('演示任务', '/演示'):
                self.propose_demo()
                return
            if text in ('睡觉', '/睡觉'):
                self.add_reply('那敲咪先眯一小会儿，叫我就来。')
                self.pet.set_state('sleep')
                self.show_pet()
                return
            messages = self.store.messages(limit=20)
            memories = self.store.list_memories() if self.config.share_memories and self.voice.settings['memory_enabled'] else []
        except Exception as exc:
            log.error('Local chat operation failed (%s)', type(exc).__name__)
            self.error('本地数据未能保存，请检查磁盘空间或数据目录权限。')
            return
        self._cancelled = False
        self._stream_text = ''
        self.worker = ChatWorker(self.api_key, self.config.model, messages, memories, self,
                                 provider=self.config.provider)
        self.worker.chunk.connect(self.on_chunk)
        self.worker.reply.connect(self.on_reply)
        self.worker.failure.connect(self.on_failure)
        self.worker.finished.connect(self.worker_finished)
        self.window.set_busy(True)
        self.window.set_task('正在准备本地回应…' if self.config.provider == 'offline' else '敲咪正在思考…（首次加载模型可能较慢）')
        self.pet.set_busy(True)
        self.voice.set_busy(True)
        self.worker.start()

    def propose_memory(self, proposal):
        if self.game_mode:return
        if self.shutting_down or self._cancelled or not self.voice.settings['memory_enabled']:
            return
        rows = self.store.list_memories()
        for row in rows:
            if row['key'].casefold() == proposal['key'].casefold() and row['value'].strip().casefold() == proposal['value'].strip().casefold():
                self.window.set_task('相同记忆已存在，无需重复保存。')
                return
        # AI only proposes; user sees the exact payload and any overwrite.
        self.pending_memory = dict(proposal)
        same = next((r for r in rows if r['key']==proposal['key']), None)
        warning = ('\n将替换同名旧内容：'+same['value']) if same else ''
        self.window.memory_text.setPlainText(
            f"妈妈，要把这件事保存到长期记忆吗？\n类型：{proposal['type']}\n名称：{proposal['key']}\n内容：{proposal['value']}"+warning+
            '\n请核对内容；可点击确认，或说「确认保存」/「不保存」。60 秒后自动取消。')
        self.window.memory_card.show()
        self.window.set_task('等待确认记忆；尚未写入数据库')
        self.pet.show_bubble('妈妈，要把这件事保存到长期记忆吗？')
        self.show_assistant()
        self.memory_timer.start(60000)
        self.voice.speak('妈妈，要把这件事保存到长期记忆吗？')

    def reject_memory(self):
        self.pending_memory = None
        self.memory_timer.stop()
        self.window.memory_card.hide()
        self.window.set_task('已取消保存；长期记忆未修改。')
        self.personality_resume()

    def accept_memory(self):
        if self.game_mode or self.pending_memory is None or self.shutting_down:
            return
        if not self.voice.settings['memory_enabled']:
            self.reject_memory()
            return
        proposal = self.pending_memory
        try:
            self.store.save_reviewed_memory(proposal['key'], proposal['value'], proposal['type'])
            self.window.memories.refresh()
        except Exception:
            self.error('记忆保存失败，请检查数据库权限。')
            return
        self.pending_memory = None
        self.memory_timer.stop()
        self.window.memory_card.hide()
        self.window.input.clear()
        self.add_reply('记住啦：'+proposal['key']+'。可以在长期记忆页面修改、删除或导出。')
        self.voice.speak('记住啦，妈妈！')
        self.window.set_task('已确认并保存到本机 SQLite')

    def check_connection(self):
        if self.game_mode:
            self.window.set_task("深度休眠中不会探测 AI，请先唤醒。");return
        if self.worker is not None or self.shutting_down:
            return
        self._cancelled = False
        self.worker = ChatWorker('', self.window.model_input.text().strip() if self.window.provider_input.currentData() == 'ollama' else 'qwen3:8b',
                                 [], [], self, probe=True)
        self.worker.reply.connect(self.on_connection)
        self.worker.failure.connect(self.on_connection)
        self.worker.finished.connect(self.worker_finished)
        self.window.set_busy(True)
        self.window.set_task('正在检测本机 Ollama 和模型…')
        self.worker.start()

    def on_connection(self, text):
        if self.game_mode or self.shutting_down or self._cancelled:
            return
        self.window.connection_status.setText(text)
        self.window.set_task(text)

    def on_chunk(self, text):
        if self.game_mode or self.shutting_down or self._cancelled:
            return
        self._stream_text += text
        self.window.render_messages([*self.store.messages(limit=100),
                                     {'role': 'assistant', 'content': self._stream_text}])
        self.window.set_task('敲咪正在回复…')

    def on_reply(self, text):
        if self.game_mode:return
        if self.shutting_down or self._cancelled:
            return
        try:
            self.add_reply(text)
            self.window.set_task('回复已保存到本机')
        except Exception as exc:
            log.error('Reply persistence failed (%s)', type(exc).__name__)
            self.error('回复未能保存，请检查本地数据目录。')
        self.pet.set_busy(False)
        self.voice.speak(text)

    def on_failure(self, message):
        if self.game_mode or self.shutting_down or self._cancelled:
            return
        self.window.set_task(message)
        self.pet.set_busy(False)
        # Persist a short, safe failure notice, never a raw SDK exception.
        try:
            self.add_reply('本次未获得 AI 回复：' + message)
        except Exception as exc:
            log.error('Error notice persistence failed (%s)', type(exc).__name__)

    def worker_finished(self):
        if self.worker is not None:
            self.worker.deleteLater()
            self.worker = None
        self._stream_text = ''
        if not self.closed:
            self.refresh_chat()
        self.window.set_busy(False)
        self.sync_deep_sleep_controls()
        if hasattr(self,"personality"):self.personality.schedule()
        self.voice.set_busy(False)
        self.pet.set_busy(False)
        if self._cancelled:
            self.window.set_task('请求已取消 · 原消息保留在记录中')
            self.pet.set_busy(False)
        if self.shutting_down:
            self.finish_quit()

    def cancel_chat(self):
        self.personality_task_started()
        self.voice.interrupt()
        if self.worker is not None:
            self._cancelled = True
            self.worker.cancel()
            self.window.stop_button.setEnabled(False)
            self.window.set_task('正在取消请求并关闭连接…')

    def ask(self, title, message):
        box = QMessageBox(self.window)
        box.setWindowTitle(title)
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(message)
        box.setIcon(QMessageBox.Icon.Question)
        box.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        box.setDefaultButton(QMessageBox.StandardButton.No)
        box.button(QMessageBox.StandardButton.Yes).setText('确认')
        box.button(QMessageBox.StandardButton.No).setText('取消')
        return box.exec() == QMessageBox.StandardButton.Yes

    def clear_chat(self):
        if self.worker is not None:
            return
        if self.ask('清空聊天记录', '将删除本机的全部聊天记录，长期记忆不会被删除。确认清空？'):
            try:
                self.store.clear_messages()
                self.cancel_demo()
                self.refresh_chat()
                self.window.set_task('聊天记录已清空')
            except Exception as exc:
                log.error('Chat clear failed (%s)', type(exc).__name__)
                self.error('聊天记录清空失败，请检查本地数据库。')

    def propose_demo(self):
        if self.game_mode:return
        if self.worker is not None or self.shutting_down:
            return
        self.pending_demo = self.automation.propose_demo()
        self.window.show_confirmation(self.pending_demo.description)
        self.window.set_task('等待你确认演示任务')
        self.pet.set_state('listening')

    def confirm_demo(self):
        if self.pending_demo is None or self.shutting_down:
            return
        try:
            result = self.automation.confirm(self.pending_demo.id)
            self.pending_demo = None
            self.window.confirm_card.hide()
            self.pet.set_state('working', 1800)
            self.window.set_task('演示已完成 · 未操作系统')
            self.add_reply(result)
        except ValueError as exc:
            self.cancel_demo()
            self.error(str(exc))
        except Exception as exc:
            log.error('Demo status persistence failed (%s)', type(exc).__name__)
            self.error('演示记录未能保存。没有执行系统操作。')

    def cancel_demo(self):
        if self.pending_demo is not None:
            self.automation.cancel(self.pending_demo.id)
            self.pending_demo = None
        self.window.confirm_card.hide()
        self.window.set_task('准备就绪')
        self.pet.set_state('idle')

    def request_quit(self):
        if self.shutting_down:
            return
        self.shutting_down = True
        self.position_timer.stop()
        self.save_desktop()
        self.tray_monitor.stop()
        self.desktop_window.close()
        self.personality_window.close()
        self.save_personality();self.personality.close()
        self.reject_memory()
        self.voice.close()
        self.cancel_demo()
        if self.worker is not None:
            self.cancel_chat()
            self.window.set_task('正在结束网络请求，随后退出…')
            self.tray.setToolTip('QIAOMI AI · 正在结束请求并退出')
            self.pet.show_bubble('正在收好东西，马上退出…')
            self.window.setEnabled(False)
        else:
            self.finish_quit()

    def finish_quit(self):
        self.tray.hide()
        self.window._allow_close = True
        self.window.close()
        self.pet.hide()
        self.cleanup()
        self.app.quit()

    def cleanup(self):
        if self.closed:
            return
        self.shutting_down = True
        self._cancelled = True
        self.position_timer.stop()
        self.save_desktop()
        self.tray_monitor.stop()
        self.app.removeNativeEventFilter(self.explorer_filter)
        self.desktop_window.close()
        self.personality_window.close()
        self.save_personality();self.personality.close()
        # Normal exit is scheduled only after the worker has finished.
        # OS/application quit may bypass the UI: retain the QThread until safe.
        if self.worker is not None and self.worker.isRunning():
            self.worker.cancel()
            self.worker.wait()
        self.voice.close()
        self.memory_timer.stop()
        self.tray.hide()
        self.api_key = ''
        self.window.key_input.clear()
        self.store.close()
        self.closed = True
        log.info('Application closed')


def main(argv=None):
    parser = argparse.ArgumentParser(description='QIAOMI AI — 敲咪桌面管家')
    parser.add_argument('--autostart', action='store_true', help='登录后静默显示桌宠与托盘')
    parser.add_argument('--data-dir', type=Path, help='明确指定持久用户数据目录（自启动使用）')
    parser.add_argument('--assistant', action='store_true', help='启动时打开管家界面')
    parser.add_argument('--smoke-test', action='store_true', help='使用隔离数据运行离线启动检查，自动退出')
    parser.add_argument('--smoke-report', type=Path, help='将启动自检结果写入 JSON（需 --smoke-test）')
    args = parser.parse_args(argv)
    if args.smoke_report and not args.smoke_test:
        parser.error('--smoke-report 需与 --smoke-test 一起使用')
    scratch = tempfile.TemporaryDirectory(prefix='qiaomi-smoke-') if args.smoke_test else None
    folder = Path(scratch.name) if scratch else (args.data_dir.expanduser().resolve() if args.data_dir else data_dir())
    app = QApplication.instance() or QApplication(sys.argv[:1])
    app.setApplicationName('QIAOMI AI')
    app.setOrganizationName('QIAOMI')
    app.setQuitOnLastWindowClosed(False)
    app.setFont(QFont('Microsoft YaHei UI', 10))
    app.setStyleSheet(STYLE)
    controller = None
    lock = None
    runner = None
    previous_exception_hook = sys.excepthook
    try:
        folder.mkdir(parents=True, exist_ok=True)
        configure_logging(folder)
        lock=InstanceGuard(folder,app)
        if not lock.acquire():
            if args.smoke_test:raise RuntimeError('smoke_lock')
            if lock.notify_existing(activate=not args.autostart):
                return 0
            QMessageBox.information(None,'QIAOMI AI','敲咪已运行，但当前实例暂未响应（也可能是旧版）。请使用现有托盘入口，或等待退出完成。')
            return 1
        controller = Controller(app, folder, smoke=args.smoke_test)
        lock.activated.connect(controller.show_assistant)
        if args.smoke_test:
            from .smoke import SmokeRunner
            runner = SmokeRunner(controller)
        def handle_exception(exc_type, exc_value, tb):
            frames = ' > '.join(f'{Path(f.filename).name}:{f.lineno}' for f in traceback.extract_tb(tb))
            log.error('Unhandled %s at %s', exc_type.__name__, frames)
            if runner is not None:
                controller.runtime_errors.append('unhandled_exception')
                runner.fail('unhandled_exception')
            else:
                controller.error('遇到一个错误，敲咪仍在运行。请查看本地错误日志；日志不包含聊天内容。')
        sys.excepthook = handle_exception
        controller.show_assistant() if args.assistant and not args.autostart else controller.show_pet()
        if runner is not None:
            QTimer.singleShot(100, runner.start)
        result = app.exec()
        controller.cleanup()
        if runner is not None:
            from .smoke import write_report
            report = runner.result()
            write_report(args.smoke_report, report)
            return 0 if result == 0 and report['passed'] else 1
        return result
    except Exception as exc:
        log.error('Startup failed (%s)', type(exc).__name__)
        if args.smoke_test:
            from .smoke import write_report
            try:
                write_report(args.smoke_report, {'passed': False, 'checks': {}, 'errors': ['startup: ' + type(exc).__name__]})
            except OSError:
                log.error('Smoke report write failed')
        else:
            message = str(exc) if isinstance(exc, ValidationError) else (
                '无法启动敲咪。请检查依赖安装和数据目录权限。错误类型：' + type(exc).__name__)
            QMessageBox.critical(None, 'QIAOMI AI 启动失败', message)
        return 1
    finally:
        sys.excepthook = previous_exception_hook
        if controller is not None:
            controller.cleanup()
        if lock is not None:
            lock.close()
        logging.shutdown()
        if scratch:
            scratch.cleanup()
