"""Finite, local affectionate behaviour. No focus, mouse input, AI or DB writes."""
import json
import logging
import os
from pathlib import Path
import random
import tempfile
import time
from PySide6.QtCore import QObject,QTimer,Signal
from .personality_constants import REUNION_STATES,REUNION_STAGES,CORE_LINE,REUNION_LINES,ATTENTION_STATES,ATTENTION_LINES,FREQUENCIES

log=logging.getLogger('qiaomi')

class PersonalityPreferences:
    DEFAULTS=dict(affection_enabled=True,reunion_enabled=True,bubbles_enabled=True,frequency='high',custom_seconds=180,appearance='companion',deep_sleep=False)
    def __init__(self,folder):
        self.path=Path(folder)/'personality.json';self.values=dict(self.DEFAULTS);self.read_error=False
        try:
            if self.path.stat().st_size>64*1024:raise ValueError('oversized personality config')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid personality config')
            merged=dict(self.DEFAULTS);merged.update(raw)
            for key in ('affection_enabled','reunion_enabled','bubbles_enabled','deep_sleep'):
                if type(merged[key]) is not bool:raise ValueError('invalid switch')
            if merged['frequency'] not in (*FREQUENCIES,'custom'):raise ValueError('invalid frequency')
            if type(merged['custom_seconds']) is not int or not 60<=merged['custom_seconds']<=1800:raise ValueError('invalid interval')
            if merged['appearance'] not in ('companion','work','gaming'):raise ValueError('invalid appearance')
            self.values=merged
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError,RecursionError):
            self.read_error=True;log.warning('Personality preferences invalid; safe defaults and original retained')

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.read_error and self.path.exists():
            import uuid
            self.path.with_name('personality.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.personality-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name);json.dump(self.values,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)


class PersonalityEngine(QObject):
    changed=Signal(str)
    resource_notice=Signal(str)
    def __init__(self,pet,preferences,load_skin,busy=lambda:False,parent=None,*,rng=None,timings=None):
        super().__init__(parent)
        self.pet=pet;self.preferences=preferences;self.load_skin=load_skin;self.busy=busy
        self.rng=rng or random.Random();self.timings=timings or {}
        self.phase='idle';self.dormant=preferences.values['deep_sleep'];self.closed=False
        self.stage_index=-1;self.reunion_count=0;self.last_bubble=-1e9;self.taps=[]
        self.next_action=QTimer(self);self.next_action.setSingleShot(True);self.next_action.timeout.connect(self._autonomous)
        self.phase_timer=QTimer(self);self.phase_timer.setSingleShot(True);self.phase_timer.timeout.connect(self._phase_finished)
        self.pet.interaction.connect(self.interact);self.pet.skip_requested.connect(self.skip)
        self.pet.visibility_changed.connect(self.visibility_changed)
        self.pet.personality_interactions=True
        self.pet.appearance=self.preferences.values['appearance']
        self.missing_resources=[]
        self.last_resource_message=''
        if self.dormant:self.enter_sleep()
        else:self.refresh_skin();self.schedule()

    def _duration(self,name,default):return int(self.timings.get(name,default))
    def _set_phase(self,phase):
        self.phase=phase;self.pet.personality_capture_clicks=phase in ('reunion','cuddle','pout','comfort')
        self.pet.skip_button.setVisible(not self.dormant and phase in ('reunion','cuddle','pout','comfort'))
        self.changed.emit(phase)

    def refresh_skin(self):
        if self.dormant or self.closed:return False
        self.last_resource_message=''
        skin=self.load_skin()
        if hasattr(skin,'on_error'):skin.on_error=self._skin_error
        self.pet.install_skin(skin)
        self.missing_resources=[s for s in REUNION_STATES if s not in skin.animations]
        if skin.error or self.missing_resources:
            message=skin.error or '当前形象缺少重逢资源：'+', '.join(self.missing_resources)
            self.last_resource_message=message
            self.resource_notice.emit(message)
            log.warning('Personality skin incomplete states=%s',','.join(self.missing_resources))
        return not self.missing_resources and not skin.error

    def _skin_error(self,message):
        if self.dormant or self.closed:return
        self.last_resource_message=message
        self.next_action.stop();self.phase_timer.stop();self._set_phase('idle')
        self.resource_notice.emit(message)

    def enter_sleep(self):
        self.dormant=True;self.preferences.values['deep_sleep']=True
        self.next_action.stop();self.phase_timer.stop();self.taps.clear()
        self._set_phase('dormant');self.pet.suspend_animations()

    def wake(self):
        if not self.dormant or self.closed:return False
        self.dormant=False;self.preferences.values['deep_sleep']=False
        self.pet.resume_animations();complete=self.refresh_skin()
        self.pet.show()  # WA_ShowWithoutActivating; never raise/activate/chat.
        if self.preferences.values['reunion_enabled'] and complete:
            self.reunion_count+=1;self.stage_index=-1;self._set_phase('reunion')
            if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(CORE_LINE)
            self._next_stage()
        else:
            self._normal()
        return True

    def _next_stage(self):
        if self.dormant or self.closed or self.phase!='reunion':return
        self.stage_index+=1
        if self.stage_index>=len(REUNION_STAGES):
            self._set_phase('cuddle');self.pet.play_clip('reunion_cuddle',0)
            self.phase_timer.start(self._duration('cuddle',15000));return
        state,ms=REUNION_STAGES[self.stage_index];ms=self._duration(state,ms)
        self.pet.play_clip(state,ms)
        if state=='reunion_hug' and self.preferences.values['bubbles_enabled']:
            self.pet.show_bubble(self.rng.choice(REUNION_LINES))
        self.phase_timer.start(ms)

    def _phase_finished(self):
        if self.dormant or self.closed:return
        if self.phase=='reunion':self._next_stage()
        elif self.phase=='cuddle':
            self._set_phase('pout');self.pet.play_clip('reunion_pout',self._duration('pout',5000))
            if self.preferences.values['bubbles_enabled']:self.pet.show_bubble('……敲咪还没有被哄好呢。')
            self.phase_timer.start(self._duration('pout',5000))
        elif self.phase in ('pout','comfort','action'):self._normal()

    def _normal(self):
        self.phase_timer.stop();self._set_phase('idle');self.pet.play_clip('idle',0);self.taps.clear();self.schedule()

    def skip(self):
        if self.dormant or self.closed:return
        self.pet.clear_bubble();self._normal()

    def interrupt_for_task(self):
        if self.dormant or self.closed:return
        self.next_action.stop();self.phase_timer.stop();self._set_phase('idle');self.pet.clear_bubble();self.pet.clip_duration=0

    def visibility_changed(self,visible):
        if self.dormant or self.closed:return
        if not visible:
            self.next_action.stop();self.phase_timer.stop();self._set_phase('idle');self.pet.clear_bubble();self.pet.play_clip('idle',0)
        else:self.schedule()

    def _eligible(self):
        return not (self.dormant or self.closed or self.busy()) and self.pet.isVisible() and self.phase=='idle' and self.preferences.values['affection_enabled'] and self.pet.appearance=='companion'

    def schedule(self):
        self.next_action.stop()
        if not self._eligible():return
        values=self.preferences.values
        seconds=values['custom_seconds'] if values['frequency']=='custom' else self.rng.randint(*FREQUENCIES[values['frequency']])
        self.next_action.start(seconds*1000)

    def _autonomous(self):
        if not self._eligible():
            if not self.dormant and not self.closed and self.pet.isVisible() and self.preferences.values['affection_enabled'] and self.pet.appearance=='companion':
                self.next_action.start(30000)
            return
        candidates=[state for state in ATTENTION_STATES if state in self.pet.sprites.animations]
        if not candidates:
            self.resource_notice.emit('当前自定义形象没有主动动作帧，已停止主动撒娇；不会只弹随机文字。');return
        state=self.rng.choice(candidates);self._set_phase('action');self.pet.play_clip(state,2400)
        if self.preferences.values['bubbles_enabled'] and time.monotonic()-self.last_bubble>=120:
            self.pet.show_bubble(ATTENTION_LINES[state]);self.last_bubble=time.monotonic()
        self.phase_timer.start(self._duration('action',2400))

    def interact(self,zone):
        if self.dormant or self.closed or self.busy():return
        self.next_action.stop();self.phase_timer.stop()
        now=time.monotonic();self.taps=[t for t in self.taps if now-t<1.2];self.taps.append(now)
        self._set_phase('comfort')
        if len(self.taps)>=3:
            state='reunion_happy';text='嘿嘿嘿！妈妈最喜欢敲咪啦！';duration=2200
        elif zone=='head':
            state='reunion_cuddle';text='呼噜噜……妈妈的手最舒服了。';duration=1800
        elif zone=='pad':
            state='pet_belly';text='呜……可以摸，但是要轻轻的！';duration=1700
        else:
            state='reunion_hug';text='妈妈，抱抱敲咪嘛。';duration=1800
        if state not in self.pet.sprites.animations:
            state='pet_head' if zone=='head' else 'pet_belly'
        self.pet.play_clip(state,duration)
        if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(text)
        self.phase_timer.start(self._duration('comfort',duration))

    def settings_changed(self):
        self.pet.appearance=self.preferences.values['appearance'];self.pet.invalidate_animation_cache()
        if not self.preferences.values['reunion_enabled'] and self.phase in ('reunion','cuddle','pout','comfort'):self.skip()
        if not self.preferences.values['affection_enabled'] and self.phase=='action':self.skip()
        self.schedule()

    def close(self):
        self.closed=True;self.next_action.stop();self.phase_timer.stop();self.phase='closed'
        self.pet.suspend_animations()
