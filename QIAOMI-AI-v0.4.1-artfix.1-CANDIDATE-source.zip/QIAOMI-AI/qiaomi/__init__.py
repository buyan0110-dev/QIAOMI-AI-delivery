"""QIAOMI AI — 敲咪桌面管家。"""
__version__ = "0.4.1"

# Additive completion build; published v0.4.0 baseline archive remains unchanged.
__build__ = "v0.4.1-artfix.1"
