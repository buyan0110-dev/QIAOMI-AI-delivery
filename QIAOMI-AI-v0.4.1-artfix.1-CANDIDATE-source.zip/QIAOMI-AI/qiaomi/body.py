"""Pose-aware normalized hit regions. Priority: ears, paws, tail, chin, head, belly."""
from PySide6.QtCore import QRectF
FRONT=[('ear_left',(.13,.04,.28,.23)),('ear_right',(.59,.04,.28,.23)),
 ('front_left',(.23,.57,.22,.20)),('front_right',(.62,.57,.22,.20)),
 ('hind_left',(.19,.79,.25,.20)),('hind_right',(.59,.79,.25,.20)),
 ('tail',(.015,.48,.22,.40)),('chin',(.39,.47,.29,.12)),('head',(.25,.23,.53,.29)),('belly',(.35,.60,.30,.22))]
PRONE=[('ear_left',(.10,.30,.24,.21)),('ear_right',(.38,.28,.22,.20)),('front_left',(.22,.67,.23,.19)),('front_right',(.44,.67,.22,.19)),('hind_left',(.69,.65,.20,.21)),('hind_right',(.79,.62,.17,.17)),('tail',(.64,.40,.32,.24)),('chin',(.28,.60,.28,.10)),('head',(.19,.43,.43,.21)),('belly',(.54,.63,.20,.17))]
BACK=[('ear_left',(.14,.06,.28,.24)),('ear_right',(.58,.06,.28,.24)),('tail',(.28,.59,.45,.33)),('head',(.26,.27,.48,.28)),('hind_left',(.20,.81,.21,.17)),('hind_right',(.63,.81,.21,.17))]

BODY_STATES={'touch_ear_left':'左耳抖抖','touch_ear_right':'右耳抖抖','touch_ear_tuck':'痒得缩脖子','touch_ear_droop':'垂耳小猫',
 'touch_head':'呼噜噜蹭脑袋','touch_chin':'抬下巴眯眼','touch_belly':'露出小肚皮','touch_belly_cover':'捂住小肚皮',
 'touch_front_left':'左前爪握手','touch_front_right':'右前爪握手','touch_hind_left':'左后脚缩缩','touch_hind_right':'右后脚缩缩','touch_tail':'回头甩尾巴'}
BODY_PARTS={'ear_left','ear_right','head','chin','belly','front_left','front_right','hind_left','hind_right','tail'}

# Repaired sprite-local profiles: silhouette metadata maps them to the atlas.
HUG=[('ear_left',(.13,.02,.28,.24)),('ear_right',(.58,.02,.28,.24)),
 ('front_left',(.28,.50,.22,.20)),('front_right',(.53,.50,.22,.20)),
 ('tail',(.29,.53,.42,.45)),('chin',(.34,.41,.35,.11)),('head',(.24,.20,.53,.28)),
 ('hind_left',(.09,.76,.22,.22)),('hind_right',(.72,.76,.21,.22))]
TOP=[('front_left',(.18,0,.24,.16)),('front_right',(.57,0,.24,.16)),
 ('ear_left',(.16,.13,.28,.22)),('ear_right',(.56,.13,.28,.22)),
 ('chin',(.37,.47,.29,.10)),('head',(.25,.28,.52,.23)),('belly',(.34,.57,.34,.23)),
 ('hind_left',(.24,.76,.23,.21)),('hind_right',(.52,.76,.23,.21)),('tail',(.07,.69,.22,.29))]
BOTTOM=[('ear_left',(.16,.02,.28,.27)),('ear_right',(.51,.02,.27,.27)),
 ('front_left',(.24,.68,.22,.26)),('front_right',(.51,.68,.22,.26)),
 ('tail',(.0,.15,.20,.56)),('chin',(.32,.58,.37,.14)),('head',(.24,.26,.52,.38)),('belly',(.15,.64,.15,.20))]
CLING_LEFT=[('ear_left',(.18,.02,.26,.24)),('ear_right',(.54,.02,.27,.24)),
 ('front_left',(.03,.49,.24,.16)),('front_right',(.03,.65,.24,.16)),
 ('tail',(.67,.79,.22,.17)),('chin',(.24,.48,.39,.12)),('head',(.20,.23,.52,.28)),
 ('belly',(.29,.63,.29,.25)),('hind_left',(.32,.85,.21,.14)),('hind_right',(.54,.85,.21,.14))]
CLING_RIGHT=[('ear_left',(.17,.02,.26,.24)),('ear_right',(.56,.02,.27,.24)),
 ('front_left',(.76,.49,.23,.16)),('front_right',(.76,.65,.23,.16)),
 ('tail',(.01,.68,.22,.29)),('chin',(.35,.48,.39,.12)),('head',(.29,.23,.52,.28)),
 ('belly',(.42,.63,.29,.25)),('hind_left',(.39,.85,.21,.14)),('hind_right',(.62,.85,.21,.14))]


def regions(state,frame_index=0):
    if state=='edge_top':return TOP
    if state=='edge_bottom':return BOTTOM
    if state=='edge_left':return CLING_LEFT
    if state=='edge_right':return CLING_RIGHT
    if state=='angry_tail' or state in ('touch_tail','reunion_cuddle') and frame_index>=2:return HUG
    if state in ('daily_sleep','daily_prone','sleep','daily_stretch'):return PRONE
    if state=='angry_back':return BACK
    return FRONT

def hit_region(state,point,frame_index=0):
    for name,box in regions(state,frame_index):
        if QRectF(*box).contains(point):return name
    return None
