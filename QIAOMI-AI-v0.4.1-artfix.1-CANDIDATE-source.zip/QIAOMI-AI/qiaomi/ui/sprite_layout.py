"""Contact anchors in the repaired full silhouettes, not painted screen props.
Qt clips only at the actual viewport/work-area edge. Coordinates are logical.
"""
from PySide6.QtCore import QRectF
import math
EDGE_CONTACTS={'edge_top':(.5,.06),'edge_bottom':(.5,.78),'edge_left':(.16,.5),'edge_right':(.84,.5)}

def sprite_destination(state,viewport_width=300,viewport_height=350,contact=None,frame_width=256,frame_height=256):
    if state not in EDGE_CONTACTS:
        scale=min(250/frame_width,223/frame_height);w=frame_width*scale;h=frame_height*scale
        return QRectF(viewport_width/2-w/2,286-h,w,h)
    x,y=EDGE_CONTACTS[state]
    if isinstance(contact,(list,tuple)) and len(contact)==2 and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for v in contact):x,y=contact
    size=256
    if state=='edge_top':return QRectF((viewport_width-size)/2,-y*size,size,size)
    if state=='edge_bottom':return QRectF((viewport_width-size)/2,viewport_height-y*size,size,size)
    if state=='edge_left':return QRectF(-x*size,85,size,size)
    return QRectF(viewport_width-x*size,85,size,size)
