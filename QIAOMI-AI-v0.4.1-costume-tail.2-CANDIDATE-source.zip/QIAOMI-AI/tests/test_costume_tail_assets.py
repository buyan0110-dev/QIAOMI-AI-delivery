"""Resource integrity guards. These do not certify semantic anatomy."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_export_inventory_covers_all_existing_animation_files():
    rows=json.loads((ROOT/'docs/validation/costume-tail-export.json').read_text())
    names={p.name for p in (ROOT/'assets/personality').glob('*.webp')}
    assert len(rows)==len(names)==252
    assert {r['frame'] for r in rows}==names
    for row in rows:
        assert hashlib.sha256((ROOT/'assets/personality'/row['frame']).read_bytes()).hexdigest()==row['sha256']

def test_asset_audit_has_no_basic_decode_alpha_dimension_or_path_error():
    report=json.loads((ROOT/'docs/validation/costume-tail-alpha-audit.json').read_text())
    assert report['files_checked']==252
    assert report['basic_errors']==[]
    assert report['limitations']

def test_preserved_runtime_hashes_include_interaction_voice_and_storage():
    rows=json.loads((ROOT/'docs/costume-tail/runtime-preservation.json').read_text())
    assert 'qiaomi/personality.py' in rows and 'qiaomi/voice.py' in rows
    # Rendering and pose hit geometry are the explicit scope of refinement2.
    changes=json.loads((ROOT/'docs/refinement2/rendering-changes.json').read_text())
    assert {x['path'] for x in changes}=={'qiaomi/ui/pet.py','qiaomi/ui/sprite_layout.py','qiaomi/body.py','qiaomi/personality_assets.py'}
    for row in changes:assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['after_sha256']
    for name,digest in rows.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest

def test_candidate_is_not_mislabeled_as_windows_accepted():
    m=json.loads((ROOT/'assets/personality/manifest.json').read_text())
    assert m['costume_tail_repair']['status']=='candidate_partial_not_windows_accepted'
    assert m['states']['touch_tail']['frames']==[f'touch_tail-{i}.webp' for i in [0,1,2,3,2,1,0]]
