"""Persistent global Qt appearance, independent from the pet animation engine."""
import json
import logging
from pathlib import Path
import re
from PySide6.QtCore import QObject,Signal,QEvent,Qt
from PySide6.QtGui import QFont,QIcon
from PySide6.QtWidgets import QApplication,QDialog,QMessageBox,QFileDialog,QScrollArea,QWidget,QVBoxLayout,QFormLayout
from .personality import PersonalityPreferences
from .ui.theme import STYLE

PALETTES={
 'dark':dict(bg='#0b111c',panel='#121e2d',text='#dce7f5',muted='#a8b9ce',accent='#6ddcfa',user='#203b54',cat='#172735',border='#33475d'),
 'light':dict(bg='#faf7f3',panel='#ffffff',text='#30333b',muted='#626671',accent='#93465f',user='#fce7ed',cat='#ffffff',border='#d9cfd3'),
}
SCALES=(100,110,125,150)

class AppearancePreferences(PersonalityPreferences):
    DEFAULTS=dict(theme='dark',scale=100,welcome=True)
    def __init__(self,folder):
        # Separate file: no rewrite of config/voice/desktop/personality.
        self.path=Path(folder)/'appearance.json';self.values=dict(self.DEFAULTS);self.read_error=False
        try:
            if self.path.stat().st_size>65536:raise ValueError('oversized appearance')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid appearance')
            self.values.update(raw)
            if self.values['theme'] not in PALETTES or type(self.values['scale']) is not int or self.values['scale'] not in SCALES or type(self.values['welcome']) is not bool:raise ValueError('invalid appearance values')
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError):self.read_error=True;self.values=dict(self.DEFAULTS);logging.getLogger('qiaomi').warning('Appearance config invalid; original retained')
    def save(self):
        if self.read_error and self.path.exists():
            import uuid
            self.path.with_name('appearance.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        super().save()


def stylesheet(theme,scale):
    s=STYLE
    if theme=='light':
        colors={'#dce7f5':'#30333b','#0b111c':'#faf7f3','rgba(11,17,28,246)':'#faf7f3','#27384c':'#ddd3d8','#101a28':'#f5e8ec','#121e2d':'#ffffff','#25374b':'#ddd3d8','#6ddcfa':'#93465f','#f0f6ff':'#30333b','#91a4bb':'#626671','#77e7cb':'#347566','#1b2a3d':'#f4edf0','#2a4059':'#d4c8ce','#253d55':'#eadce3','#5085a7':'#a8788e','#102537':'#e9d2de','#617184':'#8b8690','#142030':'#eee9eb','#243247':'#dbd4d8','#071722':'#ffffff','#9ae8fe':'#b46c89','#6b889b':'#85747e','#284d60':'#e0cad4','#1a3449':'#ead4df','#81e1ff':'#68344c','#ffadad':'#a63242','#0d1724':'#ffffff','#293c51':'#d9cfd3','#285b7b':'#e8c3d2','#69cce8':'#ae667f','#101c2a':'#ffffff','#132132':'#faf2f5','#25374a':'#e4dbe0','#244965':'#ead4df','#1b2b3d':'#f3e5eb','#a8bdd3':'#59525a','#31485f':'#b99cab','#122031':'#fffafa','#314b66':'#d8c6d0','#27465f':'#ecd8e1','#e3eef9':'#30333b','#1b2d42':'#fffafa','#35526b':'#b99cab'}
        for a,b in colors.items():s=s.replace(a,b)
    # Explicit logical pixel sizes, Qt applies monitor DPI only once.
    s=re.sub(r'font-size:\s*(\d+)px',lambda m:'font-size: '+str(round(max(13,int(m[1]) if int(m[1])>13 else 16)*scale/100))+'px',s)
    s+='\nQWidget {background-color: '+PALETTES[theme]['bg']+';}\n'
    s+='QWidget#desktopPet {background:transparent;} QLabel { background: transparent; } QSpinBox,QDoubleSpinBox,QListView,QComboBox QAbstractItemView { background:'+PALETTES[theme]['panel']+'; color:'+PALETTES[theme]['text']+'; }'
    s+='QProgressBar {border:1px solid '+PALETTES[theme]['border']+';background:'+PALETTES[theme]['panel']+';text-align:center;} QProgressBar::chunk {background:'+PALETTES[theme]['accent']+';}'
    return s

class AppearanceManager(QObject):
    changed=Signal()
    def __init__(self,app,folder,icon,parent=None):
        super().__init__(parent);self.app=app;self.preferences=AppearancePreferences(folder);self.icon=icon
        app.setAttribute(Qt.ApplicationAttribute.AA_DontUseNativeDialogs,True)
        app.installEventFilter(self);self.apply(save=False)
    @property
    def values(self):return self.preferences.values
    def apply(self,*,save=True):
        v=self.values;style=stylesheet(v['theme'],v['scale'])
        signature=str(v['theme'])+':'+str(v['scale'])
        if self.app.styleSheet()!=style or self.app.property('qiaomiAppearance')!=signature:
            self.app.setStyleSheet(style)
            font=QFont('Microsoft YaHei UI');font.setPixelSize(round(16*v['scale']/100));self.app.setFont(font)
            self.app.setProperty('qiaomiAppearance',signature)
        self.app.setWindowIcon(self.icon)
        if save:self.preferences.save()
        self.changed.emit()
    def eventFilter(self,obj,event):
        if event.type()==QEvent.Type.Show and isinstance(obj,QWidget) and obj.isWindow():
            obj.setWindowIcon(self.icon)
            if isinstance(obj,QDialog) and not isinstance(obj,(QMessageBox,QFileDialog)) and not obj.findChildren(QScrollArea) and obj.layout() and not obj.property('appearanceScroll'):
                old=obj.layout();body=QWidget();body.setLayout(old);outer=QVBoxLayout(obj);scroll=QScrollArea();scroll.setWidgetResizable(True);scroll.setWidget(body);outer.addWidget(scroll);obj.setProperty('appearanceScroll',True)
            for form in obj.findChildren(QFormLayout):form.setRowWrapPolicy(QFormLayout.RowWrapPolicy.WrapLongRows)
        return False
    def close(self):self.app.removeEventFilter(self)
