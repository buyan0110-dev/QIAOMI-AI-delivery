"""Pose-aware normalized hit regions. Priority: ears, paws, tail, chin, head, belly."""
from PySide6.QtCore import QRectF
FRONT=[('ear_left',(.13,.04,.28,.23)),('ear_right',(.59,.04,.28,.23)),
 ('front_left',(.23,.57,.22,.20)),('front_right',(.62,.57,.22,.20)),
 ('hind_left',(.19,.79,.25,.20)),('hind_right',(.59,.79,.25,.20)),
 ('tail',(.015,.48,.22,.40)),('chin',(.39,.47,.29,.12)),('head',(.25,.23,.53,.29)),('belly',(.35,.60,.30,.22))]
PRONE=[('ear_left',(.10,.30,.24,.21)),('ear_right',(.38,.28,.22,.20)),('front_left',(.22,.67,.23,.19)),('front_right',(.44,.67,.22,.19)),('hind_left',(.69,.65,.20,.21)),('hind_right',(.79,.62,.17,.17)),('tail',(.64,.40,.32,.24)),('chin',(.28,.60,.28,.10)),('head',(.19,.43,.43,.21)),('belly',(.54,.63,.20,.17))]
BACK=[('ear_left',(.14,.06,.28,.24)),('ear_right',(.58,.06,.28,.24)),('tail',(.28,.59,.45,.33)),('head',(.26,.27,.48,.28)),('hind_left',(.20,.81,.21,.17)),('hind_right',(.63,.81,.21,.17))]

def regions(state):
    if state in ('daily_sleep','daily_prone','sleep','daily_stretch'):return PRONE
    if state=='angry_back':return BACK
    profile=FRONT
    if state in ('edge_right','exit_right'):return [(name,(1-x-w,y,w,h)) for name,(x,y,w,h) in profile]
    if state=='edge_top':
        return [(name,(x,y*.68+.27,w,h*.68)) for name,(x,y,w,h) in profile]
    return profile

def hit_region(state,point):
    for name,box in regions(state):
        if QRectF(*box).contains(point):return name
    return None

BODY_STATES={'touch_ear_left':'左耳抖抖','touch_ear_right':'右耳抖抖','touch_ear_tuck':'痒得缩脖子','touch_ear_droop':'垂耳小猫',
 'touch_head':'呼噜噜蹭脑袋','touch_chin':'抬下巴眯眼','touch_belly':'露出小肚皮','touch_belly_cover':'捂住小肚皮',
 'touch_front_left':'左前爪握手','touch_front_right':'右前爪握手','touch_hind_left':'左后脚缩缩','touch_hind_right':'右后脚缩缩','touch_tail':'回头甩尾巴'}
BODY_PARTS={'ear_left','ear_right','head','chin','belly','front_left','front_right','hind_left','hind_right','tail'}
