"""Lazy, bounded image frames. Deep sleep holds no decoded animation frames."""
from collections import OrderedDict
import json
import logging
from pathlib import Path
from PySide6.QtGui import QImageReader,QPixmap

log=logging.getLogger('qiaomi')

class LazySkin:
    def __init__(self, manifest=None):
        self.root=Path(manifest).resolve().parent if manifest else Path(__file__).resolve().parents[1]/'assets'/'personality'
        path=Path(manifest) if manifest else self.root/'manifest.json'
        self.animations={};self.entries={};self.error=None
        self.cache=OrderedDict();self.cached_bytes=0;self.max_bytes=12_000_000
        self.frame_reads=0;self.failed_paths=set();self.on_error=None
        try:
            if path.stat().st_size>128_000:raise ValueError('形象清单过大')
            raw=json.loads(path.read_text(encoding='utf-8'))
            if raw.get('version')!=2 or not isinstance(raw.get('states'),dict):raise ValueError('形象清单版本或格式错误')
            if not 1<=len(raw['states'])<=128:raise ValueError('形象状态数量错误')
            unique=set()
            for state,entry in raw['states'].items():
                if not isinstance(state,str) or not isinstance(entry,dict):raise ValueError('形象状态格式错误')
                fps=entry.get('fps');frames=entry.get('frames')
                if type(fps) not in (int,float) or not 1<=fps<=24 or not isinstance(frames,list) or not 1<=len(frames)<=30:
                    raise ValueError('形象帧数/帧率错误')
                paths=[]
                for name in frames:
                    if not isinstance(name,str):raise ValueError('帧路径无效')
                    frame=(self.root/name).resolve()
                    if not frame.is_relative_to(self.root) or frame.suffix.lower() not in ('.png','.webp') or not frame.is_file() or frame.stat().st_size>8_000_000:
                        raise ValueError('形象帧不存在或路径无效')
                    paths.append(frame);unique.add(frame)
                self.animations[state]=(paths,float(fps))
                self.entries[state]=dict(entry)
            if len(unique)>384:raise ValueError('形象帧数量超过限制')
        except (OSError,ValueError,TypeError,AttributeError,RecursionError):
            log.exception('Personality skin metadata rejected')
            self.error='性格动画资源缺失或格式错误；已保留兼容形象，详情见日志。'
            self.animations={};self.entries={}

    def missing(self,names):return [name for name in names if name not in self.animations]

    def frame(self,state,seconds):
        if state not in self.animations:return None
        paths,fps=self.animations[state]
        index=max(0,int(seconds*fps))
        if self.entries[state].get('loop',True):index%=len(paths)
        else:index=min(index,len(paths)-1)
        path=paths[index]
        if path in self.failed_paths:return None
        if path in self.cache:
            self.cache.move_to_end(path);return self.cache[path]
        try:
            reader=QImageReader(str(path));size=reader.size()
            if not size.isValid() or max(size.width(),size.height())>2048:raise ValueError('形象帧尺寸无效')
            pixmap=QPixmap.fromImage(reader.read())
            if pixmap.isNull():raise ValueError('形象帧解码失败')
            cost=pixmap.width()*pixmap.height()*4
            if cost>self.max_bytes:raise ValueError('形象帧超过缓存预算')
            while self.cache and self.cached_bytes+cost>self.max_bytes:
                _,old=self.cache.popitem(last=False);self.cached_bytes-=old.width()*old.height()*4
            self.cache[path]=pixmap;self.cached_bytes+=cost;self.frame_reads+=1
            return pixmap
        except Exception:
            log.exception('Personality frame decode failed state=%s',state)
            self.failed_paths.add(path)
            self.error='性格动画帧解码失败，已使用兼容绘制。'
            if callable(self.on_error):self.on_error(self.error)
            return None

    def release(self):
        self.cache.clear();self.cached_bytes=0


def load_custom_skin(path):
    path=Path(path)
    try:
        if path.stat().st_size>128_000:raise ValueError('manifest too large')
        raw=json.loads(path.read_text(encoding='utf-8'))
        if isinstance(raw,dict) and raw.get('version')==2:return LazySkin(path)
    except (OSError,ValueError,TypeError):
        pass  # Legacy loader reports a visible failure, never invokes code.
    from .ui.pet import SpriteLibrary
    return SpriteLibrary(path)
