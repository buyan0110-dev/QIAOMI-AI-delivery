"""Monotonic-clock and real Qt tests. Hardware/Windows artwork QA separate."""
import json
import os
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6.QtCore import QPoint,Qt
from PySide6.QtTest import QTest
from qiaomi.lifestyle import InteractionClock,TOUCH_GAP
from qiaomi.personality import PersonalityEngine,PersonalityPreferences
from qiaomi.personality_assets import LazySkin
from qiaomi.personality_constants import DAILY_STATES,MOOD_STATES,DREAM_LINES,SOOTHE_STEPS
from qiaomi.ui.pet import PetWindow
from test_desktop_lifecycle import app,controller,until

class Clock:
    def __init__(self):self.value=0.0
    def __call__(self):return self.value
    def advance(self,seconds):self.value+=seconds

@pytest.fixture
def life_engine(app,tmp_path):
    clock=Clock();p=PetWindow();p.show()
    e=PersonalityEngine(p,PersonalityPreferences(tmp_path),LazySkin,now=clock,timings={'welcome':10,'daily':10,'nap':30000,'startle':5,'doze_again':5,'soothing':10,'neglect':10})
    yield e,clock
    e.close();p.deleteLater();app.processEvents()

@pytest.mark.parametrize('seconds,stage',[(0,0),(599.99,0),(600,1),(1199.99,1),(1200,2),(1799.99,2),(1800,3),(7200,3)])
def test_real_thresholds_no_polling(seconds,stage):
    now=Clock();life=InteractionClock({},now);now.advance(seconds)
    assert life.evaluate()==stage
    assert life.sulking==(stage==3)


def test_game_pauses_both_elapsed_and_progress():
    now=Clock();life=InteractionClock({},now);now.advance(1200);life.pause();now.advance(36000)
    assert life.elapsed==1200 and life.stage==2
    life.resume();now.advance(600);assert life.evaluate()==3
    assert life.touch()==1;life.pause();now.advance(36000);assert life.touch() is None
    life.resume();assert life.soothe_count==1


def test_four_touches_not_triple_burst():
    now=Clock();life=InteractionClock({},now);now.advance(1800);life.evaluate()
    assert life.touch()==1
    for _ in range(8):now.advance(.03);assert life.touch() is None
    assert life.soothe_count==1 and life.sulking
    for expected in (2,3,4):
        now.advance(TOUCH_GAP+.01);assert life.touch()==expected
        assert life.sulking==(expected!=4)
    assert life.soothe_count==0 and life.stage==0


def test_chat_resets_clock_without_forgiveness():
    now=Clock();life=InteractionClock({},now);now.advance(1800);life.evaluate();life.interaction()
    assert life.elapsed==0 and life.sulking


def test_resume_preserves_runtime_no_offline_wall_time():
    now=Clock();life=InteractionClock({},now);now.advance(1800);life.evaluate();life.touch()
    snapshot=life.snapshot();now.advance(99999)
    resumed=InteractionClock(snapshot,now)
    assert resumed.elapsed==0 and resumed.sulking and resumed.soothe_count==1


def test_threshold_poses_and_no_action_resets_clock(life_engine):
    e,now=life_engine;now.advance(600);e._neglect_due()
    assert e.pet.state=='attention_search' and e.life.elapsed==600
    until(lambda:e.phase=='idle');now.advance(600);e._neglect_due()
    assert e.pet.state=='reunion_pout'
    until(lambda:e.phase=='idle');now.advance(600);e._neglect_due()
    assert e.phase=='angry' and e.life.sulking
    poses=[]
    for _ in range(4):e._sulk_pose();poses.append(e.pet.state)
    assert set(poses)=={'reunion_pout','angry_back','angry_tail','angry_peek'}


def test_engine_four_separate_steps_and_skip_does_not_forgive(life_engine):
    e,now=life_engine;now.advance(1800);e._neglect_due()
    for expected in range(1,5):
        e.interact('head');assert e.pet.state==SOOTHE_STEPS[expected][0]
        if expected<4:
            assert e.life.sulking and e.life.soothe_count==expected
            e.interact('pad');assert e.life.soothe_count==expected
            e.skip();assert e.life.sulking
        now.advance(.7)
    QTest.qWait(30);assert not e.life.sulking and e.phase=='idle'


def test_invalid_zone_busy_and_drag_do_not_count_as_four_touches(life_engine):
    e,now=life_engine;now.advance(1800);e._neglect_due()
    e.interact('unknown');e.busy=lambda:True;e.interact('head')
    assert e.life.soothe_count==1  # v0.4.1: valid mouse input wins over busy visuals
    e.busy=lambda:False;e._drag_started()
    assert e.life.soothe_count==1 and e.life.sulking


def test_real_mouse_releases_count_once_and_blank_does_not(life_engine):
    e,now=life_engine;now.advance(1800);e._neglect_due();p=e.pet
    QTest.mouseClick(p,Qt.MouseButton.LeftButton,pos=QPoint(10,10));assert e.life.soothe_count==0
    for count in (1,2,3):
        QTest.mouseClick(p,Qt.MouseButton.LeftButton,pos=QPoint(148,130))
        assert e.life.soothe_count==count;now.advance(.7)
    QTest.mouseClick(p,Qt.MouseButton.LeftButton,pos=QPoint(148,130))
    assert not e.life.sulking


def test_all_lifestyle_timers_stopped_in_deep_sleep(life_engine):
    e,now=life_engine;e.start_daily('daily_sleep');assert e.dream_timer.isActive()
    now.advance(123);e.enter_sleep();now.advance(99999)
    assert e.life.elapsed==123
    for timer in (e.next_action,e.phase_timer,e.neglect_timer,e.dream_timer,e.mood_timer,e.pet.timer):assert not timer.isActive()
    assert not e.start_daily('daily_eat') and not e.startup() and not e.record_interaction('chat')
    e._dream_due();e._neglect_due();assert e.phase=='dormant'
    e.wake();assert e.life.elapsed==123

@pytest.mark.parametrize('state',list(DAILY_STATES))
def test_daily_manual_actions_have_real_visual_state(life_engine,state):
    e,now=life_engine;assert e.start_daily(state)
    assert e.pet.state==state and e.pet._visual_state()==state and not e.pet.grab().isNull()
    assert e.phase==('sleeping' if state in ('daily_sleep','daily_prone') else 'daily')


def test_doze_transitions_to_curled_sleep(life_engine):
    e,now=life_engine;e.start_daily('daily_doze');until(lambda:e.phase=='sleeping')
    assert e.phase=='sleeping' and e.pet.state=='daily_prone' and e.dream_timer.isActive()


def test_dream_only_while_sleeping_local_text_and_default_silent(life_engine):
    e,now=life_engine;e._dream_due();assert not e.dream_timer.isActive()
    e.start_daily('daily_sleep');assert 180000<=e.dream_timer.interval()<=420000
    e.dream_timer.stop();e._dream_due();assert e.pet._bubble in DREAM_LINES and e.dream_timer.isActive()
    e.interact('head');assert not e.dream_timer.isActive()


def test_disable_dream_or_bubbles_stops_it(life_engine):
    e,now=life_engine;e.start_daily('daily_sleep')
    e.preferences.values['dream_enabled']=False;e.settings_changed();e._dream_due()
    assert not e.dream_timer.isActive()
    e.preferences.values['dream_enabled']=True;e.preferences.values['bubbles_enabled']=False;e.settings_changed()
    assert not e.dream_timer.isActive()


def test_welcome_once_edge_and_restore_without_saving_temporary_position(life_engine):
    e,now=life_engine;p=e.pet;p.move(200,100);origin=p.pos();positions=[]
    p.position_changed.connect(lambda *v:positions.append(v))
    assert e.startup(manual=True);assert e.phase=='welcome' and p.state=='welcome'
    assert p.x()==p.screen().availableGeometry().left() and positions==[]
    QTest.qWait(35);assert p.pos()==origin and e.phase=='idle' and positions==[]
    assert not e.startup(manual=True)


def test_autostart_never_greets(life_engine):
    e,now=life_engine;assert not e.startup(manual=False)
    assert e.phase=='idle' and not e.phase_timer.isActive()


def test_welcome_skip_and_task_restore_position(life_engine):
    e,now=life_engine;e.pet.move(200,100);origin=e.pet.pos();e.startup();e.skip()
    assert e.pet.pos()==origin and e.phase=='idle'
    e.startup_attempted=False;e.startup();e.interrupt_for_task();assert e.pet.pos()==origin


def test_game_never_loads_missing_new_frames(app,tmp_path):
    prefs=PersonalityPreferences(tmp_path);prefs.values['deep_sleep']=True
    loads=[];pet=PetWindow(dormant=True);e=PersonalityEngine(pet,prefs,lambda:loads.append(1))
    try:
        assert not e.startup() and not e.start_daily('daily_eat');assert loads==[]
        assert not e.neglect_timer.isActive() and not e.dream_timer.isActive()
    finally:e.close();pet.deleteLater()


def test_missing_daily_resource_reports_no_fake_animation(life_engine):
    e,now=life_engine;del e.pet.sprites.animations['daily_eat'];notices=[];e.resource_notice.connect(notices.append)
    state=e.pet.state;assert not e.start_daily('daily_eat');assert e.pet.state==state and notices


def test_independent_daily_and_emotion_frames_not_reunion_aliases(app):
    skin=LazySkin();original={p for state in ('reunion_wakeup','reunion_surprised','reunion_hug','reunion_cuddle') for p in skin.animations[state][0]}
    for state in (*DAILY_STATES,*MOOD_STATES):
        frames,fps=skin.animations[state];assert len(frames)==4 and not set(frames)&original
        assert len({p.read_bytes() for p in frames})==4
        assert skin.entries[state]['kind']=='independent_generated_frames'
        for i in range(4):assert skin.frame(state,i/fps+.01).hasAlphaChannel()
    assert skin.entries['daily_game']['gold_round_glasses']
    assert skin.animations['sleep'][0]==skin.animations['daily_sleep'][0]
    assert skin.cached_bytes<=skin.max_bytes


def test_settings_toggles_and_manual_daily_request(controller):
    c=controller;c.show_personality_settings()
    assert set(c.personality_window.extra_switches)=={'neglect_enabled','daily_enabled','dream_enabled','welcome_enabled','seek_enabled'}
    c.personality_window.daily_requested.emit('daily_eat');assert c.pet.state=='daily_eat'
    c.personality_window.extra_switches['dream_enabled'].setChecked(False)
    assert c.personality_preferences.values['dream_enabled'] is False
    c.set_game_mode(True);assert not c.personality_window.daily_button.isEnabled()


def test_busy_defers_neglect_without_losing_stage(life_engine):
    e,now=life_engine;e.busy=lambda:True;now.advance(1800);e._neglect_due()
    assert e.life.sulking and e.phase=='idle'
    e.busy=lambda:False;e.schedule();assert e.phase=='angry'


def test_disable_neglect_releases_mood_without_database(life_engine):
    e,now=life_engine;now.advance(1800);e._neglect_due()
    e.preferences.values['neglect_enabled']=False;e.settings_changed()
    assert not e.life.sulking and e.phase=='idle' and not e.neglect_timer.isActive()


def test_work_glasses_pause_angry_poses_without_forgiving(life_engine):
    e,now=life_engine;now.advance(1800);e._neglect_due()
    e.preferences.values['appearance']='work';e.settings_changed()
    assert e.pet._visual_state()=='working' and e.life.sulking and not e.mood_timer.isActive()
    e.preferences.values['appearance']='companion';e.settings_changed();assert e.phase=='angry'


def test_disable_neglect_saves_cleared_state(controller):
    c=controller;c.personality.life.sulking=True;c.personality.life.soothe_count=2
    c.sync_personality_controls();c.personality_window.extra_switches['neglect_enabled'].setChecked(False)
    raw=json.loads(c.personality_preferences.path.read_text())
    assert not raw['sulking'] and raw['soothe_count']==0
    restored=InteractionClock({**raw,'sulking':True,'soothe_count':2})
    assert not restored.sulking


def test_soothe_does_not_move_os_cursor(life_engine):
    from PySide6.QtGui import QCursor
    e,now=life_engine;now.advance(1800);e._neglect_due()
    cursor=QCursor.pos()
    for _ in range(3):e.interact('head');now.advance(.7)
    e.pet.grab();assert QCursor.pos()==cursor and e.pet.state=='comfort_nuzzle'

@pytest.mark.parametrize('autostart,deep,expected',[(False,False,'welcome'),(True,False,'idle'),(False,True,'dormant')])
def test_real_source_entry_startup_rules(tmp_path,autostart,deep,expected):
    import subprocess,sys
    data=tmp_path/'data';data.mkdir();result=tmp_path/'result.json'
    if deep:(data/'personality.json').write_text(json.dumps({'deep_sleep':True}))
    program='''import json,sys
from pathlib import Path
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication
from qiaomi.personality import PersonalityEngine
from qiaomi.app import main
original=PersonalityEngine.startup
def capture(self,**kwargs):
    value=original(self,**kwargs)
    Path(sys.argv[1]).write_text(json.dumps({'phase':self.phase,'dormant':self.dormant,'frames':getattr(self.pet.sprites,'frame_reads',0),'welcome':value}))
    QTimer.singleShot(60,self.parent().request_quit)
    return value
PersonalityEngine.startup=capture
raise SystemExit(main(sys.argv[2:]))
'''
    args=[sys.executable,'-c',program,str(result),'--data-dir',str(data)]
    if autostart:args.append('--autostart')
    run=subprocess.run(args,cwd=Path(__file__).resolve().parents[1],capture_output=True,text=True,timeout=25)
    assert run.returncode==0,run.stderr
    observed=json.loads(result.read_text());assert observed['phase']==expected
    assert observed['welcome']==(expected=='welcome')
    if deep:assert observed['frames']==0
