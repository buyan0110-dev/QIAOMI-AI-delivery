"""Jarvis-inspired control surface. Business logic stays in the controller."""
from __future__ import annotations
import html
import math
import random
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, Signal, QPointF,QUrl
from PySide6.QtGui import QColor, QPainter, QPen, QKeyEvent, QPixmap,QTextOption
from PySide6.QtWidgets import (
    QWidget, QFrame, QLabel, QPushButton, QHBoxLayout, QVBoxLayout,
    QStackedWidget, QTextBrowser, QPlainTextEdit, QLineEdit,
    QComboBox, QCheckBox, QFormLayout, QScrollArea, QSizeGrip, QApplication,
)
from qiaomi import __version__
from .memories import MemoryPage
from .pet import clamp_window_position
from .butler import CareArt,CareWorkspace,ButlerHome


def message_html(text):
    """Small safe fenced-code renderer; all user/model text remains escaped."""
    out=[];code=False
    for line in text.split('\n'):
        if line.lstrip().startswith('```'):
            if code:out.append('</span></p>')
            else:
                language=html.escape(line.lstrip()[3:43].strip())
                out.append('<p><b>代码'+(' · '+language if language else '')+'</b></p><p><span style="font-family:Consolas,monospace;">')
            code=not code;continue
        escaped=html.escape(line)
        if code:escaped=escaped.expandtabs(4).replace(' ','&#160;')
        out.append(escaped+'<br>')
    if code:out.append('</span></p>')
    return ''.join(out)


def label(text, name=None, wrap=False):
    item = QLabel(text)
    item.setTextFormat(Qt.TextFormat.PlainText)
    if name:
        item.setObjectName(name)
    item.setWordWrap(wrap)
    return item


def button(text, name=None):
    item = QPushButton(text)
    if name:
        item.setObjectName(name)
    item.setCursor(Qt.CursorShape.PointingHandCursor)
    return item


class StatusOrb(QWidget):
    def __init__(self):
        super().__init__()
        self.setFixedSize(54, 54)
        self.phase = 0.0
        self.busy = False
        self.timer = QTimer(self)
        self.timer.setInterval(70)
        self.timer.timeout.connect(self.tick)

    def tick(self):
        self.phase += .13
        self.update()

    def showEvent(self, event):
        if self.busy:self.timer.start()
        super().showEvent(event)

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        color = QColor('#6ddcfa' if self.busy else '#77e7cb')
        for radius in (22, 16):
            painter.setPen(QPen(QColor('#27455b'), 1))
            painter.drawEllipse(QPointF(27, 27), radius, radius)
        painter.setPen(QPen(color, 2.5))
        angle = int(self.phase * 80) if self.busy else 35
        painter.drawArc(5, 5, 44, 44, angle * 16, 110 * 16)
        color.setAlpha(int(150 + 60 * math.sin(self.phase)))
        painter.setBrush(color)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QPointF(27, 27), 6, 6)


class MessageInput(QPlainTextEdit):
    submitted = Signal()

    def __init__(self):
        super().__init__()
        self._composing = False

    def inputMethodEvent(self, event):
        self._composing = bool(event.preeditString())
        super().inputMethodEvent(event)

    def keyPressEvent(self, event: QKeyEvent):
        if not self._composing and event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not event.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            self.submitted.emit()
            event.accept()
        else:
            super().keyPressEvent(event)


class AssistantWindow(QWidget):
    voice_requested = Signal()
    listen_requested = Signal()
    memory_accept = Signal()
    memory_reject = Signal()
    send_requested = Signal(str)
    desktop_requested = Signal()
    life_requested = Signal()
    appearance_requested = Signal(str,int,bool)
    chat_closed = Signal()
    pet_requested = Signal()
    hide_requested = Signal()
    quit_requested = Signal()
    clear_requested = Signal()
    cancel_requested = Signal()
    settings_requested = Signal(str, str, bool, bool)
    connection_requested = Signal()
    demo_requested = Signal()
    demo_confirmed = Signal()
    demo_cancelled = Signal()

    def __init__(self, store, config, api_key=''):
        super().__init__()
        self.setWindowTitle('QIAOMI AI · 敲咪智能管家')
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self._drag_offset = None
        self._watched_screens = []
        self._watching_screens = False
        self._screen_timer = QTimer(self)
        self._screen_timer.setSingleShot(True)
        self._screen_timer.timeout.connect(self.ensure_on_screen)
        self.resize(1380, 940)
        self.setMinimumSize(850, 650)
        self._allow_close = False
        self._rows = []
        self.appearance_values=dict(theme="pink",scale=100,welcome=True)
        self.avatar_path=Path(__file__).resolve().parents[2]/"assets/personality/icon.png"
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        shell = QWidget()
        shell.setObjectName('shell')
        self.shell_scroll=QScrollArea();self.shell_scroll.setWidgetResizable(True);self.shell_scroll.setFrameShape(QFrame.Shape.NoFrame);self.shell_scroll.setWidget(shell);outer.addWidget(self.shell_scroll)
        layout = QHBoxLayout(shell)
        layout.setContentsMargins(12, 12, 18, 12)
        layout.setSpacing(22)

        sidebar = QFrame()
        sidebar.setObjectName('sidebar')
        self.sidebar=sidebar;sidebar.setMinimumWidth(210)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(17, 23, 17, 18)
        side.setSpacing(12)
        side.addWidget(label('🐾  QIAOMI', 'brand'))
        side.addWidget(label('敲咪的小小世界  ♡', 'eyebrow'))
        side.addSpacing(30)
        self.nav_buttons = []
        for index, text in enumerate(('◈   对话中心', '▤   长期记忆', '⚙   偏好设置', '⌂   管家首页', '♡   照顾敲咪')):
            nav = button(text, 'nav')
            nav.setCheckable(True)
            nav.clicked.connect(lambda checked=False, i=index: self.navigate(i))
            self.nav_buttons.append(nav)
        for i in (3,0,4,1,2):side.addWidget(self.nav_buttons[i])
        side.addStretch()
        side.addWidget(label('始终由你掌控', 'eyebrow'))
        side.addWidget(label('记忆留在本机。\n操作先确认，再执行。', 'muted', True))
        side.addSpacing(14)
        pet = button('↗  回到桌面猫咪')
        pet.clicked.connect(self.pet_requested)
        side.addWidget(pet)
        hide = button('收起到系统托盘', 'quiet')
        hide.clicked.connect(self.hide_requested)
        side.addWidget(hide)
        side.addWidget(label(f'敲咪  /  v{__version__}', 'muted'))
        layout.addWidget(sidebar)

        main = QVBoxLayout()
        main.setContentsMargins(0, 14, 0, 0)
        main.setSpacing(17)
        self.compact_nav=QComboBox();self.compact_nav.addItems(('对话中心','长期记忆','偏好设置','管家首页','照顾敲咪'));self.compact_nav.currentIndexChanged.connect(self.navigate);main.addWidget(self.compact_nav);self.compact_nav.hide()
        header = QHBoxLayout()
        titles = QVBoxLayout()
        self.avatar=QLabel();self.avatar.setFixedSize(72,72);self.avatar.setPixmap(QPixmap(str(self.avatar_path)).scaled(72,72,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation));header.addWidget(self.avatar)
        titles.addWidget(label('敲咪 · 您的私人 AI 管家', 'eyebrow'))
        self.title = label('你好，我是敲咪。', 'title',True)
        titles.addWidget(self.title)
        self.subtitle = label('陪你聊天，也帮你记住重要的小事。', 'subtitle',True)
        titles.addWidget(self.subtitle)
        self.welcome_line=label("", "muted",True);titles.addWidget(self.welcome_line)
        header.addLayout(titles,1)
        header.addStretch()
        self.orb = StatusOrb()
        header.addWidget(self.orb)
        window_buttons = QVBoxLayout()
        close_button = button('×', 'quiet')
        close_button.setToolTip('关闭管家，回到猫咪')
        close_button.setFixedWidth(36)
        close_button.clicked.connect(self.close)
        tray_button = button('−', 'quiet')
        tray_button.setToolTip('收起到系统托盘')
        tray_button.setFixedWidth(36)
        tray_button.clicked.connect(self.hide_requested)
        window_buttons.addWidget(close_button)
        window_buttons.addWidget(tray_button)
        header.addLayout(window_buttons)
        main.addLayout(header)

        status = QFrame()
        status.setObjectName('card')
        sl = QHBoxLayout(status)
        self.mode_label = label('●  本地陪伴', 'status')
        self.task_label = label('准备就绪', 'muted', True)
        sl.addWidget(self.mode_label)
        sl.addStretch()
        sl.addWidget(self.task_label)
        main.addWidget(status)
        self.pages = QStackedWidget()
        self.pages.addWidget(self._chat_page())
        self.memories = MemoryPage(store)
        self.pages.addWidget(self.memories)
        self.pages.addWidget(self._settings_page(config, api_key))
        self.care_art=CareArt();self.butler_home=ButlerHome(self.care_art);self.care_workspace=CareWorkspace(self.care_art)
        self.pages.addWidget(self.butler_home);self.pages.addWidget(self.care_workspace)
        self.butler_home.open_chat.connect(lambda:self.navigate(0));self.butler_home.open_care.connect(self.open_care)
        main.addWidget(self.pages, 1)
        footer = QHBoxLayout()
        footer.addWidget(label('QIAOMI AI  ·  你的私人桌面搭档', 'muted'))
        footer.addStretch()
        quit_btn = button('退出程序', 'quiet')
        quit_btn.clicked.connect(self.quit_requested)
        footer.addWidget(quit_btn)
        footer.addWidget(QSizeGrip(self))
        main.addLayout(footer)
        layout.addLayout(main, 1)
        self.navigate(3)
        self.set_connected(bool(api_key))

    def _chat_page(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(12)
        self.chat = QTextBrowser()
        self.chat.setMinimumSize(260,170)
        self.chat.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        self.chat.setOpenLinks(False)
        self.chat.setOpenExternalLinks(False)
        self.chat.setAccessibleName('聊天记录')
        layout.addWidget(self.chat, 1)
        starters = QHBoxLayout()
        for text in ('你好，敲咪', '记住：称呼=主人', '演示任务'):
            b = button(text)
            b.clicked.connect(lambda checked=False, t=text: self.send_requested.emit(t))
            starters.addWidget(b)
        starters.addStretch()
        self.starters = []
        for i in range(3):
            self.starters.append(starters.itemAt(i).widget())
        layout.addLayout(starters)
        self.confirm_card = QFrame()
        self.confirm_card.setObjectName('card')
        confirm_layout = QVBoxLayout(self.confirm_card)
        self.confirm_text = label('', wrap=True)
        confirm_layout.addWidget(self.confirm_text)
        actions = QHBoxLayout()
        yes = button('确认执行演示', 'primary')
        yes.clicked.connect(self.demo_confirmed)
        no = button('取消')
        no.clicked.connect(self.demo_cancelled)
        actions.addWidget(yes)
        actions.addWidget(no)
        actions.addStretch()
        confirm_layout.addLayout(actions)
        self.confirm_card.hide()
        layout.addWidget(self.confirm_card)
        compose = QFrame()
        compose.setObjectName('card')
        cl = QVBoxLayout(compose)
        self.input = MessageInput()
        self.input.setPlaceholderText('和敲咪说点什么…  例如：敲咪，记住我喜欢少糖拿铁')
        self.input.setMinimumHeight(110);self.input.setMaximumHeight(220)
        self.input.setAccessibleName('消息输入框')
        self.input.submitted.connect(self.submit)
        cl.addWidget(self.input)
        controls = QHBoxLayout()
        controls.addWidget(label('Enter 发送 · Shift + Enter 换行', 'muted'))
        controls.addStretch()
        self.clear_button = button('清空记录', 'quiet')
        self.clear_button.clicked.connect(self.clear_requested)
        controls.addWidget(self.clear_button)
        self.stop_button = button('取消请求')
        self.stop_button.clicked.connect(self.cancel_requested)
        self.stop_button.hide()
        controls.addWidget(self.stop_button)
        self.send_button = button('发送  ↗', 'primary')
        self.send_button.setMinimumSize(96,48)
        self.send_button.clicked.connect(self.submit)
        controls.addWidget(self.send_button)
        cl.addLayout(controls)
        self.memory_card = QFrame()
        memory_layout = QVBoxLayout(self.memory_card)
        self.memory_text = QTextBrowser()
        self.memory_text.setOpenLinks(False)
        self.memory_text.setOpenExternalLinks(False)
        self.memory_text.setMinimumHeight(135)
        self.memory_text.setMaximumHeight(200)
        memory_layout.addWidget(self.memory_text)
        memory_actions = QHBoxLayout()
        for title, signal in [('确认保存', self.memory_accept), ('不保存', self.memory_reject)]:
            action = button(title)
            action.clicked.connect(signal)
            memory_actions.addWidget(action)
        memory_layout.addLayout(memory_actions)
        self.memory_card.hide()
        layout.addWidget(self.memory_card)
        voice_controls = QHBoxLayout()
        for title, signal in [('麦克风 · 开始说话', self.listen_requested), ('语音设置 / 静音 / 打断', self.voice_requested)]:
            action = button(title)
            action.clicked.connect(signal)
            voice_controls.addWidget(action)
        layout.addLayout(voice_controls)
        layout.addWidget(compose)
        return page

    def _settings_page(self, config, api_key):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        body = QWidget()
        body.setObjectName('settingsBody')
        form = QVBoxLayout(body)
        form.setSpacing(13)
        form.addWidget(label('让敲咪更懂你', 'title'))
        form.addWidget(label('外观', 'brand'))
        self.theme_choice=QComboBox();self.theme_choice.addItem('♡ 粉色猫咪主题','pink');self.theme_choice.addItem('☀ 浅色模式','light');self.theme_choice.addItem('☾ 深色模式','dark')
        self.scale_choice=QComboBox()
        for size,title in [(100,'标准'),(110,'稍大'),(125,'大字体'),(150,'超大字体')]:self.scale_choice.addItem(str(size)+'% · '+title,size)
        self.welcome_choice=QCheckBox('打开管家时显示本地随机欢迎语')
        for widget in (self.theme_choice,self.scale_choice,self.welcome_choice):form.addWidget(widget)
        self.theme_choice.currentIndexChanged.connect(self._appearance_edited);self.scale_choice.currentIndexChanged.connect(self._appearance_edited);self.welcome_choice.toggled.connect(self._appearance_edited)

        form.addWidget(label('默认连接本机 Ollama + Qwen3 8B，无需 API Key 或 ChatGPT。', 'muted', True))
        card = QFrame()
        card.setObjectName('card')
        f = QFormLayout(card)
        f.setVerticalSpacing(15)
        self.provider_input = QComboBox()
        for title, value in [('本机 Ollama（推荐）', 'ollama'), ('本地基础回复', 'offline'), ('OpenAI（原有可选服务）', 'openai')]:
            self.provider_input.addItem(title, value)
        self.provider_input.setCurrentIndex(self.provider_input.findData(config.provider))
        f.addRow('对话服务', self.provider_input)
        f.addRow('Ollama 地址', label('http://127.0.0.1:11434'))
        self.connection_status = label('尚未检测', wrap=True)
        f.addRow('本机状态', self.connection_status)
        self.check_button = button('重新检测 Ollama')
        self.check_button.clicked.connect(self.connection_requested)
        f.addRow('', self.check_button)
        self.key_input = QLineEdit(api_key)
        self.key_input.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_input.setPlaceholderText('输入 OpenAI API Key（仅保留在本次运行内存）')
        self.key_input.setMaxLength(512)
        self.model_input = QLineEdit(config.model)
        self.model_input.setMaxLength(120)
        f.addRow('API Key', self.key_input)
        f.addRow('模型名称', self.model_input)
        self.provider_input.currentIndexChanged.connect(self._provider_changed)
        self._provider_changed()
        form.addWidget(card)
        form.addWidget(label('仅 OpenAI 模式使用密钥，且只请求其官方 API，可能产生费用。Ollama 模式不使用密钥；本地请求绕过环境代理。', 'muted', True))
        self.share_box = QCheckBox('允许将本地记忆用于 AI 对话')
        self.share_box.setChecked(config.share_memories)
        form.addWidget(self.share_box)
        form.addWidget(label('Ollama 仅向本机发送消息与最近聊天上下文；勾选后也会使用部分长期记忆。选择 OpenAI 时，这些内容会发送到其官方 API。', 'muted', True))
        life_button=button('敲咪的生活 · 喂食 / 洗澡 / 逗猫')
        life_button.clicked.connect(self.life_requested);form.addWidget(life_button)
        desktop_button=button('桌面 / 游戏模式 / 开机自启动')
        desktop_button.clicked.connect(self.desktop_requested)
        form.addWidget(desktop_button)
        self.top_box = QCheckBox('桌面猫咪始终置顶')
        self.top_box.setChecked(config.always_on_top)
        form.addWidget(self.top_box)
        actions = QHBoxLayout()
        self.save_settings = button('应用设置', 'primary')
        self.save_settings.clicked.connect(lambda: self.settings_requested.emit(self.key_input.text().strip(), self.model_input.text().strip(), self.share_box.isChecked(), self.top_box.isChecked()))
        forget = button('清除密钥输入')
        forget.clicked.connect(self.key_input.clear)
        actions.addWidget(self.save_settings)
        actions.addWidget(forget)
        actions.addStretch()
        form.addLayout(actions)
        form.addWidget(label('修改密钥后请点击「应用设置」。不自动读取浏览器、账号凭据或 ChatGPT 数据。语音请从语音设置开启；敏感操作和长期记忆保存仍需确认。', 'muted', True))
        form.addStretch()
        scroll.setWidget(body)
        layout.addWidget(scroll)
        return page

    def _provider_changed(self, *_):
        provider = self.provider_input.currentData()
        self.key_input.setEnabled(provider == 'openai')
        self.model_input.setEnabled(provider != 'offline')
        if provider == 'ollama' and self.model_input.text().startswith('gpt-'):
            self.model_input.setText('qwen3:8b')
        elif provider == 'openai' and self.model_input.text() == 'qwen3:8b':
            self.model_input.setText('gpt-4o-mini')

    def submit(self):
        text = self.input.toPlainText().strip()
        if text and self.send_button.isEnabled():
            self.send_requested.emit(text)

    def navigate(self, index):
        self.subtitle.setVisible(index!=4)
        self.welcome_line.setVisible(index!=4 and self.appearance_values['welcome'])
        self.pages.setCurrentIndex(index)
        self.shell_scroll.verticalScrollBar().setValue(0)
        for i, b in enumerate(self.nav_buttons):
            b.setChecked(i == index)
        if index == 1:
            self.memories.refresh()
        self.title.setText(('你好，我是敲咪。', '重要的小事，我记得。', '按你的习惯来。','妈妈，敲咪在这里。','今天也要好好照顾敲咪 ♡')[index])
        self.subtitle.setText(('陪你聊天，也帮你记住重要的小事。', '只保存你主动提供和审核的偏好。', '选择连接方式，让陪伴更自在。','你的本地 AI 管家，也是最黏妈妈的小猫。','洗香香，吃饱饱，快乐的事情一起做。')[index])

    def open_care(self,index=0):
        self.navigate(4);self.care_workspace.open(index)

    def set_connected(self, connected):
        provider = self.provider_input.currentData()
        self.mode_label.setText('●  Ollama · 本机 AI' if provider == 'ollama' else ('●  OpenAI 已配置' if provider == 'openai' and connected else '●  本地基础陪伴'))

    def set_busy(self, busy):
        self.check_button.setEnabled(not busy)
        self.provider_input.setEnabled(not busy)
        self.orb.busy = busy
        if busy and self.orb.isVisible():self.orb.timer.start()
        else:self.orb.timer.stop()
        self.send_button.setEnabled(not busy)
        self.clear_button.setEnabled(not busy)
        self.save_settings.setEnabled(not busy)
        self.stop_button.setVisible(busy)
        self.stop_button.setEnabled(busy)
        for b in self.starters:
            b.setEnabled(not busy)

    def set_task(self, text):
        self.task_label.setText(text)

    def render_messages(self, rows, *, force=False):
        from ..appearance import PALETTES
        from PySide6.QtGui import QTextDocument,QImage
        v=self.appearance_values;p=PALETTES[v['theme']];font=round(17*v['scale']/100)
        self._rows=list(rows)
        if not self.isVisible() and not force:
            self.chat_dirty=True;return
        self.chat_dirty=False
        # Embedded local image resource: arbitrary chat text cannot load files/network.
        self.chat.document().addResource(QTextDocument.ResourceType.ImageResource, QUrl('qiaomi-avatar'), QImage(str(self.avatar_path)))
        blocks=[]
        for row in rows:
            user=row['role']=='user';name='你' if user else '敲咪'
            content=message_html(row['content'])
            # Preserve copying and whitespace/code text, while escaping all HTML.
            avatar='' if user else '<img src="qiaomi-avatar" width="32" height="32"> '
            blocks.append(f'<table width="100%" cellspacing="0" cellpadding="12" bgcolor="{p["user"] if user else p["cat"]}"><tr><td><b>{avatar}{name}</b><br><span style="white-space:pre-wrap;">{content}</span></td></tr></table><p style="margin:8px"></p>')
        if not rows:blocks=['<p>随时待命，也随时陪你。</p><p>摸摸敲咪，或开始一段对话。长期记忆只在你确认后保存。</p>']
        self.chat.setHtml(f'<html><body style="font-size:{font}px;color:{p["text"]};">'+''.join(blocks)+'</body></html>')
        self.chat.verticalScrollBar().setValue(self.chat.verticalScrollBar().maximum())

    def resizeEvent(self,event):
        if hasattr(self,'sidebar') and hasattr(self,'compact_nav'):
            compact=self.width()<(1050 if self.appearance_values['scale']>=125 else 780)
            self.sidebar.setVisible(not compact);self.compact_nav.setVisible(compact)
        super().resizeEvent(event)

    def _appearance_edited(self,*_):
        self.appearance_requested.emit(self.theme_choice.currentData(),self.scale_choice.currentData(),self.welcome_choice.isChecked())

    def apply_appearance(self,values):
        self.appearance_values=dict(values)
        if hasattr(self,'care_workspace'):self.care_workspace.set_theme(values['theme']);self.butler_home.scene.theme=values['theme']
        for w in (self.theme_choice,self.scale_choice,self.welcome_choice):w.blockSignals(True)
        self.theme_choice.setCurrentIndex(self.theme_choice.findData(values['theme']));self.scale_choice.setCurrentIndex(self.scale_choice.findData(values['scale']));self.welcome_choice.setChecked(values['welcome'])
        for w in (self.theme_choice,self.scale_choice,self.welcome_choice):w.blockSignals(False)
        scale=values['scale']/100;self.sidebar.setMinimumWidth(round(215*scale));self.input.setMinimumHeight(round(110*scale));self.send_button.setMinimumHeight(round(48*scale))
        compact=self.width()<(1050 if values['scale']>=125 else 780);self.sidebar.setVisible(not compact);self.compact_nav.setVisible(compact)
        self.welcome_line.setVisible(values['welcome'] and self.pages.currentIndex()!=4)
        self.render_messages(self._rows)

    def choose_welcome(self):
        if self.appearance_values['welcome']:
            self.welcome_line.setText(random.choice(('妈妈！今天有什么需要敲咪处理的吗？','敲咪今天也有认真工作哦！','妈妈！工作之前先摸一下敲咪嘛！','今天的敲咪也超级聪明！','哼！敲咪才没有偷懒！','妈妈，敲咪随时待命！','工作交给敲咪，妈妈负责摸摸头！')))

    def show_confirmation(self, description):
        self.confirm_text.setText(description)
        self.confirm_card.show()
        self.navigate(0)

    def closeEvent(self, event):
        if self._allow_close:
            event.accept()
        else:
            event.ignore()
            self.hide()
            self.chat_closed.emit()

    def ensure_on_screen(self):
        if not self.isVisible():
            return
        areas = [screen.availableGeometry() for screen in QApplication.screens()]
        if not areas:
            return
        target_position = clamp_window_position(self.frameGeometry(), areas)
        area = next((rect for rect in areas if rect.contains(target_position)), areas[0])
        self.setMinimumSize(min(850, area.width()), min(650, area.height()))
        if self.width() > area.width() or self.height() > area.height():
            self.resize(min(self.width(), area.width()), min(self.height(), area.height()))
        self.move(clamp_window_position(self.frameGeometry(), areas))

    def _screen_changed(self, *_):
        self._screen_timer.start(0)

    def _topology_changed(self, *_):
        self._stop_screen_watch()
        if self.isVisible():
            self._start_screen_watch()
            self._screen_changed()

    def _start_screen_watch(self):
        if self._watching_screens:
            return
        app = QApplication.instance()
        app.screenAdded.connect(self._topology_changed)
        app.screenRemoved.connect(self._topology_changed)
        self._watched_screens = list(app.screens())
        for screen in self._watched_screens:
            screen.availableGeometryChanged.connect(self._screen_changed)
        self._watching_screens = True

    def _stop_screen_watch(self):
        if not self._watching_screens:
            return
        app = QApplication.instance()
        app.screenAdded.disconnect(self._topology_changed)
        app.screenRemoved.disconnect(self._topology_changed)
        for screen in self._watched_screens:
            try:
                screen.availableGeometryChanged.disconnect(self._screen_changed)
            except (RuntimeError, TypeError):
                pass  # Qt may already have deleted a disconnected monitor.
        self._watched_screens = []
        self._watching_screens = False
        self._screen_timer.stop()

    def showEvent(self, event):
        if not self.butler_home.scene.suspend:
            self.avatar.setPixmap(self.care_art.frame(15).scaled(72,72,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation))
        self.choose_welcome()
        self.render_messages(self._rows,force=True)
        self._start_screen_watch()
        self._screen_changed()
        super().showEvent(event)

    def hideEvent(self, event):
        self._stop_screen_watch()
        super().hideEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton and event.position().y() < 140:
            handle = self.windowHandle()
            if handle is None or not handle.startSystemMove():
                self._drag_offset = event.globalPosition().toPoint() - self.frameGeometry().topLeft()
            event.accept()
        else:
            super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_offset is not None and event.buttons() & Qt.MouseButton.LeftButton:
            self.move(event.globalPosition().toPoint() - self._drag_offset)
        else:
            super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_offset = None
        super().mouseReleaseEvent(event)
