"""Actual Qt care widgets plus simulated time; not Windows hardware acceptance."""
import hashlib,json
from pathlib import Path
import pytest
from PySide6.QtTest import QTest
from PySide6.QtCore import Qt,QPoint
from qiaomi.appearance import AppearancePreferences,PALETTES
from qiaomi.ui.butler import CareScene
from test_v050_life import life
from test_desktop_lifecycle import app,controller

ROOT=Path(__file__).resolve().parents[1]

def test_new_default_pink_preserves_saved_dark_light(tmp_path):
    assert AppearancePreferences(tmp_path).values['theme']=='pink'
    for theme in ('dark','light','pink'):
        p=AppearancePreferences(tmp_path);p.values['theme']=theme;p.save();assert AppearancePreferences(tmp_path).values['theme']==theme

def test_main_window_home_chat_memory_and_integrated_care(controller):
    c=controller;c.show_assistant();assert c.window.pages.currentIndex()==3
    c.window.butler_home.open_chat.emit();assert c.window.pages.currentIndex()==0
    c.window.navigate(1);assert c.window.pages.currentWidget() is c.window.memories
    c.show_life_panel();assert c.window.pages.currentIndex()==4 and not c.life_window.isVisible()
    c.window.care_workspace.tabs[1].click();assert c.window.care_workspace.bath.isVisible()

@pytest.mark.parametrize('food',['fish','bowl'])
def test_interactive_feed_three_distinct_portions_and_only_one_award(life,food):
    c,care,clock=life;care.state.change(hunger_satiety=20)
    c.start_care_page(food,'manual');a=care.active;assert a.interactive
    if food=='bowl':a.index=1;care._show_stage()
    for n in range(3):
        clock.advance(.36);assert care.feed_portion()
        if n<2:
            assert care.active.feed_count==n+1 and care.state.values['hunger_satiety']==pytest.approx(20,abs=.01)
            assert not care.feed_portion()
    if food=='fish':
        assert care.active.index==1 and not care.feed_portion();care.finish()
    assert care.active is None and care.state.values['hunger_satiety']==pytest.approx(38 if food=='fish' else 55,abs=.01)
    assert not care.feed_portion()

def test_pause_freezes_deadline_and_resume_preserves_remaining(life):
    c,care,clock=life;care.request('bath');remaining=care.active.deadline-clock()
    assert care.toggle_pause();assert not care.action_timer.isActive() and not c.pet.timer.isActive()
    clock.advance(50);care._stage_due();assert care.active.index==0
    assert care.toggle_pause();assert care.active.deadline-clock()==pytest.approx(remaining)
    assert care.action_timer.isActive();care.cancel();assert c.pet.timer.isActive()

def test_paused_bath_cannot_scrub_or_advance(life):
    c,care,clock=life;care.request('bath');care.next_bath();care.toggle_pause()
    assert not care.scrub('head');care.next_bath();assert care.active.index==1
    care.cancel();assert c.pet.care_visual is None

def test_dressing_plays_four_complete_frames_then_holds_final(life):
    c,care,clock=life;c.window.open_care(1);care.request('bath');a=care.active;a.index=4;care._show_stage();scene=c.window.care_workspace.bath.scene
    result=[]
    for offset in (0,.81,1.61,2.41):
        clock.value=a.deadline-a.stages[4][2]+offset;result.append(scene.frame_index())
    assert result==[12,13,14,15]
    care.finish();assert scene.frame_index()==15 and care.last_completed=='bath'
    c.window.care_workspace.bath.sync();assert c.window.care_workspace.bath.progress.value()==100
    assert not scene.timer.isActive()

def test_undress_foam_rinse_towel_dress_are_distinct(life):
    c,care,clock=life;care.request('bath');scene=c.window.care_workspace.bath.scene;a=care.active
    assert scene.frame_index()==0
    clock.advance(1.6);assert scene.frame_index()==1
    care.next_bath();assert scene.frame_index() in (2,3)
    care.next_bath();assert scene.frame_index()==4
    care.next_bath();assert scene.frame_index()==5
    clock.advance(1.6);assert scene.frame_index()==6
    care.next_bath();assert scene.frame_index()==12

@pytest.mark.parametrize('mode',['manual','quick','auto'])
def test_all_care_modes_share_the_same_owner(life,mode):
    c,care,clock=life;c.start_care_page('bath',mode);a=care.active;assert a
    assert a.name=={'manual':'bath','quick':'quick_wash','auto':'auto_wash'}[mode]
    if mode=='auto':assert not a.user
    if mode=='quick':assert care.state.values['cleanliness']==100
    c.start_care_page('fish','manual');assert care.active.name=='fish' and care.active is not a
    assert c.pet.care_visual['name']=='fish'

def test_scene_mouse_bath_and_feed_go_through_controller(life):
    c,care,clock=life;c.show_assistant();c.window.open_care(1);c.start_care_page('bath','manual');care.next_bath();c.app.processEvents()
    scene=c.window.care_workspace.bath.scene;r=scene.cat_rect();point=QPoint(round(r.center().x()),round(r.y()+r.height()*.3))
    QTest.mouseClick(scene,Qt.MouseButton.LeftButton,pos=point);assert 'head' in care.active.scrubbed
    c.window.open_care(2);c.start_care_page('fish','manual');scene=c.window.care_workspace.feed.scene;c.app.processEvents();r=scene.cat_rect()
    QTest.mouseClick(scene,Qt.MouseButton.LeftButton,pos=QPoint(round(r.center().x()),round(r.center().y())));assert care.active.feed_count==1

def test_hidden_scene_has_no_refresh_and_game_releases_art(life):
    c,care,clock=life;c.show_assistant();c.window.open_care(1);c.start_care_page('bath','manual');c.app.processEvents()
    scene=c.window.care_workspace.bath.scene;assert scene.timer.isActive();scene.grab();assert c.window.care_art.bytes>0
    c.window.navigate(0);assert not scene.timer.isActive()
    c.window.open_care(1);assert scene.timer.isActive()
    c.set_game_mode(True);assert care.active is None and c.window.care_art.bytes==0
    c.show_assistant();c.window.open_care(1);c.app.processEvents();scene.grab();assert c.window.care_art.bytes==0
    assert not any(x.timer.isActive() for x in c.window.care_workspace.findChildren(CareScene))
    c.window.care_workspace.bath.start.click();assert c.game_mode and care.active is None
    c.wake_qiaomi();assert not c.game_mode

def test_suspend_and_cleanup_clear_scene_timers(life):
    c,care,clock=life;c.show_assistant();c.window.open_care(2);c.start_care_page('fish','manual');c.app.processEvents();scene=c.window.care_workspace.feed.scene;assert scene.timer.isActive()
    c.system_power(True);assert not scene.timer.isActive() and c.window.care_art.bytes==0 and care.active is None
    c.system_power(False);assert care.active is None
    c.cleanup();assert not scene.timer.isActive() and c.window.care_art.bytes==0

@pytest.mark.parametrize('theme',['pink','dark','light'])
@pytest.mark.parametrize('scale',[100,110,125,150])
def test_care_themes_and_scales_keep_real_controls_usable(life,theme,scale):
    c,care,clock=life;c.change_appearance(theme,scale,False);c.show_life_panel();c.window.open_care(1);c.app.processEvents();page=c.window.care_workspace.bath
    assert page.isVisible() and page.start.isVisible() and page.start.isEnabled()
    assert page.font().pixelSize()==round(16*scale/100)
    assert page.start.rect().width()>40 and page.start.rect().height()>20
    page.start.click();assert care.active.name=='bath'

def test_new_art_decodes_and_original_art_stays_byte_identical(app):
    from qiaomi.ui.butler import CareArt
    art=CareArt()
    for i in range(16):assert not art.frame(i).isNull()
    for name in ('bathroom.png','home.png','dining.png'):assert not art.get(name).isNull()
    assert art.frame(15).hasAlphaChannel();art.clear();assert art.bytes==0
    expected=json.loads((ROOT/'docs/v050/upgrade-scope.json').read_text())['preserved_assets']
    for name,digest in expected.items():assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest

def test_pink_upgrade_backups_existing_life_before_opening(app,tmp_path,monkeypatch):
    from qiaomi.upgrade import ensure_upgrade_backup
    ensure_upgrade_backup(tmp_path);(tmp_path/'life.json').write_text('{"schema":1,"mood":42}')
    dest=ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.5.0-pink.json')
    assert (dest/'life.json').read_text()=='{"schema":1,"mood":42}'
    assert ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.5.0-pink.json') is None

def test_mother_hand_only_in_manual_soap_stage(life):
    c,care,clock=life;scene=c.window.care_workspace.bath.scene;care.request('bath')
    assert not scene.manual_hand_visible();care.next_bath();assert scene.manual_hand_visible()
    care.toggle_pause();assert not scene.manual_hand_visible();care.toggle_pause();assert scene.manual_hand_visible()
    care.next_bath();assert not scene.manual_hand_visible();care.cancel();assert not scene.manual_hand_visible()
    care.request('auto_wash');care.active.index=1;care._show_stage();assert not scene.manual_hand_visible()
    care.cancel();care.request('quick_wash');assert not scene.manual_hand_visible()

def test_mother_hand_follows_local_pointer_and_no_global_hook(life):
    c,care,clock=life;c.show_assistant();c.window.open_care(1);care.request('bath');care.next_bath();c.app.processEvents();scene=c.window.care_workspace.bath.scene
    QTest.mouseMove(scene,QPoint(150,160));assert scene.pointer is not None
    assert not scene.grab().isNull() and 'mother-hand.png' in c.window.care_art.cache
    care.cancel();scene.sync();assert scene.pointer is None

def test_auto_bath_includes_all_five_visual_stages(life):
    c,care,clock=life;c.start_care_page('bath','auto');a=care.active;scene=c.window.care_workspace.bath.scene
    assert len(a.stages)==5 and all(stage[2]<120 for stage in a.stages)
    indices=[]
    for i in range(5):
        a.index=i;care._show_stage();indices.append(scene.frame_index());assert not scene.manual_hand_visible()
    assert indices==[0,2,4,5,12]
    care.finish();assert scene.frame_index()==15
