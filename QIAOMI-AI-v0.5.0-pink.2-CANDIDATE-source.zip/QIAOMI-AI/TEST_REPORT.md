# QIAOMI AI v0.5.0-pink.2

完整回归578项通过（223.36秒）；最后按用户要求保留按钮粉色底，另跑92项标题按钮/几何专项（结果docs/pink2/final-caption-tests.txt）。

[完整报告](docs/pink2/TEST_REPORT.zh-CN.md) · [修复说明与Windows验收](docs/pink2/FIX_REPORT.zh-CN.md)

Windows11实机、DPI、EXE、真实麦克风/游戏仍待验。本包为候选源码。
