# QIAOMI AI v0.5.0 测试结果

455项自动化通过，Linux Qt流程通过。Windows11实机、EXE、真实麦克风与游戏性能尚未验证。

完整证据、性能限制及AC-01至AC-20状态见[本次测试报告](docs/v050/TEST_REPORT.zh-CN.md)。历史报告保留在docs。
