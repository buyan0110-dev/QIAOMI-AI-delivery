"""v0.5.0 actual state/storage/Qt tests; audio and Windows hardware are not certified."""
import json,sqlite3,hashlib,math
from pathlib import Path
import pytest
from PySide6.QtCore import Qt,QPointF
from PySide6.QtTest import QTest
from test_desktop_lifecycle import app,controller,until
from qiaomi.life_state import LifeState,DEFAULTS,VALUES
from qiaomi.upgrade import ensure_upgrade_backup,MARKER
from qiaomi.power import PowerMonitor

class Clock:
    def __init__(self):self.value=1000.
    def __call__(self):return self.value
    def advance(self,seconds):self.value+=seconds

@pytest.fixture
def life(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
    clock=Clock();care=c.care;care.now=clock;care.last_seen=clock();care.last_save=clock();care.timer.stop()
    c.personality.life.now=clock;c.personality.life.anchor=clock();c.personality.life.accumulated=0
    care.auto_after=1e9
    return c,care,clock

def test_initial_values_and_no_offline_decay(tmp_path):
    s=LifeState(tmp_path);assert all(s.values[k]==DEFAULTS[k] for k in VALUES)
    s.change(hunger_satiety=43,energy=27);s.save()
    raw=json.loads(s.path.read_text());raw['last_saved_at']='1900-01-01T00:00:00+00:00';s.path.write_text(json.dumps(raw))
    loaded=LifeState(tmp_path);assert loaded.values['hunger_satiety']==43 and loaded.values['energy']==27

def test_bounds_invalid_fields_unknown_keys_and_backup(tmp_path):
    p=tmp_path/'life.json';raw={'schema':1,'hunger_satiety':-20,'cleanliness':200,'energy':float('nan'),'mood':37,'automatic_care':'bad','extension':'keep'};p.write_text(json.dumps(raw));original=p.read_bytes()
    s=LifeState(tmp_path);assert [s.values[k] for k in VALUES]==[0,100,80,37]
    s.save();assert next(tmp_path.glob('life.invalid-*.json')).read_bytes()==original
    assert LifeState(tmp_path).values['extension']=='keep'

@pytest.mark.parametrize('text',['broken','[]','{"schema":99}'])
def test_corrupt_record_is_retained_before_recovery(tmp_path,text):
    p=tmp_path/'life.json';p.write_text(text);s=LifeState(tmp_path);assert s.read_error
    s.save();assert next(tmp_path.glob('life.invalid-*.json')).read_text()==text

def test_only_small_active_intervals_change_values(tmp_path):
    s=LifeState(tmp_path)
    for x in [3600,float('nan'),float('inf'),-2,'bad']:s.advance(x)
    assert s.values['hunger_satiety']==80
    for _ in range(12):s.advance(5)
    assert s.values['hunger_satiety']==pytest.approx(79.88)
    s.advance(5,resting=True);assert s.values['energy']>79.9

def test_upgrade_backs_up_committed_sqlite_wal_and_configs_once(tmp_path):
    (tmp_path/'voice.json').write_text('{"device":26}');original=(tmp_path/'voice.json').read_bytes()
    con=sqlite3.connect(tmp_path/'qiaomi.db');con.execute('PRAGMA journal_mode=WAL');con.execute('CREATE TABLE preserved(value TEXT)');con.execute("INSERT INTO preserved VALUES('remember')");con.commit()
    dest=ensure_upgrade_backup(tmp_path);assert dest and (dest/'voice.json').read_bytes()==original
    backup=sqlite3.connect(dest/'qiaomi.db');assert backup.execute('SELECT value FROM preserved').fetchone()[0]=='remember';backup.close()
    assert ensure_upgrade_backup(tmp_path) is None and len(list((tmp_path/'backups').iterdir()))==1
    assert con.execute('SELECT value FROM preserved').fetchone()[0]=='remember';con.close()

def test_upgrade_copy_failure_does_not_mark_success_or_change_source(tmp_path,monkeypatch):
    p=tmp_path/'config.json';p.write_text('original')
    monkeypatch.setattr('qiaomi.upgrade.shutil.copy2',lambda *a:(_ for _ in ()).throw(OSError('disk')))
    with pytest.raises(OSError):ensure_upgrade_backup(tmp_path)
    assert p.read_text()=='original' and not (tmp_path/MARKER).exists()

@pytest.mark.parametrize('name,key',[('quick_feed','hunger_satiety'),('quick_wash','cleanliness')])
def test_quick_care_immediate_idempotent_and_finish_once(life,name,key):
    c,care,clock=life;care.state.change(**{key:12})
    assert care.request(name);assert care.state.values[key]==100;token=care.active.token;writes=care.state.save_count
    for _ in range(12):assert not care.request(name)
    assert care.active.token==token and care.state.save_count==writes
    assert care.finish();values=dict(care.state.values);assert not care.finish()
    assert care.state.values==values and not care.request(name)
    assert care.active is None and c.personality.phase=='idle'

@pytest.mark.parametrize('name,amount,first',[('fish',18,'reunion_hug'),('bowl',35,'walk_center')])
def test_manual_food_distinct_complete_and_cancel(life,name,amount,first):
    c,care,clock=life;care.state.change(hunger_satiety=40)
    assert care.request(name);assert c.pet.state==first
    care.cancel();assert care.state.values['hunger_satiety']==40
    assert care.request(name);care.finish();assert care.state.values['hunger_satiety']==40+amount

def test_manual_bath_all_stages_and_region_scrub_without_soothe_cheat(life):
    c,care,clock=life;care.state.change(cleanliness=12);c.personality.life.sulking=True
    assert care.request('bath');assert care.active.index==0
    care.next_bath();assert care.active.index==1
    for zone in ['head','back','belly','front_left','hind_left']:
        clock.advance(.3);assert care.scrub(zone)
    assert len(care.active.scrubbed)==5
    c.personality.interact('head');assert c.personality.life.soothe_count==0
    for stage in [2,3,4]:care.next_bath();assert care.active.index==stage
    care.next_bath();assert care.active is None and care.state.values['cleanliness']==100
    assert c.personality.life.sulking

def test_cancel_bath_no_cleanliness_award_and_overlay_released(life):
    c,care,clock=life;care.state.change(cleanliness=12);care.request('bath');care.next_bath();care.cancel()
    assert care.state.values['cleanliness']==12 and c.pet.care_visual is None and not care.action_timer.isActive()

@pytest.mark.parametrize('toy',['wand','yarn','mouse'])
def test_three_toys_render_locally_and_never_add_windows(life,toy):
    c,care,clock=life;before=set(c.app.topLevelWidgets());energy=care.state.values['energy'];mood=care.state.values['mood']
    assert care.request(toy);care.pointer('head',235,145);c.pet.repaint();assert not c.pet.grab().isNull()
    assert c.pet.care_visual['name']==toy and set(c.app.topLevelWidgets())==before
    care.finish();assert care.state.values['mood']>mood and care.state.values['energy']<energy
    assert not c.voice.listening and not c.voice.speaking and c.worker is None

def test_wand_pointer_updates_are_throttled_and_bounded(life):
    c,care,clock=life;care.request('wand');care.pointer('',999,-100);assert c.pet.care_visual['pointer']==(255,90)
    care.pointer('',100,200);assert c.pet.care_visual['pointer']==(255,90)
    clock.advance(.06);care.pointer('',100,200);assert c.pet.care_visual['pointer']==(100,200)

@pytest.mark.parametrize('key,name',[('hunger_satiety','bowl'),('cleanliness','auto_wash'),('energy','rest'),('mood','yarn')])
def test_low_values_trigger_free_autonomous_recovery(life,key,name):
    c,care,clock=life;care.auto_after=0;care.state.change(**{key:15})
    assert care.request_autonomy() and care.active.name==name and not care.active.user
    care.finish();assert care.state.values[key]>30
    assert not care.request_autonomy()  # global cooldown, no accumulated storm

def test_three_to_five_minute_idle_uses_pet_interaction_only(life):
    c,care,clock=life;care.auto_after=0;care.fun_due=180
    for _ in range(35):clock.advance(5);care.tick()
    assert care.active is None
    clock.advance(5);care.tick();assert care.active and not care.active.user
    first=care.active.name;care.finish();care.auto_after=0;care.fun_due=care.effective
    assert care.request_autonomy() and care.active.name!=first
    care.cancel();care.direct('menu');assert care.idle_seconds==0

def test_disabled_auto_care_no_penalty_and_values_can_recover_manually(life):
    c,care,clock=life;care.state.change(automatic_care=False,hunger_satiety=0,energy=0);care.auto_after=0
    assert not care.request_autonomy();assert care.request('quick_feed');assert care.state.values['hunger_satiety']==100

def test_auto_mood_recovery_never_forgives_sulking(life):
    c,care,clock=life;p=c.personality;p.life.sulking=True;p.life.soothe_count=0;p._set_phase('angry');c.pet._state_started=c.pet.elapsed.elapsed()/1000-3
    care.auto_after=0;care.state.change(mood=10)
    assert care.request_autonomy();care.finish();assert p.life.sulking and p.life.soothe_count==0
    for i in range(4):clock.advance(.7);p.interact('head')
    assert not p.life.sulking

def test_caught_eating_finishes_before_original_touch(life):
    c,care,clock=life;care.auto_after=0;care.state.change(hunger_satiety=10);care.request_autonomy()
    care.active.index=1;care._show_stage();c.personality.interact('head')
    assert care.active is None and c.personality.pending_touch=='head' and c.personality.phase=='finish'
    c.personality._phase_finished();c.personality._phase_finished()
    assert c.personality.phase=='touch' and '没有偷吃' in c.pet._bubble

def test_drag_cancels_activity_without_eating_award(life):
    c,care,clock=life;care.state.change(hunger_satiety=10);care.request('bowl');c.pet.drag_started.emit()
    assert care.active is None and c.pet.care_visual is None and care.state.values['hunger_satiety']==10

def test_large_gap_pauses_both_life_and_old_neglect_clock(life):
    c,care,clock=life;before={k:care.state.values[k] for k in VALUES};clock.advance(36000);care.tick()
    assert {k:care.state.values[k] for k in VALUES}==before and c.personality.life.elapsed==0
    assert care.active is None and care.idle_seconds==0

def test_hide_and_busy_task_pause_life_timer(life):
    c,care,clock=life;c.pet.hide();assert not care.timer.isActive();clock.advance(3600);c.show_pet();care.tick()
    assert care.state.values['hunger_satiety']==80
    care.pause_task();clock.advance(3600);care.resume_task();care.tick();assert care.state.values['hunger_satiety']==80

def test_game_stops_all_new_work_and_only_tray_ui_wakes(life):
    c,care,clock=life;care.request('bath');c.set_game_mode(True);before=dict(care.state.values)
    assert care.dormant and care.active is None and not care.timer.isActive() and not care.action_timer.isActive()
    reads=c.pet.sprites.frame_reads if hasattr(c.pet.sprites,'frame_reads') else 0
    clock.advance(10000);care.tick();assert care.state.values==before and not care.request('quick_feed')
    c.personality_window.wake_requested.emit();c.desktop_window.wake_requested.emit();c.set_game_mode(False)
    assert c.game_mode and not c.pet.sprites.animations
    c.tray_wake.trigger();assert not c.game_mode and not care.dormant and c.personality.reunion_session
    assert care.active is None and not c.voice.wake and not c.voice.listening

def test_power_suspend_resume_does_not_exit_game(life):
    c,care,clock=life;monitor=PowerMonitor(c.system_power);c.set_game_mode(True)
    monitor.dispatch(0x218,4);clock.advance(9999);monitor.dispatch(0x218,18)
    assert c.game_mode and care.dormant and not care.timer.isActive()

def test_normal_power_resume_no_offline_decay(life):
    c,care,clock=life;monitor=PowerMonitor(c.system_power);before={k:care.state.values[k] for k in VALUES}
    monitor.dispatch(0x218,4);clock.advance(9999);monitor.dispatch(0x218,7);care.tick()
    assert {k:care.state.values[k] for k in VALUES}==before and c.personality.life.elapsed==0

def test_save_restart_and_close_cleanup(life):
    c,care,clock=life;care.state.change(hunger_satiety=48,automatic_care=False);care.persist();loaded=LifeState(c.folder)
    assert loaded.values['hunger_satiety']==48 and loaded.values['automatic_care'] is False
    care.request('mouse');care.close();assert not care.timer.isActive() and not care.action_timer.isActive() and care.active is None and c.pet.care_visual is None

def test_save_error_does_not_strand_activity(life,monkeypatch):
    c,care,clock=life;care.request('fish');monkeypatch.setattr(care.state,'save',lambda:(_ for _ in ()).throw(OSError('disk')))
    care.finish();assert care.active is None and c.personality.phase=='idle'
    assert '暂未保存' in c.window.task_label.text()

@pytest.mark.parametrize('theme',['light','dark'])
@pytest.mark.parametrize('scale',[100,110,125,150])
def test_life_panel_uses_existing_theme_and_scrolling(life,theme,scale):
    c,care,clock=life;c.change_appearance(theme,scale,False);c.show_life_panel();c.app.processEvents()
    assert c.life_window.isVisible() and all(b.isVisible() for b in c.life_window.buttons.values())
    assert c.life_window.font().pixelSize()==round(16*scale/100)
    from PySide6.QtWidgets import QScrollArea
    assert c.life_window.findChild(QScrollArea).horizontalScrollBar().maximum()==0
    c.life_window.buttons['quick_feed'].click();assert care.state.values['hunger_satiety']==100

def test_real_action_timer_completes_without_blocking_controller(controller):
    c=controller;c.show_pet();assert c.care.request('fish');a=c.care.active;a.stages=[('test','idle',.02)];a.index=0;c.care._show_stage()
    until(lambda:c.care.active is None,seconds=2)
    assert c.personality.phase=='idle'

def test_no_per_frame_writes_and_periodic_throttle(life):
    c,care,clock=life;assert care.state.save_count==0
    for _ in range(11):clock.advance(5);care.tick()
    assert care.state.save_count==0
    clock.advance(5);care.tick();assert care.state.save_count==1
    for _ in range(20):c.pet.repaint()
    assert care.state.save_count==1

def test_stale_timeout_does_not_advance_replacement_activity(life):
    c,care,clock=life;care.request('fish');token=care.active.token;care.cancel();care.request('bath')
    assert care.active.token>token;care._stage_due();assert care.active.name=='bath' and care.active.index==0

def test_too_fast_soothe_after_manual_activity_never_leaves_care_phase(life):
    c,care,clock=life;p=c.personality;p.life.sulking=True;p.interact('head');assert p.life.soothe_count==1
    care.request('fish');p.interact('head')
    assert care.active is None and p.phase=='angry' and p.life.soothe_count==1

def test_long_drag_restarts_low_frequency_scheduler_after_release(life):
    c,care,clock=life;c.pet._dragged=True;clock.advance(5);care.tick();assert not care.timer.isActive()
    c.pet.drag_finished.emit();c.pet._dragged=False;assert care.timer.isActive()

def test_menu_priority_blocks_automatic_activity(life):
    c,care,clock=life;care.auto_after=0;care.state.change(hunger_satiety=0);c.pet.menu_active=True
    assert not care.request_autonomy();c.pet.menu_active=False;assert care.request_autonomy()

def test_invalid_upgrade_marker_does_not_skip_backup(tmp_path):
    (tmp_path/'config.json').write_text('preserve');(tmp_path/MARKER).write_text('broken')
    dest=ensure_upgrade_backup(tmp_path);assert dest and (dest/'config.json').read_text()=='preserve'

def test_selected_character_and_every_existing_art_file_are_byte_identical():
    root=Path(__file__).resolve().parents[1];scope=json.loads((root/'docs/v050/upgrade-scope.json').read_text());expected=scope['preserved_assets']
    actual={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'assets').rglob('*') if p.is_file()}
    assert actual==expected and len(actual)==257

def test_controller_upgrade_preserves_preferences_and_memory(app,tmp_path,monkeypatch):
    from PySide6.QtWidgets import QSystemTrayIcon
    from qiaomi.app import Controller
    from qiaomi.storage import Store
    from qiaomi.config import Config,save_config
    from qiaomi.appearance import AppearancePreferences
    save_config(tmp_path/'config.json',Config(always_on_top=False))
    voice={'device':26,'device_name':'HyperX QuadCast S','device_hostapi':'Windows WASAPI','compute':'cpu','record_mode':'manual','threshold':.0001,'model_path':'D:/models/faster-whisper-small'}
    (tmp_path/'voice.json').write_text(json.dumps(voice))
    appearance=AppearancePreferences(tmp_path);appearance.values.update(theme='light',scale=125);appearance.save()
    original={p.name:p.read_bytes() for p in tmp_path.glob('*.json')}
    store=Store(tmp_path/'qiaomi.db');store.save_reviewed_memory('测试偏好','Chovy、Doran','个人偏好');store.close()
    monkeypatch.setattr(QSystemTrayIcon,'isSystemTrayAvailable',staticmethod(lambda:True))
    c=Controller(app,tmp_path,smoke=True)
    try:
        assert c.upgrade_backup and not c.config.always_on_top
        assert c.appearance.values['theme']=='light' and c.appearance.values['scale']==125
        for key,value in voice.items():assert c.voice.settings[key]==value
        for name,data in original.items():assert (c.upgrade_backup/name).read_bytes()==data
        for db in [tmp_path/'qiaomi.db',c.upgrade_backup/'qiaomi.db']:
            connection=sqlite3.connect(db)
            assert connection.execute('SELECT key,value FROM memories').fetchall()==[('测试偏好','Chovy、Doran')]
            assert connection.execute('PRAGMA user_version').fetchone()[0]==1
            connection.close()
        c.care.state.change(energy=36);c.care.persist();assert LifeState(tmp_path).values['energy']==36
    finally:
        app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide()
        for widget in (c.window,c.pet,c.desktop_window):widget.deleteLater()
        c.deleteLater();app.processEvents()
