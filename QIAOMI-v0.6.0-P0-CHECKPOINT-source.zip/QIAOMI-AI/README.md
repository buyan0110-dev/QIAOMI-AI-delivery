# QIAOMI AI v0.6.0 P0 开发检查点

**本包不是完整v0.6.0。** 已完成项目审计及新增玩法策略/生命周期地基；F01–F10与五个新页面尚未实现。保留现有pink.2功能、素材与数据，未导入HTML示例数据。

[真实现状、修改清单、P0–P4进度与启动方法](docs/v060/P0_STATUS.zh-CN.md) · [P0专项](docs/v060/p0-tests.txt) · [集成回归](docs/v060/p0-regression.txt)

现有Windows启动/构建脚本保留；当前没有新EXE，Windows实机尚未验收。
