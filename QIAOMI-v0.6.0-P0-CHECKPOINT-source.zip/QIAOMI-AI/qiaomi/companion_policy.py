"""v0.6 P0 policy only. No F01-F10 producers, polling, audio or inference.

Future producers must enter through this gate and the existing CareEngine;
this module intentionally does not implement a second animation scheduler.
"""
import json,os,tempfile,uuid,logging
from pathlib import Path

FEATURES=tuple('F%02d'%n for n in range(1,11))
DEFAULTS={**dict.fromkeys(FEATURES,True),'desktop_furniture':False,'reduced_motion':False,'do_not_disturb':False}

class CompanionPreferences:
    def __init__(self,folder):
        self.path=Path(folder)/'companion.json';self.values=dict(DEFAULTS);self.read_error=False
        try:
            if self.path.stat().st_size>65536:raise ValueError('oversized preferences')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid preferences')
            self.values.update(raw)
            for key,default in DEFAULTS.items():
                if type(self.values[key]) is not bool:self.values[key]=default;self.read_error=True
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError,RecursionError):self.read_error=True
    def set(self,key,value):
        if key not in DEFAULTS or type(value) is not bool:raise ValueError('invalid feature switch')
        before=self.values[key];self.values[key]=value
        try:self.save()
        except OSError:self.values[key]=before;raise
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.read_error and self.path.exists():
            self.path.with_name('companion.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.companion-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name);json.dump(self.values,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)

class CompanionPolicy:
    """Central permission/cleanup gate. No event queue; no start on resume.

    P0 does not register concrete producers or claim a feature is implemented.
    A callable is registered only while its owner has a live temporary effect.
    """
    def __init__(self,preferences,context):
        self.preferences=preferences;self.context=context;self.active=None;self.closed=False;self._cancel=None
    def allowed(self,feature):
        if feature not in FEATURES or self.closed:return False
        v=self.preferences.values;c=self.context()
        return bool(v[feature] and not v['do_not_disturb'] and not (c['game'] or c['system_sleep'] or c['task'] or c['sulking']) and c['visible'] and c['phase']=='idle' and not c['care'])
    def claim(self,feature,cancel):
        if self.active or not self.allowed(feature):return False
        if not callable(cancel):raise TypeError('cancel callback required')
        self.active=feature;self._cancel=cancel;return True
    def release(self):self.active=None;self._cancel=None
    def cancel(self):
        callback=self._cancel;self.release()
        if callback:
            try:callback()
            except Exception:logging.getLogger('qiaomi').exception('Companion cleanup failed')
    def refresh(self):
        if self.active and not self.allowed(self.active):self.cancel()
    def close(self):
        self.closed=True;self.cancel()
