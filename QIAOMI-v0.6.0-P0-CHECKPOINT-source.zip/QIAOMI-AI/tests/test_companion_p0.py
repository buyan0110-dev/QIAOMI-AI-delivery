import json,sqlite3
from pathlib import Path
import pytest
from qiaomi.companion_policy import CompanionPreferences,CompanionPolicy,FEATURES
from test_desktop_lifecycle import app,controller

def test_preferences_preserve_extensions_and_bad_original(tmp_path):
    path=tmp_path/'companion.json';path.write_text('{"F01":"bad","extension":42}');original=path.read_bytes()
    p=CompanionPreferences(tmp_path);assert p.read_error and p.values['F01'] is True
    p.set('F02',False);assert next(tmp_path.glob('companion.invalid-*.json')).read_bytes()==original
    q=CompanionPreferences(tmp_path);assert q.values['extension']==42 and q.values['F02'] is False

def test_corrupt_preferences_not_overwritten_on_read(tmp_path):
    p=tmp_path/'companion.json';p.write_text('broken');prefs=CompanionPreferences(tmp_path)
    assert prefs.read_error and p.read_text()=='broken'

@pytest.mark.parametrize('field,value',[('game',True),('system_sleep',True),('task',True),('sulking',True),('visible',False),('phase','soothing'),('care',True)])
def test_priorities_block_every_new_producer(tmp_path,field,value):
    context=dict(game=False,system_sleep=False,task=False,sulking=False,visible=True,phase='idle',care=False)
    policy=CompanionPolicy(CompanionPreferences(tmp_path),lambda:context)
    assert all(policy.allowed(f) for f in FEATURES)
    context[field]=value;assert all(not policy.allowed(f) for f in FEATURES)

def test_cancel_once_no_resume_queue(tmp_path):
    context=dict(game=False,system_sleep=False,task=False,sulking=False,visible=True,phase='idle',care=False)
    p=CompanionPolicy(CompanionPreferences(tmp_path),lambda:context);calls=[]
    assert p.claim('F01',lambda:calls.append('cancel')) and not p.claim('F02',lambda:None)
    context['game']=True;p.refresh();p.refresh();assert calls==['cancel'] and p.active is None
    context['game']=False;p.refresh();assert p.active is None
    p.close();assert not p.allowed('F01')

def test_real_controller_game_lifecycle_and_no_added_timer(controller):
    from PySide6.QtCore import QTimer
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();calls=[]
    p=c.companion_policy;assert p.claim('F01',lambda:calls.append('cancel'))
    before=len(c.findChildren(QTimer));c.set_game_mode(True)
    assert calls==['cancel'] and p.active is None and all(not p.allowed(f) for f in FEATURES)
    c.wake_qiaomi();assert p.active is None and len(c.findChildren(QTimer))==before
    c.cleanup();assert p.closed

def test_new_upgrade_snapshot_preserves_old_life_and_memory(tmp_path):
    from qiaomi.upgrade import ensure_upgrade_backup
    con=sqlite3.connect(tmp_path/'qiaomi.db');con.execute('create table old(value text)');con.execute("insert into old values ('memory')");con.commit()
    (tmp_path/'life.json').write_text('{"mood":77}')
    snapshot=ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0-p0.json')
    assert (snapshot/'life.json').read_text()=='{"mood":77}'
    db=sqlite3.connect(snapshot/'qiaomi.db');assert db.execute('select value from old').fetchone()[0]=='memory';db.close();con.close()

def test_bad_cleanup_cannot_leave_active_owner(tmp_path,caplog):
    context=dict(game=False,system_sleep=False,task=False,sulking=False,visible=True,phase='idle',care=False)
    p=CompanionPolicy(CompanionPreferences(tmp_path),lambda:context)
    p.claim('F01',lambda:(_ for _ in ()).throw(RuntimeError('test fixture')))
    p.close();assert p.closed and p.active is None and 'cleanup failed' in caplog.text

def test_direct_drag_cancels_even_when_personality_returns_idle(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();calls=[]
    assert c.companion_policy.claim('F01',lambda:calls.append('cancel'))
    c.pet.drag_started.emit();assert calls==['cancel'] and c.companion_policy.active is None
