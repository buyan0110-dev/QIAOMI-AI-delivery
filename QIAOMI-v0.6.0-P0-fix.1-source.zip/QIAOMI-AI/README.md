# QIAOMI AI v0.6.0-P0-fix.1 — 审查修正版

只修正P0地基：分场景门禁、交互前置清理、令牌/渠道/优先级、快照版本兼容。F01–F10具体玩法与新UI尚未完成。264个原素材保持不变，未改数据结构。

[逐条审查判断、文件行号、启动与未验证项](docs/p0fix/REPORT.zh-CN.md) · [完整测试输出](docs/p0fix/tests.txt)

先旧托盘退出，新目录start.bat准备，日常start.vbs；Windows构建沿用build_windows.bat。当前Linux未提供新EXE，Windows实机待验。
