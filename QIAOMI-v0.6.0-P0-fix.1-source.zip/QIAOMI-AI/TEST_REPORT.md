# v0.6.0-P0-fix.1

修正后的同一源码树全量 **624 passed / 222.75秒**。

[完整报告](docs/p0fix/TEST_REPORT.zh-CN.md) · [逐条修正与文件行号](docs/p0fix/REPORT.zh-CN.md)

Windows11实机/音频/DPI/GPU/EXE仍未验证；F01–F10具体玩法和新UI仍待P1–P4。
