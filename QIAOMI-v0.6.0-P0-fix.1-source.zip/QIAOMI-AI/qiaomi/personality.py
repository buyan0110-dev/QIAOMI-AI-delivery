"""Finite, local affectionate behaviour. No focus, mouse input, AI or DB writes."""
import json
import logging
import math
import os
from pathlib import Path
import random
import tempfile
import time
from PySide6.QtCore import QObject,QTimer,Signal
from .personality_constants import REUNION_STATES,REUNION_STAGES,CORE_LINE,REUNION_LINES,ATTENTION_STATES,ATTENTION_LINES,FREQUENCIES, DAILY_STATES, MOOD_STATES, DREAM_LINES, SOOTHE_STEPS, EXTRA_STATES
from .lifestyle import InteractionClock, NEGLECT_THRESHOLDS
from .body import BODY_PARTS,BODY_STATES

log=logging.getLogger('qiaomi')

class PersonalityPreferences:
    DEFAULTS=dict(affection_enabled=True,reunion_enabled=True,bubbles_enabled=True,frequency='high',custom_seconds=180,appearance='companion',deep_sleep=False,neglect_enabled=True,daily_enabled=True,dream_enabled=True,welcome_enabled=True,seek_enabled=True,neglect_elapsed=0,sulking=False,soothe_count=0)
    def __init__(self,folder):
        self.path=Path(folder)/'personality.json';self.values=dict(self.DEFAULTS);self.read_error=False
        try:
            if self.path.stat().st_size>64*1024:raise ValueError('oversized personality config')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid personality config')
            merged=dict(self.DEFAULTS);merged.update(raw)
            for key in ('affection_enabled','reunion_enabled','bubbles_enabled','deep_sleep','neglect_enabled','daily_enabled','dream_enabled','welcome_enabled','seek_enabled','sulking'):
                if type(merged[key]) is not bool:raise ValueError('invalid switch')
            if merged['frequency'] not in (*FREQUENCIES,'custom'):raise ValueError('invalid frequency')
            if type(merged['custom_seconds']) is not int or not 60<=merged['custom_seconds']<=1800:raise ValueError('invalid interval')
            if merged['appearance'] not in ('companion','work','gaming'):raise ValueError('invalid appearance')
            if type(merged['neglect_elapsed']) not in (int,float) or not math.isfinite(merged['neglect_elapsed']) or not 0<=merged['neglect_elapsed']<=86400:raise ValueError('invalid neglect clock')
            if type(merged['soothe_count']) is not int or not 0<=merged['soothe_count']<=3:raise ValueError('invalid soothe count')
            self.values=merged
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError,RecursionError):
            self.read_error=True;log.warning('Personality preferences invalid; safe defaults and original retained')

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.read_error and self.path.exists():
            import uuid
            self.path.with_name('personality.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.personality-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name);json.dump(self.values,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)


class PersonalityEngine(QObject):
    changed=Signal(str)
    resource_notice=Signal(str)
    seek_requested=Signal()
    def __init__(self,pet,preferences,load_skin,busy=lambda:False,parent=None,*,rng=None,timings=None,now=None):
        super().__init__(parent)
        self.pet=pet;self.preferences=preferences;self.load_skin=load_skin;self.busy=busy
        self.rng=rng or random.Random();self.timings=timings or {}
        self.life=InteractionClock(preferences.values,now or time.monotonic)
        self.presented_stage=0;self.angry_index=0;self.startup_attempted=False;self.welcome_origin=None
        self.neglect_timer=QTimer(self);self.neglect_timer.setSingleShot(True);self.neglect_timer.timeout.connect(self._neglect_due)
        self.dream_timer=QTimer(self);self.dream_timer.setSingleShot(True);self.dream_timer.timeout.connect(self._dream_due)
        self.mood_timer=QTimer(self);self.mood_timer.setSingleShot(True);self.mood_timer.timeout.connect(self._sulk_pose)
        self.pending_touch=None;self.touch_counts={};self.reunion_session=False;self.task_pose=lambda:'thinking'
        self.care_scheduler=None;self.care_feedback=''
        self.before_user_input=lambda:None;self.dream_overlay_active=lambda:False
        self.phase='idle';self.dormant=preferences.values['deep_sleep'];self.closed=False
        self.stage_index=-1;self.reunion_count=0;self.last_bubble=-1e9;self.taps=[]
        self.next_action=QTimer(self);self.next_action.setSingleShot(True);self.next_action.timeout.connect(self._autonomous)
        self.phase_timer=QTimer(self);self.phase_timer.setSingleShot(True);self.phase_timer.timeout.connect(self._phase_finished)
        self.pet.state_changed.connect(self._pet_state_changed)
        self.pet.daily_requested.connect(self.start_daily)
        self.pet.drag_started.connect(self._drag_started)
        self.pet.interaction.connect(self.interact);self.pet.skip_requested.connect(self.skip)
        self.pet.visibility_changed.connect(self.visibility_changed)
        self.pet.personality_interactions=True
        self.pet.appearance=self.preferences.values['appearance']
        self.missing_lifestyle=[]
        self.missing_resources=[]
        self.last_resource_message=''
        if self.dormant:self.enter_sleep()
        else:self.refresh_skin();self.schedule()

    def _duration(self,name,default):return int(self.timings.get(name,default))
    def _set_phase(self,phase):
        self.phase=phase;self.pet.personality_capture_clicks=phase in ('reunion','cuddle','pout','comfort','welcome','angry','soothing','finish','touch_reset','touch','seek','care')
        self.pet.skip_button.setVisible(not self.dormant and phase in ('reunion','cuddle','pout','comfort','welcome','daily','sleeping','soothing','finish','touch_reset','touch','seek'))
        self.changed.emit(phase)

    def refresh_skin(self):
        if self.dormant or self.closed:return False
        self.last_resource_message=''
        skin=self.load_skin()
        if hasattr(skin,'on_error'):skin.on_error=self._skin_error
        self.pet.install_skin(skin)
        self.missing_resources=[s for s in REUNION_STATES if s not in skin.animations]
        if skin.error or self.missing_resources:
            message=skin.error or '当前形象缺少重逢资源：'+', '.join(self.missing_resources)
            self.last_resource_message=message
            self.resource_notice.emit(message)
            log.warning('Personality skin incomplete states=%s',','.join(self.missing_resources))
        self.missing_lifestyle=[s for s in (*DAILY_STATES,*MOOD_STATES,*EXTRA_STATES,*BODY_STATES) if s not in skin.animations]
        if self.missing_lifestyle:
            self.last_resource_message+=' 日常/情绪素材缺少：'+', '.join(self.missing_lifestyle)
            self.resource_notice.emit(self.last_resource_message)
        return not self.missing_resources and not skin.error

    def _skin_error(self,message):
        self.pending_touch=None
        if self.dormant or self.closed:return
        self.last_resource_message=message
        self.next_action.stop();self.phase_timer.stop();self.dream_timer.stop();self.mood_timer.stop();self._restore_welcome();self._set_phase('idle')
        self.resource_notice.emit(message)

    def enter_sleep(self):
        if self.care_scheduler is not None:self.care_scheduler.set_deep_sleep(True)
        self.pending_touch=None
        self.life.pause();self.snapshot();self._restore_welcome()
        self.neglect_timer.stop();self.dream_timer.stop();self.mood_timer.stop()
        self.dormant=True;self.preferences.values['deep_sleep']=True
        self.next_action.stop();self.phase_timer.stop();self.taps.clear()
        self._set_phase('dormant');self.pet.suspend_animations()

    def wake(self):
        if not self.dormant or self.closed:return False
        self.dormant=False;self.preferences.values['deep_sleep']=False;self.life.resume();self.reunion_session=True
        self.pet.resume_animations();complete=self.refresh_skin()
        self.pet.show()  # WA_ShowWithoutActivating; never raise/activate/chat.
        if self.preferences.values['reunion_enabled'] and complete:
            self.reunion_count+=1;self.stage_index=-1;self._set_phase('reunion')
            if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(CORE_LINE)
            self._next_stage()
        else:
            self._normal()
        return True

    def _next_stage(self):
        if self.dormant or self.closed or self.phase!='reunion':return
        self.stage_index+=1
        if self.stage_index>=len(REUNION_STAGES):
            self._set_phase('cuddle');self.pet.play_clip('reunion_cuddle',0)
            self.phase_timer.start(self._duration('cuddle',15000));return
        state,ms=REUNION_STAGES[self.stage_index];ms=self._duration(state,ms)
        if state not in self.pet.sprites.animations:
            self.resource_notice.emit('缺少重逢阶段素材：'+state);self._next_stage();return
        self.pet.play_clip(state,ms)
        if state=='reunion_hug' and self.preferences.values['bubbles_enabled']:
            self.pet.show_bubble(self.rng.choice(REUNION_LINES))
        self.phase_timer.start(ms)

    def _phase_finished(self):
        if self.dormant or self.closed:return
        if self.phase=='reunion':self._next_stage()
        elif self.phase=='cuddle':
            self._set_phase('pout');self.pet.play_clip('reunion_pout',self._duration('pout',5000))
            if self.preferences.values['bubbles_enabled']:self.pet.show_bubble('……敲咪还没有被哄好呢。')
            self.phase_timer.start(self._duration('pout',5000))
        elif self.phase=='finish':
            self._set_phase('touch_reset');self.pet.play_clip('return_idle',300);self.phase_timer.start(self._duration('touch_reset',300))
        elif self.phase=='touch_reset':self._deliver_touch()
        elif self.phase=='daily' and self.pet.state=='daily_doze':
            self._set_phase('startle');self.pet.play_clip('doze_startle',1100);self.phase_timer.start(self._duration('startle',1100))
        elif self.phase=='startle':
            self._set_phase('doze_again');self.pet.play_clip('daily_doze',1600);self.phase_timer.start(self._duration('doze_again',1600))
        elif self.phase=='doze_again':self._start_sleep()
        elif self.phase=='daily' and self.pet.state=='daily_game':
            self._set_phase('game_result');state=self.rng.choice(('daily_game_win','daily_game_loss'));self.pet.play_clip(state,1800);self.phase_timer.start(self._duration('game_result',1800))
        elif self.phase=='game_result' and self.pet.state=='daily_game_loss':
            self._set_phase('game_retry');self.pet.play_clip('daily_game',1800);self.phase_timer.start(self._duration('game_retry',1800))
        elif self.phase=='daily' and self.pet.state=='daily_wash':
            self._set_phase('wash_finish');self.pet.play_clip('wash_hood',1800);self.phase_timer.start(self._duration('wash_finish',1800))
        elif self.phase in ('pout','comfort','action','daily','sleeping','welcome','soothing','neglect','touch','game_result','game_retry','wash_finish'):self._normal()

    def _normal(self):
        self.pending_touch=None
        if self.reunion_session:
            self.reunion_session=False;self.life.interaction();self.presented_stage=0;self.snapshot()
        self._restore_welcome();self.phase_timer.stop();self.mood_timer.stop();self._set_phase('idle');self.pet.play_clip(self.task_pose() if self.busy() else 'idle',0);self.taps.clear();self.schedule()

    def skip(self):
        if self.dormant or self.closed:return
        if self.care_scheduler is not None and self.care_scheduler.active:
            self.care_scheduler.skip();return
        self.pet.clear_bubble()
        # Skipping a clip never silently forgives an angry cat.
        if self.life.sulking:
            self.phase_timer.stop();self.mood_timer.stop();self._set_phase('angry')
            state={2:'comfort_soft',3:'comfort_nuzzle'}.get(self.life.soothe_count,'reunion_pout')
            if state in self.pet.sprites.animations:self.pet.play_clip(state,1800)
            return
        self._normal()

    def interrupt_for_task(self):
        if self.dormant or self.closed:return
        self.pending_touch=None
        self._restore_welcome();self.next_action.stop();self.phase_timer.stop();self.mood_timer.stop();self.dream_timer.stop();self._set_phase('idle');self.pet.clear_bubble();self.pet.clip_duration=0

    def visibility_changed(self,visible):
        if self.dormant or self.closed:return
        if not visible:
            self._restore_welcome();self.next_action.stop();self.phase_timer.stop();self.mood_timer.stop();self.dream_timer.stop();self._set_phase('idle');self.pet.clear_bubble();self.pet.play_clip('idle',0)
        else:self.schedule()

    def _eligible(self):
        return not (self.dormant or self.closed or self.busy()) and self.pet.isVisible() and self.phase=='idle' and self.preferences.values['affection_enabled'] and self.pet.appearance=='companion' and not getattr(self.pet,'menu_active',False)

    def schedule(self):
        self.next_action.stop();self._schedule_neglect()
        if self.dormant or self.closed:return
        if self.phase=='idle' and self._present_neglect():return
        if self.pet.state in ('sleep','daily_sleep','daily_prone'):
            self._schedule_dream();return
        if not self._eligible():return
        values=self.preferences.values
        seconds=values['custom_seconds'] if values['frequency']=='custom' else self.rng.randint(*FREQUENCIES[values['frequency']])
        self.next_action.start(seconds*1000)

    def _autonomous(self):
        if not self._eligible():
            if not self.dormant and not self.closed and self.pet.isVisible() and self.preferences.values['affection_enabled'] and self.pet.appearance=='companion':
                self.next_action.start(30000)
            return
        if self.preferences.values['daily_enabled'] and self.rng.randrange(3)==0:
            if self.care_scheduler is not None:
                if self.care_scheduler.request_autonomy():return
            else:
                candidates=[s for s in DAILY_STATES if s in self.pet.sprites.animations]
                if candidates:self.start_daily(self.rng.choice(candidates),user=False);return
        candidates=[state for state in ATTENTION_STATES if state in self.pet.sprites.animations]
        if not candidates:
            self.resource_notice.emit('当前自定义形象没有主动动作帧，已停止主动撒娇；不会只弹随机文字。');return
        state=self.rng.choice(candidates);self._set_phase('action');self.pet.play_clip(state,2400)
        if self.preferences.values['bubbles_enabled'] and time.monotonic()-self.last_bubble>=120:
            self.pet.show_bubble(ATTENTION_LINES[state]);self.last_bubble=time.monotonic()
        self.phase_timer.start(self._duration('action',2400))

    def interact(self,zone):
        if self.dormant or self.closed or zone not in BODY_PARTS|{'pad','body'}:return
        self.before_user_input()
        if self.care_scheduler is not None and self.care_scheduler.before_touch(zone):return
        if self.preferences.values['neglect_enabled']:self.life.evaluate()
        if self.life.sulking:
            self.care_feedback=''
            step=self.life.touch()
            if step is None:
                if self.phase=='care':self._start_sulk()
                return
            self._restore_welcome();self.next_action.stop();self.phase_timer.stop();self.mood_timer.stop();self.dream_timer.stop()
            self._set_phase('soothing');state,text=SOOTHE_STEPS[step]
            if state in self.pet.sprites.animations:self.pet.play_clip(state,2200)
            else:self.resource_notice.emit('缺少安抚动作素材：'+state)
            if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(text)
            self.snapshot();self.phase_timer.start(self._duration('soothing',2200));return
        self.record_interaction('touch')
        active=self.pet.state;self._restore_welcome();self.mood_timer.stop();self.dream_timer.stop();self.next_action.stop();self.phase_timer.stop()
        self.pending_touch=zone
        endings={'daily_read':'finish_book','daily_game':'finish_game','daily_game_win':'finish_game','daily_game_loss':'finish_game','daily_eat':'finish_eat','daily_prone':'wakeup_sit','daily_sleep':'wakeup_sit','sleep':'wakeup_sit','daily_doze':'wakeup_sit'}
        ending=endings.get(active,'return_idle' if active in DAILY_STATES else None)
        if ending and ending in self.pet.sprites.animations:
            self._set_phase('finish');self.pet.play_clip(ending,500);self.phase_timer.start(self._duration('finish',500))
        else:self._deliver_touch()

    def _deliver_touch(self):
        if self.dormant or self.closed or self.pending_touch is None:return
        zone=self.pending_touch;self.pending_touch=None;now=self.life.now()
        group='ears' if zone.startswith('ear_') else zone
        old,count=self.touch_counts.get(group,(-1e9,0));count=count+1 if now-old<4 else 1;self.touch_counts[group]=(now,count)
        if zone.startswith('ear_'):
            state='touch_'+zone if count==1 else ('touch_ear_tuck' if count==2 else 'touch_ear_droop')
            text=('喵？！','妈妈！痒痒！','呜……敲咪要变成垂耳猫啦！')[min(count,3)-1]
        elif zone=='belly':state='touch_belly' if count==1 else 'touch_belly_cover';text='妈妈！肚肚都要被揉扁啦！' if count>1 else '肚皮只给妈妈摸一下哦。'
        else:
            state={'head':'touch_head','chin':'touch_chin','front_left':'touch_front_left','front_right':'touch_front_right','hind_left':'touch_hind_left','hind_right':'touch_hind_right','tail':'touch_tail','pad':'pet_belly','body':'reunion_hug'}[zone]
            text={'head':'呼噜噜……再摸一下嘛！','chin':'嘿嘿……这里也喜欢！','tail':'谁抓住敲咪的尾巴啦！','pad':'呜……可以摸，但是要轻轻的！','body':'妈妈，抱抱敲咪嘛。'}.get(zone,'妈妈！握爪爪！' if zone.startswith('front') else '喵？！妈妈又偷摸敲咪jio！')
            if zone=='head' and count>=3:state='reunion_happy';text='嘿嘿嘿！妈妈最喜欢敲咪啦！'
        self._set_phase('touch')
        if state in self.pet.sprites.animations:self.pet.play_clip(state,1800)
        else:self.resource_notice.emit('缺少对应部位反馈素材：'+state)
        if self.care_feedback:text=self.care_feedback+' '+text;self.care_feedback=''
        if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(text)
        self.phase_timer.start(self._duration('touch',1800))

    def settings_changed(self):
        self.pet.appearance=self.preferences.values['appearance'];self.pet.invalidate_animation_cache()
        if self.pet.appearance!='companion' and self.phase in ('angry','soothing','neglect'):
            self.interrupt_for_task();self.pet.play_clip('idle',0)
        if not self.preferences.values['reunion_enabled'] and self.phase in ('reunion','cuddle','pout','comfort'):self.skip()
        if not self.preferences.values['affection_enabled'] and self.phase=='action':self.skip()
        if not self.preferences.values['neglect_enabled']:
            self.life.sulking=False;self.life.soothe_count=0;self.life.accumulated=0;self.life.anchor=self.life.now();self.presented_stage=0
            self.neglect_timer.stop();self.mood_timer.stop()
            if self.phase in ('angry','soothing','neglect'):self._normal()
        if not self.preferences.values['daily_enabled'] and self.phase in ('daily','sleeping'):self._normal()
        if not self.preferences.values['welcome_enabled'] and self.phase=='welcome':self.skip()
        if not self.preferences.values['dream_enabled'] or not self.preferences.values['bubbles_enabled']:self.dream_timer.stop()
        self.schedule()

    def close(self):
        self.pending_touch=None
        self.life.pause();self.snapshot();self._restore_welcome();self.neglect_timer.stop();self.dream_timer.stop();self.mood_timer.stop()
        self.closed=True;self.next_action.stop();self.phase_timer.stop();self.phase='closed'
        self.pet.suspend_animations()

    def snapshot(self):
        self.preferences.values.update(self.life.snapshot())

    def record_interaction(self, source):
        """Only explicit human input calls this; animations/replies never do."""
        if self.dormant or self.closed or source!='touch':return False
        if self.preferences.values['neglect_enabled']:self.life.evaluate()
        self.life.interaction();self.presented_stage=0
        self._schedule_neglect();self.snapshot()
        self.changed.emit(self.phase)
        return True

    def _schedule_neglect(self):
        self.neglect_timer.stop()
        if self.dormant or self.closed or not self.preferences.values['neglect_enabled'] or self.life.sulking:return
        remaining=[t-self.life.elapsed for t in NEGLECT_THRESHOLDS if t>self.life.elapsed]
        if self.life.stage==3:
            self.neglect_timer.start(1)
        elif remaining:
            self.neglect_timer.start(max(1,round(min(remaining)*1000)))

    def _neglect_due(self):
        if self.dormant or self.closed or not self.preferences.values['neglect_enabled']:return
        self.life.evaluate();self.snapshot();self.changed.emit(self.phase)
        self._present_neglect();self._schedule_neglect()

    def _present_neglect(self):
        if self.dormant or self.closed or self.busy() or not self.pet.isVisible() or not self.preferences.values['neglect_enabled']:return False
        stage=self.life.evaluate()
        if self.pet.appearance!='companion':return False
        if self.phase not in ('idle','action','daily','sleeping','angry'):return False
        if stage==3:
            if self.phase!='angry':self._start_sulk()
            return True
        if stage<=self.presented_stage:return False
        if stage in (1,2):
            state='attention_search' if stage==1 else 'reunion_pout'
            if state not in self.pet.sprites.animations:return False
            self.presented_stage=stage;self.next_action.stop();self.phase_timer.stop();self.dream_timer.stop()
            self._set_phase('neglect');self.pet.play_clip(state,3500)
            if self.preferences.values['bubbles_enabled']:
                self.pet.show_bubble('妈妈……？今天还没有摸敲咪呢！' if stage==1 else '……哼。敲咪才没有想妈妈！')
            self.phase_timer.start(self._duration('neglect',3500));return True
        return False

    def _start_sulk(self):
        self.next_action.stop();self.phase_timer.stop();self.dream_timer.stop()
        self._set_phase('angry');self._sulk_pose()
        if not self.life.soothe_count:self.seek_requested.emit()

    def _sulk_pose(self):
        self.mood_timer.stop()
        if self.dormant or self.closed or not self.life.sulking or self.busy() or not self.pet.isVisible() or self.pet.appearance!='companion' or self.phase not in ('idle','angry'):return
        self._set_phase('angry')
        choices=('reunion_pout','angry_back','angry_tail','angry_peek')
        if self.life.soothe_count==2:choices=('comfort_soft','angry_peek')
        if self.life.soothe_count==3:choices=('comfort_nuzzle','angry_peek')
        available=[s for s in choices if s in self.pet.sprites.animations]
        if not available:
            self.resource_notice.emit('当前形象缺少生气动作，冷落与四次安抚仍追踪；不伪装动画。');return
        state=available[self.angry_index%len(available)];self.angry_index+=1
        self.pet.play_clip(state,1800)
        # A finite clip then held pose; no looping tears or repeated notifications.
        self.mood_timer.start(self._duration('mood',8000))

    def start_daily(self, state, *, user=True):
        if state not in DAILY_STATES or self.dormant or self.closed or self.busy():return False
        if self.care_scheduler is not None:
            handled=self.care_scheduler.start_legacy_daily(state,user)
            if handled is not None:return handled
        if state not in self.pet.sprites.animations:
            self.resource_notice.emit('缺少独立日常动作素材：'+state);return False
        if user:self.record_interaction('daily-menu')
        if self.life.sulking:
            self.resource_notice.emit('敲咪还在生闷气，要四次独立摸摸才能哄好。');return False
        self._restore_welcome();self.next_action.stop();self.phase_timer.stop();self.mood_timer.stop();self.dream_timer.stop()
        if state in ('daily_sleep','daily_prone'):self._start_sleep(state);return True
        self._set_phase('daily');duration=self._duration('daily',5000)
        if self.care_scheduler is not None:self.care_scheduler.observe_legacy_start(state,duration)
        self.pet.play_clip(state,duration);self.phase_timer.start(duration);return True

    def _start_sleep(self,state="daily_prone"):
        if self.dormant or self.closed:return
        if 'daily_sleep' not in self.pet.sprites.animations:
            self.resource_notice.emit('缺少独立蜷睡素材');self._normal();return
        self.next_action.stop();self._set_phase('sleeping');self.pet.play_clip(state,0)
        self.phase_timer.start(self._duration('nap',600000));self._schedule_dream()

    def _pet_state_changed(self, state):
        if state not in ('sleep','daily_sleep','daily_prone'):
            self.dream_timer.stop()
        else:
            self.next_action.stop();self._schedule_dream()

    def _can_dream(self):
        return not (self.dormant or self.closed or self.busy() or self.life.sulking) and self.pet.isVisible() and self.pet.state in ('sleep','daily_sleep','daily_prone') and self.preferences.values['dream_enabled'] and self.preferences.values['bubbles_enabled']

    def _schedule_dream(self):
        if not self._can_dream():self.dream_timer.stop();return
        if not self.dream_timer.isActive():
            self.dream_timer.start(self._duration('dream',self.rng.randint(180,420)*1000))

    def _dream_due(self):
        if not self._can_dream():return
        if not self.dream_overlay_active():self.pet.show_bubble(self.rng.choice(DREAM_LINES))
        self._schedule_dream()

    def startup(self, *, manual=True):
        """One explicit manual process startup, never activation/autostart/wake."""
        if self.startup_attempted:return False
        self.startup_attempted=True
        if not manual or self.dormant or self.closed or self.busy() or self.life.sulking or not self.preferences.values['welcome_enabled']:return False
        if 'welcome' not in self.pet.sprites.animations:
            self.resource_notice.emit('缺少启动探头/眨眼/挥爪/跳出素材，未用文字替代。');return False
        self.next_action.stop();self.phase_timer.stop();self.dream_timer.stop()
        self.welcome_origin=self.pet.pos()
        screen=self.pet.screen()
        if screen:
            area=screen.availableGeometry()
            blocked=self.pet.blockSignals(True)
            self.pet.move(area.left(),max(area.top(),area.bottom()-self.pet.height()+1))
            self.pet.blockSignals(blocked)
        self._set_phase('welcome');duration=self._duration('welcome',3200)
        self.pet.play_clip('welcome',duration)
        if self.preferences.values['bubbles_enabled']:self.pet.show_bubble(self.rng.choice(('妈妈！！！！敲咪来啦！！！','敲咪今天也超级可爱哦！','妈妈！先摸头再工作嘛！','哼！敲咪才没有一直等妈妈呢！','今天也要多摸摸敲咪！')))
        self.phase_timer.start(duration);return True

    def _restore_welcome(self):
        if self.welcome_origin is None:return
        origin=self.welcome_origin;self.welcome_origin=None
        blocked=self.pet.blockSignals(True);self.pet.move(origin);self.pet.blockSignals(blocked)

    def _drag_started(self):
        if self.dormant or self.closed:return
        self.before_user_input()
        if self.care_scheduler is not None:self.care_scheduler.before_drag()
        self.welcome_origin=None  # An intentional drag overrides the saved location.
        self.record_interaction('drag');self.interrupt_for_task();self.pet.play_clip('idle',0);self.schedule()
