"""Local, once-per-upgrade snapshot before any existing settings/DB are opened."""
from pathlib import Path
import json,sqlite3,shutil,uuid,re
from datetime import datetime,timezone

MARKER='.upgrade-v0.5.0.json'

def ensure_upgrade_backup(folder,*,marker_name=MARKER,target_version='0.5.0'):
    if not re.fullmatch(r'[0-9]+\.[0-9]+\.[0-9]+(?:-[a-z0-9.]+)?',target_version):raise ValueError('invalid snapshot version')
    if Path(marker_name).name!=marker_name:raise ValueError('invalid marker filename')
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    marker=folder/marker_name
    if marker.exists():
        try:
            if marker.stat().st_size>65536:raise ValueError('oversized upgrade marker')
            record=json.loads(marker.read_text(encoding='utf-8'))
            legacy_p0=(marker_name=='.upgrade-v0.6.0-p0.json' and target_version=='0.6.0-p0' and record.get('version')=='0.5.0')
            if record.get('version')==target_version or legacy_p0:
                if record.get('fresh_install') is True and record.get('backup') is None:return None
                backup=Path(record.get('backup','')).resolve()
                if backup.is_relative_to((folder/'backups').resolve()) and (backup/'BACKUP.json').is_file():return None
        except (OSError,ValueError,TypeError,AttributeError):pass  # invalid marker triggers a fresh backup
    configs=[p for p in folder.glob('*.json') if p.is_file()]
    database=folder/'qiaomi.db';existing=bool(configs or database.exists())
    destination=None
    if existing:
        destination=folder/'backups'/('pre-v'+target_version+'-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S')+'-'+uuid.uuid4().hex[:8]);destination.mkdir(parents=True)
        for path in configs:shutil.copy2(path,destination/path.name)
        if database.exists():
            # SQLite online backup includes committed WAL data; never copy a live DB blindly.
            source=sqlite3.connect(database.resolve().as_uri()+'?mode=ro',uri=True,timeout=5)
            try:
                target=sqlite3.connect(destination/'qiaomi.db')
                try:source.backup(target);target.commit()
                finally:target.close()
            finally:source.close()
        (destination/'BACKUP.json').write_text(json.dumps({'version':('0.4.x' if target_version=='0.5.0' else '0.5.0-pink.2')+' -> '+target_version,'target_version':target_version,'config_files':[p.name for p in configs],'sqlite':database.exists()},ensure_ascii=False,indent=2),encoding='utf-8')
    temporary=marker.with_suffix('.tmp')
    temporary.write_text(json.dumps({'version':target_version,'backup':str(destination) if destination else None,'fresh_install':not existing}),encoding='utf-8');temporary.replace(marker)
    return destination
