"""Regression of real render geometry/window clipping, not Windows hardware."""
import json,hashlib
from pathlib import Path
import pytest
from PySide6.QtCore import QSizeF,QRectF,QPointF,Qt
from PySide6.QtGui import QPixmap,QPainter,QColor
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from qiaomi.ui.butler import CareArt,CareScene
from qiaomi.ui.geometry import contain_rect,scene_viewport,to_scene,from_scene
from test_desktop_lifecycle import app,controller
from test_v050_life import life

@pytest.fixture(scope='module')
def art():
    application=QApplication.instance() or QApplication([]);images=CareArt()
    yield images
    images.clear()

@pytest.mark.parametrize('index',range(16))
@pytest.mark.parametrize('size',[(300,600),(600,200),(800,500),(1080,780)])
def test_every_frame_keeps_intrinsic_aspect_and_fits_inside_scene(art,index,size):
    scene=CareScene('feed',art);scene.resize(*size);scene.frame_index=lambda:index
    image=art.frame(index);rect=scene.cat_rect();viewport=scene_viewport(scene.rect())
    assert rect.width()/rect.height()==pytest.approx(image.width()/image.height())
    assert viewport.adjusted(-.01,-.01,.01,.01).contains(rect)
    assert viewport.width()/viewport.height()==pytest.approx(1.5)
    scene.deleteLater()

def test_contain_and_pointer_mapping_are_invertible():
    target=QRectF(12,21,500,250);rect=contain_rect(QSizeF(300,400),target)
    assert rect.width()/rect.height()==.75 and target.contains(rect)
    viewport=scene_viewport(QRectF(0,0,600,500));source=QRectF(600,300,20,40);mapped=from_scene(source,viewport)
    assert to_scene(mapped.topLeft(),viewport).x()==pytest.approx(source.x())
    assert to_scene(mapped.topLeft(),viewport).y()==pytest.approx(source.y())
    assert to_scene(QPointF(0,0),viewport) is None
    assert contain_rect(QSizeF(0,5),target).isEmpty()

@pytest.mark.parametrize('stage',[-1,0,1,2,3,4,5])
def test_all_bath_states_stay_behind_actual_tub_front(life,stage):
    c,care,clock=life;scene=c.window.care_workspace.bath.scene;scene.resize(800,500)
    if 0<=stage<=4:
        care.request('bath');care.active.index=stage;care.active.user=False;care._show_stage()
    elif stage==5:care.request('bath');care.finish()
    scene.timer.stop();actual=scene.grab().toImage();viewport=scene_viewport(scene.rect())
    expected=QPixmap(scene.size());expected.fill(QColor('#fbe6ee'));p=QPainter(expected);p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform);p.translate(viewport.topLeft());p.scale(viewport.width()/1536,viewport.height()/1024);bg=scene.art.get('bathroom.png');p.drawPixmap(QRectF(0,0,1536,1024),bg,QRectF(bg.rect()));p.end();expected=expected.toImage()
    # These pixels would contain hind paws/tail in the broken compositor.
    for x_fraction in (.36,.42,.48,.54,.60):
        for y_fraction in (.84,.88,.92):
            x=round(viewport.x()+viewport.width()*x_fraction);y=round(viewport.y()+viewport.height()*y_fraction)
            assert actual.pixelColor(x,y)==expected.pixelColor(x,y)

@pytest.mark.parametrize('size',[(1080,780),(900,700),(1280,800)])
@pytest.mark.parametrize('theme',['pink','light','dark'])
def test_four_corners_stay_transparent_and_window_controls_do_not_scroll(controller,size,theme):
    c=controller;w=c.window;c.change_appearance(theme,100,False);c.show_assistant();c.app.processEvents();w._screen_timer.stop();w.resize(*size);w.open_care(1);c.app.processEvents()
    assert not w.shell_scroll.isAncestorOf(w.close_button) and not w.shell_scroll.isAncestorOf(w.quit_button)
    assert not w.shell_scroll.isAncestorOf(w.sidebar)
    mask=w.shell.mask();assert mask.boundingRect()==w.shell.rect()
    for value in [0,w.shell_scroll.verticalScrollBar().maximum()]:
        w.shell_scroll.verticalScrollBar().setValue(value);image=w.grab().toImage()
        for x,y in [(0,0),(w.width()-1,0),(0,w.height()-1),(w.width()-1,w.height()-1)]:
            assert image.pixelColor(x,y).alpha()==0 and not w.shell.mask().contains(__import__('PySide6.QtCore',fromlist=['QPoint']).QPoint(x,y))
        assert w.close_button.isVisible() and w.quit_button.isVisible()
    assert w.shell.mask()==mask and w.shell_scroll.horizontalScrollBar().maximum()==0

def test_standard_reported_window_fits_home_bath_and_feed_without_page_scroll(controller):
    c=controller;w=c.window;c.change_appearance('pink',100,False);c.show_assistant();c.app.processEvents();w._screen_timer.stop();w.resize(1080,780)
    for index in [3,4]:
        w.navigate(index)
        for subpage in ([0] if index==3 else [1,2]):
            if index==4:w.care_workspace.open(subpage)
            c.app.processEvents();QTest.qWait(20)
            assert w.shell_scroll.verticalScrollBar().maximum()==0
            assert w.shell_scroll.horizontalScrollBar().maximum()==0
            if index==4:
                page=w.care_workspace.stack.currentWidget();point=page.cancel.mapTo(w,page.cancel.rect().center());assert w.rect().contains(point) and page.cancel.isVisible()

def test_narrow_font_navigation_matches_visible_page(controller):
    c=controller;w=c.window;c.show_assistant();w.resize(900,700);c.change_appearance('pink',150,False);w.open_care(1);c.app.processEvents()
    assert w.compact_nav.isVisible() and w.compact_nav.currentIndex()==4
    w.compact_nav.setCurrentIndex(1);assert w.pages.currentWidget() is w.memories

def test_scroll_to_end_keeps_both_top_and_bottom_round(controller):
    c=controller;w=c.window;c.show_assistant();w.resize(900,700);w.open_care(0);c.app.processEvents();bar=w.shell_scroll.verticalScrollBar();bar.setValue(bar.maximum())
    mask=w.shell.mask();w.navigate(3);c.app.processEvents();assert w.shell.mask()==mask

def test_new_geometry_does_not_decode_during_game_sleep(controller):
    c=controller;c.set_game_mode(True);c.show_assistant();c.window.open_care(1);c.app.processEvents();scene=c.window.care_workspace.bath.scene
    scene.cat_rect();scene.grab();assert c.window.care_art.bytes==0 and not scene.timer.isActive()

def test_all_original_and_pink_assets_are_byte_identical():
    root=Path(__file__).resolve().parents[1];scope=json.loads((root/'docs/pink2/upgrade-scope.json').read_text())
    actual={p.relative_to(root).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (root/'assets').rglob('*') if p.is_file()}
    assert actual==scope['preserved_assets'] and len(actual)==264

def test_geometry_upgrade_runtime_hashes_match_declared_scope():
    root=Path(__file__).resolve().parents[1];scope=json.loads((root/'docs/pink2/upgrade-scope.json').read_text())
    assert set(scope['updated_runtime'])=={'qiaomi/__init__.py','qiaomi/ui/assistant.py','qiaomi/ui/butler.py'}
    p0=json.loads((root/'docs/v060/p0-scope.json').read_text())['updated_runtime']
    review=json.loads((root/'docs/p0fix/scope.json').read_text())['updated_runtime']
    for name,row in scope['updated_runtime'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==review.get(name,p0.get(name,row))['after_sha256']
    for name,digest in scope['new_runtime'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest
