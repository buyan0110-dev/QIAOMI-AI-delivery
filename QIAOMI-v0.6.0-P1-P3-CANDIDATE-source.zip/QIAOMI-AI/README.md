# QIAOMI AI v0.6.0 · 小小世界功能候选版

基于实际 `v0.6.0-P0-fix.1` 增量开发，构建号 `v0.6.0-P3-candidate.2`。

已实际修正启动/运行许可分离及 F08 长会话，并进入 P1–P3：鼠标观察、六类梦泡、七类微动作、局部模仿、普通闲置回来、四类闯祸、七种收藏、八件槽位家具、三个小游戏、陪伴相册及五个新原生页面。**功能逻辑可运行，但新增精绘动作/家具为明确轻量占位，Windows11 实机验收未完成，不能当作美术及 Windows 验收成品。**

最终本地完整回归 **685 passed / 264.83秒**，WindowsServer2025 CI 同样 **685 项通过**，GUI EXE 构建成功且打包启动自检通过；不等同 Windows11实机。

[Windows便携版下载](https://github.com/buyan0110-dev/QIAOMI-AI-delivery/releases/tag/v0.6.0-world-candidate.2) · [Windows CI证据](docs/world/WINDOWS_CI.zh-CN.md)

原桌宠、身体互动、四次独立摸摸、生活系统、长期记忆、聊天、语音、托盘、无黑窗、自启动、主题/缩放均保留。264 个运行素材逐文件 SHA256 不变。未引入浏览器、全局键盘监听、云端调用或自动开麦。

- [逐项完成程度、素材缺口、数据与游戏模式](docs/world/IMPLEMENTATION.zh-CN.md)
- [测试结果与原始证据](docs/world/TEST_REPORT.zh-CN.md)
- [安装/启动/打包及 Windows 验收步骤](docs/world/WINDOWS_ACCEPTANCE.zh-CN.md)
- [修改文件清单](docs/world/CHANGED_FILES.md)
- [实际 Qt 页面截图](docs/world/screenshots/)
- [性能短测及限制](docs/world/PERFORMANCE.zh-CN.md)

升级前退出旧托盘程序，新 ZIP 完整解压至新目录。保留原数据目录与模型路径；不要复制空配置覆盖旧数据。第一次 `start.bat` 准备环境，日常 `start.vbs` 或 `install_shortcut.vbs` 创建的 GUI 快捷方式启动；Windows 打包使用 `build_windows.bat`，PyInstaller `console=False`。

首次运行新版本会生成一次 `pre-v0.6.0-*` 本地快照（JSON 与 SQLite online backup，含 WAL 已提交数据）。新小世界数据在 `companion.db`，旧 `qiaomi.db` Schema 不变。游戏模式仍只可从托盘手动唤醒；新玩法不补跑、不补扣、不自动推理。
