# v0.6.0 小小世界候选版测试

最终整套回归 **685 passed / 264.83秒**。

[阶段完整回归与限制](docs/world/TEST_REPORT.zh-CN.md)，[最终原始输出](docs/world/final-full.txt)，[Linux启动自检](docs/world/final-smoke.json)，[实际Qt截图](docs/world/screenshots/)。WindowsServer2025 CI亦685项通过，GUI EXE构建及91项打包启动自检通过。Windows11真实硬件仍需另行验收；新增动作和道具含明确轻量占位。
