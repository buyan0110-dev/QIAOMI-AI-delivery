> 历史记录：本页对应 costume-tail.1。66张触边警告已在下一轮检查清零，其他未完成项不据此视为全部通过。当前状态请看 [第2轮报告](../refinement2/REPORT.zh-CN.md)。

# 向尾喵睡衣装饰尾巴专项返修 — 部分完成的美术工作稿

日期：2026-11-11（上海时间）。基础：v0.4.1-artfix.1；工作构建：v0.4.1-costume-tail.1。**不是已通过全量美术验收的正式修复版，不建议直接替换日常安装。**

## 参考与实际改动

以用户最后补充的装饰尾巴近景为造型依据，使用图像编辑工具建立 approved-tail-design-guide.png 并用于所有候选：臀部后方连接、柔软弯曲粉色尾身、明显的稍椭圆粉色主绒球、上方三根细梗及三颗奶黄色小球。参考提取图是生成式制作指南，不冒充用户原图文件。

已实际修改全部252张现有 WebP 候选文件；每个原文件名、256×256画布、状态帧引用、时序、循环与别名关系均保留。另对 edge_left、exit_left、walk_center、touch_belly 做单组返修。没有用程序绘制尾巴、遮挡、模糊、抠掉毛发或矩形裁剪轮廓冒充修补；程序仅按图集单元切分、统一缩放到原画布和生成对比预览。美术修改由图像编辑工具完成。

## 用户指出的问题及状态

|问题|本轮实际处理|验收状态|
|---|---|---|
|背面两条橘尾|去掉臀部中央重复橘色部分，修回粉色睡衣，保留侧后方一条橘尾|已返修候选；仍需连贯播放验收|
|睡觉两条橘尾|退回错误中间稿，只保留身前环抱的一条橘尾|已返修候选；仍需最终逐帧确认|
|伸懒腰两条橘尾|退回错误中间稿，保留臀部上翘的一条，去掉地面额外卷尾|已返修候选；仍需最终逐帧确认|
|粉色大球缺失/装饰长在脸旁|统一造型参考；行走与侧身离开组单独重建完整粉色弯尾、大球及三颗小球|部分完成，不能认证所有姿态根部连接均合格|
|第三只招手前爪|左右扒边挥手帧分别删除额外旧抓边爪，只保留一抓一挥|已返修候选；需运行命中/切换复核|
|全动作风格/尺寸一致|保留角色类型、睡衣、动作和原文件布局，分组处理|部分完成；生成编辑仍会改变局部毛发、脸部细节和占比，尚不能保证全252帧脸型身材严格一致|
|干净透明边缘及连续性|读写检查、半透明/孤立分量/边界统计、部分单独清底|未完成，见下面具体文件与完整清单|

最初失败的睡觉、伸懒腰和招手候选中有本轮生成引入的错误，不能全部归因于原始项目。那些中间稿已退回，不采用为最终对应动作资源。reported-defects-before-after.png 左侧明确标为 REJECTED DRAFT（被退回的中间稿）；all-frames-XX-before-after.png 左侧才是上一交付 artfix.1 的真实原文件。

## 仍需人工修图/复核的具体文件

全252帧都有启发式透明通道警告；这不等于252帧都一定有可见错误，但本轮不能通过“零残留”标准，也不能声称普通格式测试能自动数尾巴或猫爪。frame-review.csv 逐一列出全部252个文件名、哈希、低透明像素、孤岛与画布边界计数和未完成状态。

以下帧在画布边界仍有不透明像素，需要人工逐帧判断是杂点还是实际部件截断，不采用阈值擦除掩盖：

- daily_eat-1.webp
- finish_book-0.webp
- finish_book-1.webp
- finish_book-2.webp
- finish_book-3.webp
- finish_eat-0.webp
- finish_eat-1.webp
- finish_eat-2.webp
- finish_eat-3.webp
- finish_game-0.webp
- finish_game-1.webp
- finish_game-2.webp
- finish_game-3.webp
- reconcile-3.webp
- return_idle-0.webp
- reunion_cry-3.webp
- reunion_cry-4.webp
- reunion_cry-5.webp
- reunion_hug-2.webp
- reunion_hug-5.webp
- reunion_pout-0.webp
- reunion_pout-3.webp
- reunion_pout-4.webp
- reunion_run-0.webp
- reunion_run-1.webp
- reunion_run-2.webp
- reunion_run-3.webp
- reunion_run-4.webp
- reunion_run-5.webp
- reunion_surprised-0.webp
- reunion_surprised-1.webp
- reunion_surprised-2.webp
- reunion_surprised-3.webp
- reunion_surprised-4.webp
- reunion_surprised-5.webp
- reunion_wakeup-0.webp
- reunion_wakeup-1.webp
- reunion_wakeup-2.webp
- reunion_wakeup-3.webp
- reunion_wakeup-4.webp
- reunion_wakeup-5.webp
- touch_belly_cover-0.webp
- touch_belly_cover-1.webp
- touch_belly_cover-2.webp
- touch_belly_cover-3.webp
- touch_chin-0.webp
- touch_chin-1.webp
- touch_chin-2.webp
- touch_chin-3.webp
- touch_ear_droop-0.webp
- touch_ear_droop-1.webp
- touch_front_right-1.webp
- touch_head-0.webp
- touch_head-1.webp
- touch_head-2.webp
- touch_head-3.webp
- wakeup_sit-2.webp
- wash_hood-2.webp
- wash_hood-3.webp
- welcome-0.webp
- working-0.webp
- working-1.webp
- working-2.webp
- working-3.webp
- working-4.webp
- working-5.webp

此外，全部 edge_top/bottom/left/right、exit_top/bottom/left/right（各0–3）；angry_back/angry_peek/angry_tail/touch_tail（各0–3）；reunion_cuddle（0–5）；daily_sleep/daily_stretch/walk_center（各0–3）必须继续全尺寸审核尾根、遮挡、两种尾巴与运动连贯性。其余帧也不能跳过，详见完整252帧台账。四边接触点和身体命中元数据沿用原版，素材位置变化后尚未完成逐帧重新标定。

当前图像编辑输出在多轮返修后，仍不能可靠保证所有252帧同时达到透明边缘、脸型占比、部件数量和连续运动标准；这些部分需要后续人工逐帧精修。**本包是可审查的实际修改工作稿，不能认定完整需求已经完成。**

## 代码、数据与回归

除构建标记外，qiaomi 下32个 Python 运行模块逐字节未改，包括桌宠渲染/命中、四次安抚、冷落、游戏深度休眠、托盘、GUI启动、主题、语音、聊天和记忆模块；runtime-preservation.json 给出校验值。未作数据库迁移。现有 start.bat、无控制台入口、构建脚本保留。没有把数据库、个人配置、录音、模型、虚拟环境或密钥装入包。代码保留不等于新的美术动作已全部通过运行验证。

自动化结果见 docs/validation/costume-tail-tests.txt 与 XML。首次全量测试 388通过、2失败：一项是真实资源无全透明像素，另一项语音模拟子进程3秒等待超时。前者换用实际清底候选后修正，后者单独复测通过；针对性复测共18项通过。最终全量结果另列，不隐去首次失败。资源脚本252张读取/尺寸/RGBA/路径检查无基本错误，但美术警告仍存在。

本环境为 Linux / Python3.12 / PySide6离屏。**没有 Windows11实机、真实桌面透明叠加、DPI多屏、游戏覆盖和HyperX麦克风验收。没有构建Windows EXE。**

## Windows手动验收（未执行）

1. 备份原安装和用户数据；在独立目录运行工作稿，保留原数据库/配置持久目录，不覆盖私人数据。已打包EXE需重新构建才会使用新素材。
2. 先打开 actions-preview.mp4 和16张全量前后对比，逐帧核对粉色尾巴的臀部连接点、大粉球及三颗小球；不接受从脖子、脸颊、肩部出发，或把小球接在橘尾上。
3. 播放坐下、趴下、睡觉、伸展、行走、背身、摸尾巴、抱尾巴、四次安抚到待机的完整切换。可见真实橘尾只能是一条，遮挡应连贯；粉色装饰尾不能重复。检查两前爪两后足，招手时不保留第三只前爪。
4. 四边拖动、离边、从边缘摸尾巴及挥爪；深浅桌面、100/125/150% DPI逐一观察透明残留、矩形切口、比例跳动及所有身体部位命中。
5. 游戏深度休眠无动画；手动唤醒重逢；托盘、无黑窗启动、主题字号、语音与长期记忆逐项回归。
6. 将不合格帧名、截图、DPI、状态和切换条件记到 frame-review.csv；在所有条目通过前，不标记整包修复完成。

## 预览说明

all-frames-00 至15-before-after.png 覆盖全部252张实际 WebP；reported-defects-before-after.png 对应用户指出的中间稿问题；actions-transparent.webp 为真实 RGBA候选素材动画；actions-preview.mp4 为普通播放器预览，未添加语音。它们均不是 Windows实机录屏。

最终全量回归：390 passed in 60.00s。不是 Windows11实机通过，也不代表美术验收通过。
