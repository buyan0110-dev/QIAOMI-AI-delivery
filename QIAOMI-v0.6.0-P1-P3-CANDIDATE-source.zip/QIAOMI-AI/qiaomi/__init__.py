"""QIAOMI AI — 敲咪桌面管家。"""
__version__ = "0.6.0"

# Additive completion build; published v0.4.0 baseline archive remains unchanged.
__build__ = "v0.6.0-P3-candidate.1"
