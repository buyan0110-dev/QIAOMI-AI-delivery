"""One low-frequency, interruptible local life coordinator alongside personality.
No AI, microphone, input hooks, inventory or care burden. Qt GUI thread only.
"""
from dataclasses import dataclass,field
import logging,random,time
from PySide6.QtCore import QObject,QTimer,Signal
from .life_state import LifeState,TICK_MS,MAX_ACTIVE_GAP,SAVE_SECONDS,AUTO_GRACE,AUTO_COOLDOWN,FUN_IDLE,QUICK_DEBOUNCE

log=logging.getLogger('qiaomi')
LABELS={'fish':'吃小鱼干','bowl':'吃猫饭','quick_feed':'一键喂食','bath':'妈妈帮洗澡','quick_wash':'一键清洗','auto_wash':'自己洗香香','wand':'逗猫棒','yarn':'毛线球','mouse':'玩具老鼠','game':'偷偷玩游戏机','rest':'打瞌睡休息','read':'看书','groom':'洗脸','stretch':'伸懒腰'}
TOYS={'wand','yarn','mouse'}
@dataclass
class Activity:
    name:str
    user:bool
    stages:list
    token:int
    started:float
    index:int=0
    deadline:float=0.
    done:bool=False
    scrubbed:set=field(default_factory=set)
    interactive:bool=False
    feed_count:int=0
    paused:bool=False
    remaining:float=0.

class CareEngine(QObject):
    completed=Signal(str)
    changed=Signal()
    notice=Signal(str)
    def __init__(self,pet,personality,folder,busy=lambda:False,parent=None,*,now=time.monotonic,rng=None):
        super().__init__(parent);self.pet=pet;self.personality=personality;self.state=LifeState(folder);self.busy=busy;self.now=now;self.rng=rng or random.Random()
        self.furniture_choices=lambda:[]
        self.before_activity=lambda:None;self.active=None;self.last_completed=None;self.legacy_pending=None;self.generation=0;self.closed=False;self.dormant=personality.dormant;self.system_paused=False;self.task_paused=False
        self.effective=0.;self.last_direct=0.;self.direct_quiet_until=0.;self.last_seen=now();self.last_save=now();self.auto_after=AUTO_GRACE;self.fun_due=self.rng.uniform(*FUN_IDLE);self.last_auto=None;self.quick_at={};self.last_scrub=-1e9;self.last_feed=-1e9;self.last_pointer=-1e9;self.message='敲咪会自己照顾自己；数值只用于娱乐。'
        self.timer=QTimer(self);self.timer.setInterval(TICK_MS);self.timer.timeout.connect(self.tick)
        self.action_timer=QTimer(self);self.action_timer.setSingleShot(True);self.action_timer.timeout.connect(self._stage_due)
        personality.care_scheduler=self;personality.changed.connect(self._personality_changed)
        pet.visibility_changed.connect(self.visibility_changed);pet.care_pointer.connect(self.pointer);pet.menu_opened.connect(lambda:self.direct('menu'))
        pet.drag_finished.connect(self.drag_finished)
        if not self.dormant and pet.isVisible():self.timer.start()
    @property
    def idle_seconds(self):return max(0.,self.effective-self.last_direct)
    def _running(self):return not (self.closed or self.dormant or self.system_paused or self.task_paused or self.busy() or self.pet._dragged) and self.pet.isVisible()
    def _sample(self):
        current=self.now();delta=current-self.last_seen;self.last_seen=current
        if not self._running():return
        if not 0<=delta<=MAX_ACTIVE_GAP:
            if delta>MAX_ACTIVE_GAP and not self.personality.life.paused:
                self.personality.life.anchor+=delta
            self.cancel('暂停期间不补扣生活数值。');self.auto_after=self.effective+AUTO_GRACE;return
        self.effective+=delta
        resting=(self.active and self.active.name=='rest') or self.pet.state in ('daily_sleep','daily_prone','sleep')
        self.state.advance(delta,resting=bool(resting),bored=self.idle_seconds>=FUN_IDLE[0])
    def tick(self):
        if self.closed or self.dormant or self.system_paused:return
        self._sample()
        if not self._running():self.timer.stop();return
        if self.now()-self.last_save>=SAVE_SECONDS:self.persist()
        if self.active is None:self.request_autonomy()
        self.changed.emit()
    def persist(self):
        self.last_save=self.now()
        try:self.state.save()
        except OSError:
            log.exception('Life state save failed; existing file retained');self.notice.emit('生活状态暂未保存，请检查用户数据目录权限；原记忆库未修改。')
    def direct(self,source='menu'):
        if self.closed or self.dormant or self.system_paused:return
        self._sample();self.last_direct=self.effective;self.direct_quiet_until=self.effective+5;self.fun_due=self.effective+self.rng.uniform(*FUN_IDLE)
    def _eligible(self,user):
        if not self._running():return False
        p=self.personality
        if user:return True
        if self.active or self.effective<max(self.auto_after,self.direct_quiet_until) or p.reunion_session or getattr(self.pet,'menu_active',False):return False
        if p.phase=='idle':return True
        # Self-care may use a held sulking pose, never a key soothe/seek event.
        return p.phase=='angry' and self.pet.elapsed.elapsed()/1000-self.pet._state_started>=2
    def request_autonomy(self):
        if not self.state.values['automatic_care'] or not self._eligible(False):return False
        v=self.state.values
        if v['hunger_satiety']<=30:name='bowl'
        elif v['cleanliness']<=30:name='auto_wash'
        elif v['energy']<=25:name='rest'
        elif v['mood']<=30:name='yarn'
        else:
            prefs=self.personality.preferences.values
            if not (v['autonomous_fun'] and prefs['daily_enabled'] and prefs['affection_enabled']) or self.idle_seconds<FUN_IDLE[0] or self.effective<self.fun_due:return False
            choices=['game','fish','rest','read','groom','stretch','yarn']+self.furniture_choices()
            if v['energy']>65:choices+=['game','yarn']
            if self.last_auto in choices:choices=[x for x in choices if x!=self.last_auto]
            name=self.rng.choice(choices)
        return self.request(name,user=False)
    def _stages(self,name,user):
        if name=='fish':return [('捧着小鱼干','reunion_hug',1.8),('舔舔嘴巴','finish_eat',1.2)]
        if name=='bowl':return [('去小饭碗','walk_center',.7),('低头吃猫饭','daily_eat',3.)]
        if name=='quick_feed':return [('短版开饭','daily_eat',.9)]
        if name=='bath':return [('脱睡衣 · 进澡盆','idle',3.),('搓泡泡','daily_wash',120.),('冲洗','wash_hood',1.5),('浴巾 · 吹干','idle',3.),('恢复睡衣 · 香香完成','daily_stretch',3.2)]
        if name=='auto_wash':return [('脱睡衣 · 入浴','idle',3.),('自己搓泡泡','daily_wash',4.),('冲洗干净','wash_hood',2.),('浴巾 · 吹干','idle',3.),('恢复睡衣 · 完成','daily_stretch',3.2)]
        if name=='quick_wash':return [('泡泡清洗','daily_wash',.7),('卡通吹干','wash_hood',.8)]
        if name=='wand':return [('追逗猫棒','attention_reach',45.)]
        if name=='yarn':return [('拨拨毛线球','daily_yarn',5.)]
        if name=='mouse':return [('盯住玩具老鼠','daily_stretch',1.5),('扑向玩具','attention_jump',2.5)]
        if name=='game':return [('偷偷玩游戏机','daily_game',4.),('这把怎么样','daily_game_win' if self.rng.randrange(2) else 'daily_game_loss',1.5)]
        if name=='rest':return [('脑袋点点','daily_doze',2.),('蜷着休息','daily_sleep',10.),('睡醒伸腰','daily_stretch',1.5)]
        return {'read':[('翻翻小书','daily_read',4.),('合上书','finish_book',.7)],'groom':[('洗洗小脸','daily_wash',3.),('整理帽子','wash_hood',1.)],'stretch':[('伸个懒腰','daily_stretch',3.)]}[name]
    def request(self,name,*,user=True,interactive=False):
        if name not in LABELS or not self._eligible(user):return False
        self.before_activity()
        if user:self.direct()
        if self.active and self.active.name==name:return False
        if name in ('quick_feed','quick_wash') and self.now()-self.quick_at.get(name,-1e9)<QUICK_DEBOUNCE:return False
        self.legacy_pending=None;self.last_completed=None
        if self.active:self.cancel('切换生活活动',restore=False)
        self.personality.interrupt_for_task();self.personality._set_phase('care')
        self.generation+=1;stages=self._stages(name,user)
        if interactive and name in ('fish','bowl'):
            i=0 if name=='fish' else 1;label,clip,_=stages[i];stages[i]=(label,clip,120.)
        self.active=Activity(name,user,stages,self.generation,self.now(),interactive=interactive);self.pet.care_interactive=True
        if name in ('quick_feed','quick_wash'):
            self.quick_at[name]=self.now();self.state.change(**({'hunger_satiety':100} if name=='quick_feed' else {'cleanliness':100}));self.persist()
        self.message=LABELS[name]+('（妈妈陪敲咪）' if user else '（敲咪自己来）')
        self._show_stage();self.changed.emit();return True
    def _show_stage(self):
        a=self.active
        if not a:return
        label,clip,seconds=a.stages[a.index];a.deadline=self.now()+seconds
        if clip not in self.pet.sprites.animations:clip='idle';self.notice.emit('当前形象缺少对应姿态，使用原待机形象与生活效果占位。')
        self.pet.play_clip(clip,0 if a.name=='wand' or (a.name=='bath' and a.index==1) else round(seconds*1000))
        kind='bath' if a.name in ('bath','quick_wash','auto_wash') else ('food' if a.name in ('fish','bowl','quick_feed') else ('toy' if a.name in TOYS else ''))
        self.pet.care_visual={'kind':kind,'name':a.name,'stage':a.index,'label':label,'scrubbed':len(a.scrubbed),'pointer':(190.,160.),'pounce':False}
        self.pet.skip_button.setVisible(True);self.pet.invalidate_animation_cache()
        if self.personality.preferences.values['bubbles_enabled']:self.pet.show_bubble(label+'，妈妈不用操心喵。')
        self.action_timer.start(max(1,round(seconds*1000)));self.changed.emit()
    def _stage_due(self):
        if not self.active or self.closed or self.dormant or self.active.paused:return
        if self.now()-self.last_seen>MAX_ACTIVE_GAP:
            self.last_seen=self.now();self.cancel('暂停后已安全结束活动；没有补扣数值。');return
        a=self.active
        if self.now()+.02<a.deadline:self.action_timer.start(max(1,round((a.deadline-self.now())*1000)));return
        if a.interactive and a.name in ('fish','bowl') and a.stages[a.index][2]>=120:self.cancel('喂饭暂停太久，已收好餐具；没有扣分。');return
        if a.name=='bath' and a.index==1:self.cancel('泡泡时间到啦，随时可以重新开始。');return
        a.index+=1
        if a.index>=len(a.stages):self.finish()
        else:self._show_stage()
    def next_bath(self):
        if self.active and self.active.name=='bath' and not self.active.paused:
            self.active.index+=1
            if self.active.index>=len(self.active.stages):self.finish()
            else:self._show_stage()
    def scrub(self,zone):
        a=self.active
        if not a or a.name!='bath' or a.index!=1 or self.dormant or a.paused or self.now()-self.last_scrub<.2:return False
        group='head' if zone in ('head','chin','ear_left','ear_right') else ('front' if zone.startswith('front') else ('hind' if zone.startswith('hind') else ('belly' if zone=='belly' else 'back')))
        if zone not in ('head','chin','ear_left','ear_right','front_left','front_right','hind_left','hind_right','belly','body','back','tail'):return False
        self.last_scrub=self.now();a.scrubbed.add(group)
        self.pet.care_visual['scrubbed']=len(a.scrubbed);self.pet.invalidate_animation_cache();self.message='泡泡搓到'+str(len(a.scrubbed))+'处啦，可以继续冲洗。';self.changed.emit();return True
    def toggle_pause(self):
        a=self.active
        if not a or self.dormant or self.closed:return False
        if a.paused:
            a.paused=False;a.deadline=self.now()+a.remaining;self.last_seen=self.now()
            self.action_timer.start(max(1,round(a.remaining*1000)))
            if self.pet.isVisible():self.pet.timer.start()
        else:
            a.remaining=max(.01,a.deadline-self.now());a.paused=True;self.action_timer.stop();self.pet.timer.stop()
        self.changed.emit();return True
    def feed_portion(self):
        a=self.active
        if not a or not a.interactive or a.paused or a.name not in ('fish','bowl') or self.dormant or self.now()-self.last_feed<.35:return False
        if a.stages[a.index][2]<120:return False
        self.last_feed=self.now();a.feed_count+=1;self.direct('feed')
        if a.feed_count>=3:
            a.index+=1
            if a.index>=len(a.stages):self.finish()
            else:self._show_stage()
        self.changed.emit();return True
    def pointer(self,zone,x,y):
        a=self.active
        if not a or self.dormant or a.paused:return
        if a.name=='bath' and a.index==1 and zone:self.scrub(zone)
        if a.name in TOYS:
            if self.now()-self.last_pointer<.05:return
            self.last_pointer=self.now()
            self.last_direct=self.effective
            self.pet.care_visual['pointer']=(max(45.,min(255.,x)),max(90.,min(275.,y)))
            self.pet.care_visual['pounce']=self.rng.randrange(5)!=0
            self.pet.invalidate_animation_cache()
    def finish(self,*,restore=True):
        a=self.active
        if not a or a.done or self.dormant:return False
        a.done=True;self.last_completed=a.name
        effects={'fish':{'hunger_satiety':18,'mood':3},'bowl':{'hunger_satiety':35,'mood':3},'wand':{'mood':12,'energy':-3},'yarn':{'mood':12,'energy':-3},'mouse':{'mood':14,'energy':-4},'game':{'mood':10,'energy':-2},'rest':{'energy':55,'mood':4},'read':{'mood':8,'energy':-1},'groom':{'cleanliness':8,'mood':3},'stretch':{'energy':4,'mood':3}}
        if a.name in ('bath','quick_wash','auto_wash'):self.state.change(cleanliness=100);self.state.add(mood=5)
        elif a.name in effects:self.state.add(**effects[a.name])
        if not a.user:
            if a.name in ('fish','bowl'):self.state.change(hunger_satiety=max(80,self.state.values['hunger_satiety']))
            elif a.name=='rest':self.state.change(energy=max(75,self.state.values['energy']))
            elif a.name=='yarn':self.state.change(mood=max(65,self.state.values['mood']))
        self.message='刚洗完香香啦！' if 'wash' in a.name or a.name=='bath' else '照顾好自己啦，妈妈忙完再来摸敲咪。'
        self._release(restore);self.persist();self.completed.emit(a.name);return True
    def _release(self,restore):
        a=self.active;self.action_timer.stop();self.active=None;self.generation+=1
        self.pet.care_visual=None;self.pet.care_interactive=False;self.pet.invalidate_animation_cache()
        self.auto_after=self.effective+AUTO_COOLDOWN;self.fun_due=self.effective+self.rng.uniform(*FUN_IDLE)
        if a and a.paused and self.pet.isVisible() and not (self.dormant or self.system_paused or self.closed):self.pet.timer.start()
        if a and not a.user:self.last_auto=a.name
        if restore and not self.dormant and not self.closed:
            self.personality._normal()
        self.changed.emit()
    def cancel(self,message='活动已取消，不会扣分。',*,restore=True):
        if not self.active:return False
        self.last_completed=None;self.message=message;self._release(restore);return True
    def before_touch(self,zone):
        self.legacy_pending=None
        self.direct('touch')
        if self.active and self.active.name=='bath' and self.active.index==1:return self.scrub(zone) or True
        if self.active:
            a=self.active
            if not a.user and a.name in ('fish','bowl','game'):
                self.personality.care_feedback='妈妈！敲咪没有偷吃！' if a.name in ('fish','bowl') else '喵？！游戏机先藏好！'
            if a.name in TOYS:self.finish(restore=False)
            else:self.cancel('先收好东西，再陪妈妈。',restore=False)
        self.state.add(mood=1)
        return False
    def before_drag(self):
        self.legacy_pending=None
        self.direct('drag');self.cancel('拖动优先，活动已安全收起。',restore=False)
    def drag_finished(self):
        # Qt emits drag_finished just before clearing its internal drag flag.
        self.last_seen=self.now()
        if not (self.closed or self.dormant or self.system_paused or self.task_paused or self.busy()) and self.pet.isVisible():self.timer.start()
    def skip(self):return self.finish()
    def start_legacy_daily(self,state,user):
        if not user:return self.request_autonomy()
        if user:self.direct();self.cancel('切换日常动作')
        return None
    def observe_legacy_start(self,state,duration):
        self.legacy_pending=(state,self.now()+duration/1000) if state in ('daily_eat','daily_game','daily_yarn') else None
    def _personality_changed(self,phase):
        if self.closed:return
        if self.active and phase!='care':self.cancel('优先响应当前事件。',restore=False)
        if phase=='idle' and self.legacy_pending:
            state,deadline=self.legacy_pending;self.legacy_pending=None
            if self.now()>=deadline and not self.dormant:
                if state=='daily_eat':self.state.add(hunger_satiety=35,mood=3)
                else:self.state.add(mood=8,energy=-2)
                self.persist()
    def visibility_changed(self,visible):
        self.last_seen=self.now()
        if not visible:self.cancel('小猫已收起，生活时间暂停。',restore=False);self.timer.stop()
        elif self._running():self.timer.start()
    def pause_task(self):
        self.legacy_pending=None
        self._sample();self.task_paused=True;self.timer.stop();self.cancel('先处理妈妈的任务。',restore=False)
    def resume_task(self):
        self.task_paused=False;self.last_seen=self.now()
        if self._running():self.timer.start()
    def set_deep_sleep(self,enabled):
        if enabled:
            self.legacy_pending=None
            self._sample();self.cancel('游戏模式：生活活动暂停。',restore=False);self.dormant=True;self.timer.stop();self.action_timer.stop();self.persist()
        else:
            self.dormant=False;self.task_paused=False;self.last_seen=self.now();self.last_direct=self.effective;self.auto_after=self.effective+AUTO_GRACE;self.fun_due=self.effective+self.rng.uniform(*FUN_IDLE)
            if self._running():self.timer.start()
        self.changed.emit()
    def system_sleep(self,suspended):
        if suspended:
            self.legacy_pending=None
            self._sample();self.system_paused=True;self.cancel('电脑休眠，生活时间暂停。',restore=False);self.timer.stop();self.action_timer.stop();self.persist()
        else:
            self.system_paused=False;self.last_seen=self.now();self.auto_after=self.effective+AUTO_GRACE
            if self._running():self.timer.start()
    def close(self):
        if self.closed:return
        self._sample();self.cancel('退出',restore=False);self.closed=True;self.timer.stop();self.action_timer.stop();self.persist()
