"""Local sidecar storage. No chat/audio/cursor content; transactional event receipts.
The original qiaomi.db schema is never changed by this module.
"""
import sqlite3,json
from datetime import datetime
from pathlib import Path
ITEMS={
 'yarn':('毛线球','🧶','软软的线团，留着和妈妈一起玩。'),
 'fish':('小鱼玩具','🐟','这条小鱼不会被吃掉哦。'),
 'bow':('蝴蝶结','🎀','想把可爱的蝴蝶结送给妈妈。'),
 'feather':('羽毛','🪶','风送来了一根轻轻的羽毛。'),
 'clover':('四叶草','🍀','今天的小幸运也分给妈妈。'),
 'stone':('亮晶晶小石子','💎','像星星一样，藏进宝贝箱。'),
 'heart':('爱心','♡','因为妈妈一直温柔地照顾敲咪。')}
FURNITURE={
 'box':('纸箱','📦','main','rest'), 'scratch':('猫抓板','▱','main','stretch'),
 'sofa':('小沙发','🛋','main','rest'), 'rug':('小地毯','❀','small','groom'),
 'books':('小书架','📚','small','read'), 'tank':('小鱼缸','🐟','small','rest'),
 'tree':('猫爬架','♜','main','stretch'), 'bed':('小被窝','☾','main','rest')}
MEMORIES={'touch':'第一次摸摸，妈妈的手好温柔。','feed':'和妈妈一起吃饭饭。','bath':'今天洗得香香啦。','game':'和妈妈玩了一次小游戏。','soothe':'妈妈哄好了敲咪，贴贴！','gift':'敲咪捡到一件小宝贝。','dream':'敲咪做了一个软软的梦。'}

class CompanionData:
 def __init__(self,folder):
  self.path=Path(folder)/'companion.db';self.path.parent.mkdir(parents=True,exist_ok=True)
  self.db=sqlite3.connect(self.path);self.closed=False
  with self.db:
   self.db.executescript('''CREATE TABLE IF NOT EXISTS receipts(id TEXT PRIMARY KEY);
   CREATE TABLE IF NOT EXISTS collection(item TEXT PRIMARY KEY,count INTEGER NOT NULL,first_at TEXT,last_at TEXT);
   CREATE TABLE IF NOT EXISTS memories(id INTEGER PRIMARY KEY,event TEXT UNIQUE,kind TEXT,at TEXT,text TEXT);
   CREATE TABLE IF NOT EXISTS room(slot TEXT PRIMARY KEY,item TEXT);''')
 def event(self,event_id,kind,*,item=None,record=True):
  if kind not in MEMORIES or not isinstance(event_id,str) or not 0<len(event_id)<=120:raise ValueError('invalid event')
  if item is not None and item not in ITEMS:raise ValueError('unknown item')
  now=datetime.now().astimezone().isoformat(timespec='microseconds')
  with self.db:
   if not self.db.execute('INSERT OR IGNORE INTO receipts VALUES (?)',(event_id,)).rowcount:return False
   if item:self.db.execute('INSERT INTO collection VALUES (?,1,?,?) ON CONFLICT(item) DO UPDATE SET count=count+1,last_at=excluded.last_at',(item,now,now))
   if record:
    # Only gifts recur. Ordinary daily entries are capped; milestone receipts
    # remain durable even after the user deletes an album card.
    ordinary=kind=='gift' and self.db.execute("SELECT 1 FROM memories WHERE kind='gift' LIMIT 1").fetchone()
    daily=self.db.execute("SELECT COUNT(*) FROM memories WHERE kind='gift' AND substr(at,1,10)=?",(now[:10],)).fetchone()[0]
    if not ordinary or daily<3:self.db.execute('INSERT INTO memories(event,kind,at,text) VALUES (?,?,?,?)',(event_id,kind,now,MEMORIES[kind]))
  return True
 def collection(self):return self.db.execute('SELECT item,count,first_at,last_at FROM collection ORDER BY last_at DESC').fetchall()
 def memories(self):return self.db.execute('SELECT id,kind,at,text FROM memories ORDER BY id DESC').fetchall()
 def delete(self,identifier):
  with self.db:self.db.execute('DELETE FROM memories WHERE id=?',(identifier,))
 def clear(self):
  # Keep receipts: clearing an album must not recreate first milestones later.
  with self.db:self.db.execute('DELETE FROM memories')
 def export(self,path):
  path=Path(path);temp=path.with_suffix(path.suffix+'.tmp')
  temp.write_text(json.dumps({'memories':self.memories(),'collection':self.collection(),'room':self.room()},ensure_ascii=False,indent=2),encoding='utf-8');temp.replace(path)
 def room(self):return dict(self.db.execute('SELECT slot,item FROM room'))
 def place(self,slot,item):
  if slot not in ('main','small1','small2') or (item is not None and (item not in FURNITURE or FURNITURE[item][2]!=('main' if slot=='main' else 'small'))):raise ValueError('invalid room slot')
  with self.db:
   if item is None:self.db.execute('DELETE FROM room WHERE slot=?',(slot,))
   else:
    self.db.execute('DELETE FROM room WHERE item=?',(item,));self.db.execute('INSERT OR REPLACE INTO room VALUES (?,?)',(slot,item))
 def close(self):
  if not self.closed:self.closed=True;self.db.close()
