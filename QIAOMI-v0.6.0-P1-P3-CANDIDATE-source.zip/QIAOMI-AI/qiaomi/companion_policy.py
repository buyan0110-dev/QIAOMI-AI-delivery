"""Shared v0.6 start/continuation gates and bounded cancellation leases.
No polling, audio or inference; producers live in companion_runtime/stories.
"""
import json,os,tempfile,uuid,logging
from pathlib import Path

FEATURES=tuple('F%02d'%n for n in range(1,11))
DEFAULTS={**dict.fromkeys(FEATURES,True),'desktop_furniture':False,'reduced_motion':False,'do_not_disturb':False}

class CompanionPreferences:
    def __init__(self,folder):
        self.path=Path(folder)/'companion.json';self.values=dict(DEFAULTS);self.read_error=False
        try:
            if self.path.stat().st_size>65536:raise ValueError('oversized preferences')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid preferences')
            self.values.update(raw)
            for key,default in DEFAULTS.items():
                if type(self.values[key]) is not bool:self.values[key]=default;self.read_error=True
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError,RecursionError):self.read_error=True
    def set(self,key,value):
        if key not in DEFAULTS or type(value) is not bool:raise ValueError('invalid feature switch')
        before=self.values[key];self.values[key]=value
        try:self.save()
        except OSError:self.values[key]=before;raise
    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.read_error and self.path.exists():
            self.path.with_name('companion.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.companion-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name);json.dump(self.values,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)

from dataclasses import dataclass
from collections import OrderedDict
import time,math

@dataclass(frozen=True)
class EventToken:
    generation:int
    feature:str
    channel:str

@dataclass
class Effect:
    token:EventToken
    cancel:object
    expires:float
    cooldown:float
    owned_phase:str|None=None

class CompanionPolicy:
    """Feature-specific gates; observation, overlay and exclusive visual leases.

    Cleanup must remove only the producer's local effects. Async completions
    require their token, never a global reset of the pet's main pose.
    F10 is a synchronous passive sink; durable dedup is in CompanionData; receipts here guard synchronous reentry.
    """
    PRIORITY={'F02':10,'F03':10,'F04':10,'F07':20,'F09':30,'F08':80}
    PROTECTED={'touch','finish','touch_reset','soothing','seek','reunion','welcome','cuddle','comfort','pout','care','dormant'}
    def __init__(self,preferences,context,*,now=time.monotonic):
        self.preferences=preferences;self.context=context;self.now=now;self.closed=False
        self._effects={};self._generation=0;self._cancelling=False;self._cancel_requested=False;self._cooldowns={};self._receipts=OrderedDict()
    @property
    def active(self):
        e=self._effects.get('visual');return e.token.feature if e else None
    def can_start(self,feature):
        if feature not in FEATURES or self.closed or self._cancelling:return False
        v=self.preferences.values;c=self.context()
        if not v[feature] or c['game'] or c['system_sleep']:return False
        if feature=='F10':return True  # recording is not an animation/attention request
        if v['do_not_disturb'] or c['task'] or not c['visible'] or c.get('dragging',False):return False
        if self.now()<self._cooldowns.get(feature,0):return False
        phase=c['phase']
        if feature=='F03' and (not c.get('dream_enabled',True) or not c.get('bubbles_enabled',True) or v['reduced_motion']):return False
        if phase in self.PROTECTED or c['care']:return False
        if feature=='F09':return phase in ('idle','angry','sleeping')  # never edits sulking/count
        if feature=='F05':return not v['reduced_motion'] and phase in ('idle','daily','sleeping','angry')
        if c['sulking']:return False
        if feature=='F03':
            return phase=='sleeping' and not (c.get('bubble_active',False) and self.active!='F03')
        if feature=='F01':return phase in ('idle','daily')
        return phase=='idle'
    allowed=can_start  # backwards-compatible start-only query
    def can_continue(self,token):
        effect=self._effects.get(getattr(token,'channel',None))
        if not effect or effect.token!=token or self.closed:return False
        c=self.context();v=self.preferences.values
        if c['game'] or c['system_sleep'] or not v[token.feature]:return False
        if v['do_not_disturb'] or c['task'] or not c['visible'] or c.get('dragging',False):return False
        if c['phase'] in self.PROTECTED or c['care']:return False
        if token.feature=='F05' and v['reduced_motion']:return False
        if effect.owned_phase is not None and c['phase']==effect.owned_phase:return True
        return self.can_start(token.feature)
    def activate(self,token,phase,apply):
        effect=self._effects.get(getattr(token,'channel',None))
        if not effect or effect.token!=token or not self.can_continue(token):return False
        if phase not in ('daily','companion','minigame'):raise ValueError('protected activity phase')
        effect.owned_phase=phase  # set before synchronous Qt changed signals
        try:apply()
        except Exception:self.finish(token);raise
        return self.can_continue(token)
    def _start(self,feature,channel,cancel,duration,cooldown):
        self.refresh()
        if not callable(cancel):raise TypeError('cancel callback required')
        if not all(type(x) in (int,float) and math.isfinite(x) for x in (duration,cooldown)) or not 0<duration<=(300 if feature=='F08' else 10) or not 0<=cooldown<=86400:raise ValueError('invalid lease timing')
        if not self.can_start(feature) or channel in self._effects:return None
        if channel=='visual':
            self._cancel_channels(('overlay',))
        elif channel=='overlay' and self.active:return None
        # Cleanup may close the controller or change phase synchronously.
        if not self.can_start(feature) or channel in self._effects:return None
        self._generation+=1;token=EventToken(self._generation,feature,channel)
        self._effects[channel]=Effect(token,cancel,self.now()+duration,cooldown);return token
    def claim(self,feature,cancel,*,duration=8,cooldown=0):
        if feature in ('F01','F05','F10'):return None
        self.refresh();old=self._effects.get('visual')
        if old:
            if not self.can_start(feature) or self.PRIORITY.get(feature,0)<=self.PRIORITY.get(old.token.feature,0):return None
            self._cancel_channels(('visual',))
        return self._start(feature,'visual',cancel,duration,cooldown)
    def observe(self,cancel,*,duration=8):return self._start('F01','observation',cancel,duration,0)
    def overlay(self,cancel,*,duration=3):return self._start('F05','overlay',cancel,duration,0)
    def release(self,token):
        effect=self._effects.get(getattr(token,'channel',None))
        if effect is None or effect.token!=token:return False
        self._cancel_channels((token.channel,));return True
    finish=release
    def _cancel_channels(self,channels):
        if self._cancelling:return
        effects=[self._effects.pop(ch) for ch in channels if ch in self._effects]
        self._cancelling=True
        try:
            for effect in effects:
                self._cooldowns[effect.token.feature]=self.now()+effect.cooldown
                try:effect.cancel()
                except Exception:logging.getLogger('qiaomi').exception('Companion cleanup failed')
        finally:self._cancelling=False
        if self._cancel_requested or self.closed:
            self._cancel_requested=False
            if self._effects:self._cancel_channels(tuple(self._effects))
    def cancel(self):
        if self._cancelling:self._cancel_requested=True;return
        self._cancel_channels(tuple(self._effects))
    def refresh(self):
        if self._cancelling:return
        self._cancel_channels(tuple(ch for ch,e in self._effects.items() if self.now()>=e.expires or not self.can_continue(e.token)))
    def record(self,event_id,writer):
        if not isinstance(event_id,str) or not 1<=len(event_id)<=120:raise ValueError('invalid event receipt')
        if not self.can_start('F10') or event_id in self._receipts:return False
        if not callable(writer):raise TypeError('writer required')
        # Reserve before the callback so recursive signals cannot double-write.
        self._receipts[event_id]=None
        try:writer()
        except Exception:del self._receipts[event_id];raise
        while len(self._receipts)>4096:self._receipts.popitem(last=False)
        return True
    def close(self):self.closed=True;self.cancel()
