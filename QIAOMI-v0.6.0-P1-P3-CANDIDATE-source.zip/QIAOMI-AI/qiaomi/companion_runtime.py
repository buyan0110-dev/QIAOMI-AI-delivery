"""P1 local producers. One 2s heartbeat, bounded effects, near-only cursor reads.
No global hooks, audio, model calls, screenshots or input/content persistence.
"""
import ctypes,sys,time,random
from collections import deque
from PySide6.QtCore import QObject,QTimer,QPointF
from PySide6.QtGui import QCursor
from .habitat import foreground_allows_motion

MICROS=('ear_scratch','tail_curl','shy','peek','doze','roll','proud')
DREAMS=(('fish','梦到好多小鱼干……'),('yarn','毛线球带敲咪去旅行……'),('crown','敲咪是小猫国王……'),('penguin','坏企鹅，不许抢鱼干……'),('heart','妈妈抱着敲咪睡……'),('cloud','软绵绵的云朵小窝……'))

def idle_seconds():
    if sys.platform!='win32':return None
    from ctypes import wintypes
    class LASTINPUTINFO(ctypes.Structure):_fields_=[('cbSize',wintypes.UINT),('dwTime',wintypes.DWORD)]
    value=LASTINPUTINFO();value.cbSize=ctypes.sizeof(value)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(value)):return None
    tick=ctypes.windll.kernel32.GetTickCount64;tick.restype=ctypes.c_ulonglong
    return ((tick()&0xffffffff)-value.dwTime&0xffffffff)/1000

class CompanionRuntime(QObject):
    def __init__(self,c,parent=None,*,now=time.monotonic,cursor=QCursor.pos,idle=idle_seconds,foreground=foreground_allows_motion,rng=None):
        super().__init__(parent);self.c=c;self.pet=c.pet;self.policy=c.companion_policy;self.now=now;self.cursor=cursor;self.idle=idle;self.foreground=foreground;self.rng=rng or random.Random();self.closed=False
        self.effects={};self.clicks=deque(maxlen=3);self.moves=deque(maxlen=8);self.pending=None;self.away=False;self.last_return=-1e9;self.next_micro=now()+120;self.next_watch=0
        self.timer=QTimer(self);self.timer.setInterval(2000);self.timer.timeout.connect(self.tick)
        self.motion=QTimer(self);self.motion.setInterval(120);self.motion.timeout.connect(self.track)
        self.end=QTimer(self);self.end.setSingleShot(True);self.end.timeout.connect(self.finish_due)
        c.personality.changed.connect(lambda _:self.sync());c.care.changed.connect(self.sync);self.pet.visibility_changed.connect(lambda _:self.sync())
        self.pet.interaction.connect(self.touched);self.pet.ambient_pointer.connect(self.local_motion)
        self.pet.drag_started.connect(self.dragged)
        self.sync()
    def enabled(self):
        c=self.c;v=c.companion_preferences.values
        return not (self.closed or c.game_mode or c.care.system_paused or c.care.task_paused or c.care.busy() or v['do_not_disturb'] or v['reduced_motion']) and self.pet.isVisible() and any(v[f] for f in ('F01','F02','F03','F05','F06','F07','F09'))
    def sync(self):
        self.policy.refresh()
        if self.enabled():
            if not self.timer.isActive():self.timer.start()
        else:
            self.timer.stop();self.motion.stop();self.end.stop()
            # A sleeping ambient producer must not revoke an external F08 lease.
            for token in tuple(self.effects):self.policy.finish(token)
            self.clicks.clear();self.moves.clear();self.pending=None;self.away=False
        self._schedule_end()
    def start(self,feature,kind,seconds=3,text='',icon=''):
        if not self.enabled():return False
        holder={}
        def clear():
            token=holder.get('token');self.effects.pop(token,None)
            if getattr(self.pet,'ambient_visual',None) and self.pet.ambient_visual.get('token')==token:
                self.pet.ambient_visual=None;self.pet.update()
            if text and self.pet._bubble==text:self.pet.clear_bubble()
            if feature=='F01':self.motion.stop()
            pose=holder.get('pose')
            if pose and self.c.personality.phase=='companion':
                p=self.c.personality;phase,state,timers=pose
                if feature=='F09' and phase=='sleeping':phase,state,timers='idle','idle',[]
                p._set_phase(phase)
                if self.enabled() and not p.dormant:
                    self.pet.play_clip(state,0)
                    for timer,left in timers:
                        if left>0:timer.start(left)
                    if phase=='idle':p.schedule()
            self._schedule_end()
        if feature=='F05':token=self.policy.overlay(clear,duration=seconds)
        elif feature=='F01':token=self.policy.observe(clear,duration=seconds)
        else:token=self.policy.claim(feature,clear,duration=seconds,cooldown=30 if feature=='F03' else 0)
        if not token:return False
        holder['token']=token;self.effects[token]=self.now()+seconds
        self.pet.ambient_visual=dict(token=token,kind=kind,start=self.now(),icon=icon,look=0.)
        if text and self.c.personality_preferences.values['bubbles_enabled']:self.pet.show_bubble(text);self.pet.bubble_timer.start(round(seconds*1000))
        if feature=='F01':self.motion.start()
        if feature in ('F06','F07','F09'):
            p=self.c.personality;timers=[(timer,timer.remainingTime()) for timer in (p.next_action,p.phase_timer,p.mood_timer)]
            holder['pose']=(p.phase,self.pet.state,timers)
            for timer,_ in timers:timer.stop()
            if not self.policy.activate(token,'companion',lambda:p._set_phase('companion')):
                self.policy.finish(token);return False
            clip='attention_wave' if feature=='F09' else 'attention_reach'
            if feature=='F07':
                from .companion_stories import PRANKS
                clip=PRANKS[kind.removeprefix('prank_')][0]
            self.pet.play_clip(clip,round(seconds*1000))
        self.pet.update();self._schedule_end();return True
    def _schedule_end(self):
        if self.closed or not self.effects:self.end.stop();return
        self.end.start(max(1,round((min(self.effects.values())-self.now())*1000)))
    def finish_due(self):
        for token,deadline in list(self.effects.items()):
            if self.now()>=deadline:self.policy.finish(token)
        self._schedule_end()
    def dream(self):
        p=self.c.personality
        if not p._can_dream():return False
        icon,text=self.rng.choice(DREAMS);return self.start('F03','dream',6,text,icon)
    def touched(self,zone):
        self.away=False
        if self.c.personality.life.sulking:return
        self.clicks.append(self.now())
        if len(self.clicks)==3 and self.clicks[-1]-self.clicks[0]<=2:self.pending=self.now()+6;self.clicks.clear()
    def dragged(self):self.pending=None;self.clicks.clear();self.moves.clear();self.away=False
    def local_motion(self,x,y):
        if not self.enabled() or not self.c.companion_preferences.values['F06']:return
        self.moves.append((self.now(),x))
        if len(self.moves)>=6 and self.moves[-1][0]-self.moves[0][0]<2:
            directions=[b[1]-a[1] for a,b in zip(self.moves,list(self.moves)[1:])]
            if sum(a*b<0 for a,b in zip(directions,directions[1:]))>=3:self.pending=self.now()+6;self.moves.clear()
    def track(self):
        if not self.enabled() or not self.pet.ambient_visual or self.pet.ambient_visual['kind']!='watch':self.motion.stop();return
        point=self.pet.mapFromGlobal(self.cursor());dx=point.x()-150;dy=point.y()-190
        if dx*dx+dy*dy>180**2:self.policy.finish(self.pet.ambient_visual['token']);return
        self.pet.ambient_visual['look']=max(-1,min(1,dx/90));self.pet.update()
    def returned(self):
        if not self.enabled() or self.now()-self.last_return<3600 or not self.foreground():return False
        text='妈妈回来啦……哼！敲咪还在等摸摸呢。' if self.c.personality.life.sulking else '妈妈回来啦！敲咪一直乖乖等你哦。'
        if self.start('F09','greet',5,text,'heart'):self.last_return=self.now();return True
        return False
    def tick(self):
        if not self.enabled():self.sync();return
        self.policy.refresh();v=self.c.companion_preferences.values
        if v['F09']:
            idle=self.idle()
            if idle is not None:
                if idle>=900:self.away=True
                elif idle<5 and self.away:self.away=False;self.returned()
        if self.pending:
            if self.now()>self.pending:self.pending=None
            elif self.policy.can_start('F06') and self.start('F06','imitate',3,'妈妈这样，敲咪也这样！'):self.pending=None
        if hasattr(self.c,'companion_stories'):self.c.companion_stories.tick()
        if self.pet.ambient_visual:return
        if v['F01'] and self.now()>=self.next_watch and self.policy.can_start('F01'):
            point=self.pet.mapFromGlobal(self.cursor())
            if (point.x()-150)**2+(point.y()-190)**2<=180**2:
                if self.start('F01','watch',5):self.next_watch=self.now()+20;self.track();return
        if v['F05'] and self.now()>=self.next_micro:
            mood=self.c.care.state.values['mood'];energy=self.c.care.state.values['energy']
            choices=('peek','tail_curl') if self.c.personality.life.sulking else (('doze','ear_scratch') if energy<35 else (('shy','peek') if mood<40 else MICROS))
            if self.start('F05',self.rng.choice(choices),3):self.next_micro=self.now()+self.rng.uniform(120,240)
    def close(self):
        self.closed=True;self.timer.stop();self.motion.stop();self.end.stop();self.policy.cancel();self.pending=None;self.pet.ambient_visual=None
