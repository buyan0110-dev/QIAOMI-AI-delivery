"""P2 event producer using the shared heartbeat and effective life clock."""
import logging,uuid
from .companion_data import ITEMS
PRANKS={'snack':('daily_eat','喵？！没有偷吃，鱼干先藏起来！','🐟'), 'box':('attention_reach','纸箱卡住啦……妈妈摸一下就出来。','📦'), 'tail':('daily_yarn','追自己的尾巴转晕啦……','〰'), 'hiccup':('daily_doze','嗝……敲咪什么都没说！','♪')}
class CompanionStories:
 def __init__(self,c):
  self.c=c;self.r=c.companion_runtime;self.data=c.companion_data;self.next_prank=c.care.effective+240;self.next_find=c.care.effective+self.r.rng.uniform(1800,5400)
  self.last_sulk=c.personality.life.sulking
  c.pet.interaction.connect(self.touch);c.care.completed.connect(self.completed);c.personality.changed.connect(self.phase)
 def safe_event(self,identifier,kind,**kwargs):
  if self.c.shutting_down or self.c.game_mode or self.c.care.system_paused:return False
  record=self.c.companion_preferences.values['F10']
  # Optional recording is independent of visual eligibility/DND and durable receipts.
  if not record and not kwargs.get('item'):return False
  try:return self.data.event(identifier,kind,record=record,**kwargs)
  except Exception:
   logging.getLogger('qiaomi').exception('Companion event storage failed');self.c.life_notice('小世界记录暂未保存；原长期记忆未修改。');return False
 def touch(self,zone):self.safe_event('first-touch','touch')
 def completed(self,name):
  if name in ('fish','bowl','quick_feed'):self.safe_event('first-feed','feed')
  if name in ('bath','quick_wash','auto_wash'):self.safe_event('first-bath','bath')
 def phase(self,phase):
  current=self.c.personality.life.sulking
  if self.last_sulk and not current:self.safe_event('first-soothe','soothe')
  self.last_sulk=current
 def prank(self,key):
  if key not in PRANKS:raise ValueError('unknown prank')
  clip,text,icon=PRANKS[key]
  return self.r.start('F07','prank_'+key,6,text,icon)
 def find(self,item=None):
  if not self.c.companion_policy.can_start('F02'):return False
  item=item or self.r.rng.choice(list(ITEMS));name,icon,_=ITEMS[item]
  # Commit once before the visual; cancelling the bubble does not lose the gift.
  if not self.safe_event('gift-'+uuid.uuid4().hex,'gift',item=item):return False
  self.r.start('F02','gift',3,'敲咪捡到'+name+'，收进宝贝箱啦！',icon);return True
 def tick(self):
  c=self.c
  if not self.r.enabled():return
  t=c.care.effective
  if t>=self.next_find and c.companion_policy.can_start('F02'):
   if self.find():self.next_find=t+self.r.rng.uniform(1800,5400);return
  if c.care.idle_seconds>=180 and t>=self.next_prank and c.companion_policy.can_start('F07'):
   self.next_prank=t+self.r.rng.uniform(180,300)
   if self.r.rng.random()<.4:self.prank(self.r.rng.choice(list(PRANKS)))
 def reset(self):
  t=self.c.care.effective;self.next_prank=t+240;self.next_find=t+self.r.rng.uniform(1800,5400)
