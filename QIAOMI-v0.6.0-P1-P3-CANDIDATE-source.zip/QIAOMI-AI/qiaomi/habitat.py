"""Four-edge homes and bounded, interruptible, temporary central seeking."""
import ctypes
import logging
import os
import sys
import time
from PySide6.QtCore import QObject,QRect,QPoint,QTimer,QVariantAnimation,QEasingCurve
from PySide6.QtWidgets import QApplication
from .ui.pet import clamp_window_position
log=logging.getLogger('qiaomi')
EDGES=('top','bottom','left','right')

def snap_position(rect,areas,enabled=True,threshold=32):
    if not areas:return rect.topLeft(),None
    area=max(areas,key=lambda a:(rect.intersected(a).width()*rect.intersected(a).height(),-((a.center()-rect.center()).manhattanLength())))
    pos=clamp_window_position(rect,areas)
    r=QRect(pos,rect.size())
    distances={'top':abs(r.top()-area.top()),'bottom':abs(r.bottom()-area.bottom()),'left':abs(r.left()-area.left()),'right':abs(r.right()-area.right())}
    edge=min(distances,key=distances.get)
    if not enabled or distances[edge]>threshold:return pos,None
    if edge=='top':pos.setY(area.top())
    elif edge=='bottom':pos.setY(area.bottom()-rect.height()+1)
    elif edge=='left':pos.setX(area.left())
    else:pos.setX(area.right()-rect.width()+1)
    return pos,edge


def foreground_allows_motion(*,platform=None):
    """Read-only Win32 APIs, no hooks/capture/process enumeration. Fail closed."""
    if (platform or sys.platform)!='win32':return False
    try:
        from ctypes import wintypes as w
        u=ctypes.windll.user32
        u.GetForegroundWindow.restype=w.HWND
        u.OpenInputDesktop.restype=w.HANDLE
        u.OpenInputDesktop.argtypes=[w.DWORD,w.BOOL,w.DWORD]
        u.CloseDesktop.argtypes=[w.HANDLE]
        u.GetUserObjectInformationW.argtypes=[w.HANDLE,ctypes.c_int,w.LPVOID,w.DWORD,ctypes.POINTER(w.DWORD)]
        desktop=u.OpenInputDesktop(0,False,1)
        if not desktop:return False
        try:
            buf=ctypes.create_unicode_buffer(256);needed=w.DWORD()
            if not u.GetUserObjectInformationW(desktop,2,buf,ctypes.sizeof(buf),ctypes.byref(needed)) or buf.value.lower()!='default':return False
        finally:u.CloseDesktop(desktop)
        hwnd=u.GetForegroundWindow()
        if not hwnd:return False
        u.GetWindowThreadProcessId.argtypes=[w.HWND,ctypes.POINTER(w.DWORD)]
        pid=w.DWORD();u.GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value==os.getpid():return True
        name=ctypes.create_unicode_buffer(128);u.GetClassNameW.argtypes=[w.HWND,w.LPWSTR,ctypes.c_int];u.GetClassNameW(hwnd,name,128)
        if name.value in ('Progman','WorkerW','Shell_TrayWnd'):return True
        rect=w.RECT();u.GetWindowRect.argtypes=[w.HWND,ctypes.POINTER(w.RECT)]
        if not u.GetWindowRect(hwnd,ctypes.byref(rect)):return False
        class Monitor(ctypes.Structure):_fields_=[('cbSize',w.DWORD),('rcMonitor',w.RECT),('rcWork',w.RECT),('dwFlags',w.DWORD)]
        u.MonitorFromWindow.argtypes=[w.HWND,w.DWORD];u.MonitorFromWindow.restype=w.HMONITOR
        u.GetMonitorInfoW.argtypes=[w.HMONITOR,ctypes.POINTER(Monitor)]
        info=Monitor();info.cbSize=ctypes.sizeof(info)
        if not u.GetMonitorInfoW(u.MonitorFromWindow(hwnd,2),ctypes.byref(info)):return False
        m=info.rcMonitor
        return not (rect.left<=m.left+2 and rect.top<=m.top+2 and rect.right>=m.right-2 and rect.bottom>=m.bottom-2)
    except Exception:
        log.exception('Foreground safety check failed; seeking deferred');return False

class Habitat(QObject):
    def __init__(self,pet,engine,desktop,save,guard=foreground_allows_motion,parent=None):
        super().__init__(parent);self.pet=pet;self.engine=engine;self.desktop=desktop;self.save=save;self.guard=guard
        self.edge=desktop.values.get('edge')
        if self.edge is None and desktop.values.get('position') is None and desktop.values.get('snap_enabled',True):
            _,self.edge=snap_position(pet.geometry(),[s.availableGeometry() for s in QApplication.screens()]);desktop.values['edge']=self.edge
        self.transient=False;self.origin=None;self.seek_done=False;self.deferred=False;self.guard_at=0
        self.exit_timer=QTimer(self);self.exit_timer.setSingleShot(True);self.exit_timer.timeout.connect(self._walk)
        self.motion=QVariantAnimation(self);self.motion.setDuration(2200);self.motion.setEasingCurve(QEasingCurve.Type.InOutSine);self.motion.valueChanged.connect(self._step);self.motion.finished.connect(self._arrived)
        pet.drag_finished.connect(self.place);pet.drag_started.connect(lambda:self.cancel(restore=False));pet.habitat_changed.connect(self.reflow)
        pet.visibility_changed.connect(self._visibility);engine.seek_requested.connect(self.request_seek);engine.changed.connect(self._phase)
        pet.perch_edge=self.edge
    def areas(self):return [s.availableGeometry() for s in QApplication.screens()]
    def _move(self,pos):
        previous=self.transient;self.transient=True;self.pet.move(pos);self.transient=previous
    def reflow(self):
        if self.engine.dormant or self.transient or self.pet._dragged:return
        areas=self.areas()
        if not areas:return
        pos=clamp_window_position(self.pet.geometry(),areas)
        if self.edge:
            area=max(areas,key=lambda a:a.intersected(QRect(pos,self.pet.size())).width()*a.intersected(QRect(pos,self.pet.size())).height())
            if self.edge=='top':pos.setY(area.top())
            elif self.edge=='bottom':pos.setY(area.bottom()-self.pet.height()+1)
            elif self.edge=='left':pos.setX(area.left())
            else:pos.setX(area.right()-self.pet.width()+1)
        self._move(pos);self.pet.perch_edge=self.edge;self.pet.update_chrome();self.pet.update()
    def place(self):
        if self.engine.dormant:return
        self.cancel(restore=False)
        pos,self.edge=snap_position(self.pet.geometry(),self.areas(),self.desktop.values.get('snap_enabled',True))
        self._move(pos);self.pet.perch_edge=self.edge;self.pet.update_chrome();self.pet.update()
        self.desktop.values['position']={'x':pos.x(),'y':pos.y()};self.desktop.values['edge']=self.edge
        self.desktop.values['screen_name']=self.pet.screen().name() if self.pet.screen() else ''
        self.save()
    def set_snap(self,enabled):
        self.desktop.values['snap_enabled']=bool(enabled)
        if not enabled:self.edge=None;self.pet.perch_edge=None;self.desktop.values['edge']=None;self.pet.update_chrome();self.pet.update()
        self.save()
    def request_seek(self,*,retry=False):
        if self.seek_done or self.motion.state()==QVariantAnimation.State.Running or self.exit_timer.isActive():return False
        if self.deferred and not retry:return False
        if self.engine.phase not in ('idle','angry') or self.engine.reunion_session or self.engine.busy():return False
        if self.engine.dormant or self.engine.closed or not self.engine.life.sulking or self.engine.life.soothe_count or self.pet._dragged or not self.pet.isVisible() or not self.engine.preferences.values.get('seek_enabled',True):return False
        if not self.edge:return False
        if not self.guard():self.deferred=True;return False
        state='exit_'+self.edge
        if any(s not in self.pet.sprites.animations for s in (state,'walk_center')):
            self.engine.resource_notice.emit('缺少边缘爬出或行走素材，未移动窗口。');self.deferred=True;return False
        self.deferred=False;self.seek_done=True;self.origin=self.pet.pos();self.transient=True
        self.engine.mood_timer.stop();self.engine.phase_timer.stop();self.engine.next_action.stop();self.engine._set_phase('seek')
        self.pet.play_clip(state,700);self.exit_timer.start(700)
        if self.engine.preferences.values['bubbles_enabled']:self.pet.show_bubble('妈妈！！！敲咪生胖气啦！！！')
        return True
    def _walk(self):
        if self.engine.dormant or self.pet._dragged or not self.guard():self.cancel();return
        area=self.pet.screen().availableGeometry();target=area.center()-self.pet.rect().center()
        self.pet.play_clip('walk_center',2200);self.guard_at=time.monotonic()
        self.motion.setStartValue(self.pet.pos());self.motion.setEndValue(target);self.motion.start()
    def _step(self,pos):
        if self.engine.dormant or self.pet._dragged:self.cancel();return
        if time.monotonic()-self.guard_at>=.2:
            self.guard_at=time.monotonic()
            if not self.guard():self.cancel();self.pet.hide();return
        self.pet.move(pos)
    def _arrived(self):
        if self.engine.dormant:return
        self.engine._set_phase('angry');self.pet.play_clip('angry_tail',1800);self.engine.mood_timer.start(8000)
    def cancel(self,restore=True):
        self.exit_timer.stop();self.motion.stop()
        if restore and self.origin is not None:self._move(self.origin)
        self.origin=None;self.transient=False
        if not restore:
            self.edge=None;self.pet.perch_edge=None
        if self.engine.phase=='seek' and not self.engine.dormant:
            self.engine._set_phase('angry');self.engine.mood_timer.start(8000)
    def _phase(self,phase):
        if phase=='idle' and (self.exit_timer.isActive() or self.motion.state()==QVariantAnimation.State.Running):self.cancel()
        if phase in ('dormant','closed') or self.engine.closed:self.cancel()
        elif phase=='idle' and not self.engine.life.sulking:
            self.cancel();self.seek_done=False;self.deferred=False
        elif phase in ('soothing','finish','touch','comfort') and (self.motion.state()==QVariantAnimation.State.Running or self.exit_timer.isActive()):self.cancel()
    def _visibility(self,shown):
        if not shown:self.cancel()
        elif self.deferred:self.request_seek(retry=True)
    def close(self):self.cancel()
