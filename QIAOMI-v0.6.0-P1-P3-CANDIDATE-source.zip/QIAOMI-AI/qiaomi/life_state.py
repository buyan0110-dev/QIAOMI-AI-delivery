"""Entertainment values only. No offline decay, health, currency or model calls."""
import json,math,os,tempfile,time,uuid
from pathlib import Path
from datetime import datetime,timezone

DEFAULTS={'hunger_satiety':80.,'cleanliness':90.,'energy':80.,'mood':80.,'automatic_care':True,'autonomous_fun':True}
VALUES=('hunger_satiety','cleanliness','energy','mood')
# Units per minute of eligible active running time, intentionally slow.
DECAY={'hunger_satiety':.12,'cleanliness':.06,'energy':.10,'mood':.025}
TICK_MS=5000
MAX_ACTIVE_GAP=15.
SAVE_SECONDS=60.
AUTO_GRACE=15.
AUTO_COOLDOWN=60.
FUN_IDLE=(180.,300.)
QUICK_DEBOUNCE=2.

class LifeState:
    def __init__(self,folder):
        self.path=Path(folder)/'life.json';self.values=dict(DEFAULTS);self.dirty=False;self.read_error=False;self.save_count=0
        try:
            if self.path.stat().st_size>65536:raise ValueError('oversized life state')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict) or type(raw.get('schema',1)) is not int or raw.get('schema',1)!=1:raise ValueError('invalid life state')
            self.values.update(raw)
            for key in VALUES:
                v=raw.get(key,DEFAULTS[key]);valid=type(v) in (int,float) and math.isfinite(v)
                self.values[key]=min(100.,max(0.,float(v))) if valid else DEFAULTS[key]
                if not valid or not 0<=v<=100:self.read_error=True;self.dirty=True
            for key in ('automatic_care','autonomous_fun'):
                self.values[key]=raw.get(key,True) if type(raw.get(key,True)) is bool else True
                if type(raw.get(key,True)) is not bool:self.read_error=True;self.dirty=True
        except FileNotFoundError:pass
        except (OSError,ValueError,TypeError,RecursionError):self.read_error=True;self.dirty=True;self.values=dict(DEFAULTS)
    def change(self,**changes):
        for key,value in changes.items():
            if key in VALUES:
                if type(value) not in (int,float) or not math.isfinite(value):continue
                value=min(100.,max(0.,float(value)))
            elif key in ('automatic_care','autonomous_fun'):
                if type(value) is not bool:continue
            else:continue
            if self.values.get(key)!=value:self.values[key]=value;self.dirty=True
    def add(self,**changes):self.change(**{key:self.values[key]+delta for key,delta in changes.items() if key in VALUES})
    def advance(self,seconds,*,resting=False,bored=False):
        if type(seconds) not in (int,float) or not math.isfinite(seconds) or not 0<seconds<=MAX_ACTIVE_GAP:return
        delta={key:-rate*seconds/60 for key,rate in DECAY.items() if key!='mood' or bored}
        if resting:delta['energy']=4*seconds/60
        self.add(**delta)
    def save(self):
        if not self.dirty and self.path.exists():return False
        self.path.parent.mkdir(parents=True,exist_ok=True)
        if self.read_error and self.path.exists():
            self.path.with_name('life.invalid-'+uuid.uuid4().hex+'.json').write_bytes(self.path.read_bytes());self.read_error=False
        raw=dict(self.values,schema=1,last_saved_at=datetime.now(timezone.utc).isoformat());temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.life-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name);json.dump(raw,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path);self.values=raw;self.dirty=False;self.save_count+=1
            return True
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
