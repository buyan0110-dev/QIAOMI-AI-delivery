"""Finite local character scripts; never trigger AI or write long-term memory."""
REUNION_STATES={
 'reunion_wakeup':'睡醒揉眼睛','reunion_surprised':'发现妈妈啦','reunion_cry':'泪眼汪汪',
 'reunion_run':'跑来找妈妈','reunion_hug':'伸爪求抱抱','reunion_pout':'鼓脸偷看',
 'reunion_happy':'被哄开心啦','reunion_cuddle':'撒娇依偎',
}
ATTENTION_STATES={
 'attention_wave':'向妈妈挥爪','attention_tilt':'歪头等摸摸','attention_reach':'伸爪求摸摸',
 'attention_tail':'抱尾巴卖萌','attention_jump':'开心蹦跳','attention_cry':'假装委屈',
 'attention_pout':'鼓脸偷看','attention_roll':'开心打滚','attention_search':'睡醒找妈妈',
}
REUNION_STAGES=[('reunion_wakeup',1100),('reunion_surprised',900),('reunion_cry',1200),('reunion_run',1300),('reunion_hug',1300)]
CORE_LINE='妈妈！！！你怎么才回来！！！'
REUNION_LINES=[
 '呜呜呜……敲咪等你好久啦！','妈妈！！敲咪还以为你不要我了！','不管！现在必须抱抱敲咪！',
 '敲咪都快变成望妈石了！！','哼！这次要摸头十下才原谅妈妈！',
 '妈妈！！你终于想起家里还有一只小猫咪啦！','呜……敲咪的肉垫都等凉了！',
]
ATTENTION_LINES={
 'attention_wave':'妈妈，敲咪在这里呀！','attention_tilt':'可以分一点点注意力给敲咪嘛？',
 'attention_reach':'就摸一下下，好不好？','attention_tail':'尾巴抱好啦，还差妈妈的抱抱。',
 'attention_jump':'嘿！妈妈看敲咪！','attention_cry':'呜……就想蹭蹭妈妈。',
 'attention_pout':'哼，敲咪只是刚好坐在这里。','attention_roll':'妈妈最喜欢敲咪啦！',
 'attention_search':'妈妈在这里，敲咪就放心啦。',
}
FREQUENCIES={'low':(600,900),'normal':(240,420),'high':(120,240)}

DAILY_STATES={
 'daily_eat':'小鱼干开饭啦','daily_doze':'脑袋一点一点','daily_sleep':'蜷成小橘团睡觉',
 'daily_game':'金丝眼镜游戏时间','daily_wash':'认真洗脸','daily_stretch':'伸长小猫腰','daily_yarn':'扑扑毛线球',
}
MOOD_STATES={
 'angry_back':'哼，背对妈妈','angry_tail':'抱尾巴生闷气','angry_peek':'偷偷看妈妈',
 'comfort_soft':'第二下，有点心软','comfort_nuzzle':'第三下，悄悄蹭鼠标',
 'welcome':'探头眨眼挥爪跳出来',
}
DREAM_LINES=('唔……妈妈……','小鱼干……','坏企鹅……不许欺负敲咪……','再睡五分钟……')
SOOTHE_STEPS={
 1:('angry_back','哼……第一下还不够，敲咪还在生气。'),
 2:('comfort_soft','第二下……才没有心软呢。'),
 3:('comfort_nuzzle','第三下……就偷偷蹭一下妈妈的鼠标。'),
 4:('reunion_happy','第四下！原谅妈妈啦，抱抱敲咪！'),
}

DAILY_STATES.update(daily_read='戴金丝眼镜看书翻页',daily_prone='趴着呼噜睡觉')
EXTRA_STATES={
 **{'edge_'+s:'栖息 · '+s for s in ('top','bottom','left','right')},
 **{'exit_'+s:'从边缘爬出 · '+s for s in ('top','bottom','left','right')},
 'walk_center':'气鼓鼓走向中央','finish_book':'合书放下','finish_game':'放下游戏机','finish_eat':'吃完舔嘴','wakeup_sit':'揉眼坐起','return_idle':'回到基础坐姿','reunion_box':'纸盒里睡醒',
 'reconcile':'举爪求抱抱和好','daily_game_win':'游戏赢啦','daily_game_loss':'气鼓鼓继续玩','doze_startle':'打瞌睡惊醒','wash_hood':'洗脸整理帽子',
}
DREAM_LINES=('唔……妈妈……','小鱼干……嘿嘿……','坏企鹅……走开……','不要抢敲咪的游戏机……','妈妈……再摸摸头……','再睡五分钟……')
SOOTHE_STEPS.update({1:('reunion_pout','哼！现在才想起敲咪！'),2:('comfort_soft','……敲咪才没有这么容易被哄好！'),3:('comfort_nuzzle','……再摸一下嘛。'),4:('reconcile','妈妈！！！！抱抱！！！')})
REUNION_STAGES.insert(0,('reunion_box',1000))
