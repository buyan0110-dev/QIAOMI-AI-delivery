"""Read-only Windows suspend notifications, no hooks or polling."""
import ctypes,sys
from PySide6.QtCore import QAbstractNativeEventFilter

class PowerMonitor(QAbstractNativeEventFilter):
    def __init__(self,callback):super().__init__();self.callback=callback
    def dispatch(self,message,wparam):
        if message!=0x218:return False
        if wparam==4:self.callback(True);return True
        if wparam in (7,18):self.callback(False);return True
        return False
    def nativeEventFilter(self,event_type,message):
        if sys.platform=='win32':
            from ctypes import wintypes
            try:
                data=wintypes.MSG.from_address(int(message));self.dispatch(data.message,int(data.wParam))
            except (TypeError,ValueError):pass
        return False,0
