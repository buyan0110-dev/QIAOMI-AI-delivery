"""Bounded procedural P1 overlays; never redraw cat anatomy or add a tail."""
import math,time
from PySide6.QtCore import QPointF,Qt
from PySide6.QtGui import QTransform,QColor,QPen,QFont

def transform(visual):
    t=QTransform()
    if not visual:return t
    phase=max(0,time.monotonic()-visual['start']);kind=visual['kind'];wave=math.sin(phase*4)
    angle={'ear_scratch':-3*wave,'tail_curl':wave,'shy':2*wave,'peek':-3,'doze':wave,'roll':7*wave,'proud':0,'watch':visual.get('look',0)*3,'imitate':4*wave,'greet':3*wave}.get(kind,0)
    dy={'doze':2+wave*2,'proud':-2,'greet':-abs(wave)*3,'imitate':abs(wave)*2}.get(kind,0)
    t.translate(150,200+dy);t.rotate(angle);t.translate(-150,-200);return t

def draw(p,visual):
    if not visual:return
    p.save();p.setRenderHint(p.RenderHint.Antialiasing);p.setPen(QPen(QColor('#e995af'),2));p.setBrush(Qt.BrushStyle.NoBrush);p.setFont(QFont('Segoe UI',18))
    kind=visual['kind'];symbols={'ear_scratch':'⌁','tail_curl':'✧','shy':'♡','peek':'…','doze':'z z','roll':'✿','proud':'✦','watch':'·','imitate':'♪','greet':'♡'}
    if kind=='dream':
        p.setBrush(QColor(255,245,249,235));p.drawRoundedRect(105,65,95,48,18,18)
        icon={'fish':'🐟','yarn':'🧶','crown':'♛','penguin':'🐧','heart':'♡','cloud':'☁'}.get(visual['icon'],'☁')
        p.drawText(120,99,icon)
    elif kind.startswith('prank_') or kind=='gift':
        p.drawText(QPointF(205,220),visual.get('icon','✧'))
    else:p.drawText(QPointF(215,100) if kind!='tail_curl' else QPointF(45,235),symbols.get(kind,'✧'))
    p.restore()
