"""Integrated care UI: real controls over lazy local art, single CareEngine owner.
No models, audio, network or hidden-window animation. Artwork is additive.
"""
from pathlib import Path
from collections import OrderedDict
import math,time
from PySide6.QtCore import Qt,QTimer,QRectF,QPointF,QSizeF,Signal
from PySide6.QtGui import QPainter,QPixmap,QColor,QPen,QFont,QPainterPath,QLinearGradient
from PySide6.QtWidgets import (QWidget,QFrame,QLabel,QPushButton,QVBoxLayout,QHBoxLayout,QGridLayout,QProgressBar,QStackedWidget,QScrollArea,QComboBox,QCheckBox,QSizePolicy)

from .window_shell import ActivePageStack,FlexiblePage,FlexibleColumn
from .geometry import contain_rect,scene_viewport,to_scene,from_scene,SCENE_SIZE

ART=Path(__file__).resolve().parents[2]/'assets/butler'
BATH_STEPS=('脱睡衣 · 入浴','搓泡泡','冲洗干净','浴巾 · 吹干','穿回睡衣 · 完成')
FEED_STEPS=('准备小饭碗','一口一口吃','舔舔嘴 · 吃饱啦')

def title(text,name=None):
    w=QLabel(text);w.setWordWrap(True);w.setTextFormat(Qt.TextFormat.PlainText)
    if name:w.setObjectName(name)
    return w

def btn(text,callback,name=None):
    w=QPushButton(text);w.clicked.connect(callback);w.setCursor(Qt.CursorShape.PointingHandCursor)
    if name:w.setObjectName(name)
    return w

class CareArt:
    def __init__(self):self.cache=OrderedDict();self.max_bytes=28_000_000;self.error=''
    def get(self,name):
        if name not in self.cache:
            path=ART/name;p=QPixmap(str(path))
            if p.isNull():self.error='场景素材加载失败：'+name
            self.cache[name]=p
        value=self.cache[name];self.cache.move_to_end(name);self.trim();return value
    def frame(self,index):
        key=('frame',index)
        if key not in self.cache:
            sheet=self.get('care-atlas.png' if index<12 else 'dress-complete.png');col=index%4;row=index//4 if index<12 else 0;rows=3 if index<12 else 1
            left=round(sheet.width()*col/4);right=round(sheet.width()*(col+1)/4);top=round(sheet.height()*row/rows);bottom=round(sheet.height()*(row+1)/rows)
            self.cache[key]=sheet.copy(left,top,right-left,bottom-top)
        value=self.cache[key];self.cache.move_to_end(key);self.trim();return value
    def trim(self):
        while self.bytes>self.max_bytes and len(self.cache)>1:self.cache.popitem(last=False)
    def clear(self):self.cache.clear()
    @property
    def bytes(self):return sum(p.width()*p.height()*4 for p in self.cache.values())

class Stats(QWidget):
    def __init__(self):
        super().__init__();self.bars={};grid=QGridLayout(self);self.grid=grid;self.cards=[];grid.setContentsMargins(0,0,0,0);grid.setSpacing(10)
        for i,(key,label,icon) in enumerate([('hunger_satiety','饱腹度','♧'),('mood','心情值','♡'),('energy','精力值','ϟ'),('cleanliness','清洁度','✧')]):
            card=QFrame();card.setObjectName('careStat');l=QVBoxLayout(card);l.setContentsMargins(14,8,14,10);l.setSpacing(5)
            lab=title(icon+'  '+label);l.addWidget(lab);bar=QProgressBar();bar.setRange(0,100);bar.setFormat('%p%');bar.setMinimumHeight(18);l.addWidget(bar);self.bars[key]=bar;grid.addWidget(card,0,i);self.cards.append(card)
    def resizeEvent(self,event):
        columns=2 if self.width()<600 else 4
        for i,card in enumerate(self.cards):self.grid.addWidget(card,i//columns,i%columns)
        super().resizeEvent(event)
    def sync(self,care):
        for key,bar in self.bars.items():bar.setValue(round(care.state.values[key]))

class CareScene(QWidget):
    touched=Signal(str)
    def __init__(self,kind,art):
        super().__init__();self.kind=kind;self.art=art;self.care=None;self.setObjectName('careScene');self.setMinimumSize(180,140);self.setSizePolicy(QSizePolicy.Policy.Expanding,QSizePolicy.Policy.Expanding);self.setMouseTracking(True)
        self.timer=QTimer(self);self.timer.setInterval(80);self.timer.timeout.connect(self.update);self.pointer=None;self._activity_identity=None;self.suspend=False;self.theme='pink'
    def set_model(self,care):self.care=care;self.sync()
    def owns_activity(self):
        a=self.care.active if self.care else None
        return a if a and ((self.kind=='bath' and a.name in ('bath','quick_wash','auto_wash')) or (self.kind=='feed' and a.name in ('fish','bowl','quick_feed'))) else None
    def sync(self):
        active=self.owns_activity()
        identity=(active.token,active.index) if active else None
        if identity!=self._activity_identity:self.pointer=None;self._activity_identity=identity
        if self.isVisible() and active and not active.paused and not self.suspend and not self.care.dormant and not self.care.system_paused:self.timer.start()
        else:self.timer.stop()
        self.update()
    def hideEvent(self,e):self.timer.stop();super().hideEvent(e)
    def showEvent(self,e):self.sync();super().showEvent(e)
    def set_suspended(self,value):self.suspend=value;self.sync()
    def frame_index(self):
        a=self.owns_activity()
        if not a:return 15
        remaining=a.remaining if a.paused else max(0,a.deadline-self.care.now());duration=a.stages[a.index][2];elapsed=max(0,duration-remaining)
        if self.kind=='bath':
            if a.name=='quick_wash':return 2 if a.index==0 else 6
            if a.index==0:return 0 if elapsed<duration*.45 else 1
            if a.index==1:return 2 if int(elapsed*2)%2==0 else 3
            if a.index==2:return 4
            if a.index==3:return 5 if elapsed<duration*.5 else 6
            return 12+min(3,int(elapsed/max(.01,duration)*4))
        if a.name=='fish':return (8 if int(elapsed*2)%2==0 else 9) if a.index==0 else 11
        if a.name=='bowl' and a.index==0:return 0
        return 10 if remaining>.5 else 11
    def normalized_zone(self,pos):
        r=self.cat_rect();x=(pos.x()-r.x())/max(1,r.width());y=(pos.y()-r.y())/max(1,r.height())
        if not 0<=x<=1 or not 0<=y<=1:return ''
        if y<.45:return 'head'
        if y<.7:return 'back' if x<.35 else 'belly'
        return 'front_left' if y<.88 else 'hind_left'
    def logical_cat_rect(self):
        # Atlas cells have different aspect ratios. Never stretch them to a square.
        if self.suspend or (self.care and self.care.dormant):size=QSizeF(543,724)
        else:size=QSizeF(self.art.frame(self.frame_index()).size())
        return contain_rect(size,QRectF(1536*.20,1024*.035,1536*.60,1024*.94),bottom=True)
    def cat_rect(self):return from_scene(self.logical_cat_rect(),scene_viewport(self.rect()))
    def mousePressEvent(self,e):
        if self.suspend or (self.care and self.care.dormant):return
        if e.button()==Qt.MouseButton.LeftButton:
            self.pointer=e.position();self.touched.emit(self.normalized_zone(e.position()));self.update()
        super().mousePressEvent(e)
    def mouseMoveEvent(self,e):
        active=self.owns_activity()
        if self.suspend or (active and active.paused):return
        self.pointer=e.position()
        if e.buttons()&Qt.MouseButton.LeftButton:self.touched.emit(self.normalized_zone(e.position()))
        if self.timer.isActive():self.update()
        super().mouseMoveEvent(e)
    def manual_hand_visible(self):
        a=self.owns_activity()
        return bool(self.kind=='bath' and a and a.name=='bath' and a.user and a.index==1 and not a.paused and not self.suspend and not self.care.dormant)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        outline=QPainterPath();outline.addRoundedRect(QRectF(self.rect()),16,16);p.setClipPath(outline)
        p.fillRect(self.rect(),QColor('#fbe6ee' if self.theme!='dark' else '#201c29'))
        if self.suspend or (self.care and self.care.dormant):
            p.setPen(QColor('#ac768d'));p.drawText(self.rect(),Qt.AlignmentFlag.AlignCenter,'敲咪在游戏深眠中\n请从系统托盘手动唤醒');return
        viewport=scene_viewport(self.rect())
        if viewport.isEmpty():return
        p.save();p.translate(viewport.topLeft());p.scale(viewport.width()/1536,viewport.height()/1024)
        cw,ch=1536.,1024.;bg=self.art.get('bathroom.png' if self.kind=='bath' else 'home.png')
        if not bg.isNull():p.drawPixmap(QRectF(0,0,cw,ch),bg,QRectF(bg.rect()))
        a=self.owns_activity();r=self.logical_cat_rect();phase=self.care.now() if self.care else time.monotonic()
        if a and not a.paused:r.translate(0,math.sin(phase*2)*2)
        if self.kind!='bath' or not a or (a.name in ('bath','auto_wash') and a.index>=3):
            p.setPen(Qt.PenStyle.NoPen);p.setBrush(QColor(117,59,79,35));p.drawEllipse(QRectF(r.x()+r.width()*.18,ch*.925,r.width()*.64,ch*.035))
        cat=self.art.frame(self.frame_index())
        if not cat.isNull():p.drawPixmap(r,cat,QRectF(cat.rect()))
        if self.kind=='bath':
            # Every bath pose belongs behind the tub, including idle and dressed completion.
            # The front wall is redrawn from the exact same image/transform; paws must
            # never float over its front face. It is not an invented rectangle.
            p.save();p.setClipRect(QRectF(0,ch*.79,cw,ch*.21),Qt.ClipOperation.IntersectClip)
            if not bg.isNull():p.drawPixmap(QRectF(0,0,cw,ch),bg,QRectF(bg.rect()))
            p.restore()
            for i in range(8) if a and (a.name=='quick_wash' or a.index in (1,2)) else ():
                x=cw*(.23+i*.075);y=ch*(.60+(i%3)*.06)+4*math.sin(phase+i);p.setBrush(QColor(245,252,255,160));p.setPen(QPen(QColor(215,241,255,190),2));p.drawEllipse(QPointF(x,y),10+i%3*4,10+i%3*4)
            if a and a.name in ('bath','auto_wash') and a.index==2:
                p.setPen(QPen(QColor(176,231,255,175),3))
                for i in range(7):x=cw*(.35+i*.05);p.drawLine(QPointF(x,ch*.18),QPointF(x-10,ch*.35))
        if self.kind=='bath' and a and a.name in ('bath','auto_wash') and a.index==3:
            x=cw*.82;y=ch*.45;p.setPen(QPen(QColor('#b96e8d'),3));p.setBrush(QColor('#ed9ab7'));p.drawRoundedRect(QRectF(x,y,90,56),18,18)
            for i in range(3):p.drawLine(QPointF(x-6,y+i*20),QPointF(x-60,y+i*20-4*math.sin(phase*4)))
        if self.manual_hand_visible():
            hand=self.art.get('mother-hand.png');anchor=to_scene(self.pointer,viewport) if self.pointer is not None else None
            anchor=anchor or QPointF(r.x()+r.width()*.67,r.y()+r.height()*.48)
            h=r.height()*.70;w=h*hand.width()/max(1,hand.height());hx=min(max(0,anchor.x()-w*.25),max(0,cw-w));hy=min(max(0,anchor.y()-h*.20),max(0,ch-h))
            if not hand.isNull():p.drawPixmap(QRectF(hx,hy,w,h),hand,QRectF(hand.rect()))
        p.restore()
        # Text stays in logical UI pixels, not scaled with the scene artwork.
        message='妈妈，今天也要一起好好生活呀。'
        if a:
            message=('呼噜噜……这里也要揉揉喵。' if self.kind=='bath' and a.index==1 else '妈妈，一小口就好喵！' if self.kind=='feed' else a.stages[a.index][0]+'，妈妈陪着真好。')
            if a.paused:message='已暂停，妈妈慢慢来。'
        if self.width()>=520 and self.height()>=280:
            p.setPen(QPen(QColor('#edafc3'),1.5));p.setBrush(QColor(255,247,250,235));bubble=QRectF(12,12,max(0,min(self.width()-24,350)),48);p.drawRoundedRect(bubble,22,22);p.setPen(QColor('#793b54'));font=QFont(p.font());font.setPixelSize(14);p.setFont(font);p.drawText(bubble.adjusted(8,3,-8,-3),Qt.AlignmentFlag.AlignCenter|Qt.TextFlag.TextWordWrap,message)
        if bg.isNull():p.drawText(QRectF(self.rect()),Qt.AlignmentFlag.AlignCenter,self.art.error)
        if self.theme=='dark':p.fillRect(self.rect(),QColor(15,10,27,50))

class CarePage(FlexiblePage):
    action=Signal(str,str)
    def __init__(self,kind,art):
        super().__init__();self.kind=kind;self.care=None;self.setObjectName('carePage');self.buttons=[]
        layout=FlexibleColumn(self);layout.setContentsMargins(0,0,0,0);layout.setSpacing(10);self.stats=Stats();layout.addWidget(self.stats)
        row=QHBoxLayout();self.scene=CareScene(kind,art);row.addWidget(self.scene,1)
        self.flow=QFrame();self.flow.setObjectName('careFlow');self.flow.setStyleSheet('QLabel#careStep {padding:5px 8px;}');steps=QVBoxLayout(self.flow);steps.setContentsMargins(8,8,8,8);steps.setSpacing(4);steps.addWidget(title('✿  洗澡流程' if kind=='bath' else '♧  喂饭流程','brand'));self.stage_labels=[]
        for i,text in enumerate(BATH_STEPS if kind=='bath' else FEED_STEPS):
            lab=title(str(i+1)+'  '+text);lab.setObjectName('careStep');steps.addWidget(lab);self.stage_labels.append(lab)
        steps.addStretch();self.stage_note=title('准备好再开始，妈妈随时可以取消。','muted');self.stage_note.hide();self.flow_scroll=QScrollArea();self.flow_scroll.setFrameShape(QFrame.Shape.NoFrame);self.flow_scroll.setWidgetResizable(True);self.flow_scroll.setWidget(self.flow);self.flow_scroll.setMinimumWidth(170);self.flow_scroll.setMaximumWidth(240);self.flow_scroll.setStyleSheet('QScrollArea {background:transparent;border:0;}');row.addWidget(self.flow_scroll);layout.addLayout(row,1)
        self.progress=QProgressBar();self.progress.setMinimumHeight(24);layout.addWidget(self.progress)
        controls=QFrame();controls.setObjectName('careControls');controls.setStyleSheet('QPushButton {padding:6px 10px;} QComboBox {padding:6px;}');grid=QGridLayout(controls);self.mode=QComboBox();self.mode.addItem('妈妈帮忙（手动互动）','manual');self.mode.addItem('敲咪自己来（自动流程）','auto');self.mode.addItem('一键完成（短动画）','quick');grid.addWidget(self.mode,0,0,1,2)
        self.start=btn('♡ 开始洗澡' if kind=='bath' else '♧ 喂小鱼干',self.request,'primary');grid.addWidget(self.start,0,2);self.buttons.append(self.start)
        self.bowl=None
        if kind=='feed':self.bowl=btn('喂猫饭',lambda:self.request(food='bowl'));grid.addWidget(self.bowl,0,3);self.buttons.append(self.bowl)
        self.pause=btn('暂停',self.pause_action);grid.addWidget(self.pause,1,0)
        self.next=btn('下一步 / 冲洗' if kind=='bath' else '喂一小口',self.next_action);grid.addWidget(self.next,1,1)
        self.skip=btn('完成 / 跳过',self.finish_action);grid.addWidget(self.skip,1,2)
        self.cancel=btn('取消洗澡' if kind=='bath' else '收好饭饭',self.cancel_action);grid.addWidget(self.cancel,1,3)
        self.scrubs={}
        if kind=='bath':
            for i,(zone,text) in enumerate([('head','脸蛋'),('back','背背'),('belly','肚肚'),('front_left','前爪'),('hind_left','后爪'),('tail','尾巴')]):
                b=btn(text,lambda checked=False,z=zone:self.scrub(z));b.setMinimumWidth(50)
                self.scrubs[zone]=b
            scrubrow=QHBoxLayout()
            for b in self.scrubs.values():scrubrow.addWidget(b)
            grid.addLayout(scrubrow,2,0,1,4)
        layout.addWidget(controls);self.scene.touched.connect(self.scene_touch);self.scene.timer.timeout.connect(self.update_progress)
    def set_model(self,care):self.care=care;self.scene.set_model(care);self.sync()
    def request(self,checked=False,food='fish'):
        name=('bath' if self.kind=='bath' else food);self.action.emit(name,self.mode.currentData())
    def pause_action(self):
        if self.scene.owns_activity():self.care.toggle_pause()
    def next_action(self):
        if self.scene.owns_activity():
            if self.kind=='bath':self.care.next_bath()
            else:self.care.feed_portion()
    def finish_action(self):
        if self.scene.owns_activity():self.care.finish()
    def cancel_action(self):
        if self.scene.owns_activity():self.care.cancel()
    def scrub(self,zone):
        if self.scene.owns_activity() and self.care.scrub(zone):
            r=self.scene.cat_rect();positions={'head':(.65,.3),'back':(.3,.5),'belly':(.55,.65),'front_left':(.42,.8),'hind_left':(.45,.92),'tail':(.18,.77)}
            x,y=positions.get(zone,(.5,.5));self.scene.pointer=QPointF(r.x()+r.width()*x,r.y()+r.height()*y);self.scene.update()
    def scene_touch(self,zone):
        if not zone or not self.scene.owns_activity():return
        if self.kind=='bath':self.scrub(zone)
        else:self.care.feed_portion()
    def completed(self):
        return bool(self.care and self.care.last_completed in (('bath','quick_wash','auto_wash') if self.kind=='bath' else ('fish','bowl','quick_feed')))
    def update_progress(self):
        a=self.scene.owns_activity();completed=self.completed();value=100 if completed else 0
        if a:
            remaining=a.remaining if a.paused else max(0,a.deadline-self.care.now());frac=1-remaining/a.stages[a.index][2]
            if a.interactive and a.stages[a.index][2]>=120:frac=a.feed_count/3
            value=round((a.index+min(1,max(0,frac)))/len(a.stages)*100)
        self.progress.setValue(value);self.progress.setFormat(('已暂停 · ' if a and a.paused else '')+((a.stages[a.index][0]+' · %p%') if a else '完成 · 100%' if completed else '准备就绪'))
    def sync(self):
        if not self.care:return
        self.stats.sync(self.care);a=self.scene.owns_activity();locked=self.care.dormant or self.care.system_paused or self.care.task_paused
        for b in self.buttons:b.setEnabled(not locked)
        for b in [self.pause,self.next,self.skip,self.cancel]:b.setEnabled(bool(a) and not locked)
        self.pause.setText('继续' if a and a.paused else '暂停')
        if a and a.paused:self.next.setEnabled(False)
        for b in self.scrubs.values():b.setEnabled(bool(a and a.name=='bath' and a.index==1 and not a.paused) and not locked)
        index=len(self.stage_labels) if self.completed() else -1
        if a:
            if self.kind=='bath':index=a.index if a.name in ('bath','auto_wash') else (1 if a.index==0 else 3)
            else:index=2 if (a.name=='fish' and a.index==1) else (1 if a.name!='bowl' or a.index>0 else 0)
        self.update_progress()
        self.stage_note.setText('深度休眠中，仅托盘手动唤醒。' if locked else self.care.message)
        for i,lab in enumerate(self.stage_labels):lab.setProperty('current',i==index);lab.setText(('✓ ' if index>i else '● ' if index==i else str(i+1)+'  ')+(BATH_STEPS if self.kind=='bath' else FEED_STEPS)[i]);lab.style().unpolish(lab);lab.style().polish(lab)
        self.scene.sync()

class CareWorkspace(FlexiblePage):
    action_requested=Signal(str,str)
    settings_requested=Signal(bool,bool)
    def __init__(self,art):
        super().__init__();self.art=art;self.care=None;root=FlexibleColumn(self);root.setContentsMargins(0,0,0,0)
        tabs=QHBoxLayout();self.tabs=[]
        for i,text in enumerate(('♡ 照顾敲咪','✿ 洗澡澡','♧ 喂饭饭')):
            b=btn(text,lambda checked=False,n=i:self.open(n));b.setCheckable(True);tabs.addWidget(b);self.tabs.append(b)
        tabs.addStretch();root.addLayout(tabs);self.stack=ActivePageStack();root.addWidget(self.stack,1)
        overview=QWidget();lay=QVBoxLayout(overview);self.stats=Stats();lay.addWidget(self.stats);lay.addWidget(title('妈妈忙自己的，敲咪也会好好照顾自己。','subtitle'));cards=QHBoxLayout()
        for i,kind in enumerate(('bath','feed')):
            card=QFrame();card.setObjectName('careCard');cl=QVBoxLayout(card);scene=CareScene(kind,art);scene.setMinimumHeight(190);cl.addWidget(scene,1);cl.addWidget(title('✿ 洗澡澡 · 香香小猫' if kind=='bath' else '♧ 喂饭饭 · 吃饱抱抱','brand'));cl.addWidget(btn('去洗澡澡' if kind=='bath' else '去喂饭饭',lambda checked=False,n=i+1:self.open(n),'primary'));cards.addWidget(card)
        lay.addLayout(cards,1);self.automatic=QCheckBox('自动照顾自己（免费）');self.fun=QCheckBox('无人碰敲咪时自己娱乐');self.automatic.toggled.connect(self.settings);self.fun.toggled.connect(self.settings);lay.addWidget(self.automatic);lay.addWidget(self.fun);lay.addWidget(title('不会生病或死亡，离线不扣分。生闷气仍需妈妈四次独立摸摸。','muted'));self.stack.addWidget(overview)
        self.bath=CarePage('bath',art);self.feed=CarePage('feed',art)
        for page in (self.bath,self.feed):self.stack.addWidget(page);page.action.connect(self.action_requested)
        self.open(0)
    def open(self,index):
        self.stack.setCurrentIndex(index)
        for i,b in enumerate(self.tabs):b.setChecked(i==index)
        self.sync()
    def set_model(self,care):
        self.care=care;self.bath.set_model(care);self.feed.set_model(care);self.sync()
    def settings(self):self.settings_requested.emit(self.automatic.isChecked(),self.fun.isChecked())
    def sync(self):
        if not self.care:return
        self.stats.sync(self.care)
        for widget,key in [(self.automatic,'automatic_care'),(self.fun,'autonomous_fun')]:widget.blockSignals(True);widget.setChecked(self.care.state.values[key]);widget.blockSignals(False);widget.setEnabled(not self.care.dormant)
        self.bath.sync();self.feed.sync()
    def suspend(self,enabled):
        for scene in self.findChildren(CareScene):scene.set_suspended(enabled)
        if enabled:self.art.clear()
    def set_theme(self,theme):
        for scene in self.findChildren(CareScene):scene.theme=theme;scene.update()

class ButlerHome(FlexiblePage):
    open_chat=Signal()
    open_care=Signal(int)
    def __init__(self,art):
        super().__init__();root=FlexibleColumn(self);root.setContentsMargins(0,0,0,0);root.setSpacing(15)
        hero=QFrame();hero.setObjectName('careHero');row=QHBoxLayout(hero);copy=QVBoxLayout();copy.setContentsMargins(16,12,0,12);copy.addWidget(title('A LITTLE LOVE, EVERY DAY','eyebrow'));copy.addWidget(title('妈妈，欢迎回家 ♡','title'));copy.addWidget(title('今天也要把温柔的小日子，\n过成喜欢的样子。','subtitle'));copy.addStretch();copy.addWidget(btn('和敲咪聊聊天  ↗',self.open_chat,'primary'));row.addLayout(copy,1);self.scene=CareScene('home',art);self.scene.setMinimumSize(220,180);row.addWidget(self.scene,1);root.addWidget(hero,1)
        self.stats=Stats();root.addWidget(self.stats);cards=QHBoxLayout()
        for i,headline,body in [(1,'✿  洗澡澡','搓搓泡泡，变成香香小猫。'),(2,'♧  喂饭饭','一口小鱼干，一点小幸福。')]:
            c=QFrame();c.setObjectName('careCard');l=QVBoxLayout(c);l.addWidget(title(headline,'brand'));l.addWidget(title(body,'muted'));l.addWidget(btn('陪敲咪一起  →',lambda checked=False,n=i:self.open_care.emit(n)));cards.addWidget(c)
        root.addLayout(cards);root.addWidget(title('♡  记忆留在本机，陪伴始终由妈妈掌控。','muted'))
    def sync(self,care):self.stats.sync(care)
