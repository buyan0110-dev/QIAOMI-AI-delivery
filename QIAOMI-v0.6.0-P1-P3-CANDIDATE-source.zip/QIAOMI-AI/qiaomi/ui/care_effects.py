"""Small local vector props. Never redraw a cat, tail, ear or paw."""
import math
from PySide6.QtCore import QRectF,QPointF,Qt
from PySide6.QtGui import QColor,QPen,QPainterPath

def draw_care(p,visual,seconds,*,front=False):
    if not visual:return
    p.save();p.setRenderHint(p.RenderHint.Antialiasing);kind=visual.get('kind');name=visual.get('name');stage=visual.get('stage',0)
    if kind=='bath':
        if not front:
            p.setPen(QPen(QColor('#b782a2'),2));p.setBrush(QColor('#eac7d9'));p.drawRoundedRect(QRectF(58,225,184,62),24,24)
            p.setBrush(QColor('#a8e3ec'));p.drawEllipse(QRectF(63,227,174,27))
        else:
            p.setPen(QPen(QColor('#c18ca9'),2));p.setBrush(QColor('#f5dce7'));p.drawRoundedRect(QRectF(58,277,184,12),6,6)
            if stage in (0,1):
                for i in range(4+min(8,visual.get('scrubbed',0)*2)):
                    x=94+(i*31)%120;y=145+(i*29)%107+2*math.sin(seconds*2+i);p.setPen(QPen(QColor(160,221,239,175),1));p.setBrush(QColor(240,252,255,150));p.drawEllipse(QRectF(x,y,9+i%3*3,9+i%3*3))
            if stage==2:
                p.setPen(QPen(QColor(121,206,239,170),2))
                for i in range(6):x=100+i*20;p.drawLine(QPointF(x,135),QPointF(x-6,160+8*math.sin(seconds*4+i)))
            if stage>=3 or (name in ('quick_wash','auto_wash') and stage==1):
                p.setPen(QPen(QColor('#a39fb5'),1));p.setBrush(QColor('#ddd9ee'));p.drawRoundedRect(QRectF(245,220,35,28),8,8)
                p.setPen(QPen(QColor(196,204,238,190),2))
                for i in range(3):p.drawLine(QPointF(243,225+i*7),QPointF(225,222+i*7+2*math.sin(seconds*3)))
    elif front and kind=='food' and name=='fish' and stage==0:
        p.setPen(QPen(QColor('#ac794a'),1));p.setBrush(QColor('#d8b47a'));p.drawEllipse(QRectF(135,215,28,11));path=QPainterPath();path.moveTo(135,220);path.lineTo(128,214);path.lineTo(128,227);path.closeSubpath();p.drawPath(path)
    elif front and kind=='toy':
        x,y=visual.get('pointer',(205,210))
        if name=='wand':
            p.setPen(QPen(QColor('#b69276'),3));p.drawLine(QPointF(260,104),QPointF(x+8,y-20));p.setPen(QPen(QColor('#e7b8d4'),1));p.drawLine(QPointF(x+8,y-20),QPointF(x,y));p.setBrush(QColor('#f3b0c9'));p.drawEllipse(QRectF(x-7,y-4,14,19))
        elif name=='mouse':
            x=160+35*math.sin(seconds*2);y=267;p.setPen(QPen(QColor('#919aaa'),1));p.setBrush(QColor('#bcc4cf'));p.drawEllipse(QRectF(x,y,24,13));p.drawEllipse(QRectF(x+13,y-3,6,7));p.drawLine(QPointF(x,y+6),QPointF(x-15,y+11))
        # Yarn ball is already present in original daily_yarn; never duplicate it.
    p.restore()
