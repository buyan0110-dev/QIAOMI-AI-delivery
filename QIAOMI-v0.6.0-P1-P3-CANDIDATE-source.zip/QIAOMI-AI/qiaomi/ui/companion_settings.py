from PySide6.QtCore import Signal
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QCheckBox,QPushButton,QComboBox
from ..companion_runtime import MICROS

class CompanionSettings(QDialog):
    edited=Signal(str,bool)
    preview=Signal(str)
    def __init__(self):
        super().__init__();self.setWindowTitle('敲咪 · 生活趣味 · 小小世界');self.resize(560,540);layout=QVBoxLayout(self)
        text=QLabel('本地、静音、低频。原有触摸优先；游戏深眠中全部停止。');text.setWordWrap(True);layout.addWidget(text);self.switches={}
        for key,label in [('F02','自主捡拾收藏'),('F04','小窝家具与动作偏好'),('F07','低频趣味闯祸'),('F08','主动小游戏'),('F10','回忆记录（可在相册删除/导出）'),('desktop_furniture','桌面家具占位图标'),('F01','邻近鼠标观察'),('F03','梦境气泡（同时遵守原梦话/文字气泡开关）'),('F05','情绪微动作'),('F06','仅桌宠区域模仿妈妈'),('F09','普通离开回来提醒（Windows最近输入时长）'),('reduced_motion','减少动画'),('do_not_disturb','暂时不打扰')]:
            box=QCheckBox(label);box.toggled.connect(lambda value,k=key:self.edited.emit(k,value));layout.addWidget(box);self.switches[key]=box
        self.choices=QComboBox()
        for key,label in zip(MICROS,['挠耳提示','尾尖心情','害羞','偷看','点头瞌睡','开心侧滚','挺胸得意']):self.choices.addItem(label,key)
        layout.addWidget(self.choices);self.play=QPushButton('预览选定微动作（不打断身体互动）');self.play.clicked.connect(lambda:self.preview.emit(self.choices.currentData()));layout.addWidget(self.play)
        note=QLabel('动作使用原猫精灵的局部轻移/倾斜与符号占位，不是新精绘骨骼动画。普通回来检测不读取键盘内容、窗口文字或画面。Linux无Windows闲置接口，不能实测普通返场。');note.setWordWrap(True);layout.addWidget(note)
    def load(self,values,deep):
        for key,box in self.switches.items():box.blockSignals(True);box.setChecked(values[key]);box.blockSignals(False)
        self.play.setEnabled(not deep)
