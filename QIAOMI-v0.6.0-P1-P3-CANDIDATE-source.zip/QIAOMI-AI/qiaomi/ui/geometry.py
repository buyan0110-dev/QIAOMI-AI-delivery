"""Aspect-preserving local image geometry; no resampling or asset edits."""
from PySide6.QtCore import QRectF,QSizeF,QPointF

def contain_rect(size,target,*,bottom=False):
    target=QRectF(target);size=QSizeF(size)
    if size.width()<=0 or size.height()<=0 or target.width()<=0 or target.height()<=0:return QRectF()
    scale=min(target.width()/size.width(),target.height()/size.height());w=size.width()*scale;h=size.height()*scale
    return QRectF(target.x()+(target.width()-w)/2,target.bottom()-h if bottom else target.y()+(target.height()-h)/2,w,h)

SCENE_SIZE=QSizeF(1536,1024)

def scene_viewport(rect):return contain_rect(SCENE_SIZE,QRectF(rect).adjusted(6,6,-6,-6))

def to_scene(point,viewport):
    if viewport.isEmpty() or not viewport.contains(point):return None
    return QPointF((point.x()-viewport.x())*SCENE_SIZE.width()/viewport.width(),(point.y()-viewport.y())*SCENE_SIZE.height()/viewport.height())

def from_scene(rect,viewport):
    if viewport.isEmpty():return QRectF()
    scale=viewport.width()/SCENE_SIZE.width();return QRectF(viewport.x()+rect.x()*scale,viewport.y()+rect.y()*scale,rect.width()*scale,rect.height()*scale)
