"""Explicit, scrollable care controls; no background UI polling or focus grabs."""
from PySide6.QtCore import Signal,Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QLabel,QProgressBar,QPushButton,QCheckBox,QScrollArea,QWidget,QGridLayout

class LifePanel(QDialog):
    action_requested=Signal(str)
    next_requested=Signal()
    finish_requested=Signal()
    cancel_requested=Signal()
    scrub_requested=Signal(str)
    settings_requested=Signal(bool,bool)
    def __init__(self):
        super().__init__();self.setWindowTitle('敲咪 · 零负担生活');self.resize(600,680)
        outer=QVBoxLayout(self);scroll=QScrollArea();scroll.setWidgetResizable(True);outer.addWidget(scroll);body=QWidget();scroll.setWidget(body);layout=QVBoxLayout(body)
        intro=QLabel('生活数值只用于娱乐。敲咪会自己吃饭、洗香香、玩耍和休息；离线和游戏模式不扣分，不会生病或死亡。');intro.setWordWrap(True);layout.addWidget(intro)
        self.bars={}
        for key,label in [('hunger_satiety','饱腹度'),('cleanliness','清洁度'),('energy','精力值'),('mood','心情值')]:
            row=QHBoxLayout();row.addWidget(QLabel(label));bar=QProgressBar();bar.setRange(0,100);bar.setObjectName(key);row.addWidget(bar);layout.addLayout(row);self.bars[key]=bar
        self.current=QLabel();self.current.setWordWrap(True);self.current.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.current)
        self.buttons={};grid=QGridLayout();self.action_grid=grid
        for i,(key,label) in enumerate([('fish','喂小鱼干'),('bowl','喂猫饭'),('quick_feed','一键喂食 · 饱腹100'),('bath','洗澡澡 · 妈妈帮洗'),('quick_wash','一键清洗 · 清洁100'),('wand','逗猫棒'),('yarn','毛线球'),('mouse','玩具老鼠')]):
            b=QPushButton(label);b.setObjectName(key);b.clicked.connect(lambda checked=False,k=key:self.action_requested.emit(k));grid.addWidget(b,i//2,i%2);self.buttons[key]=b
        layout.addLayout(grid)
        self.bath_help=QLabel('搓泡泡阶段：在小猫身上轻移鼠标或单击清洗，也可点下方部位。左键拖动仍会移动小猫并中断洗澡。');self.bath_help.setWordWrap(True);layout.addWidget(self.bath_help)
        self.scrubs={};row=QHBoxLayout()
        for key,label in [('head','头部'),('back','背部'),('belly','肚肚'),('front_left','前爪'),('hind_left','后爪')]:
            b=QPushButton(label);b.clicked.connect(lambda checked=False,k=key:self.scrub_requested.emit(k));row.addWidget(b);self.scrubs[key]=b
        layout.addLayout(row)
        row=QVBoxLayout();self.next=QPushButton('下一步 / 冲洗');self.next.clicked.connect(self.next_requested);row.addWidget(self.next)
        self.finish=QPushButton('完成 / 跳过动画');self.finish.clicked.connect(self.finish_requested);row.addWidget(self.finish)
        self.cancel=QPushButton('取消 / 收起');self.cancel.clicked.connect(self.cancel_requested);row.addWidget(self.cancel);layout.addLayout(row)
        self.auto=QCheckBox('自动照顾自己（免费，默认开启）');self.fun=QCheckBox('无人互动3–5分钟后自己娱乐')
        for w in (self.auto,self.fun):w.toggled.connect(self._settings);layout.addWidget(w)
        self.resources=QLabel('想停就点取消，想快一点可以跳过动画。生活互动全程静音，不会开启麦克风。');self.resources.setWordWrap(True);layout.addWidget(self.resources)
    def reflow(self):
        if not hasattr(self,'action_grid'):return
        columns=1 if self.font().pixelSize()>=20 or self.width()<550 else 2
        for i,b in enumerate(self.buttons.values()):self.action_grid.addWidget(b,i//columns,i%columns)
    def resizeEvent(self,event):
        self.reflow();super().resizeEvent(event)
    def _settings(self):self.settings_requested.emit(self.auto.isChecked(),self.fun.isChecked())
    def load(self,care):
        self.reflow()
        for key,bar in self.bars.items():bar.setValue(round(care.state.values[key]))
        a=care.active;deep=care.dormant
        label='游戏深度休眠：生活调度暂停，仅可从系统托盘手动唤醒。' if deep else care.message
        if a:label+='\n当前：'+a.stages[a.index][0]+(' · 自主活动' if not a.user else ' · 妈妈的互动')
        if care.personality.life.sulking:label+='\n仍在生闷气：必须四次独立摸摸；生活数值不会代替安抚。'
        if a and a.name in ('quick_feed','quick_wash'):label+='\n一键数值已完成，取消只会收起短动画。'
        self.current.setText(label)
        for b in self.buttons.values():b.setEnabled(not deep and not care.system_paused)
        soap=bool(a and a.name=='bath' and a.index==1 and not deep)
        for b in self.scrubs.values():b.setEnabled(soap)
        self.next.setEnabled(bool(a and a.name=='bath' and not deep));self.finish.setEnabled(bool(a and not deep));self.cancel.setEnabled(bool(a and not deep))
        for w,key in [(self.auto,'automatic_care'),(self.fun,'autonomous_fun')]:w.blockSignals(True);w.setChecked(care.state.values[key]);w.blockSignals(False)
