"""Bounded local games. Timers exist only in a visible user-started session."""
import random,math
from PySide6.QtCore import Qt,QTimer,QPointF,Signal
from PySide6.QtGui import QPainter,QColor,QFont
from PySide6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QPushButton,QLabel,QWidget

class ToyBoard(QWidget):
 caught=Signal()
 def __init__(self,kind):
  super().__init__();self.kind=kind;self.setMinimumSize(300,190);self.pos=QPointF(70,110);self.drag=False;self.t=0.;self.flight=False;self.hit=False
  self.timer=QTimer(self);self.timer.setInterval(40);self.timer.timeout.connect(self.step)
 def paintEvent(self,e):
  p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing);p.setFont(QFont('Segoe UI',32))
  p.setPen(QColor('#9b6076'));p.drawText(220,130,'🐾');p.drawText(self.pos,'🧶' if self.kind=='yarn' else '🐟');p.end()
 def mousePressEvent(self,e):
  if self.kind=='yarn' and (e.position()-self.pos).manhattanLength()<65:self.drag=True
 def mouseMoveEvent(self,e):
  if self.drag:
   self.pos=QPointF(max(30,min(self.width()-40,e.position().x())),max(50,min(self.height()-20,e.position().y())));self.update()
 def mouseReleaseEvent(self,e):
  if self.drag:
   self.drag=False
   if (self.pos-QPointF(230,115)).manhattanLength()<80:self.caught.emit()
 def throw(self):
  if self.flight:return
  self.t=0.;self.flight=True;self.hit=random.choice([True,False]);self.timer.start()
 def step(self):
  self.t+=.06;t=min(1,self.t);self.pos=QPointF(50+180*t,120-65*math.sin(math.pi*t));self.update()
  if t>=1:
   self.timer.stop();self.flight=False;self.caught.emit()
 def hideEvent(self,e):self.timer.stop();self.flight=False;self.drag=False;super().hideEvent(e)

class Minigame(QDialog):
 def __init__(self,c,kind):
  super().__init__(c.window);self.c=c;self.kind=kind;self.token=None;self.closing=False;self.setWindowTitle('和敲咪玩 · 随时退出，不扣分');self.resize(440,320)
  layout=QVBoxLayout(self);self.note=QLabel('猜猜宝贝藏在哪只爪爪？' if kind=='paw' else ('把毛线球拖到肉垫旁，再松开。' if kind=='yarn' else '抛一条小鱼给敲咪吧！'));self.note.setWordWrap(True);layout.addWidget(self.note)
  self.board=None;self.buttons=[];self.target=random.randrange(4)
  if kind=='paw':
   row=QHBoxLayout()
   for i in range(4):
    b=QPushButton('🐾 '+str(i+1));b.clicked.connect(lambda checked=False,n=i:self.guess(n));row.addWidget(b);self.buttons.append(b)
   layout.addLayout(row)
  else:
   self.board=ToyBoard(kind);layout.addWidget(self.board);self.board.caught.connect(self.result)
   if kind=='fish':
    b=QPushButton('抛小鱼');b.clicked.connect(self.board.throw);layout.addWidget(b)
  close=QPushButton('结束游戏（Esc）');close.clicked.connect(self.reject);layout.addWidget(close)
  self.timeout=QTimer(self);self.timeout.setSingleShot(True);self.timeout.timeout.connect(self.reject)
  self.finished.connect(lambda _:self.stop())
 def begin(self):
  c=self.c;p=c.personality
  if c.game_mode or c.care.system_paused:return False
  if c.companion_policy.active=='F08':return False
  if not c.pet.isVisible():c.pet.show()
  self.token=c.companion_policy.claim('F08',self.cleanup,duration=120)
  if not self.token:return False
  self.previous=(p.phase,c.pet.state)
  p.next_action.stop();p.phase_timer.stop();p.mood_timer.stop();p.dream_timer.stop()
  if not c.companion_policy.activate(self.token,'minigame',lambda:p._set_phase('minigame')):self.stop();return False
  c.pet.play_clip('attention_reach',0);c.care.direct('minigame');self.timeout.start(120000);self.show()
  c.companion_stories.safe_event('first-game','game');return True
 def guess(self,n):
  self.note.setText('找到啦！送妈妈一颗爱心 ♡' if n==self.target else '嘿嘿藏在第'+str(self.target+1)+'只！再猜一次吧。');self.target=random.randrange(4)
 def result(self):
  self.note.setText('接住啦！妈妈再陪敲咪玩一次嘛 ♡' if self.kind=='yarn' or self.board.hit else '小鱼溜走啦，没关系，再试一次！')
 def stop(self):
  if self.token:self.c.companion_policy.finish(self.token)
  else:self.cleanup()
 def cleanup(self):
  if self.closing:return
  self.closing=True;self.timeout.stop()
  if self.board:self.board.timer.stop();self.board.flight=False
  self.hide();self.token=None;p=self.c.personality
  if p.phase=='minigame':
   if not (p.dormant or self.c.game_mode or self.c.care.system_paused):p._normal()
   else:p._set_phase('idle')
  self.closing=False
 def hideEvent(self,e):
  super().hideEvent(e)
  if not self.closing:self.stop()
