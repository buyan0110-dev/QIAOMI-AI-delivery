"""Explicit local character controls; opening this dialog never wakes the pet."""
from PySide6.QtCore import Signal,Qt
from ..personality_constants import DAILY_STATES
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QCheckBox,QComboBox,QSpinBox,QPushButton,QHBoxLayout,QScrollArea,QWidget

class PersonalitySettings(QDialog):
    edited=Signal()
    wake_requested=Signal()
    skip_requested=Signal()
    daily_requested=Signal(str)
    def __init__(self):
        super().__init__();self.setWindowTitle('敲咪 · 性格与形象');self.resize(630,520)
        outer=QVBoxLayout(self);scroll=QScrollArea();scroll.setWidgetResizable(True);outer.addWidget(scroll)
        content=QWidget();scroll.setWidget(content);layout=QVBoxLayout(content)
        title=QLabel('超级黏人，但不打扰妈妈');layout.addWidget(title)
        self.affection=QCheckBox('主动撒娇与日常（总开关，不调用 AI）')
        self.reunion=QCheckBox('手动唤醒后播放一次重逢动画')
        self.bubbles=QCheckBox('显示撒娇文字气泡（不强制语音）')
        for widget in (self.affection,self.reunion,self.bubbles):widget.toggled.connect(self.edited);layout.addWidget(widget)
        self.extra_switches={}
        for key,label in [('neglect_enabled','冷落与四次安抚（10 / 20 / 30 分钟）'),('daily_enabled','自动日常生活动作'),('dream_enabled','睡觉时低频梦话（文字、静音）'),('welcome_enabled','普通手动启动迎接动画'),('seek_enabled','冷落后主动爬向中央（全屏/安全桌面时推迟）')]:
            checkbox=QCheckBox(label);checkbox.toggled.connect(self.edited);layout.addWidget(checkbox);self.extra_switches[key]=checkbox
        self.frequency=QComboBox()
        for text,value in [('低：10–15 分钟','low'),('标准：4–7 分钟','normal'),('高：2–4 分钟（默认，单次短动作）','high'),('自定义','custom')]:self.frequency.addItem(text,value)
        self.frequency.currentIndexChanged.connect(self.edited);layout.addWidget(self.frequency)
        self.interval=QSpinBox();self.interval.setRange(60,1800);self.interval.setSuffix(' 秒（自定义间隔）');self.interval.valueChanged.connect(self.edited);layout.addWidget(self.interval)
        self.appearance=QComboBox()
        for text,value in [('陪伴：粉色向尾喵睡衣，不戴眼镜','companion'),('工作：圆形金丝边眼镜 + 小电脑','work'),('游戏造型：圆形金丝边眼镜 + 手柄（仅清醒时）','gaming')]:self.appearance.addItem(text,value)
        self.appearance.currentIndexChanged.connect(self.edited);layout.addWidget(self.appearance)
        tip=QLabel('工作/游戏造型下暂停主动撒娇；重逢暂时摘下眼镜。游戏深度休眠期间不显示或解码造型，只有“唤醒敲咪”能恢复。')
        tip.setWordWrap(True);layout.addWidget(tip)
        self.status=QLabel();self.status.setWordWrap(True);self.status.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.status)
        self.resources=QLabel();self.resources.setWordWrap(True);self.resources.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.resources)
        self.daily_choice=QComboBox()
        for key,label in DAILY_STATES.items():self.daily_choice.addItem(label,key)
        self.daily_button=QPushButton('播放选定日常动作');self.daily_button.clicked.connect(lambda:self.daily_requested.emit(self.daily_choice.currentData()))
        layout.addWidget(self.daily_choice);layout.addWidget(self.daily_button)
        row=QHBoxLayout();self.wake=QPushButton('唤醒敲咪');self.wake.clicked.connect(self.wake_requested);row.addWidget(self.wake)
        self.skip=QPushButton('跳过本次动画');self.skip.clicked.connect(self.skip_requested);row.addWidget(self.skip);layout.addLayout(row)

    def load(self,values,deep,phase,resource_status):
        widgets=(self.affection,self.reunion,self.bubbles,self.frequency,self.interval,self.appearance,*self.extra_switches.values())
        for widget in widgets:widget.blockSignals(True)
        self.affection.setChecked(values['affection_enabled']);self.reunion.setChecked(values['reunion_enabled']);self.bubbles.setChecked(values['bubbles_enabled'])
        self.frequency.setCurrentIndex(self.frequency.findData(values['frequency']));self.interval.setValue(values['custom_seconds'])
        self.interval.setEnabled(values['frequency']=='custom');self.appearance.setCurrentIndex(self.appearance.findData(values['appearance']))
        for key,checkbox in self.extra_switches.items():checkbox.setChecked(values[key])
        self.daily_button.setEnabled(not deep)
        for widget in widgets:widget.blockSignals(False)
        self.wake.setEnabled(deep);self.skip.setEnabled(not deep and phase not in ('idle','dormant','closed'))
        self.status.setText('深度休眠：全部性格计时器/动画已停止，只保存设置。' if deep else '当前状态：'+phase)
        self.resources.setText(resource_status)

    def values(self):
        return dict(**{key:c.isChecked() for key,c in self.extra_switches.items()},affection_enabled=self.affection.isChecked(),reunion_enabled=self.reunion.isChecked(),bubbles_enabled=self.bubbles.isChecked(),
                    frequency=self.frequency.currentData(),custom_seconds=self.interval.value(),appearance=self.appearance.currentData())
