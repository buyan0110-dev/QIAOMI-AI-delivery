"""Contact anchors in the repaired full silhouettes, not painted screen props.
Qt clips only at the actual viewport/work-area edge. Coordinates are logical.
"""
from PySide6.QtCore import QRectF
import math
EDGE_CONTACTS={'edge_top':(.5,.06),'edge_bottom':(.5,.78),'edge_left':(.16,.5),'edge_right':(.84,.5)}

def sprite_destination(state,viewport_width=300,viewport_height=350,contact=None,frame_width=256,frame_height=256,reference_box=None):
    if state not in EDGE_CONTACTS:
        scale=min(250/frame_width,223/frame_height);w=frame_width*scale;h=frame_height*scale
        result=QRectF(viewport_width/2-w/2,286-h,w,h)
        # Restored artwork may extend outside the former cropped canvas.
        # Map the old logical canvas to the same desktop coordinates; render
        # the complete expanded image, including restored ears, around it.
        if (isinstance(reference_box,(list,tuple)) and len(reference_box)==4
            and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for v in reference_box)
            and reference_box[2]>=.5 and reference_box[3]>=.5
            and reference_box[0]+reference_box[2]<=1.00001 and reference_box[1]+reference_box[3]<=1.00001):
            x,y,rw,rh=reference_box
            return QRectF(result.x()-w*x/rw,result.y()-h*y/rh,w/rw,h/rh)
        return result
    x,y=EDGE_CONTACTS[state]
    if isinstance(contact,(list,tuple)) and len(contact)==2 and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for v in contact):x,y=contact
    size=256
    if state=='edge_top':return QRectF((viewport_width-size)/2,-y*size,size,size)
    if state=='edge_bottom':return QRectF((viewport_width-size)/2,viewport_height-y*size,size,size)
    if state=='edge_left':return QRectF(-x*size,85,size,size)
    return QRectF(viewport_width-x*size,85,size,size)
