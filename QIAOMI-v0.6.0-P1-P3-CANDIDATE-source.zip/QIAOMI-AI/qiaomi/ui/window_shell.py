"""Window-wide rounded shell remains fixed; only page contents may scroll."""
from PySide6.QtCore import Qt,QRectF,QSize,Signal
from PySide6.QtGui import QPainterPath,QRegion
from PySide6.QtWidgets import QWidget,QStackedWidget,QVBoxLayout

class RoundedShell(QWidget):
    radius=18
    def __init__(self):
        super().__init__();self.setObjectName('shell');self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground,True)
    def resizeEvent(self,event):
        path=QPainterPath();path.addRoundedRect(QRectF(self.rect()),self.radius,self.radius)
        # Child-widget clipping protects all four corners from scroll viewports.
        self.setMask(QRegion(path.toFillPolygon().toPolygon()))
        super().resizeEvent(event)

class ActivePageStack(QWidget):
    """Stack API whose layout only measures the visible page, including word wrap.

    QStackedLayout measures hidden pages' height-for-width too, which forced
    every page to inherit the tallest settings/care page on small windows.
    """
    currentChanged=Signal(int)
    def __init__(self,parent=None):
        super().__init__(parent);self._pages=[];self._index=-1;self._layout=QVBoxLayout(self);self._layout.setContentsMargins(0,0,0,0)
    def addWidget(self,page):
        page.setParent(self);self._pages.append(page);index=len(self._pages)-1
        if self._index<0:self.setCurrentIndex(index)
        else:page.hide()
        return index
    def count(self):return len(self._pages)
    def currentIndex(self):return self._index
    def currentWidget(self):return self._pages[self._index] if self._index>=0 else None
    def widget(self,index):return self._pages[index] if 0<=index<len(self._pages) else None
    def setCurrentIndex(self,index):
        if index==self._index or not 0<=index<len(self._pages):return
        old=self.currentWidget()
        if old:self._layout.removeWidget(old);old.hide()
        self._index=index;page=self.currentWidget();self._layout.addWidget(page);page.show();self.updateGeometry();self.currentChanged.emit(index)

class FlexiblePage(QWidget):
    """A scroll page may shrink flexible scenes, retaining actual control minima."""
    def heightForWidth(self,width):
        layout=self.layout()
        if layout:
            value=layout.minimumHeightForWidth(width)
            if value>=0:return value
        return self.minimumSizeHint().height()

class FlexibleColumn(QVBoxLayout):
    """Let the viewport shrink expanding scenes before scrolling real controls.

    Default VBox height-for-width uses a scroll area's preferred size (370px)
    as a hard height. It must not force an oversized canvas on short screens.
    """
    def hasHeightForWidth(self):return False
    def heightForWidth(self,width):return -1

from PySide6.QtCore import QEvent,QPointF
from PySide6.QtGui import QPainter,QPen,QColor
from PySide6.QtWidgets import QToolButton,QHBoxLayout

class CaptionButton(QToolButton):
    """DPI-aware 1px Windows-style caption glyph; no font/sprite stretching."""
    def __init__(self,kind,parent=None):
        super().__init__(parent);self.kind=kind;self.restore=False;self.hovered=False;self.setFixedSize(46,32);self.setCursor(Qt.CursorShape.ArrowCursor);self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setStyleSheet('QToolButton {background:transparent;border:0;}');self.setAutoFillBackground(False)
        self.setObjectName('caption_'+kind);self.setToolTip({'minimize':'最小化','maximize':'最大化','close':'关闭管家（隐藏到后台）'}[kind]);self.setAccessibleName(self.toolTip())
    def enterEvent(self,event):self.hovered=True;self.update();super().enterEvent(event)
    def leaveEvent(self,event):self.hovered=False;self.update();super().leaveEvent(event)
    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        close_hot=self.kind=='close' and self.hovered
        # Keep the existing pink/selected-theme window surface underneath.
        if self.hovered:p.fillRect(self.rect(),QColor('#ed729a' if close_hot else '#f8d3e3'))
        color=QColor('white' if close_hot else '#7f858c');p.setPen(QPen(color,1));p.setBrush(Qt.BrushStyle.NoBrush);x=self.width()/2;y=self.height()/2
        if self.kind=='minimize':p.drawLine(QPointF(x-6,y+3.5),QPointF(x+6,y+3.5))
        elif self.kind=='close':p.drawLine(QPointF(x-5.5,y-5.5),QPointF(x+5.5,y+5.5));p.drawLine(QPointF(x+5.5,y-5.5),QPointF(x-5.5,y+5.5))
        elif self.restore:
            p.drawPolyline([QPointF(x-3,y-6),QPointF(x+6,y-6),QPointF(x+6,y+3)])
            p.drawRect(QRectF(x-6,y-3,9,9))
        else:p.drawRect(QRectF(x-5,y-5,10,10))
        if self.hasFocus():p.setPen(QPen(color,1,Qt.PenStyle.DotLine));p.drawRect(self.rect().adjusted(3,3,-4,-4))

class WindowControls(QWidget):
    def __init__(self,window):
        super().__init__(window);self.window=window;self.setObjectName('windowControls');row=QHBoxLayout(self);row.setContentsMargins(0,0,0,0);row.setSpacing(0)
        self.minimize=CaptionButton('minimize',self);self.maximize=CaptionButton('maximize',self);self.close_button=CaptionButton('close',self)
        for button in (self.minimize,self.maximize,self.close_button):row.addWidget(button)
        self.minimize.clicked.connect(window.showMinimized);self.maximize.clicked.connect(self.toggle_maximized);self.close_button.clicked.connect(window.close)
        window.installEventFilter(self)
    def toggle_maximized(self):
        if self.window.isMaximized():self.window.showNormal()
        else:self.window.showMaximized()
    def eventFilter(self,watched,event):
        if watched is self.window and event.type()==QEvent.Type.WindowStateChange:
            self.maximize.restore=self.window.isMaximized();text='还原' if self.maximize.restore else '最大化';self.maximize.setToolTip(text);self.maximize.setAccessibleName(text);self.maximize.update()
        return False
