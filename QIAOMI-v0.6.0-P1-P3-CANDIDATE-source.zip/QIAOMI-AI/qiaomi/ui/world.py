"""Native PySide6 extensions; reuse original navigation/themes and cat artwork.
All furniture/icons are explicitly lightweight placeholders, not new cat art.
"""
from pathlib import Path
from PySide6.QtCore import Qt,QRectF
from PySide6.QtGui import QPainter,QColor,QPixmap,QFont
from PySide6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QComboBox,QListWidget,QCheckBox,QFileDialog,QMessageBox
from ..companion_data import ITEMS,FURNITURE
from .butler import Stats

def text(s):
 w=QLabel(s);w.setWordWrap(True);w.setTextFormat(Qt.TextFormat.PlainText);return w

def action(s,callback):
 w=QPushButton(s);w.clicked.connect(callback);return w

class RoomPreview(QWidget):
 def __init__(self,c):super().__init__();self.c=c;self.pending=None;self.setMinimumSize(280,230)
 def paintEvent(self,e):
  p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
  p.setBrush(QColor('#fff1e7'));p.setPen(QColor('#e9bbc5'));p.drawRoundedRect(self.rect().adjusted(2,2,-2,-2),18,18)
  p.setFont(QFont('Segoe UI',28));room=self.c.companion_data.room()
  if self.pending:room=dict(room,**{('main' if FURNITURE[self.pending][2]=='main' else 'small1'):self.pending})
  for slot,x in [('main',.4),('small1',.15),('small2',.76)]:
   item=room.get(slot)
   if item:p.drawText(int(self.width()*x),self.height()-25,FURNITURE[item][1])
  pix=None if self.c.game_mode else self.c.pet.sprites.frame('idle',0)
  if pix is not None and not pix.isNull():
   available=QRectF(self.width()/2-90,30,180,max(80,self.height()-65));scale=min(available.width()/pix.width(),available.height()/pix.height())
   target=QRectF(available.center().x()-pix.width()*scale/2,available.bottom()-pix.height()*scale,pix.width()*scale,pix.height()*scale);p.drawPixmap(target,pix,QRectF(pix.rect()))
  p.end()

class WorldPage(QWidget):
 def __init__(self,c,kind):
  super().__init__();self.c=c;self.kind=kind;self.grid=None;self.grid_buttons=[];self.layout=QVBoxLayout(self);self.layout.setSpacing(12)
  names={'today':'今日状态','toys':'玩具屋','collection':'秘密收藏箱','room':'布置小窝','album':'回忆相册'}
  h=text(names[kind]+'  ♡');h.setObjectName('title');self.layout.addWidget(h)
  self.layout.addWidget(text('轻松陪伴，随时可以离开。道具使用轻量图形占位，敲咪形象保持原样。'))
  if kind=='today':
   self.stats=Stats();self.layout.addWidget(self.stats)
   row=QHBoxLayout()
   for name,label in [('quick_feed','一键喂食'),('quick_wash','一键清洗')]:row.addWidget(action(label,lambda checked=False,n=name:c.handle_life_action(n)))
   row.addWidget(action('抱抱敲咪',lambda:c.pet.interaction.emit('body')));self.layout.addLayout(row)
   self.current=text('');self.layout.addWidget(self.current);self.layout.addWidget(action('去照顾敲咪',lambda:c.window.open_care(0)))
  if kind=='toys':
   grid=QGridLayout()
   for i,(name,label) in enumerate([('wand','逗猫棒'),('yarn','毛线球'),('mouse','玩具老鼠')]):grid.addWidget(action(label+' · 和敲咪玩',lambda checked=False,n=name:c.handle_life_action(n)),i,0)
   for i,(name,label) in enumerate([('paw','猜肉垫（四选一）'),('yarn','抓毛线球（拖动）'),('fish','接小鱼（抛接）')]):grid.addWidget(action(label,lambda checked=False,n=name:c.start_minigame(n)),i,1)
   self.layout.addLayout(grid);self.layout.addWidget(text('不用刷分、没有损失；结束、Esc、摸猫或游戏深眠都会取消小游戏。'))
  if kind=='collection':
   self.filter=QComboBox();self.filter.addItems(['全部','最近','礼物']);self.filter.currentIndexChanged.connect(self.refresh);self.layout.addWidget(self.filter)
   self.cards=QListWidget();self.layout.addWidget(self.cards);self.story=text('敲咪还没捡到宝贝，没关系呀。');self.layout.addWidget(self.story);self.cards.currentRowChanged.connect(self.pick_story)
  if kind=='room':
   self.preview=RoomPreview(c);self.layout.addWidget(self.preview);self.slot=QComboBox();self.slot.addItems(['主家具','小摆设一','小摆设二']);self.layout.addWidget(self.slot)
   grid=QGridLayout();self.grid=grid
   for i,(key,(name,icon,_,_)) in enumerate(FURNITURE.items()):
    b=action(icon+' '+name,lambda checked=False,k=key:self.choose(k));self.grid_buttons.append(b);grid.addWidget(b,i//4,i%4)
   self.layout.addLayout(grid);self.selected=None;self.note=text('选一件家具预览，再点应用。');self.layout.addWidget(self.note)
   row=QHBoxLayout();row.addWidget(action('应用到选定槽位',self.apply));row.addWidget(action('收起选定槽位',self.remove));row.addWidget(action('和家具玩',self.play_furniture));self.layout.addLayout(row)
   self.desktop=QCheckBox('在桌面显示小道具（默认关闭，不改变透明窗口背景）');self.desktop.setChecked(c.companion_preferences.values['desktop_furniture']);self.desktop.toggled.connect(lambda v:c.edit_companion('desktop_furniture',v));self.layout.addWidget(self.desktop)
  if kind=='album':
   self.record=QCheckBox('记录最少必要的陪伴事件（不保存聊天、录音或屏幕）');self.record.setChecked(c.companion_preferences.values['F10']);self.record.toggled.connect(lambda v:c.edit_companion('F10',v));self.layout.addWidget(self.record)
   self.month=QComboBox();self.month.currentIndexChanged.connect(self.refresh);self.layout.addWidget(self.month)
   self.rows=QListWidget();self.layout.addWidget(self.rows)
   row=QHBoxLayout();row.addWidget(action('删除选中',self.delete));row.addWidget(action('清空回忆',self.clear));row.addWidget(action('导出 JSON',self.export));self.layout.addLayout(row)
  self.layout.addStretch()
 def resizeEvent(self,e):
  if self.grid:
   columns=2 if self.width()<700 else 4
   for i,b in enumerate(self.grid_buttons):self.grid.addWidget(b,i//columns,i%columns)
  super().resizeEvent(e)
 def showEvent(self,e):self.refresh();super().showEvent(e)
 def refresh(self,*args):
  c=self.c
  if c.companion_data.closed:return
  if self.kind=='today':self.stats.sync(c.care);self.current.setText('敲咪正在：'+c.care.message)
  if self.kind=='collection':
   rows=c.companion_data.collection();self.collection_rows=rows[:7] if self.filter.currentIndex()==1 else ([r for r in rows if r[0]=='heart'] if self.filter.currentIndex()==2 else rows);self.cards.clear()
   for item,count,_,date in self.collection_rows:self.cards.addItem(ITEMS[item][1]+' '+ITEMS[item][0]+' ×'+str(count)+'   '+date[:10])
   self.story.setText('敲咪还没捡到宝贝，没关系呀。' if not rows else '点击一件宝贝，看看敲咪的小故事。')
  if self.kind=='room':self.preview.update()
  if self.kind=='album':
   rows=c.companion_data.memories();months=sorted({r[2][:7] for r in rows},reverse=True)
   selected=self.month.currentText();self.month.blockSignals(True);self.month.clear();self.month.addItems(['全部月份']+months);self.month.setCurrentText(selected if selected in months else '全部月份');self.month.blockSignals(False)
   self.album_rows=[r for r in rows if self.month.currentIndex()==0 or r[2].startswith(self.month.currentText())];self.rows.clear()
   for _,kind,at,t in self.album_rows:self.rows.addItem(at[:10]+'  ['+kind+']  '+t)
   self.record.blockSignals(True);self.record.setChecked(c.companion_preferences.values['F10']);self.record.blockSignals(False)
 def pick_story(self,i):
  if 0<=i<len(self.collection_rows):self.story.setText(ITEMS[self.collection_rows[i][0]][2])
 def choose(self,key):self.selected=key;self.preview.pending=key;self.preview.update();self.note.setText('已选：'+FURNITURE[key][0]+'（'+('主家具' if FURNITURE[key][2]=='main' else '小摆设')+'）')
 def slot_id(self):return ('main','small1','small2')[self.slot.currentIndex()]
 def apply(self):
  if self.selected:
   try:self.c.companion_data.place(self.slot_id(),self.selected);self.note.setText('布置已保存，重启后保留。');self.c.sync_room()
   except ValueError:self.note.setText('请将主家具放入主槽位，小摆设放入两个摆设槽位。')
   except Exception:self.c.life_notice('布置保存失败，请检查数据目录；原记忆未修改。')
  self.refresh()
 def remove(self):self.c.companion_data.place(self.slot_id(),None);self.c.sync_room();self.refresh()
 def play_furniture(self):
  if self.c.companion_preferences.values['F04']:
   item=self.c.companion_data.room().get('main')
   if item:self.c.handle_life_action(FURNITURE[item][3])
 def delete(self):
  i=self.rows.currentRow()
  if 0<=i<len(self.album_rows):self.c.companion_data.delete(self.album_rows[i][0]);self.refresh()
 def clear(self):
  if QMessageBox.question(self,'清空回忆','清空陪伴相册？长期记忆与聊天不会被删除。')==QMessageBox.StandardButton.Yes:self.c.companion_data.clear();self.refresh()
 def export(self):
  path,_=QFileDialog.getSaveFileName(self,'导出陪伴事件','qiaomi-companion.json','JSON (*.json)')
  if path:
   try:self.c.companion_data.export(path)
   except Exception:self.c.life_notice('导出失败，请选择可写入的目录。')
