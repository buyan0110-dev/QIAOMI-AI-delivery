"""Read-only WebP/manifest/alpha/anchor audit. Never retouches image pixels.
Requires the project's voice/dev NumPy+SciPy dependencies. Structural anatomy
(single tail/paws/ears) needs a separate human review: this is not a CV oracle.
"""
from pathlib import Path
import argparse,json,hashlib,sys
import numpy as np
from scipy import ndimage
from PySide6.QtGui import QImage


def image_array(path):
    image=QImage(str(path))
    if image.isNull():raise ValueError('image cannot be decoded')
    has_alpha=image.hasAlphaChannel();image=image.convertToFormat(QImage.Format.Format_RGBA8888)
    return np.frombuffer(image.constBits(),np.uint8).reshape(image.height(),image.width(),4).copy(),has_alpha


def box(mask):
    yy,xx=np.nonzero(mask)
    return None if not len(xx) else [int(xx.min()),int(yy.min()),int(xx.max()+1),int(yy.max()+1)]


def audit_image(path):
    rgba,has_alpha=image_array(path);alpha=rgba[:,:,3];mask=alpha>=32
    labels,count=ndimage.label(mask,np.ones((3,3),np.uint8));sizes=np.bincount(labels.ravel());sizes[0]=0
    main=labels==int(sizes.argmax()) if count else np.zeros_like(mask)
    near=ndimage.binary_dilation(main,iterations=4)
    # Detached legitimate whiskers / costume balls / drawn motion cues can flag.
    tiny=[int(n) for n in sizes[1:] if 0<n<=12]
    residual=(alpha>0)&(alpha<32)&~near
    rgb=rgba[:,:,:3].astype(np.int16)
    pink=(rgb[:,:,0]>rgb[:,:,1]*1.15)&(rgb[:,:,2]>rgb[:,:,1]*1.08)&(alpha>=128)
    roi=np.zeros_like(pink);h,w=alpha.shape;roi[int(h*.25):int(h*.80),int(w*.25):int(w*.75)]=True;pink&=roi
    yy,xx=np.nonzero(pink)
    anchor=None if not len(xx) else [round(float(xx.mean()),3),round(float(yy.mean()),3)]
    border=np.zeros_like(mask);border[[0,-1],:]=True;border[:,[0,-1]]=True
    return dict(path=Path(path).name,readable=True,width=w,height=h,alpha_channel=has_alpha,fully_transparent_pixels=int((alpha==0).sum()),semtransparent_pixels=int(((alpha>0)&(alpha<255)).sum()),visible_box=box(alpha>=128),nonzero_box=box(alpha>0),visible_components=int(count),tiny_island_components=len(tiny),tiny_island_pixels=sum(tiny),low_alpha_pixels_far_from_main=int(residual.sum()),opaque_canvas_border_pixels=int(((alpha>=128)&border).sum()),body_color_anchor=anchor,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())


def audit_assets(root):
    root=Path(root).resolve();manifest=json.loads((root/'manifest.json').read_text(encoding='utf-8'));errors=[];referenced=set();groups={}
    for state,entry in manifest.get('states',{}).items():
        anchors=[]
        for name in entry.get('frames',[]):
            path=(root/name).resolve()
            if not path.is_relative_to(root) or not path.is_file():errors.append(state+': invalid/missing path '+str(name));continue
            referenced.add(path)
        groups[state]={'frames':len(entry.get('frames',[])),'screen_contact':entry.get('screen_contact'),'interaction_box':entry.get('interaction_box')}
    records=[]
    for path in sorted(root.glob('*.webp')):
        try:
            item=audit_image(path);records.append(item)
            if not item['alpha_channel']:errors.append(path.name+': no alpha channel')
            if (item['width'],item['height'])!=(256,256):errors.append(path.name+': inconsistent frame size')
        except Exception as e:errors.append(path.name+': '+str(e))
    by_name={r['path']:r for r in records}
    for state,entry in manifest.get('states',{}).items():
        points=[by_name[n]['body_color_anchor'] for n in dict.fromkeys(entry.get('frames',[])) if n in by_name and by_name[n]['body_color_anchor'] is not None]
        if points:
            a=np.array(points);groups[state]['anchor_span_px']=[round(float(n),3) for n in np.ptp(a,axis=0)];groups[state]['anchor_warning']=bool(np.ptp(a,axis=0).max()>3)
    warnings=[r['path'] for r in records if r['tiny_island_pixels'] or r['low_alpha_pixels_far_from_main']>8 or r['opaque_canvas_border_pixels']]
    return dict(schema=1,read_only=True,files_checked=len(records),referenced_files=len(referenced),basic_errors=errors,warning_files=warnings,frames=records,states=groups,limitations='Format/alpha/path/centroid diagnostics only; cannot count semantic tails or certify anatomical continuity. Legitimate whiskers, costume ornaments and intentional effects may flag. Movement clips legitimately change anchors; manual review required.')


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--assets',type=Path,default=Path(__file__).resolve().parents[1]/'assets/personality');p.add_argument('--output',type=Path,required=True);args=p.parse_args()
    result=audit_assets(args.assets);args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('files_checked','referenced_files','basic_errors')}));print('Warnings:',len(result['warning_files']),'(manual triage, not anatomy verdict)')
    return 1 if result['basic_errors'] else 0
if __name__=='__main__':raise SystemExit(main())
