"""Capture isolated native Qt geometry/screenshots on a CI runner; no user data."""
import sys,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from tempfile import TemporaryDirectory
from PySide6.QtWidgets import QApplication,QSystemTrayIcon,QWidget
from PySide6.QtTest import QTest
from qiaomi.app import Controller
app=QApplication([]);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
output=Path('test-artifacts/layout');output.mkdir(parents=True,exist_ok=True)
temporary=TemporaryDirectory();c=Controller(app,Path(temporary.name),smoke=True);report={}
for theme,scale,size in [('pink',100,(900,700)),('light',150,(900,700))]:
 c.change_appearance(theme,scale,False);c.show_assistant();c.app.processEvents();c.window._screen_timer.stop();c.window.resize(*size);c.window.open_care(1);QTest.qWait(100)
 rows=[]
 for w in [c.window,c.window.shell_scroll,c.window.pages,c.window.care_workspace,c.window.care_workspace.bath]+c.window.care_workspace.bath.findChildren(QWidget):
  rows.append({'class':type(w).__name__,'name':w.objectName(),'text':w.text() if hasattr(w,'text') else '', 'size':[w.width(),w.height()],'minimum':[w.minimumSizeHint().width(),w.minimumSizeHint().height()],'parent':type(w.parent()).__name__})
 report[theme+str(scale)]={'horizontal':c.window.shell_scroll.horizontalScrollBar().maximum(),'widgets':rows};c.window.grab().save(str(output/(theme+str(scale)+'.png')))
c.life_window.load(c.care);c.life_window.show();QTest.qWait(100);c.life_window.grab().save(str(output/'life150.png'))
(output/'geometry.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(report,ensure_ascii=False));c.cleanup();app.processEvents()
