"""Offline isolated five-phase Qt CPU/RSS/timer/thread measurement.
Windows: run without QT_QPA_PLATFORM=offscreen. GPU values remain unknown;
record Task Manager/nvidia-smi separately; do not infer per-app GPU from total.
"""
import argparse,json,os,platform,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from qiaomi.app import Controller
from qiaomi import __version__
from measure_idle import rss_bytes

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',type=Path,required=True);p.add_argument('--seconds',type=int,default=8);p.add_argument('--cycles',type=int,default=1);a=p.parse_args()
    if not 2<=a.seconds<=60 or not 1<=a.cycles<=100:p.error('seconds 2..60, cycles 1..100')
    app=QApplication([]);app.setQuitOnLastWindowClosed(False)
    simulated=sys.platform!='win32' and not QSystemTrayIcon.isSystemTrayAvailable()
    if simulated:QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
    report=dict(version=__version__,platform=platform.platform(),qt_platform=os.environ.get('QT_QPA_PLATFORM','native'),tray_simulated=simulated,models_loaded=False,gpu_percent=None,vram_mib=None,metrics=[],limitations='Short offline sample; not Windows game, real GPU, ASR or hours-long memory endurance testing.')
    modes=['pet_idle','autonomous_read','butler_open','butler_hidden','game_sleep']*a.cycles
    with tempfile.TemporaryDirectory(prefix='qiaomi-life-') as folder:
        c=Controller(app,Path(folder),smoke=True);c.tray.showMessage=lambda *a:None;c.personality.preferences.values['reunion_enabled']=False;c.personality.timings['daily']=60000
        start=[0.,0.]
        def begin():
            mode=modes[len(report['metrics'])]
            if c.game_mode:c.wake_qiaomi()
            c.personality.skip();c.window.hide();c.pet.show()
            if mode=='autonomous_read':c.personality.start_daily('daily_read',user=False)
            elif mode=='butler_open':c.show_assistant()
            elif mode=='game_sleep':c.set_game_mode(True)
            start[:]=[time.perf_counter(),time.process_time()];QTimer.singleShot(a.seconds*1000,finish)
        def finish():
            elapsed=time.perf_counter()-start[0];cpu=time.process_time()-start[1];rss=rss_bytes()
            report['metrics'].append(dict(mode=modes[len(report['metrics'])],seconds=round(elapsed,3),cpu_percent_one_core=round(cpu/elapsed*100,3),rss_mib=round(rss/1048576,2) if rss is not None else None,
                threads=len(list(Path('/proc/self/task').iterdir())) if sys.platform.startswith('linux') else None,
                timers={name:getattr(c.personality,name).isActive() for name in ('next_action','phase_timer','neglect_timer','dream_timer','mood_timer')},pet_timer=c.pet.timer.isActive(),orb_timer=c.window.orb.timer.isActive(),seek_timer=c.habitat.exit_timer.isActive(),seek_running=c.habitat.motion.state()==c.habitat.motion.State.Running,
                decoded_frame_bytes=getattr(c.pet.sprites,'cached_bytes',0),microphone=c.voice.listening,voice_pid=c.voice.process.processId()))
            if len(report['metrics'])<len(modes):begin()
            else:
                a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');c.request_quit()
        QTimer.singleShot(100,begin);result=app.exec();c.cleanup()
    print(json.dumps(report,ensure_ascii=False,indent=2));return result
if __name__=='__main__':raise SystemExit(main())
