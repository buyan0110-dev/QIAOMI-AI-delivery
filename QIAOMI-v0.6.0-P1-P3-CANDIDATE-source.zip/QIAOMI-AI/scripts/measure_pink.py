"""Short actual Qt CPU/RSS samples; no AI/microphone/game hardware claims."""
import sys,os,tempfile,time,json,platform
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from PySide6.QtTest import QTest
from qiaomi.app import Controller
from qiaomi.ui.butler import CareScene
from measure_idle import rss_bytes

def main():
    out=Path(sys.argv[1]);out.parent.mkdir(parents=True,exist_ok=True)
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
    report={'platform':platform.platform(),'qt_platform':os.environ.get('QT_QPA_PLATFORM','native'),'tray_simulated':True,'microphone_models_ai':False,'sample_seconds':3,'measurements':[],'limits':'Short Linux isolated samples; Windows/GPU/real game/long run not tested.'}
    with tempfile.TemporaryDirectory() as folder:
        c=Controller(app,Path(folder),smoke=True);c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
        try:
            for mode in ['normal_hidden_butler','manual_bath_visible','game_deep_sleep']:
                if mode=='manual_bath_visible':
                    c.show_assistant();c.window.open_care(1);c.start_care_page('bath','manual');c.care.next_bath();QTest.qWait(300)
                if mode=='game_deep_sleep':c.set_game_mode(True);QTest.qWait(100)
                start=time.perf_counter();cpu=time.process_time();QTest.qWait(3000);elapsed=time.perf_counter()-start
                scenes=c.window.care_workspace.findChildren(CareScene);rss=rss_bytes()
                report['measurements'].append(dict(mode=mode,seconds=round(elapsed,3),cpu_percent_one_core=round((time.process_time()-cpu)/elapsed*100,3),rss_mib=round(rss/1048576,2) if rss else None,scene_cache_bytes=c.window.care_art.bytes,scene_timers=sum(s.timer.isActive() for s in scenes),life_timer=c.care.timer.isActive(),pet_timer=c.pet.timer.isActive(),voice_pid=c.voice.process.processId(),microphone=c.voice.listening))
            assert report['measurements'][-1]['scene_cache_bytes']==0 and report['measurements'][-1]['scene_timers']==0
        finally:app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close()
    out.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
