import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import sys,time,json,resource,os
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from qiaomi.app import Controller
from tempfile import TemporaryDirectory
from pathlib import Path
app=QApplication([]);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
tmp=TemporaryDirectory();c=Controller(app,Path(tmp.name),smoke=True);c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
mode=sys.argv[1]
if mode=='game':c.set_game_mode(True)
start={}
def begin():
 r=resource.getrusage(resource.RUSAGE_SELF);start.update(cpu=r.ru_utime+r.ru_stime,wall=time.perf_counter())
def end():
 r=resource.getrusage(resource.RUSAGE_SELF);wall=time.perf_counter()-start['wall'];cpu=r.ru_utime+r.ru_stime-start['cpu']
 timers=[t for t in c.findChildren(QTimer) if t.isActive()]
 value={'mode':mode,'elapsed_s':round(wall,3),'cpu_one_core_percent':round(cpu/wall*100,3),'max_rss_MiB':round(r.ru_maxrss/1024,2),'controller_active_timers':len(timers),'qt_platform':os.environ.get('QT_QPA_PLATFORM'),'gpu':'not measured','timers':[t.interval() for t in timers]}
 Path(sys.argv[2]).write_text(json.dumps(value,indent=2));c.cleanup();app.quit()
QTimer.singleShot(2000,begin);QTimer.singleShot(12000,end);app.exec()
