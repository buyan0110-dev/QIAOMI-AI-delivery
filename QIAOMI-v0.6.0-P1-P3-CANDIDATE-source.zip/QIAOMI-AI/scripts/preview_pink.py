"""Actual Qt main-window screenshots/sequence; isolated test data, no network."""
import sys,os,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from PySide6.QtTest import QTest
from qiaomi.app import Controller

def main():
    out=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/pink/previews');out.mkdir(parents=True,exist_ok=True)
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
    with tempfile.TemporaryDirectory() as folder:
        c=Controller(app,Path(folder),smoke=True);c.show_pet();c.personality.interrupt_for_task();c.personality._normal();c.personality.preferences.values['reunion_enabled']=False;c.change_appearance('pink',100,True)
        c.show_assistant();app.processEvents();c.window._screen_timer.stop();c.window.resize(1500,1040)
        def capture(name):
            app.processEvents();c.window.shell_scroll.verticalScrollBar().setValue(0);QTest.qWait(70);assert c.window.grab().save(str(out/(name+'.png')))
        try:
            c.window.navigate(3);capture('home')
            c.window.open_care(1);c.start_care_page('bath','manual');c.care.next_bath()
            for zone in ['head','back','belly','front_left','hind_left']:
                QTest.qWait(210);c.care.scrub(zone)
            capture('bath')
            c.care.next_bath();capture('rinse');c.care.next_bath();capture('towel');c.care.next_bath()
            a=c.care.active;c.care.action_timer.stop();c.window.care_workspace.bath.scene.timer.stop()
            fixed=c.care.now();base=c.care.now
            for i in range(16):
                c.care.now=lambda t=fixed+i*.199:t
                capture('dress-'+str(i).zfill(2))
            c.care.now=base;c.care.finish();capture('dressed-complete')
            c.window.open_care(2);c.start_care_page('fish','manual');c.care.feed_portion();capture('feed')
            c.care.cancel();c.start_care_page('bowl','manual');c.care.active.index=1;c.care._show_stage();capture('feed-bowl')
            c.care.cancel();c.window.navigate(0);capture('chat')
            c.set_game_mode(True);app.processEvents();assert c.window.care_art.bytes==0
            assert all(not s.timer.isActive() for s in c.window.care_workspace.findChildren(__import__('qiaomi.ui.butler',fromlist=['CareScene']).CareScene))
            (out/'smoke.json').write_text(json.dumps({'platform':sys.platform,'qt_platform':os.environ.get('QT_QPA_PLATFORM','native'),'screenshots':'real Qt QWidget.grab','tray':'simulated','private_data':'temporary synthetic only','game_cache_bytes':c.window.care_art.bytes,'runtime_errors':c.runtime_errors},indent=2))
        finally:app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close()
if __name__=='__main__':main()
