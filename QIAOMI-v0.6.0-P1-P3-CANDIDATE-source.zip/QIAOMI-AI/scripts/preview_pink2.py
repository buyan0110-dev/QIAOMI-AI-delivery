"""Actual Qt screenshots at reported small-window sizes, never resize image assets."""
import sys,tempfile,json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from PySide6.QtTest import QTest
from qiaomi.app import Controller
from qiaomi.ui.geometry import scene_viewport

def main():
    out=Path(sys.argv[1] if len(sys.argv)>1 else 'docs/pink2/previews');out.mkdir(parents=True,exist_ok=True)
    app=QApplication([]);app.setQuitOnLastWindowClosed(False);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True);records=[]
    with tempfile.TemporaryDirectory() as folder:
        c=Controller(app,Path(folder),smoke=True);c.show_pet();c.personality.interrupt_for_task();c.personality._normal();c.show_assistant();app.processEvents();w=c.window;w._screen_timer.stop()
        try:
            for width,height,scale in [(1080,780,100),(900,700,100),(1280,800,100),(1080,780,150),(1500,1040,100)]:
                c.change_appearance('pink',scale,False);w.resize(width,height);app.processEvents()
                for page in ['home','overview','bath','feed']:
                    if page=='home':w.navigate(3)
                    else:w.open_care({'overview':0,'bath':1,'feed':2}[page])
                    app.processEvents();w.shell_scroll.verticalScrollBar().setValue(0);QTest.qWait(50)
                    name=f'{page}-{width}x{height}-{scale}';image=w.grab();image.save(str(out/(name+'.png')))
                    scenes=[s for s in [w.butler_home.scene,w.care_workspace.bath.scene,w.care_workspace.feed.scene] if s.isVisible()]
                    records.append(dict(name=name,size=[w.width(),w.height()],page_viewport=[w.shell_scroll.viewport().width(),w.shell_scroll.viewport().height()],page_scroll_max=w.shell_scroll.verticalScrollBar().maximum(),horizontal_max=w.shell_scroll.horizontalScrollBar().maximum(),corner_alpha=[image.toImage().pixelColor(x,y).alpha() for x,y in [(0,0),(w.width()-1,0),(0,w.height()-1),(w.width()-1,w.height()-1)]],scene_ratios=[dict(frame=[s.art.frame(s.frame_index()).width(),s.art.frame(s.frame_index()).height()],destination=[s.cat_rect().width(),s.cat_rect().height()],viewport=[scene_viewport(s.rect()).width(),scene_viewport(s.rect()).height()]) for s in scenes]))
            w.resize(1080,780);c.change_appearance('pink',100,False);w.open_care(1);c.start_care_page('bath','manual');c.care.next_bath();app.processEvents();QTest.qWait(80);w.grab().save(str(out/'manual-bath-1080x780.png'))
            for stage in range(5):
                c.care.active.index=stage;c.care._show_stage();app.processEvents();w.grab().save(str(out/('bath-stage-'+str(stage)+'.png')))
            c.care.finish();app.processEvents();w.grab().save(str(out/'bath-complete.png'))
            w.open_care(2);c.start_care_page('fish','manual');c.care.feed_portion();app.processEvents();w.grab().save(str(out/'manual-feed-1080x780.png'))
            w.title_controls.grab().save(str(out/'caption-normal.png'))
            w.title_controls.toggle_maximized();app.processEvents();w.title_controls.grab().save(str(out/'caption-restore.png'))
            w.title_controls.toggle_maximized();app.processEvents()
            c.set_game_mode(True);assert w.care_art.bytes==0
        finally:app.aboutToQuit.disconnect(c.cleanup);c.cleanup();w._allow_close=True;w.close()
    (out/'geometry.json').write_text(json.dumps(records,indent=2)+'\n');print(json.dumps(records[:4],indent=2))
if __name__=='__main__':main()
