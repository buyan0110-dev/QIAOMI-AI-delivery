"""Actual Linux/Qt frame captures, not Windows screenshots or semantic CV tests.
python scripts/preview_refinement2.py [--before /path/to/previous/source]
"""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import Qt
from PySide6.QtGui import QImage,QPainter,QColor,QFont
from PySide6.QtWidgets import QApplication
from qiaomi.ui.pet import PetWindow
from qiaomi.personality_assets import LazySkin

class Clock:
    now=0
    def elapsed(self):return self.now

def capture(pet,app,skin,state,index,clock):
    pet.sprites=skin;pet.state=state;pet._state_started=0;pet.clip_duration=0;pet._bubble=''
    clock.now=round((index+.25)/skin.animations[state][1]*1000)
    pet._frame_cache.clear();pet.update_chrome();pet.enter_button.hide();app.processEvents();pet.timer.stop();pet.repaint()
    assert pet._hit_body_frame==index,(state,index,pet._hit_body_frame)
    return pet.grab().toImage()

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--before',type=Path);parser.add_argument('--output',type=Path,default=ROOT/'docs/refinement2/previews');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    app=QApplication.instance() or QApplication([]);pet=PetWindow();pet.personality_interactions=True;pet.show();pet.timer.stop();clock=Clock();pet.elapsed=clock
    skin=LazySkin();assert not skin.error,skin.error
    prior=LazySkin(args.before/'assets/personality/manifest.json') if args.before else None
    if prior:assert not prior.error,prior.error
    names=json.loads((ROOT/'docs/refinement2/changed-frames.json').read_text());states=sorted({n.rsplit('-',1)[0] for n in names});sequence=[]
    animation=args.output/'sequence';animation.mkdir(exist_ok=True);counter=0
    for state in states:
        count=len(set(skin.entries[state]['frames']));columns=2 if count<=4 else 3;before=[];after=[]
        for i in range(count):
            new=capture(pet,app,skin,state,i,clock);after.append(new);new.save(str(args.output/f'{state}-{i}-qt-after.png'))
            old=capture(pet,app,prior,state,i,clock) if prior else None
            if old is not None:before.append(old)
            canvas=QImage(600 if old is not None else 300,390,QImage.Format.Format_RGB32);canvas.fill(QColor('#263340'));p=QPainter(canvas);p.setFont(QFont('sans-serif',10));p.setPen(QColor('white'));p.drawText(8,18,f'{state} / frame {i} / Qt offscreen')
            if old is not None:p.drawText(8,37,'BEFORE');p.drawImage(0,40,old);p.drawText(308,37,'AFTER');p.drawImage(300,40,new)
            else:p.drawImage(0,40,new)
            p.end();canvas.save(str(animation/f'{counter:03}.png'));sequence.append({'index':counter,'state':state,'source_frame':i});counter+=1
        width=columns*300
        sheet=QImage(width*(2 if before else 1),2*350+36,QImage.Format.Format_RGB32);sheet.fill(QColor('#e6edf3'));p=QPainter(sheet);p.setPen(QColor('#1a2535'));p.setFont(QFont('sans-serif',12));p.drawText(10,24,state+' BEFORE / Qt offscreen' if before else state+' AFTER / Qt offscreen')
        if before:p.drawText(width+10,24,state+' AFTER / Qt offscreen')
        for i,new in enumerate(after):
            if before:p.drawImage(i%columns*300,36+i//columns*350,before[i])
            p.drawImage((width if before else 0)+i%columns*300,36+i//columns*350,new)
        p.end();sheet.save(str(args.output/f'{state}-before-after-qt.png'))
    (args.output/'sequence.json').write_text(json.dumps(sequence,indent=2))
    pet.hide();pet.close();pet.deleteLater();app.processEvents();print('Actual Qt frame pairs:',counter)
if __name__=='__main__':main()
