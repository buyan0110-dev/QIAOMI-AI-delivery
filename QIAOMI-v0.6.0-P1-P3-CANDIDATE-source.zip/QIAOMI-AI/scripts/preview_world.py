import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from PySide6.QtTest import QTest
from pathlib import Path
from tempfile import TemporaryDirectory
from qiaomi.app import Controller
app=QApplication([]);QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
tmp=TemporaryDirectory();c=Controller(app,Path(tmp.name),smoke=True)
c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
c.companion_stories.safe_event('first-touch','touch')
c.companion_stories.safe_event('first-feed','feed')
c.companion_stories.find('heart');c.companion_policy.cancel()
c.companion_data.place('main','sofa');c.companion_data.place('small1','books')
c.window.resize(1300,920);c.show_assistant();QTest.qWait(100)
for kind,page in c.world_pages.items():
 c.window.navigate(5+list(c.world_pages).index(kind));page.refresh();QTest.qWait(60);c.window.grab().save('docs/world/screenshots/'+kind+'.png')
c.show_companion();QTest.qWait(50);c.companion_window.grab().save('docs/world/screenshots/settings.png');c.companion_window.hide()
c.personality.interrupt_for_task();c.personality._normal();c.start_minigame('paw');QTest.qWait(50);c.minigame.grab().save('docs/world/screenshots/paw-game.png');c.minigame.reject()
c.cleanup();app.processEvents()
