"""Isolated actual Qt widget smoke/captures and short CPU sample, no models/network.
Use QT_QPA_PLATFORM=offscreen on headless Linux. Windows shell is not certified.
"""
import argparse,json,os,platform,sys,tempfile,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from PySide6.QtTest import QTest
from PySide6.QtCore import QTimer,Qt
from qiaomi.app import Controller
from measure_idle import rss_bytes

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    app=QApplication([]);app.setQuitOnLastWindowClosed(False)
    simulated=not QSystemTrayIcon.isSystemTrayAvailable()
    if simulated:QSystemTrayIcon.isSystemTrayAvailable=staticmethod(lambda:True)
    report=dict(platform=platform.platform(),qt_platform=os.environ.get('QT_QPA_PLATFORM','native'),tray_simulated=simulated,checks=[],metrics=[],limitations='Real Qt widgets with isolated synthetic data; not Windows shell, real microphone, GPU, game or long-duration validation.')
    with tempfile.TemporaryDirectory(prefix='qiaomi-v050-smoke-') as folder:
        c=Controller(app,Path(folder),smoke=True);c.tray.showMessage=lambda *a:None;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();c.personality.preferences.values['reunion_enabled']=False
        def capture(name):
            app.processEvents();QTest.qWait(80)
            assert c.pet.grab().save(str(args.output/(name+'.png')))
        def action(name):
            c.care.cancel();c.handle_life_action(name);assert c.care.active and c.care.active.name==name
        try:
            c.show_life_panel();app.processEvents()
            for theme,scale in [('light',100),('dark',150)]:
                c.change_appearance(theme,scale,False);QTest.qWait(80)
                assert c.life_window.grab().save(str(args.output/('panel-'+theme+'-'+str(scale)+'.png')))
            c.life_window.hide();c.change_appearance('light',100,False)
            for name in ['fish','bowl','quick_feed','quick_wash','wand','yarn','mouse']:
                action(name)
                if name=='wand':c.care.pointer('head',230,150)
                capture(name);c.care.finish();assert c.care.active is None and c.pet.care_visual is None
                report['checks'].append(name)
            action('bath')
            for index in range(5):
                if index:
                    c.care.next_bath()
                if index==1:
                    for zone in ['head','back','belly','front_left','hind_left']:
                        QTest.qWait(210);c.care.scrub(zone)
                capture('bath-'+str(index))
            c.care.next_bath();assert c.care.state.values['cleanliness']==100
            c.life_window.hide();report['checks'].append('bath-all-stages')
            # Actual GUI time, no accelerated-clock CPU claims.
            for mode in ['normal_idle','game_deep_sleep']:
                c.care.cancel();c.personality.interrupt_for_task();c.personality._normal()
                if mode=='game_deep_sleep':c.set_game_mode(True)
                start=time.perf_counter();cpu=time.process_time();QTest.qWait(2500);elapsed=time.perf_counter()-start
                rss=rss_bytes();record=dict(mode=mode,seconds=round(elapsed,3),cpu_percent_one_core=round((time.process_time()-cpu)/elapsed*100,3),rss_mib=round(rss/1048576,2) if rss else None,life_timer=c.care.timer.isActive(),life_action_timer=c.care.action_timer.isActive(),pet_timer=c.pet.timer.isActive(),personality_timers={n:getattr(c.personality,n).isActive() for n in ['next_action','phase_timer','neglect_timer','dream_timer','mood_timer']},voice_pid=c.voice.process.processId(),microphone=c.voice.listening,decoded_frame_bytes=getattr(c.pet.sprites,'cached_bytes',0))
                if mode=='game_deep_sleep':
                    assert not record['life_timer'] and not record['life_action_timer'] and not record['pet_timer'] and not any(record['personality_timers'].values())
                report['metrics'].append(record)
            c.system_power(False);assert c.game_mode
            c.wake_qiaomi();assert not c.game_mode and not c.care.dormant
            report['checks']+=['game-all-timers-stopped','system-resume-cannot-wake-game','manual-wake-restores']
            c.care.state.change(energy=42);c.care.persist();assert json.loads((Path(folder)/'life.json').read_text())['energy']==42
            assert not c.runtime_errors and not c.voice.process.processId() and c.worker is None
            report['checks'].append('save-and-no-model-or-mic-worker')
        finally:
            app.aboutToQuit.disconnect(c.cleanup);c.cleanup();assert not c.care.timer.isActive() and not c.care.action_timer.isActive()
            c.window._allow_close=True;c.window.close();c.pet.hide()
    report['passed']=True;(args.output/'smoke.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');print(json.dumps(report,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
