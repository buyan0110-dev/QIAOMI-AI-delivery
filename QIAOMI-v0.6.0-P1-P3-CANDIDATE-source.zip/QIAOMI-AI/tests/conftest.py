"""Drain Qt deferred destruction after fixtures release their owned resources.
processEvents alone does not flush DeferredDelete; otherwise this many real-Qt
integration tests retain hundreds of closed windows until interpreter shutdown.
"""
import pytest

@pytest.fixture(autouse=True)
def drain_qt_deferred_delete():
    yield
    from PySide6.QtCore import QCoreApplication,QEvent
    if QCoreApplication.instance() is not None:
        QCoreApplication.sendPostedEvents(None,QEvent.Type.DeferredDelete)
