"""Geometry and resource safeguards; not semantic anatomy certification."""
import json
from pathlib import Path
import pytest
from qiaomi.ui.sprite_layout import sprite_destination
from scripts.audit_assets import audit_image
ROOT=Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('state,axis,bound',[('edge_top','y',0),('edge_bottom','y',350),('edge_left','x',0),('edge_right','x',300)])
def test_contact_meets_real_viewport(state,axis,bound):
    entry=json.loads((ROOT/'assets/personality/manifest.json').read_text())['states'][state]
    contact=entry['screen_contact'];r=sprite_destination(state,contact=contact)
    value=r.x()+contact[0]*r.width() if axis=='x' else r.y()+contact[1]*r.height()
    assert value==pytest.approx(bound)

@pytest.mark.parametrize('state',['edge_top','edge_bottom','edge_left','edge_right','touch_tail','angry_tail','reunion_cuddle'])
def test_repaired_resources_valid_and_shared_registration(state):
    entry=json.loads((ROOT/'assets/personality/manifest.json').read_text())['states'][state]
    assert len(entry['interaction_box'])==4
    for name in set(entry['frames']):
        path=ROOT/'assets/personality'/name;before=path.read_bytes();r=audit_image(path)
        assert r['alpha_channel'] and (r['width'],r['height'])==(256,256)
        assert r['fully_transparent_pixels']>0
        assert path.read_bytes()==before

def test_touch_round_trip_uses_same_unique_tail_frames():
    entry=json.loads((ROOT/'assets/personality/manifest.json').read_text())['states']['touch_tail']
    assert entry['frames']==[f'touch_tail-{i}.webp' for i in [0,1,2,3,2,1,0]]
    assert entry['hold_last'] is True

def test_invalid_contact_uses_safe_default():
    assert sprite_destination('edge_right',contact=[float('nan'),.5])==sprite_destination('edge_right')
