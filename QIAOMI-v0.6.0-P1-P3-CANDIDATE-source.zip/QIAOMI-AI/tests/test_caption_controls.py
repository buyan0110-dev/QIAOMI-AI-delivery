"""Standard caption behavior through actual Qt button clicks, not Win11 shell."""
from PySide6.QtCore import Qt,QPoint
from PySide6.QtTest import QTest
from test_desktop_lifecycle import app,controller

def test_caption_order_and_pink_surface_icon_render(controller):
    c=controller;c.show_assistant();c.app.processEvents();bar=c.window.title_controls
    buttons=(bar.minimize,bar.maximize,bar.close_button)
    assert [bar.layout().itemAt(i).widget() for i in range(3)]==list(buttons)
    for b in buttons:
        image=b.grab().toImage();assert image.width()==46 and image.height()==32
        assert image.pixelColor(2,2).name()!='#dfe5ec'
        position=b.mapTo(c.window,QPoint(2,2));surface=c.window.grab().toImage().pixelColor(position)
        assert surface.alpha()==255 and surface.red()>surface.blue() and surface.blue()>surface.green()
    assert bar.minimize.toolTip()=='最小化' and bar.maximize.toolTip()=='最大化'

def test_caption_maximize_and_restore_updates_glyph(controller):
    c=controller;w=c.window;c.show_assistant();c.app.processEvents();w._screen_timer.stop();w.resize(1080,780)
    QTest.mouseClick(w.maximize_button,Qt.MouseButton.LeftButton);c.app.processEvents()
    assert w.isMaximized() and w.maximize_button.restore and w.maximize_button.toolTip()=='还原'
    assert not w.maximize_button.grab().isNull()
    QTest.mouseClick(w.maximize_button,Qt.MouseButton.LeftButton);c.app.processEvents()
    assert not w.isMaximized() and not w.maximize_button.restore and w.maximize_button.toolTip()=='最大化'
    assert not c.game_mode and c.worker is None

def test_caption_minimize_is_not_exit_or_game_sleep(controller):
    c=controller;c.show_pet();c.show_assistant();c.app.processEvents()
    QTest.mouseClick(c.window.minimize_button,Qt.MouseButton.LeftButton);c.app.processEvents()
    assert c.window.isMinimized() and not c.closed and not c.game_mode and c.pet.isVisible()
    c.window.showNormal();assert not c.window.isMinimized()

def test_caption_close_only_hides_but_keeps_pet_and_tray(controller):
    c=controller;c.show_pet();c.show_assistant();c.app.processEvents()
    QTest.mouseClick(c.window.close_button,Qt.MouseButton.LeftButton);c.app.processEvents()
    assert not c.window.isVisible() and not c.closed and c.pet.isVisible() and c.tray.isVisible()

def test_minimized_care_window_does_not_refresh_scene(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();c.show_assistant();c.window.open_care(1);c.care.request('bath');c.care.next_bath();c.app.processEvents();scene=c.window.care_workspace.bath.scene
    assert scene.timer.isActive();c.window.showMinimized();c.app.processEvents();assert not scene.timer.isActive()
    c.window.showNormal();c.app.processEvents();assert scene.timer.isActive()
