import pytest
from PySide6.QtCore import QPoint
from PySide6.QtTest import QTest
from qiaomi.companion_runtime import MICROS,DREAMS
from test_desktop_lifecycle import app,controller,until

@pytest.fixture
def runtime(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();c.pet.clear_bubble()
    r=c.companion_runtime;r.timer.stop();r.motion.stop();return c,r

@pytest.mark.parametrize('kind',MICROS)
def test_micro_visible_overlay_preserves_main_and_finishes(runtime,kind):
    c,r=runtime;phase=c.personality.phase;state=c.pet.state
    assert r.start('F05',kind,.04);assert c.pet.ambient_visual['kind']==kind
    assert not c.pet.grab().isNull();assert (c.personality.phase,c.pet.state)==(phase,state)
    until(lambda:c.pet.ambient_visual is None);assert not r.end.isActive()

@pytest.mark.parametrize('legacy,new,bubbles,reduced,dnd',[(False,True,True,False,False),(True,False,True,False,False),(True,True,False,False,False),(True,True,True,True,False),(True,True,True,False,True)])
def test_dream_switches_all_respected(runtime,legacy,new,bubbles,reduced,dnd):
    c,r=runtime;p=c.personality;p.preferences.values.update(dream_enabled=legacy,bubbles_enabled=bubbles)
    c.companion_preferences.values.update(F03=new,reduced_motion=reduced,do_not_disturb=dnd)
    c.pet.play_clip('sleep',0);p._set_phase('sleeping');p.settings_changed();r.sync()
    assert not r.dream() and not p.dream_timer.isActive()

def test_six_dreams_and_no_old_bubble_overlap(runtime):
    c,r=runtime;assert len(DREAMS)==6;p=c.personality;c.pet.play_clip('sleep',0);p._set_phase('sleeping')
    assert r.dream();text=c.pet._bubble;assert c.pet.ambient_visual['kind']=='dream'
    p._dream_due();assert c.pet._bubble==text
    c.pet.interaction.emit('head');assert c.pet.ambient_visual is None and c.pet._bubble!=text

def test_old_dream_off_persisted_then_on_works(runtime):
    c,r=runtime;c.personality.preferences.values['dream_enabled']=False;c.personality.preferences.save()
    c.pet.play_clip('sleep',0);c.personality._set_phase('sleeping');assert not r.dream()
    c.personality.preferences.values['dream_enabled']=True;c.personality.settings_changed();assert r.dream()

def test_near_cursor_observes_far_releases_no_body_override(runtime):
    c,r=runtime;r.cursor=lambda:c.pet.mapToGlobal(QPoint(190,190));r.tick()
    assert c.pet.ambient_visual['kind']=='watch' and r.motion.isActive() and c.companion_policy.active is None
    assert c.personality.phase=='idle';r.cursor=lambda:c.pet.mapToGlobal(QPoint(900,900));r.track()
    assert c.pet.ambient_visual is None and not r.motion.isActive()

def test_three_local_clicks_defer_until_original_touch_finishes(runtime):
    c,r=runtime
    for _ in range(3):c.pet.interaction.emit('head')
    assert r.pending and c.personality.phase=='touch' and c.pet.ambient_visual is None
    c.personality._normal();r.next_watch=1e12;r.tick();assert c.pet.ambient_visual['kind']=='imitate'
    assert c.personality.phase=='companion'
    c.pet.interaction.emit('front_left');assert c.pet.ambient_visual is None and c.pet.state=='touch_front_left'

def test_imitation_does_not_forgive_sulk(runtime):
    c,r=runtime;c.personality.life.sulking=True;c.personality.life.soothe_count=1;c.personality._set_phase('angry')
    for _ in range(3):r.touched('head')
    assert r.pending is None and c.personality.life.soothe_count==1

def test_normal_return_observes_idle_cooldown_and_keeps_sulk(runtime):
    c,r=runtime;idle=[1000];r.idle=lambda:idle[0];r.foreground=lambda:True;r.next_watch=1e12;r.tick();assert r.away
    c.personality.life.sulking=True;c.personality.life.soothe_count=2;c.personality._set_phase('angry')
    idle[0]=0;r.tick();assert c.companion_policy.active=='F09' and c.pet.state=='attention_wave'
    assert c.personality.life.sulking and c.personality.life.soothe_count==2
    c.companion_policy.cancel();assert not r.returned()

def test_fullscreen_or_unknown_drops_return(runtime):
    c,r=runtime;r.foreground=lambda:False;assert not r.returned() and c.pet.ambient_visual is None

def test_real_game_stops_all_new_timers_and_never_auto_wakes(runtime):
    c,r=runtime;r.start('F05','peek');c.set_game_mode(True)
    assert not any(t.isActive() for t in (r.timer,r.motion,r.end)) and not c.pet.ambient_visual
    r.idle=lambda:0;r.away=True;r.tick();assert c.game_mode and not r.returned()
    c.wake_qiaomi();assert not r.away and not r.pending and not r.effects

def test_settings_real_native_switch_and_preview(runtime):
    c,r=runtime;c.show_companion();c.companion_window.switches['F01'].setChecked(False)
    assert not c.companion_preferences.values['F01']
    c.companion_window.preview.emit('proud');assert c.pet.ambient_visual['kind']=='proud'
    c.companion_window.switches['do_not_disturb'].setChecked(True)
    assert not c.pet.ambient_visual and not r.timer.isActive()

def test_os_sleep_cleans_effect_and_exit_stops(runtime):
    c,r=runtime;r.start('F05','shy');c.system_power(True)
    assert not c.pet.ambient_visual and not r.timer.isActive();c.system_power(False)
    c.cleanup();assert not any(t.isActive() for t in (r.timer,r.motion,r.end))
