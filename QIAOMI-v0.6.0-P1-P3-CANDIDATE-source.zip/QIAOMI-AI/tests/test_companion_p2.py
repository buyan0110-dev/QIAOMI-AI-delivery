import sqlite3,json,pytest
from qiaomi.companion_data import CompanionData,ITEMS
from qiaomi.companion_stories import PRANKS
from test_desktop_lifecycle import app,controller,until

def test_durable_dedup_delete_clear_export_no_old_database_change(tmp_path):
 old=tmp_path/'qiaomi.db';old.write_bytes(b'untouched memory');d=CompanionData(tmp_path)
 for item in ITEMS:
  assert d.event('a-'+item,'gift',item=item)
  assert not d.event('a-'+item,'gift',item=item)
  assert d.event('b-'+item,'gift',item=item)
 assert len(d.collection())==7 and all(r[1]==2 for r in d.collection())
 d.close();d=CompanionData(tmp_path);assert not d.event('a-yarn','gift',item='yarn')
 row=d.memories()[0];d.delete(row[0]);assert len(d.memories())==2
 d.clear();assert not d.memories();assert not d.event('a-yarn','gift',item='yarn')
 d.export(tmp_path/'export.json');assert len(json.loads((tmp_path/'export.json').read_text())['collection'])==7
 assert old.read_bytes()==b'untouched memory';d.close()

def test_transaction_rolls_back_receipt_on_failure(tmp_path):
 d=CompanionData(tmp_path)
 d.db.execute("CREATE TRIGGER fail BEFORE INSERT ON memories BEGIN SELECT RAISE(ABORT,'fault');END")
 with pytest.raises(sqlite3.IntegrityError):d.event('one','gift',item='fish')
 assert not d.collection() and not d.db.execute('SELECT * FROM receipts').fetchall();d.close()

@pytest.mark.parametrize('kind',PRANKS)
def test_four_pranks_owned_phase_touch_cancel(controller,kind):
 c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
 assert c.companion_stories.prank(kind);assert c.personality.phase=='companion'
 c.companion_policy.refresh();assert c.companion_policy.active=='F07'
 c.pet.interaction.emit('head');assert c.companion_policy.active is None and c.pet.ambient_visual is None
 assert c.personality.phase in ('touch','finish')

def test_gift_survives_visual_cancel_and_record_switch(controller):
 c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
 c.companion_preferences.values['F10']=False
 assert c.companion_stories.find('heart');c.companion_policy.cancel()
 assert c.companion_data.collection()[0][0]=='heart' and not c.companion_data.memories()
 c.companion_preferences.values['F10']=True;c.pet.interaction.emit('head');c.pet.interaction.emit('head')
 assert len(c.companion_data.memories())==1
 c.set_game_mode(True);assert not c.companion_stories.find() and not c.companion_stories.safe_event('x','game')
