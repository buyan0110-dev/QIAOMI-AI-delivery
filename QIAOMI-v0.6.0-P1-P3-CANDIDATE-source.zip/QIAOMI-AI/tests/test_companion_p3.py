import pytest
from PySide6.QtCore import QPointF,Qt
from PySide6.QtTest import QTest
from qiaomi.companion_data import CompanionData,FURNITURE
from test_desktop_lifecycle import app,controller,until

@pytest.fixture
def ready(controller):
 c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();return c

def test_eight_furniture_slots_persist_and_never_exceed_three(tmp_path):
 d=CompanionData(tmp_path)
 for item,(_,_,kind,_) in FURNITURE.items():
  slot='main' if kind=='main' else 'small1';d.place(slot,item);assert d.room()[slot]==item
  with pytest.raises(ValueError):d.place('small2' if kind=='main' else 'main',item)
 d.place('small2','books');assert len(d.room())<=3;before=d.room();d.close();d=CompanionData(tmp_path);assert d.room()==before
 d.place('main',None);assert 'main' not in d.room();d.close()

@pytest.mark.parametrize('kind',['paw','yarn','fish'])
def test_real_game_session_touch_cancel_no_lingering_timer(ready,kind):
 c=ready;assert c.start_minigame(kind);g=c.minigame
 assert g.isVisible() and c.personality.phase=='minigame'
 c.companion_policy.refresh();assert g.token and g.timeout.isActive()
 assert not c.start_minigame(kind)
 if kind=='paw':QTest.mouseClick(g.buttons[0],Qt.MouseButton.LeftButton);assert g.note.text()
 if kind=='fish':g.board.throw();assert g.board.timer.isActive()
 c.pet.interaction.emit('head')
 assert not g.isVisible() and g.token is None and not g.timeout.isActive()
 if g.board:assert not g.board.timer.isActive()
 assert c.personality.phase in ('touch','finish')

def test_games_close_escape_timeout_disable_suspend_and_game(ready):
 c=ready
 for how in ['escape','timeout','disable','suspend','game']:
  c.personality.interrupt_for_task();c.personality._normal();assert c.start_minigame('fish');g=c.minigame;g.board.throw()
  if how=='escape':QTest.keyClick(g,Qt.Key.Key_Escape)
  elif how=='timeout':g.timeout.timeout.emit()
  elif how=='disable':c.edit_companion('F08',False)
  elif how=='suspend':c.system_power(True)
  else:c.set_game_mode(True)
  assert not g.isVisible() and not g.timeout.isActive() and not g.board.timer.isActive() and g.token is None
  if how=='disable':c.edit_companion('F08',True)
  if how=='suspend':c.system_power(False)
 assert c.game_mode and not c.start_minigame('paw');c.open_world('toys');assert not c.window.isVisible()

def test_native_navigation_and_old_pages_coexist(ready,tmp_path):
 c=ready;assert c.window.pages.count()==10
 for i in range(10):
  c.window.navigate(i);assert c.window.pages.currentIndex()==i
  assert not c.window.grab().isNull()
 c.open_world('collection');p=c.world_pages['collection'];assert p.cards.count()==0
 c.personality.interrupt_for_task();c.personality._normal();assert c.companion_stories.find('fish');p.refresh();assert p.cards.count()==1
 album=c.world_pages['album'];album.refresh();assert album.rows.count()==1
 album.rows.setCurrentRow(0);album.delete();assert not c.companion_data.memories()
 c.companion_data.export(tmp_path/'export.json');assert (tmp_path/'export.json').exists()

def test_room_apply_preview_and_desktop_toggle_and_game(ready):
 c=ready;p=c.world_pages['room'];p.choose('sofa');assert p.preview.pending=='sofa'
 p.apply();assert c.companion_data.room()['main']=='sofa'
 assert c.furniture_choices()==['rest'];assert not c.pet.room_props
 c.edit_companion('desktop_furniture',True);assert c.pet.room_props=={'main':'sofa'};assert not c.pet.grab().isNull()
 c.edit_companion('F04',False);assert not c.pet.room_props and not c.furniture_choices()
 c.set_game_mode(True);assert not c.companion_runtime.timer.isActive()

def test_f08_lease_exceeds_10_seconds_real_qt_refresh(ready):
 c=ready;assert c.start_minigame('paw');g=c.minigame
 token=g.token;effect=c.companion_policy._effects['visual']
 assert 110<effect.expires-c.companion_policy.now()<=120
 c.companion_policy.now=lambda:effect.expires-1;c.companion_policy.refresh();assert g.token==token
 c.companion_policy.now=lambda:effect.expires+1;c.companion_policy.refresh();assert not g.isVisible() and g.token is None
