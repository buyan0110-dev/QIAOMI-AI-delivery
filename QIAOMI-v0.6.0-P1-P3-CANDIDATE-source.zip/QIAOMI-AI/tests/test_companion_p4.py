import json,sqlite3,pytest
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from qiaomi.upgrade import ensure_upgrade_backup
from test_desktop_lifecycle import app,controller

def test_backup_includes_committed_sidecar_wal_and_accurate_versions(tmp_path):
 for name in ['qiaomi.db','companion.db']:
  db=sqlite3.connect(tmp_path/name);db.execute('PRAGMA journal_mode=WAL');db.execute('CREATE TABLE marker(value)');db.execute('INSERT INTO marker VALUES (42)');db.commit()
  # Keep it open while taking the online snapshot.
  if name=='qiaomi.db':first=db
  else:second=db
 out=ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0.json',target_version='0.6.0',source_version='0.6.0-p0-fix.1')
 meta=json.loads((out/'BACKUP.json').read_text());assert meta['target_version']=='0.6.0' and meta['version']=='0.6.0-p0-fix.1 -> 0.6.0'
 for name in ['qiaomi.db','companion.db']:
  db=sqlite3.connect(out/name);assert db.execute('SELECT value FROM marker').fetchone()==(42,);db.close()
 first.close();second.close()
 assert ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0.json',target_version='0.6.0') is None

@pytest.mark.parametrize('theme',['pink','light','dark'])
@pytest.mark.parametrize('scale',[100,110,125,150])
def test_new_pages_render_with_old_themes_and_scales(controller,theme,scale):
 c=controller;c.appearance.values.update(theme=theme,scale=scale);c.appearance.apply(save=False);c.window.resize(1100,800);c.show_assistant()
 for index in range(5,10):
  c.window.navigate(index);QTest.qWait(5);assert not c.window.grab().isNull()
 assert c.window.pages.count()==10

def test_no_companion_timers_or_events_and_no_wake_through_new_ui(controller):
 c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();assert c.start_minigame('fish');g=c.minigame;g.board.throw();c.set_game_mode(True)
 baseline=len(c.companion_data.memories());c.companion_runtime.tick();c.companion_stories.tick();c.open_world('room');c.show_companion();assert not c.start_minigame('paw')
 assert c.game_mode and not c.window.isVisible() and not c.companion_window.isVisible()
 assert not any(t.isActive() for t in c.companion_runtime.findChildren(QTimer));assert not any(t.isActive() for t in g.findChildren(QTimer));assert len(c.companion_data.memories())==baseline
 assert not c.pet.timer.isActive() and not c.care.timer.isActive()

def test_album_six_milestones_switch_and_daily_cap(controller):
 c=controller
 for key,kind in [('first-touch','touch'),('first-feed','feed'),('first-bath','bath'),('first-game','game'),('first-soothe','soothe'),('first-gift','gift')]:assert c.companion_stories.safe_event(key,kind)
 assert len(c.companion_data.memories())==6
 for n in range(10):c.companion_stories.safe_event('repeat-'+str(n),'gift',item='fish')
 assert len([x for x in c.companion_data.memories() if x[1]=='gift'])==3
 c.edit_companion('F10',False);assert not c.companion_stories.safe_event('new-dream','dream')
 assert c.companion_stories.safe_event('find-still-works','gift',item='heart')
 assert dict((row[0],row[1]) for row in c.companion_data.collection())['heart']==1
