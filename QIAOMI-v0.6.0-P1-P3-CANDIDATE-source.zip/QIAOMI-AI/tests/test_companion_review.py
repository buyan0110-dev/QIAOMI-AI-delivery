import json,sqlite3
from pathlib import Path
import pytest
from PySide6.QtCore import QTimer
from qiaomi.companion_policy import CompanionPolicy,CompanionPreferences
from qiaomi.upgrade import ensure_upgrade_backup
from test_desktop_lifecycle import app,controller

def context(**changes):
    return dict(dict(game=False,system_sleep=False,task=False,sulking=False,visible=True,phase='idle',care=False,bubble_active=False,dragging=False),**changes) if not changes else {**context(),**changes}

def policy(tmp_path,c):return CompanionPolicy(CompanionPreferences(tmp_path),lambda:c)

def test_dream_sleep_allowed_but_existing_bubble_blocks(tmp_path):
    c=context(phase='sleeping');p=policy(tmp_path,c)
    assert p.allowed('F03');c['bubble_active']=True;assert not p.allowed('F03')
    c['bubble_active']=False;t=p.claim('F03',lambda:None);assert t
    c['bubble_active']=True;p.refresh();assert p.active=='F03'
    assert not p.claim('F03',lambda:None);c['phase']='idle';p.refresh();assert p.active is None

def test_passive_record_does_not_own_animation_and_is_once(tmp_path):
    c=context(phase='care',care=True);p=policy(tmp_path,c);db=sqlite3.connect(tmp_path/'synthetic-events.db');db.execute('create table events(kind text)')
    for phase,event in [('care','bath_complete'),('touch','first_touch'),('soothing','forgiven')]:
        c['phase']=phase;writer=lambda e=event:db.execute('insert into events values (?)',(e,))
        assert p.record(event,writer) and not p.record(event,writer);assert p.active is None
    assert db.execute('select count(*) from events').fetchone()[0]==3
    c['game']=True;assert not p.record('new',lambda:db.execute("insert into events values ('bad')"));db.close()

def test_record_reentry_and_error_retry(tmp_path):
    p=policy(tmp_path,context());seen=[]
    assert p.record('one',lambda:seen.append(p.record('one',lambda:None))) and seen==[False]
    with pytest.raises(RuntimeError):p.record('retry',lambda:(_ for _ in ()).throw(RuntimeError()))
    assert p.record('retry',lambda:None)

def test_observer_never_blocks_visual_and_overlay_is_distinct(tmp_path):
    c=context();p=policy(tmp_path,c);cancelled=[]
    observer=p.observe(lambda:cancelled.append('observe'));assert observer and p.active is None
    micro=p.overlay(lambda:cancelled.append('micro'));assert micro
    event=p.claim('F07',lambda:cancelled.append('event'));assert event and cancelled==['micro']
    assert not p.claim('F01',lambda:None) and not p.claim('F10',lambda:None)
    assert not p.overlay(lambda:None);p.finish(event);assert p.active is None and 'observe' not in cancelled
    p.cancel();assert cancelled==['micro','event','observe']

@pytest.mark.parametrize('phase',['idle','daily','sleeping','angry'])
def test_micro_allowed_without_mutating_original_state(tmp_path,phase):
    c=context(phase=phase,sulking=phase=='angry');p=policy(tmp_path,c);before=dict(c)
    t=p.overlay(lambda:None);assert t;p.finish(t);assert c==before

@pytest.mark.parametrize('phase',['touch','soothing','finish','touch_reset','seek','care','reunion','welcome'])
def test_visual_never_takes_over_protected_feedback(tmp_path,phase):
    c=context(phase=phase);p=policy(tmp_path,c)
    assert all(not p.allowed(f) for f in ('F01','F03','F05','F07','F09'))
    assert p.allowed('F10')

def test_tokens_preemption_timeout_and_reentrant_cleanup(tmp_path):
    c=context();p=policy(tmp_path,c);clock=[100.];p.now=lambda:clock[0];seen=[]
    first=p.claim('F02',lambda:seen.append(p.claim('F08',lambda:None)))
    newer=p.claim('F07',lambda:seen.append('cleaned'),duration=2,cooldown=4)
    assert newer and seen==[None] and not p.finish(first) and p.active=='F07'
    clock[0]+=3;p.refresh();assert seen==[None,'cleaned'] and p.active is None
    assert not p.claim('F07',lambda:None);clock[0]+=5;last=p.claim('F07',lambda:None)
    assert last and not p.finish(newer);p.close();assert not p.finish(last)

@pytest.mark.parametrize('feature',['F01','F03','F07'])
@pytest.mark.parametrize('zone',['head','front_left','drag'])
def test_cancel_happens_before_old_body_feedback(controller,feature,zone):
    c=controller;p=c.personality;c.show_pet();p.interrupt_for_task();p._normal();c.pet.clear_bubble()
    if feature=='F03':c.pet.play_clip('sleep',0);p._set_phase('sleeping')
    timer=QTimer(c);timer.start(50000);calls=[]
    def clean():timer.stop();calls.append('cancel');c.pet.play_clip('error',0);c.pet.clear_bubble()
    token=c.companion_policy.observe(clean) if feature=='F01' else c.companion_policy.claim(feature,clean)
    assert token
    if zone=='drag':c.pet.drag_started.emit();assert c.pet.state=='idle'
    else:
        c.pet.interaction.emit(zone)
        assert p.phase=='touch' and c.pet.state==('touch_head' if zone=='head' else 'touch_front_left')
        assert c.pet._bubble
    assert calls==['cancel'] and not timer.isActive() and c.companion_policy.active is None

def test_return_allows_sulk_without_forgiving(controller):
    c=controller;p=c.personality;c.show_pet();p.interrupt_for_task();p._normal();p.life.sulking=True;p.life.soothe_count=2;p._set_phase('angry')
    token=c.companion_policy.claim('F09',c.pet.clear_bubble);assert token
    c.pet.show_bubble('妈妈回来啦……哼！');c.companion_policy.finish(token)
    assert p.life.sulking and p.life.soothe_count==2

def test_old_dream_talk_does_not_replace_owned_dream(controller):
    c=controller;p=c.personality;c.show_pet();p.interrupt_for_task();p._normal();c.pet.clear_bubble();c.pet.play_clip('sleep',0);p._set_phase('sleeping')
    token=c.companion_policy.claim('F03',c.pet.clear_bubble);assert token
    c.pet.show_bubble('测试梦泡');p._dream_due();assert c.pet._bubble=='测试梦泡'
    c.pet.interaction.emit('head');assert c.companion_policy.active is None and c.pet._bubble!='测试梦泡'

def test_backup_target_labels_and_wal(tmp_path):
    con=sqlite3.connect(tmp_path/'qiaomi.db');con.execute('pragma journal_mode=WAL');con.execute('create table old(value text)');con.execute("insert into old values ('kept')");con.commit()
    dest=ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0-p0.json',target_version='0.6.0-p0')
    assert dest.name.startswith('pre-v0.6.0-p0-')
    assert json.loads((tmp_path/'.upgrade-v0.6.0-p0.json').read_text())['version']=='0.6.0-p0'
    assert json.loads((dest/'BACKUP.json').read_text())['target_version']=='0.6.0-p0'
    db=sqlite3.connect(dest/'qiaomi.db');assert db.execute('select value from old').fetchone()[0]=='kept';db.close();con.close()

def test_valid_legacy_p0_snapshot_kept_without_rebackup_or_rewrite(tmp_path):
    (tmp_path/'life.json').write_text('{"energy":33}')
    dest=ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0-p0.json')
    before={str(p.relative_to(tmp_path)):p.read_bytes() for p in tmp_path.rglob('*') if p.is_file()}
    assert ensure_upgrade_backup(tmp_path,marker_name='.upgrade-v0.6.0-p0.json',target_version='0.6.0-p0') is None
    assert before=={str(p.relative_to(tmp_path)):p.read_bytes() for p in tmp_path.rglob('*') if p.is_file()}
    assert dest.exists()

def test_cleanup_reentrant_close_drains_other_channels(tmp_path):
    p=policy(tmp_path,context());calls=[];p.observe(lambda:calls.append('observer'))
    p.claim('F02',p.close);assert not p.claim('F07',lambda:None)
    assert p.closed and calls==['observer'] and p.active is None

def test_overlay_cleanup_close_cannot_create_new_visual_after_shutdown(tmp_path):
    p=policy(tmp_path,context());assert p.overlay(p.close)
    assert not p.claim('F07',lambda:None)
    assert p.closed and p.active is None and not p._effects
