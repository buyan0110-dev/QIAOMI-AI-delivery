"""Resource integrity guards. These do not certify semantic anatomy."""
import hashlib,json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_export_inventory_covers_all_existing_animation_files():
    rows=json.loads((ROOT/'docs/validation/costume-tail-export.json').read_text())
    names={p.name for p in (ROOT/'assets/personality').glob('*.webp')}
    assert len(rows)==len(names)==252
    assert {r['frame'] for r in rows}==names
    for row in rows:
        assert hashlib.sha256((ROOT/'assets/personality'/row['frame']).read_bytes()).hexdigest()==row['sha256']

def test_asset_audit_has_no_basic_decode_alpha_dimension_or_path_error():
    report=json.loads((ROOT/'docs/validation/costume-tail-alpha-audit.json').read_text())
    assert report['files_checked']==252
    assert report['basic_errors']==[]
    assert report['limitations']

def test_preserved_runtime_hashes_include_interaction_voice_and_storage():
    rows=json.loads((ROOT/'docs/costume-tail/runtime-preservation.json').read_text())
    pink=json.loads((ROOT/'docs/pink/upgrade-scope.json').read_text())['updated_runtime']
    pink2=json.loads((ROOT/'docs/pink2/upgrade-scope.json').read_text())['updated_runtime']
    p0=json.loads((ROOT/'docs/v060/p0-scope.json').read_text())['updated_runtime']
    review=json.loads((ROOT/'docs/p0fix/scope.json').read_text())['updated_runtime']
    review.update(json.loads((ROOT/'docs/p1/scope.json').read_text())['updated_runtime'])
    review.update(json.loads((ROOT/'docs/world/scope.json').read_text())['updated_runtime'])
    current=lambda name: review.get(name,{}).get('after_sha256') or p0.get(name,{}).get('after_sha256') or pink2.get(name,{}).get('after_sha256') or pink.get(name,{}).get('after_sha256')
    scope=json.loads((ROOT/'docs/v050/upgrade-scope.json').read_text())['updated_runtime']
    assert set(scope)=={'qiaomi/app.py','qiaomi/personality.py','qiaomi/ui/pet.py','qiaomi/ui/assistant.py','qiaomi/ui/desktop_settings.py'}
    assert 'qiaomi/voice.py' in rows and 'qiaomi/storage.py' in rows
    for name,digest in rows.items():
        if name in scope:
            assert scope[name]['before_sha256']==digest
            assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==(current(name) or scope[name]['after_sha256'])
        else:assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==(current(name) or digest)
    changes=json.loads((ROOT/'docs/refinement2/rendering-changes.json').read_text())
    for row in changes:
        if row['path'] in scope:
            assert scope[row['path']]['before_sha256']==row['after_sha256']
            assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==(current(row['path']) or scope[row['path']]['after_sha256'])
        else:assert hashlib.sha256((ROOT/row['path']).read_bytes()).hexdigest()==row['after_sha256']


def test_candidate_is_not_mislabeled_as_windows_accepted():
    m=json.loads((ROOT/'assets/personality/manifest.json').read_text())
    assert m['costume_tail_repair']['status']=='candidate_partial_not_windows_accepted'
    assert m['states']['touch_tail']['frames']==[f'touch_tail-{i}.webp' for i in [0,1,2,3,2,1,0]]
