"""Real Qt/IPC, mocked Windows APIs. No Windows-shell validation claim."""
import ctypes
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6.QtCore import QCoreApplication, QTimer, Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QSystemTrayIcon
from qiaomi.app import Controller
from qiaomi.desktop import DesktopPreferences
from qiaomi.instance import InstanceGuard
from qiaomi.windows import AutoStartManager,ExplorerRestartFilter,gui_python,RUN_KEY,RUN_NAME

ROOT=Path(__file__).resolve().parents[1]


def until(predicate, seconds=5):
    deadline=time.monotonic()+seconds
    while not predicate() and time.monotonic()<deadline:QTest.qWait(10)
    assert predicate()

@pytest.fixture
def app():return QApplication.instance() or QApplication([])

@pytest.fixture
def controller(app,tmp_path,monkeypatch):
    monkeypatch.setattr(QSystemTrayIcon,'isSystemTrayAvailable',staticmethod(lambda:True))
    c=Controller(app,tmp_path,smoke=True)
    yield c
    if c.worker:
        c.worker.cancel();c.worker.wait(3000);app.processEvents()
    app.aboutToQuit.disconnect(c.cleanup)
    c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide();c.desktop_window.close()
    c.window.deleteLater();c.pet.deleteLater();c.desktop_window.deleteLater();c.deleteLater();app.processEvents()


class Registry:
    HKEY_CURRENT_USER='HKCU';KEY_READ=1;KEY_SET_VALUE=2;REG_SZ=1;REG_EXPAND_SZ=2
    def __init__(self):self.values={'Other app':('untouched',1)};self.writes=[]
    def OpenKey(self,hive,key,reserved,access):
        assert hive=='HKCU' and key==RUN_KEY
        return self
    CreateKeyEx=OpenKey
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def QueryValueEx(self,key,name):
        if name not in self.values:raise FileNotFoundError()
        return self.values[name]
    def SetValueEx(self,key,name,reserved,kind,command):
        self.values[name]=(command,kind);self.writes.append(('set',name))
    def DeleteValue(self,key,name):
        if name not in self.values:raise FileNotFoundError()
        del self.values[name];self.writes.append(('delete',name))


def test_autostart_default_off_user_only_and_reversible(tmp_path):
    executable=tmp_path/'folder with spaces'/'QIAOMI-AI.exe'
    executable.parent.mkdir();executable.write_bytes(b'test fixture')
    registry=Registry()
    manager=AutoStartManager(tmp_path/'private data',registry=registry,platform='win32',executable=executable,frozen=True)
    assert not manager.enabled() and registry.writes==[]
    manager.set_enabled(True)
    command=registry.values[RUN_NAME][0]
    assert command.startswith('"') and '--autostart' in command and '--data-dir' in command
    assert 'private data' in command and manager.enabled()
    assert 'cmd.exe' not in command and 'powershell' not in command.lower()
    manager.set_enabled(False);manager.set_enabled(False)
    assert not manager.enabled() and registry.values['Other app']==('untouched',1)


def test_source_autostart_and_workers_require_pythonw(tmp_path):
    executable=tmp_path/'python.exe';executable.write_bytes(b'fixture')
    with pytest.raises(RuntimeError):gui_python(executable,'win32')
    pythonw=tmp_path/'pythonw.exe';pythonw.write_bytes(b'fixture')
    registry=Registry()
    entry=tmp_path/'project space'/'scripts'/'gui_entry.pyw';entry.parent.mkdir(parents=True);entry.write_text('fixture')
    manager=AutoStartManager(tmp_path,registry=registry,platform='win32',executable=executable,frozen=False,root=tmp_path/'project space')
    manager.set_enabled(True)
    command=manager.current_command()
    assert 'pythonw.exe' in command and 'gui_entry.pyw' in command
    assert gui_python(executable,'win32')==str(pythonw)


def test_autostart_missing_pythonw_never_writes(tmp_path):
    registry=Registry()
    manager=AutoStartManager(tmp_path,registry=registry,platform='win32',executable=tmp_path/'python.exe',frozen=False)
    with pytest.raises(RuntimeError):manager.set_enabled(True)
    assert registry.writes==[]


def test_nonwindows_autostart_does_not_modify_registry(tmp_path):
    registry=Registry()
    manager=AutoStartManager(tmp_path,registry=registry,platform='linux')
    assert not manager.supported
    with pytest.raises(RuntimeError):manager.set_enabled(True)
    assert registry.writes==[]


def test_close_chat_keeps_pet_and_tray(controller):
    controller.show_pet();controller.show_assistant()
    assert controller.pet.isVisible() and controller.window.isVisible()
    controller.window.close()
    assert not controller.window.isVisible() and controller.pet.isVisible()
    assert controller.tray.isVisible() and not controller.closed
    controller.tray_activated(QSystemTrayIcon.ActivationReason.Trigger)
    assert controller.window.isVisible()


def test_pet_visibility_independent_of_chat(controller):
    controller.show_pet();controller.show_assistant();controller.toggle_pet()
    assert not controller.pet.isVisible() and controller.window.isVisible()
    controller.toggle_pet()
    assert controller.pet.isVisible() and controller.window.isVisible()
    controller.hide_to_tray()
    assert not controller.pet.isVisible() and not controller.window.isVisible()
    assert not controller.closed


def test_no_tray_never_hides_last_entry(controller,monkeypatch):
    monkeypatch.setattr(QSystemTrayIcon,'isSystemTrayAvailable',staticmethod(lambda:False))
    controller.show_pet();controller.toggle_pet()
    assert controller.pet.isVisible()
    controller.pet.hide();controller.window.hide();controller.ensure_tray()
    assert controller.pet.isVisible()


def test_position_atomic_save_and_unknown_fields_preserved(tmp_path):
    existing={'position':{'x':120,'y':150},'pet_manifest':'','future_option':'keep'}
    path=tmp_path/'desktop.json';path.write_text(json.dumps(existing))
    prefs=DesktopPreferences(tmp_path)
    assert prefs.values['position']==existing['position']
    prefs.values['position']={'x':155,'y':125};prefs.save()
    assert json.loads(path.read_text())['future_option']=='keep'
    assert not list(tmp_path.glob('.desktop-*.tmp'))


def test_invalid_desktop_settings_are_backed_up_before_save(tmp_path):
    path=tmp_path/'desktop.json';path.write_text('invalid original')
    prefs=DesktopPreferences(tmp_path)
    assert prefs.read_error
    prefs.save()
    assert list(tmp_path.glob('desktop.invalid-*.json'))[0].read_text()=='invalid original'
    assert json.loads(path.read_text())['position'] is None


def test_position_restore_and_offscreen_clamp(app,tmp_path):
    prefs=DesktopPreferences(tmp_path);prefs.values['position']={'x':120,'y':150};prefs.save()
    c=Controller(app,tmp_path,smoke=True)
    try:
        assert (c.pet.x(),c.pet.y())==(120,150)
        c.pet.move(99999,99999);c.pet._keep_on_screen()
        c.save_desktop()
        area=app.primaryScreen().availableGeometry()
        assert area.contains(c.pet.frameGeometry().topLeft())
        assert json.loads((tmp_path/'desktop.json').read_text())['position']=={'x':c.pet.x(),'y':c.pet.y()}
    finally:
        app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide();c.desktop_window.close()


def test_missing_custom_art_uses_visible_fallback(app,tmp_path):
    prefs=DesktopPreferences(tmp_path);prefs.values['pet_manifest']=str(tmp_path/'gone.json');prefs.save()
    c=Controller(app,tmp_path,smoke=True)
    try:
        assert c._asset_error and not c.pet.grab().isNull()
        c.report_desktop_error()
        assert '不存在' in c.window.task_label.text()
    finally:
        app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide();c.desktop_window.close()


def test_game_mode_static_no_automatic_mic_or_popup(controller,monkeypatch):
    c=controller
    notices=[]
    monkeypatch.setattr(c.tray,'showMessage',lambda *args:notices.append(args))
    c.show_pet();c.show_assistant()
    c.set_game_mode(True)
    assert c.game_mode and c.pet.low_power and not c.pet.timer.isActive()
    assert not c.pet.isVisible() and not c.window.isVisible()
    assert c.voice.background_suspended and not c.voice.wake
    assert c.voice.process.processId()==0
    c.voice.wake_box.setChecked(True)
    assert not c.voice.wake
    c.voice._wake_listen();c.voice._follow_listen()
    assert not c.voice.listening and c.voice.process.processId()==0
    c.toggle_pet();c.pet.set_state('speaking')
    assert not c.pet.isVisible() and not c.pet.timer.isActive() and not c.pet._always_on_top  # v0.4 deep sleep blocks display
    c.hide_to_tray();assert notices==[]
    c.show_assistant();assert c.window.isVisible()  # Explicit user action is permitted.
    c.personality_preferences.values['reunion_enabled']=False
    c.wake_qiaomi()
    assert c.pet.timer.isActive() and not c.voice.background_suspended
    assert not c.voice.wake and c.config.always_on_top


def test_game_mode_does_not_change_main_or_voice_preferences(controller):
    c=controller
    c.config_path.write_text('existing-main-file')
    c.voice.path.write_text('existing-voice-file')
    c.set_game_mode(True);c.set_game_mode(False)
    assert c.config_path.read_text()=='existing-main-file'
    assert c.voice.path.read_text()=='existing-voice-file'


def test_tray_recovery_keeps_menu_and_does_not_duplicate_controller(controller):
    menu=controller.tray.contextMenu()
    controller.tray.hide();controller.restore_tray()
    assert controller.tray.isVisible() and controller.tray.contextMenu() is menu
    titles=[a.text() for a in menu.actions()]
    for title in ['打开敲咪','语音设置','🎮 进入游戏模式 · 深度休眠','🐾 唤醒敲咪','开机自启动','退出敲咪']:assert title in titles
    assert controller.tray_monitor.interval()==10000


def test_explorer_restart_callback_coalesces_without_hooks(app):
    from ctypes.wintypes import MSG
    calls=[]
    api=SimpleNamespace(RegisterWindowMessageW=lambda name:777 if name=='TaskbarCreated' else 0)
    filter=ExplorerRestartFilter(lambda:calls.append(True),platform='win32',user32=api)
    message=MSG();message.message=777
    for _ in range(3):assert filter.nativeEventFilter(b'windows_generic_MSG',ctypes.addressof(message))==(False,0)
    until(lambda:len(calls)==1)


def test_single_instance_lock_endpoint_preserved(app,tmp_path):
    first=InstanceGuard(tmp_path);second=InstanceGuard(tmp_path)
    try:
        assert first.acquire() and not second.acquire()
        second.close()
        assert first.server.isListening()
    finally:first.close();second.close()
    third=InstanceGuard(tmp_path)
    try:assert third.acquire()
    finally:third.close()


@pytest.mark.parametrize('activate',[True,False])
def test_real_secondary_process_activates_or_pings_existing(app,tmp_path,activate):
    guard=InstanceGuard(tmp_path);assert guard.acquire()
    calls=[];guard.activated.connect(lambda:calls.append(True))
    code='from PySide6.QtCore import QCoreApplication; from qiaomi.instance import InstanceGuard; import sys; app=QCoreApplication([]); g=InstanceGuard(sys.argv[1]); print(g.notify_existing(activate=sys.argv[2]=="yes"),flush=True)'
    process=subprocess.Popen([sys.executable,'-c',code,str(tmp_path),'yes' if activate else 'no'],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        until(lambda:process.poll() is not None,10)
        stdout,stderr=process.communicate()
        assert process.returncode==0 and stdout.strip()=='True',stderr
        assert len(calls)==(1 if activate else 0)
    finally:
        if process.poll() is None:process.kill();process.wait()
        guard.close()


def test_single_instance_rejects_arbitrary_commands(app,tmp_path):
    from PySide6.QtNetwork import QLocalSocket
    guard=InstanceGuard(tmp_path);assert guard.acquire()
    called=[];guard.activated.connect(lambda:called.append(True))
    socket=QLocalSocket();socket.connectToServer(guard.name)
    try:
        until(lambda:socket.state()==QLocalSocket.LocalSocketState.ConnectedState)
        socket.write(b'execute anything\n');socket.flush()
        until(lambda:socket.state()==QLocalSocket.LocalSocketState.UnconnectedState)
        assert called==[]
    finally:socket.abort();guard.close()


def test_gui_spec_shortcuts_icon_and_worker_paths():
    import struct
    spec=(ROOT/'qiaomi.spec').read_text()
    assert 'console=False' in spec and 'qiaomi.ico' in spec
    assert struct.unpack('<HHH',(ROOT/'assets/qiaomi.ico').read_bytes()[:6])==(0,1,4)
    for name in ['start.vbs','install_shortcut.vbs']:
        source=(ROOT/name).read_text()
        assert 'cmd.exe' not in source.lower() and 'powershell' not in source.lower()
        assert 'pythonw.exe' in source and 'QIAOMI-AI.exe' in source
        for line in source.splitlines():assert line.count('"')%2==0,(name,line)
    assert 'voice_worker_program()' in (ROOT/'qiaomi/voice.py').read_text()


def test_full_app_duplicate_launch_and_clean_shutdown(tmp_path):
    data=tmp_path/'app data';data.mkdir()
    (data/'config.json').write_text(json.dumps(dict(provider='offline',model='qwen3:8b',share_memories=False,always_on_top=True)))
    from qiaomi.storage import Store
    store=Store(data/'qiaomi.db');store.upsert_memory('keep','existing value');store.close()
    code='''
import sys
from pathlib import Path
from PySide6.QtCore import QTimer
from qiaomi import app as module
Original=module.Controller
class TestController(Original):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  self.voice.process.started.connect(lambda: (self.folder/'worker.pid').write_text(str(self.voice.process.processId())))
  self.voice._command({'op':'unload'})
  QTimer.singleShot(4500,self.request_quit)
module.Controller=TestController
raise SystemExit(module.main(['--data-dir',sys.argv[1]]))
'''
    env=dict(os.environ,QT_QPA_PLATFORM='offscreen')
    process=subprocess.Popen([sys.executable,'-c',code,str(data)],cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    try:
        deadline=time.monotonic()+5
        log=data/'logs/qiaomi.log'
        while time.monotonic()<deadline and not (log.exists() and 'Application initialized' in log.read_text()):time.sleep(.03)
        assert process.poll() is None
        second=subprocess.run([sys.executable,'-m','qiaomi','--data-dir',str(data)],cwd=ROOT,env=env,capture_output=True,text=True,timeout=5)
        assert second.returncode==0,second.stderr
        stdout,stderr=process.communicate(timeout=10)
        assert process.returncode==0,stderr
        store=Store(data/'qiaomi.db')
        assert store.list_memories()[0]['value']=='existing value';store.close()
        assert not (data/'qiaomi.lock').exists()
        if sys.platform.startswith('linux'):
            worker_pid=int((data/'worker.pid').read_text())
            assert not Path('/proc',str(worker_pid)).exists()
    finally:
        if process.poll() is None:process.kill();process.wait()


def test_autostart_registry_error_restores_ui_without_crash(controller):
    registry=Registry()
    def denied(*args):raise PermissionError('simulated registry denial')
    registry.CreateKeyEx=denied
    exe=controller.folder/'QIAOMI-AI.exe';exe.write_bytes(b'fixture')
    controller.autostart=AutoStartManager(controller.folder,registry=registry,platform='win32',executable=exe,frozen=True)
    errors=[];controller.error=errors.append
    controller.set_autostart(True)
    assert errors and not controller.tray_autostart.isChecked()
    assert registry.writes==[]


def test_game_mode_preserves_manual_recording_and_cancels_pending_ai(controller,monkeypatch):
    from threading import Event
    import qiaomi.app as application
    entered=Event()
    def delayed(*args,**kwargs):
        stop=args[3] if len(args)>3 else kwargs['stop_event']
        entered.set();stop.wait(3);return 'late answer'
    controller.config.provider='ollama'
    monkeypatch.setattr(application,'ollama_reply',delayed)
    controller.send('temporary test request')
    until(entered.is_set)
    controller.set_game_mode(True)
    until(lambda:controller.worker is None)
    assert len(controller.store.messages())==1
    sent=[];monkeypatch.setattr(controller.voice,'_command',sent.append)
    controller.voice.listen()
    assert not controller.voice.listening and sent==[]  # v0.4 sleep blocks manual capture too
    controller.personality_preferences.values['reunion_enabled']=False
    controller.wake_qiaomi();controller.voice.listen()
    assert controller.voice.listening and sent[0]['op']=='listen'
    controller.voice.cancel_capture()
    controller.voice._event(dict(event='done',request_id=controller.voice.active_request,outcome='cancelled'))
    assert not controller.voice.retry.isActive()


def test_saved_custom_pet_and_builtin_choice_reload(app,tmp_path):
    from PySide6.QtGui import QImage,QColor
    image=QImage(24,24,QImage.Format.Format_ARGB32);image.fill(QColor('orange'));assert image.save(str(tmp_path/'cat.png'))
    manifest=tmp_path/'pet.json';manifest.write_text(json.dumps(dict(version=1,states={'idle':{'fps':2,'frames':['cat.png']}})))
    prefs=DesktopPreferences(tmp_path);prefs.values['pet_manifest']=str(manifest);prefs.save()
    c=Controller(app,tmp_path,smoke=True)
    try:
        assert 'idle' in c.pet.sprites.animations
        c.reset_pet_manifest()
        assert 'reunion_hug' in c.pet.sprites.animations
        assert json.loads((tmp_path/'desktop.json').read_text())['use_builtin_pet'] is True
    finally:
        app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide();c.desktop_window.close()
    c=Controller(app,tmp_path,smoke=True)
    try:assert 'reunion_hug' in c.pet.sprites.animations and c.desktop.values['use_builtin_pet']
    finally:
        app.aboutToQuit.disconnect(c.cleanup);c.cleanup();c.window._allow_close=True;c.window.close();c.pet.hide();c.desktop_window.close()


def test_source_gui_worker_and_frozen_worker_path_selection(tmp_path,monkeypatch):
    import qiaomi.windows as windows
    executable=tmp_path/'python.exe';executable.write_bytes(b'fixture')
    pythonw=tmp_path/'pythonw.exe';pythonw.write_bytes(b'fixture')
    monkeypatch.setattr(windows.sys,'executable',str(executable))
    monkeypatch.setattr(windows.sys,'platform','win32')
    monkeypatch.setattr(windows.sys,'frozen',False,raising=False)
    assert windows.voice_worker_program()==str(pythonw)
    monkeypatch.setattr(windows.sys,'frozen',True)
    assert windows.voice_worker_program()==str(executable)


def test_animation_cache_reuses_frames_and_has_pixel_budget(controller,monkeypatch):
    pet=controller.pet
    pet.set_low_power(True);pet.show()
    calls=[];original=pet._paint_frame
    def paint(*args):calls.append(True);return original(*args)
    monkeypatch.setattr(pet,'_paint_frame',paint)
    pet.grab();pet.grab()
    assert len(calls)==1
    for i in range(40):pet._bubble=f'cache test {i}';pet.grab()
    assert len(pet._frame_cache)<=32
    assert sum(p.width()*p.height()*4 for p in pet._frame_cache.values())<=32_000_000
    pet.set_low_power(False);pet.set_state('idle')
    assert pet.timer.interval()==125


def test_high_dpi_change_clears_previous_pixel_cache(controller,monkeypatch):
    pet=controller.pet;pet.set_low_power(True);pet.show();pet.grab()
    monkeypatch.setattr(pet,'devicePixelRatioF',lambda:2.0)
    for i in range(20):pet._bubble=str(i);pet.grab()
    assert all(key[3]==2.0 for key in pet._frame_cache)
    assert sum(p.width()*p.height()*4 for p in pet._frame_cache.values())<=32_000_000


def test_no_tray_in_game_mode_does_not_cover_game(controller,monkeypatch):
    monkeypatch.setattr(QSystemTrayIcon,'isSystemTrayAvailable',staticmethod(lambda:False))
    controller.show_pet();controller.set_game_mode(True)
    controller.ensure_tray();controller.hide_to_tray()
    assert not controller.pet.isVisible() and not controller.window.isVisible()


def test_gui_import_failure_is_logged_without_private_exception_text(tmp_path,monkeypatch):
    import builtins
    from qiaomi import launcher
    original=builtins.__import__
    def importing(name,*args,**kwargs):
        if name=='app' and kwargs.get('level',args[3] if len(args)>3 else 0)==1:raise ImportError('private value must not be logged')
        return original(name,*args,**kwargs)
    monkeypatch.setattr(builtins,'__import__',importing)
    notices=[];monkeypatch.setattr(launcher,'_notice',notices.append)
    assert launcher.launch(['--data-dir',str(tmp_path)])==1
    text=(tmp_path/'logs/startup.log').read_text()
    assert 'ImportError' in text and 'private value' not in text and notices


def test_focus_permission_granted_only_to_specific_user_requested_pid():
    from qiaomi.windows import grant_activation
    called=[]
    api=SimpleNamespace(AllowSetForegroundWindow=lambda pid:called.append(pid) or 1)
    assert grant_activation(123,platform='win32',user32=api)
    assert not grant_activation(-1,platform='win32',user32=api)
    assert not grant_activation(123,platform='linux',user32=api)
    assert called==[123]


def test_autostart_flag_never_opens_chat_even_with_assistant_flag(tmp_path):
    data=tmp_path/'boot data';data.mkdir()
    (data/'config.json').write_text(json.dumps(dict(provider='offline',model='qwen3:8b',share_memories=False,always_on_top=True)))
    code='''
import sys,json
from PySide6.QtCore import QTimer
from qiaomi import app as module
Original=module.Controller
class TestController(Original):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs)
  def check():
   (self.folder/'boot-state.json').write_text(json.dumps(dict(chat=self.window.isVisible(),pet=self.pet.isVisible(),worker=self.worker is not None,mic=self.voice.listening)))
   self.request_quit()
  QTimer.singleShot(100,check)
module.Controller=TestController
raise SystemExit(module.main(['--autostart','--assistant','--data-dir',sys.argv[1]]))
'''
    run=subprocess.run([sys.executable,'-c',code,str(data)],cwd=ROOT,env=dict(os.environ,QT_QPA_PLATFORM='offscreen'),text=True,capture_output=True,timeout=10)
    assert run.returncode==0,run.stderr
    assert json.loads((data/'boot-state.json').read_text())==dict(chat=False,pet=True,worker=False,mic=False)
