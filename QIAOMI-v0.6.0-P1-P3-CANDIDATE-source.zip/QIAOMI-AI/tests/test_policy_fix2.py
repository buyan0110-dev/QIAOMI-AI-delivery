import pytest
from PySide6.QtCore import QTimer
from PySide6.QtTest import QTest
from test_desktop_lifecycle import app,controller

@pytest.mark.parametrize('feature,phase,duration',[('F07','daily',3),('F09','companion',3),('F08','minigame',60)])
def test_owned_phase_survives_real_qt_changed_and_finish(controller,feature,phase,duration):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();p=c.companion_policy;calls=[]
    token=p.claim(feature,lambda:calls.append('done'),duration=duration);assert token
    assert p.activate(token,phase,lambda:c.personality._set_phase(phase))
    QTest.qWait(30);p.refresh();assert p.active==feature and not calls
    assert p.finish(token) and calls==['done'];assert not p.finish(token)

def test_session_60s_interrupt_and_stale_timeout(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal();p=c.companion_policy;clock=[100.];p.now=lambda:clock[0];calls=[]
    token=p.claim('F08',lambda:calls.append(1),duration=60);p.activate(token,'minigame',lambda:c.personality._set_phase('minigame'))
    clock[0]+=45;QTest.qWait(10);p.refresh();assert p.active=='F08'
    c.pet.interaction.emit('head');assert p.active is None and c.personality.phase=='touch' and calls==[1]
    c.personality._normal();new=p.claim('F08',lambda:None,duration=60);assert new and not p.finish(token)
    c.set_game_mode(True);assert p.active is None and not p.can_continue(new)

def test_short_effect_remains_bounded(controller):
    c=controller;c.show_pet();c.personality.interrupt_for_task();c.personality._normal()
    with pytest.raises(ValueError):c.companion_policy.claim('F07',lambda:None,duration=60)
    with pytest.raises(ValueError):c.companion_policy.claim('F08',lambda:None,duration=301)
