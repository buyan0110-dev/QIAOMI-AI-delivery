"""Real Qt rendering and hit regression; no automatic paw/anatomy claim."""
import json,math
from pathlib import Path
import numpy as np
import pytest
from PySide6.QtCore import QPoint,QPointF,Qt
from PySide6.QtGui import QImage
from PySide6.QtTest import QTest
from test_desktop_lifecycle import app
from qiaomi.ui.sprite_layout import sprite_destination
from qiaomi.ui.pet import PetWindow
from qiaomi.personality_assets import LazySkin
ROOT=Path(__file__).resolve().parents[1]

@pytest.mark.parametrize('state',['touch_head','touch_chin','wash_hood'])
def test_restoration_padding_preserves_logical_screen_coordinates(state):
    m=json.loads((ROOT/'assets/personality/manifest.json').read_text())['states'][state]
    x,y,w,h=m['reference_box'];before=sprite_destination(state);after=sprite_destination(state,reference_box=m['reference_box'])
    for px,py in [(0,0),(.5,.5),(1,1),(.37,.86)]:
        assert after.x()+after.width()*(x+w*px)==pytest.approx(before.x()+before.width()*px)
        assert after.y()+after.height()*(y+h*py)==pytest.approx(before.y()+before.height()*py)

@pytest.mark.parametrize('box',[[0,0,.01,1],[.5,0,.8,.8],[0,0,float('nan'),1],[0,0,True,1],[0,0,1]])
def test_invalid_reference_metadata_is_rejected(tmp_path,box):
    im=QImage(2,2,QImage.Format.Format_RGBA8888);im.fill(Qt.GlobalColor.transparent);im.save(str(tmp_path/'x.png'))
    m={'version':2,'states':{'idle':{'fps':1,'frames':['x.png'],'reference_box':box}}}
    path=tmp_path/'manifest.json';path.write_text(json.dumps(m));skin=LazySkin(path)
    assert skin.error and not skin.animations

def test_every_current_resource_has_no_opaque_canvas_border():
    files=list((ROOT/'assets/personality').glob('*.webp'));assert len(files)==252
    for f in files:
        a=QImage(str(f)).convertToFormat(QImage.Format.Format_RGBA8888)
        values=np.frombuffer(a.constBits(),np.uint8).reshape(256,256,4)[:,:,3]
        assert max(values[0,:].max(),values[-1,:].max(),values[:,0].max(),values[:,-1].max())<128,f.name

def test_missing_ear_art_was_restored_above_old_cutline_not_only_padded():
    for state in ['touch_head','touch_chin']:
        for i in [0,1]:
            im=QImage(str(ROOT/'assets/personality'/f'{state}-{i}.webp')).convertToFormat(QImage.Format.Format_RGBA8888)
            a=np.frombuffer(im.constBits(),np.uint8).reshape(256,256,4)[:,:,3]
            assert (a[:25,:]>=128).sum()>10,(state,i)

def test_action_timings_orders_and_loops_unchanged():
    before=json.loads((ROOT/'docs/refinement2/before-manifest.json').read_text())['states']
    after=json.loads((ROOT/'assets/personality/manifest.json').read_text())['states']
    assert before.keys()==after.keys()
    for name in before:
        for key in ('frames','fps','loop','hold_last'):
            assert before[name].get(key)==after[name].get(key),(name,key)

@pytest.mark.parametrize('frame',[1,2,3])
def test_actual_qt_raised_paw_and_rear_foot_clicks_after_six_paw_fix(app,frame):
    pet=PetWindow();pet.sprites=LazySkin();pet.personality_interactions=True
    pet.state='touch_head';pet._state_started=0;pet.clip_duration=0;pet._bubble=''
    fps=pet.sprites.animations['touch_head'][1]
    class Clock:
        def elapsed(self):return round((frame+.25)/fps*1000)
    pet.elapsed=Clock();pet.show();pet.timer.stop();app.processEvents();pet.repaint()
    assert pet._hit_body_frame==frame
    assert not pet.grab().isNull()
    seen=[];pet.interaction.connect(seen.append)
    dest=pet._sprite_destination;x,y,w,h=pet.sprites.entries['touch_head']['interaction_box']
    # Points manually selected from the corrected forepaws/rear feet and belly.
    for px,py,expected in [(.34,.32,'front_left'),(.70,.29,'front_right'),(.37,.86,'hind_left'),(.70,.86,'hind_right'),(.50,.72,'belly')]:
        p=QPoint(round(dest.x()+dest.width()*(x+w*px)),round(dest.y()+dest.height()*(y+h*py)))
        QTest.mouseClick(pet,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier,p)
        assert seen and seen[-1]==expected,(frame,expected,seen)
    pet.hide();pet.close();pet.deleteLater()
