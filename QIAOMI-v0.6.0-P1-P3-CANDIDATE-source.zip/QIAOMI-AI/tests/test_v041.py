"""v0.4.1: real Qt/persistence/animation, pure geometry and mocked Win32 APIs.
No Windows hardware or physical multi-monitor/DPI claim.
"""
import json
import os
from pathlib import Path
from types import SimpleNamespace
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6.QtCore import QPoint,QPointF,QRect,Qt
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication,QDialog,QLabel,QVBoxLayout,QScrollArea,QFormLayout
from qiaomi.appearance import AppearancePreferences,stylesheet,PALETTES,SCALES
from qiaomi.habitat import snap_position,foreground_allows_motion
from qiaomi.body import hit_region,regions,BODY_PARTS,BODY_STATES
from qiaomi.personality_assets import LazySkin
from qiaomi.personality_constants import EXTRA_STATES
from test_desktop_lifecycle import app,controller,until
from test_lifestyle import life_engine,Clock

@pytest.mark.parametrize('theme',['dark','light'])
@pytest.mark.parametrize('scale',SCALES)
def test_theme_scale_applies_all_windows_without_waking_or_decoding(controller,theme,scale):
    c=controller;c.set_game_mode(True);skin=c.pet.sprites
    c.change_appearance(theme,scale,False)
    assert c.appearance.values['theme']==theme and c.appearance.values['scale']==scale
    assert c.pet.sprites is skin and c.personality.dormant and not c.pet.timer.isActive()
    assert f'font-size: {round(16*scale/100)}px' in c.app.styleSheet()
    assert not c.window.welcome_line.isVisible()
    for w in (c.window,c.voice.panel,c.personality_window,c.desktop_window):assert not w.windowIcon().isNull()
    saved=AppearancePreferences(c.appearance.preferences.path.parent)
    assert saved.values['theme']==theme and saved.values['scale']==scale


def test_appearance_unknown_and_bad_config_backup(tmp_path):
    p=AppearancePreferences(tmp_path);p.values['future']='keep';p.save();assert AppearancePreferences(tmp_path).values['future']=='keep'
    p.path.write_text('{bad');q=AppearancePreferences(tmp_path);assert q.read_error;q.save()
    assert list(tmp_path.glob('appearance.invalid-*.json'))[0].read_text()=='{bad'


def test_large_font_chat_wrap_and_compact_navigation(controller):
    c=controller;c.show_assistant();c.window.resize(800,780);c.change_appearance('light',150,True)
    c.window.render_messages([{'role':'assistant','content':'长文本'*300+'A'*500+'\n```python\nprint("<script>")\n```'}]);c.app.processEvents()
    assert c.window.compact_nav.isVisible() and not c.window.sidebar.isVisible()
    assert c.window.chat.horizontalScrollBar().maximum()==0
    assert '<script>' in c.window.chat.toPlainText()
    assert c.window.input.minimumHeight()>=165 and c.window.send_button.minimumHeight()>=72


def test_welcome_is_local_changes_only_on_open_no_idle_ui_timer(controller):
    c=controller;c.show_assistant();assert c.window.welcome_line.text()
    assert not c.window.orb.timer.isActive()
    line=c.window.welcome_line.text();QTest.qWait(30);assert c.window.welcome_line.text()==line
    c.window.hide();assert not c.window.orb.timer.isActive()


def test_popup_theme_and_scroll_adapter(controller):
    c=controller;c.change_appearance('light',150,True)
    d=QDialog();layout=QVBoxLayout(d);layout.addWidget(QLabel('本地设置'))
    d.show();c.app.processEvents();assert d.findChildren(QScrollArea) and not d.windowIcon().isNull()
    d.close();d.deleteLater()

@pytest.mark.parametrize('rect,edge',[(QRect(2,100,300,350),'left'),(QRect(1618,100,300,350),'right'),(QRect(600,2,300,350),'top'),(QRect(600,698,300,350),'bottom')])
def test_four_edge_snap_independent(rect,edge):
    area=QRect(0,0,1920,1050);pos,got=snap_position(rect,[area]);assert got==edge and area.contains(QRect(pos,rect.size()))


def test_snap_disabled_detach_negative_monitor_and_dpi_logical_rects():
    areas=[QRect(-1600,-100,1600,900),QRect(0,0,1920,1040)]
    p,e=snap_position(QRect(-1598,20,300,350),areas);assert e=='left' and p.x()==-1600
    p,e=snap_position(QRect(-1200,100,300,350),areas);assert e is None
    p,e=snap_position(QRect(1,50,300,350),areas,False);assert e is None
    p,e=snap_position(QRect(4000,4000,300,350),areas);assert any(a.contains(QRect(p,QRect(0,0,300,350).size())) for a in areas)


def test_manual_snap_persists_and_reflows(controller):
    c=controller;c.show_pet();area=c.pet.screen().availableGeometry();c.pet.move(area.left()+2,area.top()+100);c.habitat.place()
    assert c.habitat.edge=='left' and c.pet._visual_state()=='edge_left'
    raw=json.loads(c.desktop.path.read_text());assert raw['edge']=='left'
    c.habitat.set_snap(False);assert c.habitat.edge is None and not c.desktop.values['snap_enabled']

@pytest.mark.parametrize('part',sorted(BODY_PARTS))
def test_body_hit_priority_and_independent_feedback(life_engine,part):
    e,clock=life_engine;e.interact(part)
    assert e.phase=='touch' and e.pet.state in BODY_STATES and e.pet.state=='touch_'+part
    assert not e.next_action.isActive()


def test_pose_profiles_change_and_priority_is_explicit():
    assert regions('daily_prone')!=regions('idle') and regions('angry_back')!=regions('idle')
    assert hit_region('idle',QPointF(.30,.25))=='ear_left'  # overlap head: ear wins
    assert hit_region('idle',QPointF(.50,.50))=='chin'
    assert hit_region('idle',QPointF(.50,.72))=='belly'
    assert hit_region('idle',QPointF(-1,-1)) is None


def test_repeated_ear_and_belly_feedback(life_engine):
    e,clock=life_engine
    for state in ('touch_ear_left','touch_ear_tuck','touch_ear_droop'):
        e.interact('ear_left');assert e.pet.state==state;clock.advance(.7)
    e.interact('belly');assert e.pet.state=='touch_belly'
    e.interact('belly');assert e.pet.state=='touch_belly_cover'

@pytest.mark.parametrize('activity,ending',[('daily_read','finish_book'),('daily_game','finish_game'),('daily_eat','finish_eat'),('daily_prone','wakeup_sit'),('daily_yarn','return_idle')])
def test_activity_interrupt_runs_finish_idle_then_specific_touch(life_engine,activity,ending):
    e,clock=life_engine;e.start_daily(activity);e.interact('ear_left')
    assert e.phase=='finish' and e.pet.state==ending
    e._phase_finished();assert e.phase=='touch_reset' and e.pet.state=='return_idle'
    e._phase_finished();assert e.phase=='touch' and e.pet.state=='touch_ear_left'
    state=e.pet.state;e._autonomous();assert e.pet.state==state


def test_only_mouse_resets_clock_and_reconciliation_resets_after_reunion(life_engine):
    e,clock=life_engine;clock.advance(500)
    for source in ('manual-input','chat','voice','drag','daily-menu'):assert not e.record_interaction(source)
    assert e.life.elapsed==500
    e.interact('chin');assert e.life.elapsed==0
    clock.advance(500);e.preferences.values['reunion_enabled']=False;e.enter_sleep();clock.advance(5000);e.wake()
    assert e.life.elapsed==0


def test_game_during_pending_interruption_cancels_all(life_engine):
    e,clock=life_engine;e.start_daily('daily_read');e.interact('ear_left');assert e.pending_touch
    e.enter_sleep();e._phase_finished();assert e.phase=='dormant' and e.pending_touch is None
    for t in (e.next_action,e.phase_timer,e.neglect_timer,e.dream_timer,e.mood_timer):assert not t.isActive()


def prepare_seeker(c):
    c.show_pet();area=c.pet.screen().availableGeometry();c.pet.move(area.left(),area.top()+80);c.habitat.place();c.habitat.guard=lambda:True
    c.personality.life.sulking=True;c.personality.life.soothe_count=0


def test_temporary_seeking_once_restore_without_overwriting_saved_home(controller):
    c=controller;prepare_seeker(c);home=c.pet.pos();saved=dict(c.desktop.values['position'])
    assert c.habitat.request_seek() and c.personality.phase=='seek'
    c.habitat.exit_timer.stop();c.habitat._walk();c.habitat.motion.setCurrentTime(2200)
    assert c.personality.phase=='angry' and c.habitat.transient
    assert c.desktop.values['position']==saved and c.pet.pos()!=home
    assert not c.habitat.request_seek()
    c.personality.life.sulking=False;c.personality._normal();assert c.pet.pos()==home and not c.habitat.transient


def test_fullscreen_safety_defers_no_polling_and_manual_interrupt(controller):
    c=controller;prepare_seeker(c);c.habitat.guard=lambda:False
    assert not c.habitat.request_seek() and c.habitat.deferred and not c.habitat.exit_timer.isActive()
    c.habitat.guard=lambda:True;assert not c.habitat.request_seek()  # no repeated forced retries
    assert c.habitat.request_seek(retry=True)
    c.personality.interact('head');assert c.personality.phase=='soothing' and not c.habitat.exit_timer.isActive()


def test_deep_sleep_stops_motion_and_retains_home(controller):
    c=controller;prepare_seeker(c);home=c.pet.pos();assert c.habitat.request_seek()
    c.set_game_mode(True)
    assert not c.habitat.exit_timer.isActive() and c.habitat.motion.state()==c.habitat.motion.State.Stopped
    assert c.pet.pos()==home and not c.habitat.request_seek(retry=True)
    assert not c.personality.next_action.isActive() and not c.pet.timer.isActive()


def test_no_native_safety_information_fails_closed():
    assert foreground_allows_motion(platform='linux') is False


class Call:
    def __init__(self,fn):self.fn=fn
    def __call__(self,*args):return self.fn(*args)

@pytest.mark.parametrize('secure,fullscreen,safe',[(False,False,True),(False,True,False),(True,False,False)])
def test_mock_win32_fullscreen_and_secure_desktop(monkeypatch,secure,fullscreen,safe):
    import ctypes
    def name(desktop,index,buf,size,needed):buf.value='Winlogon' if secure else 'Default';return 1
    def pid(hwnd,p):p._obj.value=999999;return 1
    def cls(hwnd,buf,size):buf.value='GameOrEditor';return 1
    def rect(hwnd,r):r._obj.left=0;r._obj.top=0;r._obj.right=1920 if fullscreen else 1000;r._obj.bottom=1080 if fullscreen else 700;return 1
    def monitor(hwnd,m):m._obj.rcMonitor.left=0;m._obj.rcMonitor.top=0;m._obj.rcMonitor.right=1920;m._obj.rcMonitor.bottom=1080;return 1
    fake=SimpleNamespace(**{k:Call(v) for k,v in dict(GetForegroundWindow=lambda:100,OpenInputDesktop=lambda *a:200,CloseDesktop=lambda *a:1,GetUserObjectInformationW=name,GetWindowThreadProcessId=pid,GetClassNameW=cls,GetWindowRect=rect,MonitorFromWindow=lambda *a:300,GetMonitorInfoW=monitor).items()})
    monkeypatch.setattr(ctypes,'windll',SimpleNamespace(user32=fake),raising=False)
    assert foreground_allows_motion(platform='win32') is safe


def test_new_resources_are_real_independent_bounded_and_all_decode(app):
    skin=LazySkin();assert not skin.error
    wanted={**EXTRA_STATES,**BODY_STATES}
    for state in wanted:
        frames,fps=skin.animations[state];assert len(frames)==(7 if state=='touch_tail' else 4)
        assert len({p.read_bytes() for p in frames})==4
        for i in range(4):assert not skin.frame(state,i/fps+.01).isNull()
    assert skin.cached_bytes<=skin.max_bytes
    assert len({p for frames,_ in skin.animations.values() for p in frames})==252


def test_reunion_and_busy_priority_never_start_deferred_walk(controller):
    c=controller;prepare_seeker(c);c.habitat.guard=lambda:False
    assert not c.habitat.request_seek() and c.habitat.deferred
    c.set_game_mode(True);c.habitat.guard=lambda:True;c.wake_qiaomi()
    assert c.personality.phase=='reunion' and not c.habitat.exit_timer.isActive()
    assert not c.habitat.request_seek(retry=True)
    c.personality.skip();c.voice.busy=True
    # busy callback covers microphone/TTS and pending inference, use a live override.
    old=c.personality.busy;c.personality.busy=lambda:True
    assert not c.habitat.request_seek(retry=True)
    c.personality.busy=old;c.voice.busy=False


def test_auxiliary_dialogs_owned_but_do_not_open_chat(controller):
    c=controller;c.window.hide();c.voice.show()
    assert not c.window.isVisible() and c.voice.panel.parentWidget() is c.window
    assert c.desktop_window.parentWidget() is c.window and c.personality_window.parentWidget() is c.window


def test_reapply_identical_appearance_does_not_repolish_global_widgets(controller,monkeypatch):
    c=controller;calls=[]
    monkeypatch.setattr(c.app,'setStyleSheet',lambda *a:calls.append(a))
    c.appearance.apply(save=False);assert calls==[]


def test_mouse_feedback_wins_over_voice_visual_and_busy_hint(controller):
    c=controller;c.show_pet();c.personality.interact('chin');assert c.pet.state=='touch_chin'
    c.voice.animation.emit('listening');c.set_pet_task_busy(False)
    assert c.pet.state=='touch_chin'
    c.voice.listening=True;c.personality._normal();assert c.pet.state=='listening'
    c.voice.listening=False


def test_code_blocks_safe_copyable_and_wrap(controller):
    from qiaomi.ui.assistant import message_html
    text='```python\n    print("<img src=file:///private>")\n'+('x'*500)+'\n```'
    rendered=message_html(text);assert '&lt;img' in rendered and '<img ' not in rendered
    c=controller;c.show_assistant();c.window.render_messages([{'role':'assistant','content':text}]);c.app.processEvents()
    assert 'print("<img src=file:///private>")' in c.window.chat.toPlainText()
    assert c.window.chat.horizontalScrollBar().maximum()==0


def test_hidden_chat_defers_html_and_restores_on_show(controller,monkeypatch):
    c=controller;c.window.hide();calls=[];original=c.window.chat.setHtml
    monkeypatch.setattr(c.window.chat,'setHtml',lambda value:(calls.append(value),original(value))[-1])
    c.window.render_messages([{'role':'assistant','content':'隐藏期间只保留数据，不刷新HTML'}])
    assert calls==[] and c.window.chat_dirty
    c.show_assistant();assert len(calls)==1 and not c.window.chat_dirty
    assert '隐藏期间只保留数据' in c.window.chat.toPlainText()


def test_fresh_default_uses_edge_without_overriding_saved_manual_position(controller):
    c=controller;assert c.habitat.edge in ('bottom','right')
    assert c.desktop.values['position'] is None
    c.habitat.set_snap(False);c.pet.move(150,100);c.habitat.place()
    assert c.desktop.values['position']=={'x':150,'y':100} and c.desktop.values['edge'] is None


def test_missing_custom_edge_pose_keeps_custom_idle_instead_of_wrong_cat(controller):
    c=controller;c.pet.perch_edge='left';skin=c.pet.sprites
    original=skin.animations.pop('edge_left')
    try:assert c.pet._visual_state()=='idle'
    finally:skin.animations['edge_left']=original


def test_disabling_seeking_cancels_active_move_and_restores_home(controller):
    c=controller;prepare_seeker(c);home=c.pet.pos();assert c.habitat.request_seek()
    c.sync_personality_controls();c.personality_window.extra_switches['seek_enabled'].setChecked(False)
    assert not c.habitat.exit_timer.isActive() and c.pet.pos()==home
    assert not c.personality_preferences.values['seek_enabled']
