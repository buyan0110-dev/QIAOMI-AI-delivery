# 从 v0.2.0 升级

本版本直接修改上传的 v0.2.0，保留原界面与功能。

1. 从旧版托盘完全退出，备份 `%LOCALAPPDATA%\QIAOMI AI` 或现有 `QIAOMI_DATA_DIR`。
2. 新版完整解压至可写项目目录。不要删除原用户目录，不要用样例文件替换自己的数据库。
3. 首次运行 start.bat 准备基础依赖；之后用 start.vbs 或 install_shortcut.vbs 创建的快捷方式无控制台启动。
4. 可选执行 install_voice.bat，依 docs/VOICE.md 安装本地模型与中文系统声音。

## 数据兼容

继续使用 config.json、qiaomi.db、messages、memories 和原 data_dir()。初始化只新增 memory_categories 和删除类型元数据的触发器，不删除或改写原有记忆，user_version=1 不变。旧 version=1 JSON 备份保持名称与内容兼容，不包括新增类型元数据。

新增 voice.json 不改变旧配置结构。持续唤醒开关不持久化，每次启动默认关闭。交付包不含私人数据库、模型、Ollama 或虚拟环境。

原 Ollama、本地基础回复、OpenAI 文字入口、自动化演示、宠物互动、托盘及记忆管理保留。演示仍是明确标注的演示，不执行真实系统操作。

## 有意调整

- 固定记忆命令仍有效，确认从模态弹窗改为非模态卡片，支持语音确认。默认不保存，60 秒超时取消。
- 回答完成后回待机，原开心等互动状态保留。新增 3 种语音状态，总计 13 种绘制状态。
- 记忆总开关关闭后不解析、不通过命令保存、不参与 AI 上下文；管理入口与数据保留。

## 实现位置

- start.vbs / scripts/gui_entry.pyw / install_shortcut.vbs：正常启动及导入错误日志。
- qiaomi/memory_intent.py：本地提取、严格校验，AI 线程不能写数据库。
- qiaomi/app.py：候选确认、拒绝、超时、主线程存储、统一打断和退出。
- qiaomi/voice.py：异步进程控制、Windows TTS、实验唤醒及语音面板。
- qiaomi/voice_worker.py：采集、能量结束检测、Whisper/Silero、CPU 回退与缓存卸载。
- qiaomi/ui/pet.py：保留原绘制，补充嘴部开合、唤醒和错误标记。

## 回滚

先完全退出，再运行旧版；原字段和 user_version 兼容。新增语音配置和类型表可以保留，旧版不使用。恢复旧备份会失去备份之后的新增聊天和记忆，需先导出新数据。不要同时运行多个版本操作同一数据库。

Windows 真机、中文语音质量、实际 Qwen3 提取、GPU OOM 与产品级唤醒仍待验收。详见 TEST_REPORT.md 和 WINDOWS_ACCEPTANCE_V0.3.0.md。
