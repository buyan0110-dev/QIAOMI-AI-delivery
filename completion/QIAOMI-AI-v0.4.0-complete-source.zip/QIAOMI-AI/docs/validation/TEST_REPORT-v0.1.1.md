# QIAOMI AI MVP 0.1.1 验证记录

日期：2026-11-10（北京时间）。

## 环境与执行方式

- Linux x86_64；Python 3.12.14。
- PySide6 / Qt 6.8.3；OpenAI Python SDK 1.109.1；pytest 8.3.5。
- 依赖安装到隔离虚拟环境；没有使用真实用户数据或真实 API Key。
- Qt 平台插件为 `offscreen`。这是实际 QWidget 创建、事件处理、交互模拟和绘制验证，**不是 Windows 原生 GUI 验收**。

```bash
QT_QPA_PLATFORM=offscreen python -m pytest -q
QT_QPA_PLATFORM=offscreen python -m qiaomi --smoke-test --smoke-report test-artifacts/smoke.json
python -m compileall -q qiaomi scripts tests
```

## 自动化结果

**131 项测试全部通过（131 passed in 3.06s）**；程序编译检查通过；24 个已安装依赖的兼容性检查通过。

## 已检查的行为

- SQLite 重启持久化、记忆增改删、同名更新与冲突、聊天清空不删除记忆。
- JSON 格式、大小与字段校验；批量导入失败回滚；备份往返；防止导出覆盖活动数据库。
- API 客户端模拟：官方地址、上下文边界、空回复、认证/额度/网络/超时错误、取消及错误文本脱敏。没有真实联网 AI 调用。
- 密钥不写入配置；分享记忆默认关闭；确认任务为一次性令牌；无授权不会执行演示。
- 十种猫咪状态的实际离屏绘制、头/肚皮点击、拖动不误触、隐藏时停止动画、资源越界回退。
- 记忆审核导入：默认不勾选、审核后才能确认、修改选择会撤销审核。
- 整合流程：双形态切换、离线线程回复、记忆保存确认、任务确认/取消、清空确认、无系统托盘时保留可见窗口。
- 正在请求时禁止重复发送；取消后丢弃迟到回复；退出等待工作线程；关闭数据库后不保存已经排队的回复。
- 中文输入法预编辑状态下 Enter 不发送；Shift+Enter 换行；聊天 HTML 标签作为文字显示。
- 启动脚本的依赖哈希缓存、依赖修复与准备模式（Python 层测试）。

实际启动自检退出码为 0，22 项检查全部通过：创建程序 → 十种状态绘制 → 打开管家 → 离线问候与持久化 → 记忆备份/删除/导入/重新打开数据库 → 返回猫咪 → 干净退出。`docs/validation/startup-v0.1.1.json` 保存本次机器可读结果；`docs/validation/tests-v0.1.1.xml` 保存测试明细。Qt offscreen 输出的 `This plugin does not support raise()` 是该平台不支持置顶请求的提示；不能据此推断 Windows 的置顶已验证。

## 0.1.1 新增回归验证

- 使用 OpenAI SDK 加 httpx.MockTransport 验证协作式取消会到达传输层并关闭客户端；整体异步请求时限、迟到回复和错误脱敏也已测试。没有真实 API 网络调用。
- 验证本地记忆命令及确认不会进入普通聊天上下文；分享关闭时不附加保存的偏好。
- 验证 SDK 延迟导入后不会因 OPENAI_LOG 重启请求内容日志。
- 负坐标、多屏间隙、工作区变化、屏幕移除、隐藏订阅清理和菜单释放均有回归测试；不等于真实 Windows 多屏验收。
- 无效 Unicode、非文本控制字符、嵌套过深的配置与资源清单安全回退；未来版本数据库拒绝修改并释放连接。
- 最大容量 Unicode 记忆备份往返通过；发布 ZIP/SHA256、缺失文件、路径边界及源码不变验证通过。
- 启动入口通过独立子进程测试：成功时报告 passed=true；注入错误回复时退出码为 1、报告失败且不弹出阻塞对话框；既有用户目录未改动。
- Windows 工作流 YAML 已做静态检查，**未运行远程 CI**。本地 ZIP 测试使用明确标注的测试夹具，不能视为构建了真实 Windows EXE。

## 截图与修复

`docs/previews/` 中的 PNG 是程序实际离屏渲染截图，不是设计稿。已目检猫咪、聊天、记忆、设置四个页面。

本轮修复了设置页背景继承、空记忆页空间分配、中文输入法提交保护、配置规范化、退出期间排队回调，以及 Windows 半透明窗所需的无边框标志；后者仍待 Windows 实机验证。

## 尚未验证 / 尚未交付

- Windows 11 实际透明合成、拖动、始终置顶、系统托盘、中文输入法、DPI 与多屏。
- Windows `.bat` 实际运行、PyInstaller Windows 构建、代码签名和安装包。
- 真实 OpenAI Key、账户权限、费用及网络代理兼容性。
- 正式美术、真实语音、Windows 自动化、ChatGPT 历史导入；这些属于后续阶段。

Windows 人工验收步骤见 README 和 `docs/WINDOWS_RELEASE.md`。Windows Server/offscreen 工作流即使未来通过，也不能代替 Windows 11 原生 GUI 验收。当前交付为可运行的源码 MVP，不能视为已完成 Windows 发布认证。
