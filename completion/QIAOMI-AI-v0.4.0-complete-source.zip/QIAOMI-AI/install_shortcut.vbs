Option Explicit
Dim shell, fso, root, link, target, args, icon
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
args = ""
target = fso.BuildPath(root, "QIAOMI-AI.exe")
If Not fso.FileExists(target) Then
    target = fso.BuildPath(root, "dist\QIAOMI-AI\QIAOMI-AI.exe")
End If
If Not fso.FileExists(target) Then
    target = fso.BuildPath(root, ".venv\Scripts\pythonw.exe")
    args = """" & fso.BuildPath(root, "scripts\gui_entry.pyw") & """"
    If Not fso.FileExists(target) Then
        MsgBox "Run start.bat once to prepare Python, or place this script beside QIAOMI-AI.exe.", 48, "QIAOMI AI"
        WScript.Quit 1
    End If
End If
Set link = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\" & ChrW(&H6572) & ChrW(&H54AA) & ".lnk")
link.TargetPath = target
link.Arguments = args
link.WorkingDirectory = fso.GetParentFolderName(target)
icon = fso.BuildPath(root, "assets\qiaomi.ico")
If LCase(fso.GetFileName(target)) = "qiaomi-ai.exe" Then
    link.IconLocation = target & ",0"
Else
    link.IconLocation = icon & ",0"
End If
link.Description = "QIAOMI AI v0.4.0"
link.Save
MsgBox "Desktop shortcut created. Keep the application folder at this location.", 64, "QIAOMI AI"
