@echo off
setlocal
cd /d "%~dp0"
call "%~dp0start.bat" --prepare-only
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m pip install -r requirements-voice.txt
if errorlevel 1 goto failed
"%~dp0.venv\Scripts\python.exe" -m pip check
if errorlevel 1 goto failed
echo Voice dependencies installed. Download a local model separately; see docs\VOICE.md.
pause
exit /b 0
:failed
echo Voice setup failed. Read errors above.
pause
exit /b 1
