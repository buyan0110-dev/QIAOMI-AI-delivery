"""Shared capture/measurement path. No disk audio; no model dependency.

Telemetry uses linear full-scale float units (0..1), matching the VAD threshold.
Stereo is retained during capture, then the highest-energy channel is selected
for the whole clip; opposite phase channels cannot cancel each other.
"""
from dataclasses import dataclass
from fractions import Fraction
import logging
import math
import numpy as np

log = logging.getLogger('qiaomi.voice')

class AudioError(ValueError):
    pass

class DeviceReleaseError(AudioError):
    pass


def float_audio(data):
    array = np.asarray(data)
    if array.dtype.kind not in 'fiu' or array.ndim not in (1, 2):
        raise AudioError('音频数组类型或形状无效，应为 frames × channels。')
    if array.dtype.kind in 'iu':
        info = np.iinfo(array.dtype)
        scale = float(max(abs(info.min), abs(info.max)+1))
        array = array.astype(np.float32)
        if info.min == 0:
            array -= (info.max+1)/2
            scale = (info.max+1)/2
        array /= scale
    else:
        array = array.astype(np.float32, copy=False)
    if array.ndim == 1:
        array = array[:, None]
    if not array.size or not 1 <= array.shape[1] <= 64:
        raise AudioError('未采集到有效音频帧。')
    if not np.isfinite(array).all():
        raise AudioError('采集音频含 NaN 或无穷值，请重新选择输入设备。')
    return np.ascontiguousarray(np.clip(array, -1, 1), dtype=np.float32)


def levels(data):
    array = float_audio(data)
    # Use float64 accumulation to avoid integer overflow/precision loss.
    channel_rms = np.sqrt(np.mean(array.astype(np.float64)**2, axis=0))
    return float(channel_rms.max()), float(np.abs(array).max())


def voiced(rms, threshold):
    if not math.isfinite(rms) or not math.isfinite(threshold) or not 0 < threshold <= 1:
        raise AudioError('语音检测阈值无效。')
    return rms >= threshold


def prepare_audio(data, sample_rate):
    array = float_audio(data)
    if not math.isfinite(sample_rate) or not 8000 <= sample_rate <= 384000:
        raise AudioError('录音采样率无效。')
    power = np.mean(array.astype(np.float64)**2, axis=0)
    channel = int(np.argmax(power))
    mono = array[:, channel]
    if not np.any(np.abs(mono) > 1e-7):
        raise AudioError('采集音频全零或接近全零；请检查设备选择、静音和输入增益。')
    if sample_rate != 16000:
        from scipy.signal import resample_poly
        ratio = Fraction(16000 / sample_rate).limit_denominator(10000)
        mono = resample_poly(mono, ratio.numerator, ratio.denominator)
    mono = np.ascontiguousarray(np.clip(mono, -1, 1), dtype=np.float32)
    if not np.isfinite(mono).all() or not mono.size:
        raise AudioError('重采样后音频无效。')
    return mono, channel


def enumerate_inputs(sd):
    apis = sd.query_hostapis()
    result = []
    for index, device in enumerate(sd.query_devices()):
        if device['max_input_channels'] > 0:
            api = int(device['hostapi'])
            result.append(dict(id=index, name=str(device['name']), hostapi=str(apis[api]['name']),
                               samplerate=float(device['default_samplerate']),
                               channels=int(device['max_input_channels'])))
    return result


def resolve_input(sd, settings):
    devices = enumerate_inputs(sd)
    index = settings.get('device')
    if index is None:
        index = int(sd.default.device[0])
        device = next((d for d in devices if d['id']==index), None)
        if device is None:
            raise AudioError('系统没有有效的默认输入设备，请刷新并明确选择麦克风。')
        return device
    if type(index) is not int or index < 0:
        raise AudioError('输入设备 ID 无效，请刷新设备。')
    device = next((d for d in devices if d['id']==index), None)
    name, api = settings.get('device_name', ''), settings.get('device_hostapi', '')
    if not name:
        if device is None:
            raise AudioError('保存的输入设备 ID 已失效；请刷新并重新选择麦克风。')
        log.warning('Legacy numeric device selection id=%s has no stable identity; reselect recommended', index)
        return device
    if device and device['name']==name and (not api or device['hostapi']==api):
        return device
    matches = [d for d in devices if d['name']==name and (not api or d['hostapi']==api)]
    if len(matches) != 1:
        raise AudioError('原麦克风已断开或设备映射不唯一；请刷新并重新选择，未改用其他设备。')
    log.warning('Input index changed old=%s new=%s name=%s hostapi=%s', index, matches[0]['id'], name, api)
    return matches[0]


def choose_format(sd, device):
    rates = list(dict.fromkeys([round(device['samplerate']), 48000, 44100, 16000]))
    channels = [min(2, device['channels'])]
    if channels[0] > 1:
        channels.append(1)
    for rate in rates:
        if rate < 8000:
            continue
        for count in channels:
            try:
                sd.check_input_settings(device=device['id'], channels=count, samplerate=rate, dtype='float32')
                return rate, count
            except Exception:
                log.warning('Input format rejected id=%s rate=%s channels=%s', device['id'], rate, count, exc_info=True)
    raise AudioError('麦克风没有可用录音格式（已尝试设备默认采样率、48k/44.1k/16k）；详情见 voice.log。')


@dataclass
class Recording:
    audio: object
    samplerate: float
    channels: int
    frames: int
    duration: float
    rms: float
    peak: float
    speech: bool
    reason: str
    device: dict

    def diagnostics(self):
        return dict(device_name=self.device['name'], device_id=self.device['id'],
                    hostapi=self.device['hostapi'], samplerate=self.samplerate,
                    channels=self.channels, frames=self.frames, duration=round(self.duration,3),
                    rms=self.rms, peak=self.peak, speech=self.speech, reason=self.reason)


def record(settings, cancel_event, finish_event, notify, sd=None):
    if cancel_event.is_set():
        notify(event='state',value='cancelled')
        return None
    if sd is None:
        import sounddevice as sd
    mode = settings.get('record_mode', 'manual')
    if mode not in ('manual', 'auto', 'test'):
        raise AudioError('未知录音模式。')
    threshold = float(settings.get('threshold', .012))
    voiced(0, threshold)  # Validate before opening a device.
    limit = max(.1, min(120.0, float(settings.get('max_seconds', 120 if mode=='manual' else 20))))
    if mode == 'test':
        limit = 3.0
    wait_limit = max(.1, min(limit, float(settings.get('wait_seconds', 8))))
    notify(event='state', value='initializing')
    device = resolve_input(sd, settings)
    rate, count = choose_format(sd, device)
    log.info('Microphone initializing name=%s id=%s hostapi=%s requested_rate=%s channels=%s mode=%s',
             device['name'], device['id'], device['hostapi'], rate, count, mode)
    frames, frame_count, quiet, speech, reason = [], 0, 0.0, False, 'limit'
    peak = 0.0
    power_sum = np.zeros(count, dtype=np.float64)
    block = max(1, round(rate*.1))
    stream = None
    try:
        stream = sd.InputStream(samplerate=rate, channels=count, dtype='float32', device=device['id'], blocksize=block)
        with stream:
            rate = float(getattr(stream, 'samplerate', rate))
            log.info('Microphone opened id=%s actual_rate=%s channels=%s', device['id'], rate, count)
            notify(event='state', value='listening' if mode=='auto' else 'recording')
            while not cancel_event.is_set():
                if finish_event.is_set():
                    reason = 'stopped'
                    break
                duration = frame_count/rate
                if duration >= limit:
                    reason = 'test_complete' if mode=='test' else 'limit'
                    break
                audio, overflow = stream.read(min(block, max(1, math.ceil((limit-duration)*rate))))
                if cancel_event.is_set():
                    break
                audio = float_audio(audio)
                if audio.shape[1] != count:
                    raise AudioError('设备返回声道数与已打开的格式不一致。')
                if overflow:
                    log.warning('Capture overflow id=%s frame=%s', device['id'], frame_count)
                    notify(event='warning', value='麦克风采集溢出，音频可能有间断；请减少后台负载。')
                frames.append(audio.copy())
                frame_count += len(audio)
                power_sum += np.sum(audio.astype(np.float64)**2, axis=0)
                rms, block_peak = levels(audio)
                peak = max(peak, block_peak)
                active = voiced(rms, threshold)
                if active and not speech:
                    speech = True
                    log.info('Energy voice onset id=%s rms=%.7f threshold=%.7f', device['id'], rms, threshold)
                    if mode=='auto':
                        notify(event='state', value='recording')
                quiet = 0.0 if active else quiet + len(audio)/rate
                notify(event='level', value=dict(device_name=device['name'], device_id=device['id'], hostapi=device['hostapi'],
                    samplerate=rate, channels=count, rms=rms, peak=block_peak, threshold=threshold,
                    duration=round(frame_count/rate,3), frames=frame_count, speech=speech))
                if mode=='auto' and not speech and frame_count/rate >= wait_limit:
                    reason = 'no_speech'
                    break
                if mode=='auto' and speech and quiet >= .9-1e-8:
                    reason = 'silence'
                    break
    except BaseException:
        reason='error'
        raise
    finally:
        if stream is not None and hasattr(stream,'close'):
            try:
                stream.close()
            except Exception as exc:
                log.exception('Microphone explicit close failed id=%s',device['id'])
                raise DeviceReleaseError('音频设备关闭失败，需要终止工作进程释放设备') from exc
        log.info('Microphone released id=%s frames=%s duration=%.3f speech=%s reason=%s',
                 device['id'], frame_count, frame_count/rate, speech, 'cancelled' if cancel_event.is_set() else reason)
    if cancel_event.is_set():
        notify(event='state', value='cancelled')
        return None
    if not frames:
        raise AudioError('没有录到音频；请开始讲话后再点击「结束并识别」。')
    combined = np.concatenate(frames, axis=0)
    overall_rms = float(np.sqrt((power_sum/frame_count).max()))
    result = Recording(combined, rate, count, frame_count, frame_count/rate, overall_rms, peak, speech, reason, device)
    log.info('Capture ended frames=%s rms=%.7f peak=%.7f threshold=%.7f reason=%s', frame_count, overall_rms, peak, threshold, reason)
    notify(event='summary', value=dict(result.diagnostics(), threshold=threshold))
    return result
