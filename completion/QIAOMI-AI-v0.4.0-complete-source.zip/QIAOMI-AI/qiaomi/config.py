"""Non-secret preferences and per-user application data location.

API credentials deliberately do not belong to Config: the UI keeps them in
memory for the current process, or reads OPENAI_API_KEY from the environment.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
import logging
import os
from pathlib import Path
import re
import sys
import tempfile


logger = logging.getLogger(__name__)
_MODEL_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,119}\Z")
_MAX_CONFIG_BYTES = 64 * 1024


@dataclass
class Config:
    model: str = "qwen3:8b"
    always_on_top: bool = True
    share_memories: bool = False
    provider: str = "ollama"


def data_dir() -> Path:
    """Return a writable per-user location; this function creates no files."""
    override = os.environ.get("QIAOMI_DATA_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()
    if sys.platform == "win32":
        local = os.environ.get("LOCALAPPDATA", "").strip()
        base = Path(local) if local else Path.home() / "AppData" / "Local"
        return base / "QIAOMI AI"
    xdg = os.environ.get("XDG_DATA_HOME", "").strip()
    base = Path(xdg) if xdg and Path(xdg).is_absolute() else Path.home() / ".local" / "share"
    return base / "qiaomi-ai"


def validate_config(config: Config) -> Config:
    """Validate public preferences and return a normalized copy."""
    if not isinstance(config.model, str) or not _MODEL_PATTERN.fullmatch(config.model.strip()):
        raise ValueError("模型名称应为 1–120 个字母、数字、点、冒号、下划线或连字符。")
    if type(config.always_on_top) is not bool or type(config.share_memories) is not bool:
        raise ValueError("置顶和记忆共享选项必须为布尔值。")
    if config.provider not in {"ollama", "openai", "offline"}:
        raise ValueError("请选择 Ollama、OpenAI 或本地基础回复。")
    return Config(config.model.strip(), config.always_on_top, config.share_memories, config.provider)


def load_config(path: Path) -> Config:
    """Read preferences, falling back safely if a file is missing or damaged."""
    path = Path(path)
    try:
        if path.stat().st_size > _MAX_CONFIG_BYTES:
            raise ValueError("oversized configuration")
        raw = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("configuration must be an object")
        return validate_config(Config(
            model=raw.get("model", "qwen3:8b") if "provider" in raw else "qwen3:8b",
            provider=raw.get("provider", "ollama"),
            always_on_top=raw.get("always_on_top", True),
            share_memories=raw.get("share_memories", False),
        ))
    except FileNotFoundError:
        return Config()
    except (OSError, UnicodeError, ValueError, TypeError, RecursionError):
        # Do not log file contents or exception messages: a user may have
        # accidentally pasted a credential into their configuration file.
        logger.warning("Preferences could not be read; safe defaults loaded.")
        return Config()


def save_config(path: Path, config: Config) -> None:
    """Atomically save only allowlisted, non-secret preferences."""
    validated = validate_config(config)
    payload = {
        "model": validated.model,
        "provider": validated.provider,
        "always_on_top": validated.always_on_top,
        "share_memories": validated.share_memories,
    }
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", dir=path.parent,
            prefix=".qiaomi-settings-", suffix=".tmp", delete=False,
        ) as handle:
            temp_path = Path(handle.name)
            json.dump(payload, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)
    finally:
        if temp_path is not None:
            temp_path.unlink(missing_ok=True)
