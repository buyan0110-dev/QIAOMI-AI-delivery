"""Small desktop-only preferences; never migrate or overwrite main/voice config."""
import json
import logging
import os
from pathlib import Path
import tempfile

log=logging.getLogger('qiaomi')

class DesktopPreferences:
    def __init__(self, folder):
        self.path=Path(folder)/'desktop.json'
        self.values={'position':None,'pet_manifest':'','use_builtin_pet':False}
        self.read_error=False
        try:
            if self.path.stat().st_size>64*1024:
                raise ValueError('oversized desktop settings')
            raw=json.loads(self.path.read_text(encoding='utf-8'))
            if not isinstance(raw,dict):raise ValueError('invalid desktop settings')
            self.values.update(raw)
            pos=raw.get('position')
            if pos is not None and (not isinstance(pos,dict) or set(pos)!={'x','y'} or any(type(pos[k]) is not int or abs(pos[k])>1_000_000 for k in ('x','y'))):
                raise ValueError('invalid saved position')
            if type(raw.get('use_builtin_pet',False)) is not bool:raise ValueError('invalid builtin setting')
            manifest=raw.get('pet_manifest','')
            if not isinstance(manifest,str) or len(manifest)>4096:
                raise ValueError('invalid manifest path')
        except FileNotFoundError:
            pass
        except (OSError,ValueError,TypeError,RecursionError):
            self.read_error=True
            self.values={'position':None,'pet_manifest':'','use_builtin_pet':False}
            log.warning('Desktop preferences invalid; defaults used, source file retained')

    def save(self):
        if self.read_error and self.path.exists():
            import uuid
            backup=self.path.with_name('desktop.invalid-'+uuid.uuid4().hex+'.json')
            backup.write_bytes(self.path.read_bytes())
            self.read_error=False
        self.path.parent.mkdir(parents=True,exist_ok=True)
        temporary=None
        try:
            with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=self.path.parent,prefix='.desktop-',suffix='.tmp',delete=False) as f:
                temporary=Path(f.name)
                json.dump(self.values,f,ensure_ascii=False,indent=2)
                f.write('\n');f.flush();os.fsync(f.fileno())
            os.replace(temporary,self.path)
        finally:
            if temporary is not None:temporary.unlink(missing_ok=True)
