"""Explicit extension boundaries; MVP performs no Windows automation.

The legacy voice protocol remains for compatibility; concrete local voice is
implemented in qiaomi.voice. History extraction is still a protocol only. Future implementations must
be installed and invoked explicitly; importing this module starts no service,
reads no private history and opens no microphone.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import secrets
from threading import Lock
import time
from typing import Protocol


class VoiceService(Protocol):
    """Future, user-initiated voice interface; never start it on import."""

    def listen_once(self) -> str:
        """Capture one utterance after the user explicitly requests recording."""
        ...

    def speak(self, text: str) -> None:
        """Speak explicitly requested text."""
        ...

    def stop(self) -> None:
        """Release microphone and audio resources."""
        ...


@dataclass(frozen=True)
class MemoryCandidate:
    key: str
    value: str
    source: str


class ChatHistoryMemoryExtractor(Protocol):
    """Future extraction from a user-selected export, never browser profiles.

    Implementations must require user_authorized=True and return candidates
    for the existing review UI. They must not write directly to the memory DB.
    """

    def extract(self, export_path: Path, *, user_authorized: bool = False) -> list[MemoryCandidate]:
        ...


@dataclass(frozen=True)
class AutomationRequest:
    id: str
    description: str


class ConfirmationRequiredError(ValueError):
    """No current matching, unexpired approval request exists."""


class AutomationService:
    """A one-time confirmation flow for a harmless demo only.

    There is deliberately no shell command, script, path, or callback input.
    API text cannot reach an execution backend. A new proposal replaces the
    old one, and confirmation tokens expire after five minutes.
    """

    def __init__(self) -> None:
        self._pending: AutomationRequest | None = None
        self._deadline = 0.0
        self._lock = Lock()

    def propose_demo(self) -> AutomationRequest:
        request = AutomationRequest(
            id=secrets.token_urlsafe(24),
            description="演示任务：确认后显示完成状态，不打开程序、不读取文件、不修改系统。",
        )
        with self._lock:
            self._pending = request
            self._deadline = time.monotonic() + 300
        return request

    def confirm(self, request_id: str) -> str:
        with self._lock:
            if self._pending is not None and time.monotonic() >= self._deadline:
                self._pending = None
            if (
                self._pending is None
                or not isinstance(request_id, str)
                or not request_id.isascii()
                or not secrets.compare_digest(request_id, self._pending.id)
            ):
                raise ConfirmationRequiredError("请先查看并确认当前任务；该请求可能已过期或已处理。")
            self._pending = None
        return "演示任务已完成。没有执行任何系统操作。"

    def cancel(self, request_id: str) -> bool:
        with self._lock:
            if (
                self._pending is not None
                and isinstance(request_id, str)
                and request_id.isascii()
                and secrets.compare_digest(request_id, self._pending.id)
            ):
                self._pending = None
                return True
        return False
