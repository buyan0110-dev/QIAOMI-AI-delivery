"""Per-user/data-directory lock plus a local activation pipe. No models on retry."""
import hashlib
import logging
import os
from pathlib import Path
from PySide6.QtCore import QObject, QLockFile, Signal, QTimer
from .windows import grant_activation
from PySide6.QtNetwork import QLocalServer, QLocalSocket

log=logging.getLogger('qiaomi')

class InstanceGuard(QObject):
    activated=Signal()
    def __init__(self, folder, parent=None):
        super().__init__(parent)
        folder=Path(folder).resolve()
        digest=hashlib.sha256(os.path.normcase(str(folder)).encode('utf-8')).hexdigest()[:32]
        self.name='qiaomi-'+digest
        self.lock=QLockFile(str(folder/'qiaomi.lock'))
        self.server=QLocalServer(self)
        self.server.setSocketOptions(QLocalServer.SocketOption.UserAccessOption)
        self.server.newConnection.connect(self._accept)
        self.owned=False
        self.peers=set()

    def acquire(self):
        if not self.lock.tryLock(0):return False
        self.owned=True
        # Only the process holding the lock can remove an abandoned endpoint.
        QLocalServer.removeServer(self.name)
        if not self.server.listen(self.name):
            self.close()
            raise RuntimeError('本地实例通信无法初始化，请检查用户数据目录权限。')
        return True

    def notify_existing(self, activate=True):
        if activate:
            try:grant_activation(self.lock.getLockInfo()[0])
            except Exception:log.warning('Existing instance owner information unavailable')
        message=b'activate\n' if activate else b'ping\n'
        # Short retries cover the first process creating its pipe after locking.
        for _ in range(3):
            socket=QLocalSocket()
            socket.connectToServer(self.name)
            if not socket.waitForConnected(350):
                socket.abort()
                continue
            socket.write(message);socket.flush()
            if socket.bytesAvailable() or socket.waitForReadyRead(1000):
                accepted=bytes(socket.readAll())==b'ok\n'
                socket.disconnectFromServer()
                return accepted
            socket.abort()
        return False

    def _accept(self):
        while self.server.hasPendingConnections():
            peer=self.server.nextPendingConnection()
            self.peers.add(peer)
            peer.setProperty('payload',b'')
            QTimer.singleShot(1500,lambda p=peer:p.abort() if p in self.peers else None)
            peer.readyRead.connect(lambda p=peer:self._read(p))
            peer.disconnected.connect(lambda p=peer:self._drop(p))
            if peer.bytesAvailable():self._read(peer)

    def _read(self, peer):
        if peer not in self.peers:return
        payload=bytes(peer.property('payload') or b'')+bytes(peer.readAll())
        if len(payload)>32:
            peer.abort();return
        peer.setProperty('payload',payload)
        if b'\n' not in payload:return
        if payload not in (b'activate\n',b'ping\n'):
            peer.abort();return
        if payload==b'activate\n':self.activated.emit()
        peer.write(b'ok\n');peer.flush();peer.disconnectFromServer()

    def _drop(self, peer):
        self.peers.discard(peer)
        peer.deleteLater()

    def close(self):
        for peer in list(self.peers):peer.abort()
        self.server.close()
        if self.owned:
            self.lock.unlock();self.owned=False
