"""Shared GUI/source/frozen bootstrap; import failures surface without a console."""
import ctypes
import faulthandler
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sys
import traceback
import tempfile
from .config import data_dir


def _folder(arguments):
    try:
        index=arguments.index('--data-dir')
        return Path(arguments[index+1]).expanduser().resolve()
    except (ValueError,IndexError):
        return data_dir()


def _notice(message):
    if sys.platform=='win32':
        ctypes.windll.user32.MessageBoxW(None,message,'QIAOMI AI 启动失败',16)
    elif sys.stderr:
        print(message,file=sys.stderr)


def launch(arguments=None):
    arguments=list(sys.argv[1:] if arguments is None else arguments)
    root=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[1]
    os.chdir(root)
    if '--voice-worker' in arguments:
        # This process communicates over its authenticated socket, not stdio.
        from .voice_worker import main
        return main()
    scratch=tempfile.TemporaryDirectory(prefix="qiaomi-bootstrap-smoke-") if "--smoke-test" in arguments else None
    folder=Path(scratch.name) if scratch else _folder(arguments)
    fault_file=None
    try:
        logs=folder/'logs';logs.mkdir(parents=True,exist_ok=True)
        fault_path=logs/'startup-fault.log'
        try:
            if fault_path.exists() and fault_path.stat().st_size>1_000_000:
                os.replace(fault_path,logs/'startup-fault.log.old')
        except OSError:
            pass
        fault_file=fault_path.open('a',encoding='utf-8')
        faulthandler.enable(file=fault_file,all_threads=True)
    except OSError:
        pass  # The GUI will still display a data directory error if applicable.
    try:
        if sys.stdout is None:sys.stdout=open(os.devnull,'w',encoding='utf-8')
        if sys.stderr is None:sys.stderr=open(os.devnull,'w',encoding='utf-8')
        from .app import main
        return main(arguments)
    except Exception as exc:
        frames=' > '.join(f'{Path(f.filename).name}:{f.lineno}' for f in traceback.extract_tb(exc.__traceback__))
        try:
            handler=RotatingFileHandler(folder/'logs'/'startup.log',maxBytes=512_000,backupCount=2,encoding='utf-8')
            record=logging.LogRecord('qiaomi.startup',logging.ERROR,'',0,'Startup failed %s at %s',(type(exc).__name__,frames),None)
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            handler.emit(record);handler.close()
        except OSError:
            pass
        _notice(f'无法启动敲咪（{type(exc).__name__}）。\n请用 start.bat 检查依赖与数据目录权限。\n日志目录：{folder / "logs"}')
        return 1
    finally:
        if fault_file:
            faulthandler.disable();fault_file.close()
        if scratch:scratch.cleanup()
