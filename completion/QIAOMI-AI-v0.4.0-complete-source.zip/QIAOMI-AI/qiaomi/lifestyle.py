"""Monotonic, pausable neglect clock and independent four-touch forgiveness.

No OS idle hooks, mouse movement, AI, database or wall-clock accounting.
"""
import time

NEGLECT_THRESHOLDS = (600, 1200, 1800)
TOUCH_GAP = 0.65


class InteractionClock:
    def __init__(self, values, now=time.monotonic):
        self.now = now
        self.accumulated = float(values.get('neglect_elapsed', 0))
        self.anchor = now()
        self.paused = bool(values.get('deep_sleep', False))
        self.sulking = bool(values.get('sulking', False))
        self.soothe_count = int(values.get('soothe_count', 0)) if self.sulking else 0
        self.last_touch = float('-inf')
        if not values.get('neglect_enabled', True):
            self.accumulated = 0
            self.sulking = False
            self.soothe_count = 0

    @property
    def elapsed(self):
        return self.accumulated + (0 if self.paused else max(0, self.now() - self.anchor))

    @property
    def stage(self):
        if self.sulking:
            return 3
        return sum(self.elapsed >= threshold for threshold in NEGLECT_THRESHOLDS)

    def evaluate(self):
        if not self.paused and self.stage >= 3:
            self.sulking = True
        return self.stage

    def pause(self):
        if not self.paused:
            self.accumulated = self.elapsed
            self.paused = True

    def resume(self):
        if self.paused:
            self.anchor = self.now()
            self.paused = False

    def interaction(self):
        if self.paused:
            return False
        self.accumulated = 0
        self.anchor = self.now()
        return True

    def touch(self):
        """Return 1..4 only for separated completed touches while sulking."""
        if self.paused or not self.sulking or self.now() - self.last_touch < TOUCH_GAP:
            return None
        self.last_touch = self.now()
        self.soothe_count += 1
        result = self.soothe_count
        self.interaction()
        if result == 4:
            self.sulking = False
            self.soothe_count = 0
        return result

    def snapshot(self):
        return dict(neglect_elapsed=min(86400, self.elapsed), sulking=self.sulking,
                    soothe_count=self.soothe_count)
