"""Local Ollama streaming transport; never uses API keys or environment proxies."""
from __future__ import annotations

import asyncio
from contextlib import suppress
import json
from threading import Event

import httpx

from .ai import AIError, _cancelled, _context

BASE_URL = 'http://127.0.0.1:11434'
GENERATION_TIMEOUT = 300.0


def _client():
    return httpx.AsyncClient(base_url=BASE_URL, trust_env=False,
                             timeout=httpx.Timeout(120, connect=3))


async def _installed(client, model):
    response = await client.get('/api/tags', timeout=3)
    response.raise_for_status()
    names = {item.get('name') for item in response.json().get('models', [])}
    if model not in names:
        raise AIError(f'Ollama 已运行，但未安装 {model}。请等待下载完成，或运行 ollama pull {model}。')


async def _watch(operation, stop_event, timeout):
    task = asyncio.create_task(operation)
    try:
        async with asyncio.timeout(timeout):
            while not task.done():
                _cancelled(stop_event)
                await asyncio.wait({task}, timeout=.05)
            _cancelled(stop_event)
            return task.result()
    finally:
        if not task.done():
            task.cancel()
        with suppress(asyncio.CancelledError, Exception):
            await task


def _safe_error(exc):
    if isinstance(exc, AIError):
        return exc
    if isinstance(exc, (TimeoutError, httpx.TimeoutException)):
        return AIError('Ollama 响应超时。首次加载模型可能较慢，请稍后重试。')
    if isinstance(exc, httpx.ConnectError):
        return AIError('无法连接本机 Ollama。请启动 Ollama，或运行 ollama serve，然后重新检测。')
    return AIError('Ollama 返回异常或连接中断，请检查模型和 Ollama 状态后重试。')


def check_ollama(model='qwen3:8b', stop_event: Event | None = None):
    async def check():
        async with _client() as client:
            await _installed(client, model)
        return f'Ollama 已连接 · {model} 已安装'
    try:
        return asyncio.run(_watch(check(), stop_event, 6))
    except Exception as exc:
        raise _safe_error(exc) from None


def ollama_reply(model, messages, memories, stop_event=None, on_chunk=None):
    async def generate():
        async with _client() as client:
            await _installed(client, model)
            payload = {'model': model, 'messages': _context(messages, memories),
                       'stream': True, 'think': False,
                       'options': {'num_predict': 2048, 'num_ctx': 8192}}
            parts = []
            size = 0
            async with client.stream('POST', '/api/chat', json=payload) as response:
                response.raise_for_status()
                async for line in response.aiter_lines():
                    _cancelled(stop_event)
                    if not line.strip():
                        continue
                    if len(line) > 256000:
                        raise AIError('Ollama 返回的数据过大。')
                    item = json.loads(line)
                    if item.get('error'):
                        raise AIError('Ollama 生成失败，请检查模型是否已完整下载及显存使用情况。')
                    content = item.get('message', {}).get('content', '')
                    if not isinstance(content, str):
                        raise AIError('Ollama 返回了无效的文字内容。')
                    if content:
                        size += len(content)
                        if size > 32000:
                            raise AIError('本次回复过长，请缩小问题范围后重试。')
                        parts.append(content)
                        if on_chunk:
                            on_chunk(content)
                    if item.get('done') is True:
                        answer = ''.join(parts).strip()
                        if not answer:
                            raise AIError('Ollama 没有返回文字，请重试。')
                        return answer
            raise AIError('Ollama 连接提前结束，回复未完成，请重试。')
    try:
        return asyncio.run(_watch(generate(), stop_event, GENERATION_TIMEOUT))
    except Exception as exc:
        _cancelled(stop_event)
        raise _safe_error(exc) from None
