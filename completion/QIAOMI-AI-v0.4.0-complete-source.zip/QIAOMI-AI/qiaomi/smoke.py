"""Isolated startup verification, also usable by a frozen Windows executable."""
from __future__ import annotations
import json
from pathlib import Path
import platform
import sys

from PySide6.QtCore import QObject, QTimer, qVersion

from . import __version__
from .storage import Store
from .ui.pet import STATES


class SmokeRunner(QObject):
    """Verify real application behavior without network, dialogs or user data."""

    def __init__(self, controller):
        super().__init__(controller)
        self.controller = controller
        self.checks: dict[str, bool] = {}
        self.errors: list[str] = []
        self.finished = False
        self.poll = QTimer(self)
        self.poll.setInterval(20)
        self.poll.timeout.connect(self.verify_reply)
        self.deadline = QTimer(self)
        self.deadline.setSingleShot(True)
        self.deadline.timeout.connect(lambda: self.fail('startup_deadline'))

    def check(self, name: str, passed: bool):
        self.checks[name] = bool(passed)
        if not passed:
            raise RuntimeError(name)

    def start(self):
        self.deadline.start(8000)
        try:
            c = self.controller
            self.check('offline_no_key', not c.api_key)
            c.show_pet()
            self.check('pet_visible', c.pet.isVisible() and not c.window.isVisible())
            for state in STATES:
                c.pet.set_state(state)
                self.check('render_' + state, not c.pet.grab().isNull())
            c.pet.set_state('idle')
            c.show_assistant()
            self.check('assistant_visible', c.window.isVisible() and c.pet.isVisible())
            self.check('pet_animation_continues_with_chat', c.pet.timer.isActive())
            c.send('你好，敲咪')
            self.poll.start()
        except Exception as exc:
            self.fail('startup_checks', exc)

    def verify_reply(self):
        if self.finished or self.controller.worker is not None:
            return
        self.poll.stop()
        try:
            c = self.controller
            rows = c.store.messages()
            self.check('offline_reply_saved', len(rows) == 2 and rows[0]['role'] == 'user'
                       and rows[1]['role'] == 'assistant' and rows[1]['content'].startswith('【离线模式】'))
            self.check('send_enabled_after_reply', c.window.send_button.isEnabled())
            c.store.upsert_memory('自检偏好', '临时目录内的测试数据')
            backup = c.folder / 'smoke-memory.json'
            c.store.export_memories(backup)
            items = c.store.parse_import(backup)
            self.check('memory_backup_roundtrip', items == [{'key': '自检偏好', 'value': '临时目录内的测试数据'}])
            c.store.delete_memory(c.store.list_memories()[0]['id'])
            self.check('memory_import', c.store.import_memories(items) == 1)
            check_store = Store(c.folder / 'qiaomi.db')
            try:
                self.check('sqlite_persistence', len(check_store.messages()) == 2
                           and check_store.list_memories()[0]['value'] == items[0]['value'])
            finally:
                check_store.close()
            self.check('no_runtime_errors', not c.runtime_errors)
            c.show_pet()
            self.check('return_to_pet', c.pet.isVisible() and not c.window.isVisible())
            self.finish()
        except Exception as exc:
            self.fail('reply_and_storage_checks', exc)

    def fail(self, stage: str, error: Exception | None = None):
        if self.finished:
            return
        self.checks[stage] = False
        # Fixed stage names and exception classes only; no messages or secrets.
        self.errors.append(stage + (': ' + type(error).__name__ if error else ''))
        self.finish()

    def finish(self):
        self.finished = True
        self.poll.stop()
        self.deadline.stop()
        self.controller.request_quit()

    def result(self) -> dict:
        self.checks['clean_shutdown'] = self.controller.closed and self.controller.worker is None
        self.checks['no_runtime_errors'] = not self.controller.runtime_errors
        return {
            'application': 'QIAOMI AI', 'version': __version__,
            'platform': platform.system(), 'python': platform.python_version(), 'qt': qVersion(),
            'passed': self.finished and bool(self.checks) and all(self.checks.values()) and not self.errors,
            'checks': dict(self.checks), 'errors': list(self.errors),
        }


def write_report(path: Path | None, result: dict) -> None:
    payload = json.dumps(result, ensure_ascii=False, indent=2) + '\n'
    if path is not None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(payload, encoding='utf-8')
    # PyInstaller --windowed has no stdout. The optional file is authoritative.
    if sys.stdout is not None:
        print(payload, end='')
