"""Qt presentation layer."""
