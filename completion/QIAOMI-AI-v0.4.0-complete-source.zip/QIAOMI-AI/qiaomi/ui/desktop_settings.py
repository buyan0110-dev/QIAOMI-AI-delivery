"""Optional desktop settings without changing the established chat layout."""
from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import QDialog,QVBoxLayout,QLabel,QCheckBox,QPushButton,QHBoxLayout

class DesktopSettings(QDialog):
    wake_requested=Signal()
    personality_requested=Signal()
    game_changed=Signal(bool)
    autostart_changed=Signal(bool)
    choose_pet=Signal()
    reset_pet=Signal()
    def __init__(self):
        super().__init__()
        self.setWindowTitle('敲咪 · 桌面与启动设置')
        self.resize(560,330)
        layout=QVBoxLayout(self)
        intro=QLabel('关闭聊天窗口会保留小猫与托盘。完全退出请使用托盘“退出敲咪”。')
        intro.setWordWrap(True);layout.addWidget(intro)
        self.game=QCheckBox('游戏深度休眠：停止全部动画/撒娇/语音与新推理')
        self.game.toggled.connect(self.game_changed);layout.addWidget(self.game)
        game_tip=QLabel('离开游戏、显示窗口或取消勾选都不会恢复。只有点击“唤醒敲咪”后，才能重新加载动画、聊天和语音。')
        game_tip.setWordWrap(True);layout.addWidget(game_tip)
        self.wake=QPushButton('唤醒敲咪');self.wake.clicked.connect(self.wake_requested);layout.addWidget(self.wake)
        personality=QPushButton('超级黏人 · 性格与眼镜造型');personality.clicked.connect(self.personality_requested);layout.addWidget(personality)
        self.autostart=QCheckBox('登录 Windows 后自动启动敲咪（当前用户，无管理员权限）')
        self.autostart.toggled.connect(self.autostart_changed);layout.addWidget(self.autostart)
        self.status=QLabel('');self.status.setWordWrap(True);self.status.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.status)
        self.manifest=QLabel('内置小橘猫');self.manifest.setWordWrap(True);self.manifest.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.manifest)
        actions=QHBoxLayout()
        choose=QPushButton('选择本地宠物形象清单');choose.clicked.connect(self.choose_pet);actions.addWidget(choose)
        reset=QPushButton('使用粉色睡衣敲咪');reset.clicked.connect(self.reset_pet);actions.addWidget(reset)
        layout.addLayout(actions)
        self.note=QLabel('');self.note.setWordWrap(True);self.note.setTextFormat(Qt.TextFormat.PlainText);layout.addWidget(self.note)
