"""Local memory management and an explicit, reviewable JSON import flow."""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


LOGGER = logging.getLogger(__name__)
KEY_LIMIT = 120
VALUE_LIMIT = 4000


def _button(text: str, callback=None, *, primary: bool = False) -> QPushButton:
    button = QPushButton(text)
    button.setObjectName("primary" if primary else "secondary")
    button.setCursor(Qt.CursorShape.PointingHandCursor)
    if callback is not None:
        button.clicked.connect(callback)
    return button


def _confirm(parent: QWidget, title: str, message: str) -> bool:
    dialog = QMessageBox(parent)
    dialog.setWindowTitle(title)
    dialog.setIcon(QMessageBox.Icon.Question)
    dialog.setTextFormat(Qt.TextFormat.PlainText)
    dialog.setText(message)
    dialog.setStandardButtons(QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
    dialog.setDefaultButton(QMessageBox.StandardButton.No)
    return dialog.exec() == QMessageBox.StandardButton.Yes


class MemoryEditor(QDialog):
    """Edit one user-provided preference. No automatic inference happens here."""

    def __init__(self, memory: dict | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.setWindowTitle("修改记忆" if memory else "添加记忆")
        self.resize(560, 400)
        layout = QVBoxLayout(self)
        layout.setSpacing(14)
        description = QLabel("只保存你主动提供、希望敲咪记住的偏好。")
        description.setWordWrap(True)
        layout.addWidget(description)
        form = QFormLayout()
        self.key_edit = QLineEdit(str(memory.get("key", "")) if memory else "")
        self.key_edit.setMaxLength(KEY_LIMIT)
        self.key_edit.setPlaceholderText("例如：称呼、饮食偏好、回复风格")
        self.value_edit = QPlainTextEdit()
        self.value_edit.setPlainText(str(memory.get("value", "")) if memory else "")
        self.value_edit.setPlaceholderText("例如：请叫我小林，回答问题时先给出结论。")
        self.value_edit.setMinimumHeight(180)
        form.addRow("记忆名称", self.key_edit)
        form.addRow("记忆内容", self.value_edit)
        layout.addLayout(form)
        self.counter = QLabel()
        self.counter.setObjectName("muted")
        layout.addWidget(self.counter)
        self.buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        self.save_button = self.buttons.button(QDialogButtonBox.StandardButton.Save)
        self.save_button.setText("保存记忆")
        self.save_button.setObjectName("primary")
        self.buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        self.buttons.accepted.connect(self.accept)
        self.buttons.rejected.connect(self.reject)
        layout.addWidget(self.buttons)
        self.key_edit.textChanged.connect(self._validate)
        self.value_edit.textChanged.connect(self._validate)
        self._validate()

    def _validate(self):
        value = self.value_edit.toPlainText()
        self.counter.setText(f"名称最多 {KEY_LIMIT} 字 · 内容 {len(value)} / {VALUE_LIMIT} 字")
        self.save_button.setEnabled(
            bool(self.key_edit.text().strip()) and bool(value.strip()) and len(value) <= VALUE_LIMIT
        )

    def values(self) -> tuple[str, str]:
        return self.key_edit.text().strip(), self.value_edit.toPlainText().strip()


class ImportReviewDialog(QDialog):
    """Nothing is imported until rows are selected and review is acknowledged."""

    def __init__(self, items: list[dict], existing_keys: set[str], parent: QWidget | None = None):
        super().__init__(parent)
        self._items = [dict(key=item["key"], value=item["value"]) for item in items]
        self.setWindowTitle("审核 JSON 记忆")
        self.resize(820, 680)
        self.setMinimumSize(600, 520)
        layout = QVBoxLayout(self)
        layout.setSpacing(12)
        heading = QLabel("选择你认可的条目，再确认导入")
        heading.setObjectName("sectionTitle")
        layout.addWidget(heading)
        note = QLabel(
            "文件中的内容尚未保存。点击一行可在下方查看完整内容；勾选的同名记忆将替换已有内容。"
            "此处不会读取 ChatGPT 账户或浏览器数据。"
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        actions = QHBoxLayout()
        actions.addWidget(_button("全选", lambda: self._select_all(True)))
        actions.addWidget(_button("全不选", lambda: self._select_all(False)))
        actions.addStretch()
        self.count_label = QLabel()
        actions.addWidget(self.count_label)
        layout.addLayout(actions)
        self.table = QTableWidget(len(items), 4)
        self.table.setHorizontalHeaderLabels(["导入", "记忆名称", "内容预览", "处理方式"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.Interactive)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.table.setColumnWidth(1, 160)
        for row, item in enumerate(items):
            check = QTableWidgetItem()
            check.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable | Qt.ItemFlag.ItemIsSelectable)
            check.setCheckState(Qt.CheckState.Unchecked)
            self.table.setItem(row, 0, check)
            self.table.setItem(row, 1, QTableWidgetItem(item["key"]))
            preview = item["value"].replace("\n", " ")
            self.table.setItem(row, 2, QTableWidgetItem(preview[:160] + ("…" if len(preview) > 160 else "")))
            self.table.setItem(row, 3, QTableWidgetItem("替换已有" if item["key"] in existing_keys else "新增"))
            self.table.setRowHeight(row, 36)
        layout.addWidget(self.table, 2)
        layout.addWidget(QLabel("选中条目的完整内容"))
        self.detail = QPlainTextEdit()
        self.detail.setReadOnly(True)
        self.detail.setMinimumHeight(120)
        layout.addWidget(self.detail, 1)
        self.reviewed = QCheckBox("我已审核所选内容，并同意覆盖其中的同名记忆")
        layout.addWidget(self.reviewed)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        self.confirm_button = buttons.button(QDialogButtonBox.StandardButton.Ok)
        self.confirm_button.setText("确认导入")
        self.confirm_button.setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("取消")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.table.itemChanged.connect(self._selection_changed)
        self.table.itemSelectionChanged.connect(self._show_detail)
        self.reviewed.toggled.connect(self._update_confirm)
        if items:
            self.table.selectRow(0)
        self._update_confirm()

    def selected_items(self) -> list[dict]:
        return [
            dict(item)
            for row, item in enumerate(self._items)
            if self.table.item(row, 0).checkState() == Qt.CheckState.Checked
        ]

    def _select_all(self, checked: bool):
        self.table.blockSignals(True)
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.CheckState.Checked if checked else Qt.CheckState.Unchecked)
        self.table.blockSignals(False)
        self._selection_changed()

    def _selection_changed(self, *_):
        self.reviewed.setChecked(False)
        self._update_confirm()

    def _update_confirm(self, *_):
        count = len(self.selected_items())
        self.count_label.setText(f"已选 {count} / {len(self._items)} 条")
        self.confirm_button.setEnabled(count > 0 and self.reviewed.isChecked())

    def _show_detail(self):
        row = self.table.currentRow()
        if 0 <= row < len(self._items):
            item = self._items[row]
            self.detail.setPlainText(f"{item['key']}\n\n{item['value']}")
        else:
            self.detail.clear()


class MemoryPage(QWidget):
    """CRUD page backed by the main-thread SQLite Store."""

    changed = Signal()

    def __init__(self, store, parent: QWidget | None = None):
        super().__init__(parent)
        self.store = store
        self._memories: list[dict] = []
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(16)
        title = QLabel("记住你的偏好")
        title.setObjectName("pageTitle")
        layout.addWidget(title)
        subtitle = QLabel("记忆保存在这台电脑。你可以随时修改、删除或备份。")
        subtitle.setObjectName("muted")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)
        actions = QHBoxLayout()
        actions.setSpacing(8)
        self.add_button = _button("＋ 添加记忆", self.add_memory, primary=True)
        self.edit_button = _button("修改", self.edit_memory)
        self.delete_button = _button("删除", self.delete_memory)
        actions.addWidget(self.add_button)
        actions.addWidget(self.edit_button)
        actions.addWidget(self.delete_button)
        actions.addStretch()
        actions.addWidget(_button("导入 JSON", self.import_json))
        actions.addWidget(_button("导出备份", self.export_json))
        layout.addLayout(actions)
        self.caption = QLabel()
        self.caption.setObjectName("muted")
        layout.addWidget(self.caption)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["记忆名称", "记忆内容"])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 190)
        self.table.setWordWrap(True)
        self.table.itemSelectionChanged.connect(self._update_actions)
        self.table.itemDoubleClicked.connect(lambda *_: self.edit_memory())
        layout.addWidget(self.table, 1)
        self.empty_label = QLabel("还没有记忆。\n添加一条偏好，让敲咪更了解你。")
        self.empty_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.empty_label.setObjectName("muted")
        self.empty_label.setMinimumHeight(120)
        layout.addWidget(self.empty_label, 1)
        footer = QLabel("只有在设置中开启「允许将本地记忆用于 AI 对话」后，记忆才会随对话发送给 OpenAI。")
        footer.setObjectName("muted")
        footer.setWordWrap(True)
        layout.addWidget(footer)
        self.refresh()

    def refresh(self):
        try:
            self._memories = self.store.list_memories()
            self.table.setRowCount(len(self._memories))
            for row, memory in enumerate(self._memories):
                name = QTableWidgetItem(memory["key"])
                name.setData(Qt.ItemDataRole.UserRole, memory["id"])
                content = QTableWidgetItem(memory["value"])
                content.setToolTip(memory["value"])
                self.table.setItem(row, 0, name)
                self.table.setItem(row, 1, content)
                self.table.setRowHeight(row, 64)
            self.caption.setText(f"共 {len(self._memories)} 条记忆 · 双击一行可查看或编辑完整内容")
            self.empty_label.setVisible(not self._memories)
            self.table.setVisible(bool(self._memories))
            self._update_actions()
        except Exception as error:
            self._error(error)

    def _selected(self) -> dict | None:
        row = self.table.currentRow()
        return self._memories[row] if 0 <= row < len(self._memories) else None

    def _update_actions(self):
        selected = self._selected() is not None
        self.edit_button.setEnabled(selected)
        self.delete_button.setEnabled(selected)

    def _changed(self):
        self.refresh()
        self.changed.emit()

    def _error(self, error: Exception):
        LOGGER.warning("Memory operation failed (%s)", type(error).__name__)
        message = str(error) if isinstance(error, ValueError) else "无法完成操作。请检查文件权限、磁盘空间或数据库是否被占用后重试。"
        dialog = QMessageBox(self)
        dialog.setWindowTitle("记忆操作未完成")
        dialog.setIcon(QMessageBox.Icon.Warning)
        dialog.setTextFormat(Qt.TextFormat.PlainText)
        dialog.setText(message)
        dialog.exec()

    def add_memory(self):
        dialog = MemoryEditor(parent=self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        key, value = dialog.values()
        try:
            if any(memory["key"] == key for memory in self.store.list_memories()):
                if not _confirm(self, "替换同名记忆", f"「{key}」已存在，要替换其内容吗？"):
                    return
            self.store.upsert_memory(key, value)
            self._changed()
        except Exception as error:
            self._error(error)

    def edit_memory(self):
        memory = self._selected()
        if memory is None:
            return
        dialog = MemoryEditor(memory, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        try:
            key, value = dialog.values()
            self.store.update_memory(memory["id"], key, value)
            self._changed()
        except Exception as error:
            self._error(error)

    def delete_memory(self):
        memory = self._selected()
        if memory is None:
            return
        if not _confirm(self, "删除记忆", f"确定删除「{memory['key']}」吗？此操作不能撤销。"):
            return
        try:
            self.store.delete_memory(memory["id"])
            self._changed()
        except Exception as error:
            self._error(error)

    def import_json(self):
        filename, _ = QFileDialog.getOpenFileName(self, "选择经过审核的 JSON 记忆", "", "JSON 文件 (*.json)")
        if not filename:
            return
        try:
            items = self.store.parse_import(Path(filename))
            if not items:
                QMessageBox.information(self, "没有可导入的记忆", "该文件不包含记忆条目。")
                return
            existing = {memory["key"] for memory in self.store.list_memories()}
            dialog = ImportReviewDialog(items, existing, self)
            if dialog.exec() != QDialog.DialogCode.Accepted:
                return
            # Check again even if a caller accepts the dialog programmatically.
            selected = dialog.selected_items()
            if not selected or not dialog.reviewed.isChecked():
                return
            count = self.store.import_memories(selected)
            self._changed()
            QMessageBox.information(self, "导入完成", f"已保存 {count} 条记忆。")
        except Exception as error:
            self._error(error)

    def export_json(self):
        filename, _ = QFileDialog.getSaveFileName(self, "导出本地记忆备份", "qiaomi-memories.json", "JSON 文件 (*.json)")
        if not filename:
            return
        try:
            self.store.export_memories(Path(filename))
            QMessageBox.information(self, "备份完成", "记忆已导出为 JSON。备份包含个人偏好，请妥善保存。")
        except Exception as error:
            self._error(error)
