"""Shared restrained, high contrast desktop styling."""
STYLE = """
QWidget { color: #dce7f5; font-family: 'Microsoft YaHei UI', 'Noto Sans CJK SC', 'Segoe UI', sans-serif; font-size: 13px; }
QMainWindow, QDialog { background: #0b111c; }
QScrollArea, QWidget#settingsBody { background: #0b111c; border: none; }
QWidget#shell { background: rgba(11,17,28,246); border: 1px solid #27384c; border-radius: 18px; }
QFrame#sidebar { background: #101a28; border-radius: 13px; }
QFrame#card { background: #121e2d; border: 1px solid #25374b; border-radius: 12px; }
QLabel#eyebrow { color: #6ddcfa; font-size: 11px; font-weight: 600; }
QLabel#title { color: #f0f6ff; font-size: 27px; font-weight: 700; }
QLabel#subtitle, QLabel#muted { color: #91a4bb; }
QLabel#brand { font-size: 22px; font-weight: 800; letter-spacing: 2px; }
QLabel#status { color: #77e7cb; }
QPushButton { background: #1b2a3d; border: 1px solid #2a4059; border-radius: 8px; padding: 9px 14px; font-weight: 500; }
QPushButton:hover { background: #253d55; border-color: #5085a7; }
QPushButton:pressed { background: #102537; }
QPushButton:disabled { color: #617184; background: #142030; border-color: #243247; }
QPushButton#primary { color: #071722; background: #6ddcfa; border: none; font-weight: 700; }
QPushButton#primary:hover { background: #9ae8fe; }
QPushButton#primary:disabled { color: #6b889b; background: #284d60; }
QPushButton#nav { text-align: left; background: transparent; border: none; padding: 13px 17px; }
QPushButton#nav:checked { background: #1a3449; color: #81e1ff; border-left: 3px solid #6ddcfa; }
QPushButton#danger { color: #ffadad; }
QPushButton#quiet { background: transparent; border: none; color: #91a4bb; }
QTextBrowser, QPlainTextEdit, QTextEdit, QLineEdit, QComboBox { background: #0d1724; border: 1px solid #293c51; border-radius: 8px; padding: 9px; selection-background-color: #285b7b; }
QTextBrowser { border: none; background: transparent; }
QLineEdit:focus, QPlainTextEdit:focus { border-color: #69cce8; }
QTableWidget { background: #101c2a; alternate-background-color: #132132; border: 1px solid #293c51; border-radius: 7px; gridline-color: #25374a; selection-background-color: #244965; }
QHeaderView::section { background: #1b2b3d; color: #a8bdd3; padding: 9px; border: none; }
QCheckBox { spacing: 10px; padding: 7px 0; }
QCheckBox::indicator { width: 18px; height: 18px; }
QScrollBar:vertical { background: transparent; width: 9px; margin: 0; }
QScrollBar::handle:vertical { background: #31485f; border-radius: 4px; min-height: 30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: none; }
QMenu { background: #122031; border: 1px solid #314b66; padding: 6px; }
QMenu::item { padding: 8px 24px; }
QMenu::item:selected { background: #27465f; border-radius: 4px; }
QToolTip { color: #e3eef9; background: #1b2d42; border: 1px solid #35526b; padding: 6px; }
"""
