"""Qt voice coordinator: child-process ASR + installed offline Qt/SAPI voices."""
from __future__ import annotations
import json
import logging
import sys
import time
import secrets
from pathlib import Path
from PySide6.QtCore import QObject, QProcess, QTimer, Signal
from PySide6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QPushButton,
    QCheckBox, QLabel, QComboBox, QSlider, QLineEdit, QFileDialog,
    QProgressBar, QPlainTextEdit, QScrollArea, QWidget)
from PySide6.QtNetwork import QTcpServer, QHostAddress
from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from .voice_logging import configure_voice_logging
from .windows import voice_worker_program

log = logging.getLogger('qiaomi')

class TranscriptWakeDetector:
    """Replaceable fallback, NOT a dedicated keyword spotting model."""
    label = '实验：本地转写匹配（非专用唤醒词检测）'
    def matches(self, text):
        import re
        return re.sub(r'[\s，。！？,.!?]', '', text).startswith('敲咪')

class VoiceService(QObject):
    activity_finished = Signal()
    activity_started = Signal()
    cancel_requested = Signal()
    text = Signal(str)
    status = Signal(str)
    animation = Signal(str)
    wake_detected = Signal()

    def __init__(self, folder, parent=None):
        super().__init__(parent)
        self.path = Path(folder) / 'voice.json'
        self.log_path = Path(folder) / 'logs' / 'voice.log'
        self.voice_log, self.log_error = configure_voice_logging(folder)
        self.settings = dict(model_path='', device=None, compute='cpu', threshold=.012,
                             volume=80, rate=0, voice='', tts=False, memory_enabled=True,
                             record_mode='manual', device_name='', device_hostapi='')
        try:
            saved = json.loads(self.path.read_text(encoding='utf-8'))
            if isinstance(saved, dict):
                for key in self.settings:
                    value = saved.get(key)
                    if type(value) is type(self.settings[key]):
                        self.settings[key] = value
                if type(saved.get('device')) is int:
                    self.settings['device'] = saved['device']
        except FileNotFoundError:
            pass
        except (OSError, ValueError):
            self.voice_log.exception('Voice preferences read failed; defaults used')
        self.settings['record_mode'] = 'auto' if self.settings['record_mode']=='auto' else 'manual'
        self.settings['compute'] = 'cuda' if self.settings['compute'] == 'cuda' else 'cpu'
        self.settings['threshold'] = max(.0001, min(.1, self.settings['threshold']))
        self.settings['volume'] = max(0, min(100, self.settings['volume']))
        self.settings['rate'] = max(-80, min(80, self.settings['rate']))
        self.deep_sleep = False
        self.background_suspended = False
        self.wake = False  # Never restore continuous listening after restart.
        self.muted = False
        self.busy = False
        self.listening = False
        self.closing = False
        self.mode = 'manual'
        self.capture_state = 'idle'
        self.request_sequence = 0
        self.active_request = None
        self.diagnostic_values = {}
        self.terminal_message = ''
        self.operation_started = 0.0
        self.active_record_mode = 'manual'
        self.stopping = False
        self.expected_exit = False
        self.buffer = b''
        self.pending_commands = []
        self.socket = None
        self.authenticated = False
        self.token = secrets.token_hex(32)
        self.server = QTcpServer(self)
        self.server.listen(QHostAddress.SpecialAddress.LocalHost, 0)
        self.server.newConnection.connect(self._connected)
        self.tts = None
        self.awaiting_command = False
        self.speaking = False
        self.retry = QTimer(self)
        self.retry.setSingleShot(True)
        self.retry.timeout.connect(self._wake_listen)
        self.follow = QTimer(self)
        self.follow.setSingleShot(True)
        self.follow.timeout.connect(self._follow_listen)
        self.process = QProcess(self)
        self.process.readyReadStandardOutput.connect(lambda: self.process.readAllStandardOutput())
        self.process.readyReadStandardError.connect(lambda: self.process.readAllStandardError())
        self.watchdog = QTimer(self)
        self.watchdog.setSingleShot(True)
        self.watchdog.timeout.connect(self._watchdog_expired)
        self.cancel_deadline = QTimer(self)
        self.cancel_deadline.setSingleShot(True)
        self.cancel_deadline.timeout.connect(self._kill_cancelled_worker)
        self.process.finished.connect(self._process_finished)
        self.process.errorOccurred.connect(self._process_error)
        self.detector = TranscriptWakeDetector()
        self.panel = self._panel()
        self._update_controls()
        self._show_diagnostics()
        if self.log_error:
            self.status.emit("语音日志无法写入（"+self.log_error+"），功能仍可使用。")
        self._tts_attempted = False
        self._log_failure_shown = bool(self.log_error)

    def _ensure_tts(self):
        if self.deep_sleep:return
        if self.tts is not None or self._tts_attempted:
            return
        self._tts_attempted = True
        try:
            from PySide6.QtTextToSpeech import QTextToSpeech
            # Explicit Windows SAPI is offline and uses installed system voices.
            engines = QTextToSpeech.availableEngines()
            engine = next((e for e in ('sapi', 'winrt') if e in engines), '') if sys.platform=='win32' else 'speechd'
            self.tts = QTextToSpeech(engine, self) if engine else None
            if self.tts is None:
                self.tts_status.setText('未发现可用的本地 TTS 引擎；录音与识别仍可使用。')
                return
            self.tts.stateChanged.connect(self._tts_state)
            self.tts.errorOccurred.connect(lambda *_: self.tts_status.setText('本地 TTS 不可用，请安装 Windows 中文语音包。'))
            self._load_voices()
        except Exception:
            self.voice_log.exception('Local TTS initialization failed')
            self.tts_status.setText('本地 TTS 组件不可用；录音和文字功能仍可使用。')

    def _panel(self):
        panel = QDialog()
        panel.setWindowTitle('敲咪 · 本地语音设置')
        panel.resize(700, 760)
        outer = QVBoxLayout(panel)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        body = QWidget()
        body.setObjectName('settingsBody')
        layout = QVBoxLayout(body)
        scroll.setWidget(body)
        outer.addWidget(scroll)
        layout.addWidget(QLabel('录音仅驻留内存；默认不监听。自检无需模型，转写使用本地模型。'))
        self.label = QLabel('麦克风未开启')
        self.status.connect(self.label.setText)
        self.label.setWordWrap(True)
        self.label.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.label)
        row = QHBoxLayout()
        self.mic = QComboBox()
        self.mic.addItem('系统默认麦克风', None)
        if self.settings['device'] is not None:
            self.mic.addItem((self.settings['device_name'] or '已保存设备')+'（请刷新核对）', self.settings['device'])
            self.mic.setCurrentIndex(1)
        self.device_entries = {}
        self.mic.currentIndexChanged.connect(self._device_changed)
        row.addWidget(self.mic)
        self.refresh_button = QPushButton('刷新设备')
        self.refresh_button.clicked.connect(lambda: self._command({'op':'devices'}))
        row.addWidget(self.refresh_button)
        layout.addLayout(row)
        self.mode_input = QComboBox()
        self.mode_input.addItem('手动录音（默认）：点击结束后识别，不经过 VAD 门控', 'manual')
        self.mode_input.addItem('自动检测：按能量判断说话开始和结束', 'auto')
        self.mode_input.setCurrentIndex(1 if self.settings['record_mode']=='auto' else 0)
        self.mode_input.currentIndexChanged.connect(lambda _: self._set('record_mode', self.mode_input.currentData()))
        layout.addWidget(self.mode_input)
        self.level_bar = QProgressBar()
        self.level_bar.setRange(0,100)
        self.level_bar.setValue(0)
        self.level_bar.setMinimumHeight(26)
        self.level_bar.setStyleSheet('QProgressBar {border:1px solid #31485f;border-radius:5px;text-align:center;background:#101c2a;} QProgressBar::chunk {background:#3e9cbb;}')
        self.level_bar.setFormat('输入电平 %p%（可视化增益；诊断 RMS 与阈值均为 0–1）')
        layout.addWidget(self.level_bar)
        self.duration_label = QLabel('录音时长：0.0 秒 · 已采集 0 帧')
        layout.addWidget(self.duration_label)
        self.diag_toggle = QCheckBox('展开语音诊断')
        layout.addWidget(self.diag_toggle)
        self.diagnostics = QPlainTextEdit()
        self.diagnostics.setReadOnly(True)
        self.diagnostics.setMinimumHeight(180)
        self.diagnostics.setMaximumHeight(230)
        self.diagnostics.hide()
        self.diag_toggle.toggled.connect(self.diagnostics.setVisible)
        layout.addWidget(self.diagnostics)
        actions = QHBoxLayout()
        self.start_button = QPushButton('开始说话')
        self.start_button.clicked.connect(self.listen)
        actions.addWidget(self.start_button)
        self.finish_button = QPushButton('结束并识别')
        self.finish_button.clicked.connect(self.finish_recording)
        actions.addWidget(self.finish_button)
        interrupt = QPushButton('取消 / 打断')
        interrupt.clicked.connect(self.cancel_requested.emit)
        actions.addWidget(interrupt)
        self.mute_box = QCheckBox('麦克风静音')
        self.mute_box.toggled.connect(self.set_muted)
        actions.addWidget(self.mute_box)
        layout.addLayout(actions)
        tools = QHBoxLayout()
        self.test_button = QPushButton('测试麦克风（3 秒，不转写）')
        self.test_button.clicked.connect(self.test_microphone)
        tools.addWidget(self.test_button)
        open_log = QPushButton('打开语音日志')
        open_log.clicked.connect(self.open_voice_log)
        tools.addWidget(open_log)
        layout.addLayout(tools)
        self.test_result = QLabel('自检尚未运行')
        self.test_result.setWordWrap(True)
        layout.addWidget(self.test_result)
        self.transcript = QLabel('识别结果显示在这里')
        self.transcript.setWordWrap(True)
        self.transcript.setTextFormat(Qt.TextFormat.PlainText)
        self.test_result.setTextFormat(Qt.TextFormat.PlainText)
        layout.addWidget(self.transcript)
        self.model = QLineEdit(self.settings['model_path'])
        self.model.setPlaceholderText('本地 faster-whisper 模型目录')
        self.model.editingFinished.connect(lambda: self._set('model_path', self.model.text().strip()))
        layout.addWidget(self.model)
        choose = QPushButton('选择模型目录')
        choose.clicked.connect(self._choose)
        layout.addWidget(choose)
        compute = QComboBox()
        compute.addItem('CPU int8（推荐，给 Qwen3 留出显存）', 'cpu')
        compute.addItem('CUDA float16（需要 CUDA 12 / cuDNN 9，失败回退 CPU）', 'cuda')
        compute.setCurrentIndex(1 if self.settings['compute']=='cuda' else 0)
        compute.currentIndexChanged.connect(lambda _: self._set('compute', compute.currentData()))
        layout.addWidget(compute)
        layout.addWidget(QLabel('麦克风灵敏度（越高越容易触发语音活动）'))
        self.sensitivity = QSlider(Qt.Orientation.Horizontal)
        sensitivity = self.sensitivity
        sensitivity.setRange(1, 100)
        import math
        sensitivity.setValue(max(1,min(100,round(1+(math.log10(.1/self.settings['threshold'])/3)*99))))
        sensitivity.valueChanged.connect(lambda v: self._set('threshold', .1*10**(-3*(v-1)/99)))
        layout.addWidget(sensitivity)
        self.wake_box = QCheckBox(self.detector.label + '；启用后持续使用麦克风')
        self.wake_box.toggled.connect(self.set_wake)
        layout.addWidget(self.wake_box)
        self.tts_box = QCheckBox('本地中文语音播报')
        self.tts_box.setChecked(self.settings['tts'])
        self.tts_box.toggled.connect(self._toggle_tts)
        layout.addWidget(self.tts_box)
        self.tts_status=QLabel('本地语音播报未初始化')
        self.tts_status.setWordWrap(True)
        layout.addWidget(self.tts_status)
        self.voices = QComboBox()
        self.voices.currentIndexChanged.connect(self._voice_changed)
        layout.addWidget(self.voices)
        for title, key, low, high in [('音量', 'volume', 0, 100), ('语速', 'rate', -80, 80)]:
            layout.addWidget(QLabel(title))
            slider = QSlider(Qt.Orientation.Horizontal)
            slider.setRange(low, high)
            slider.setValue(self.settings[key])
            slider.valueChanged.connect(lambda v, k=key: self._set(k, v))
            layout.addWidget(slider)
        memory = QCheckBox('启用长期记忆命令（对话引用仍由原设置中的记忆共享开关控制）')
        memory.setChecked(self.settings['memory_enabled'])
        memory.toggled.connect(lambda v: self._set('memory_enabled', v))
        layout.addWidget(memory)
        return panel

    def _set(self, key, value):
        self.settings[key] = value
        if key=='threshold' and hasattr(self,'diagnostics'):
            self._show_diagnostics()
        try:
            temp = self.path.with_suffix('.tmp')
            temp.write_text(json.dumps(self.settings, ensure_ascii=False, indent=2), encoding='utf-8')
            temp.replace(self.path)
        except OSError:
            self.voice_log.exception("Voice preferences write failed")
            self.status.emit('语音设置保存失败，请检查数据目录权限。')
        if key == 'memory_enabled' and not value:
            self.status.emit('长期记忆已关闭；原有数据保留。')

    def _choose(self):
        path = QFileDialog.getExistingDirectory(self.panel, '选择本地 faster-whisper 模型')
        if path:
            self.model.setText(path)
            self._set('model_path', path)

    def _load_voices(self):
        self.voices.blockSignals(True)
        self.voices.clear()
        # Only offer Chinese installed voices for this Chinese assistant.
        for voice in self.tts.availableVoices():
            if voice.locale().name().startswith('zh'):
                self.voices.addItem(voice.name(), voice)
        index = self.voices.findText(self.settings['voice'])
        if index >= 0:
            self.voices.setCurrentIndex(index)
        self.voices.blockSignals(False)
        if not self.voices.count():
            self.tts_status.setText('未发现中文本地声音，请在 Windows 设置中安装中文语音包。')
        else:
            self.tts.setVoice(self.voices.currentData())
            self.tts_status.setText('本地中文声音：'+self.voices.currentText())

    def _voice_changed(self, _):
        if self.tts and self.voices.currentData() is not None:
            self.tts.setVoice(self.voices.currentData())
            self._set('voice', self.voices.currentText())

    def _toggle_tts(self, enabled):
        if enabled:
            self._ensure_tts()
        self._set('tts', enabled)
        if not enabled:
            self.stop_speech()

    def show(self):
        self._ensure_tts()
        self.panel.showNormal()
        self.panel.raise_()

    def _connected(self):
        incoming = self.server.nextPendingConnection()
        if self.socket is not None:
            incoming.abort()
            incoming.deleteLater()
            return
        self.socket = incoming
        self.authenticated = False
        self.buffer = b''
        incoming.readyRead.connect(self._read)
        incoming.disconnected.connect(self._disconnected)

    def _disconnected(self):
        if self.socket:
            self.socket.deleteLater()
        self.socket = None
        self.authenticated = False

    def _write(self, command):
        self.socket.write((json.dumps(command)+'\n').encode())

    def _command(self, command):
        if self.deep_sleep and command.get('op') not in ('cancel','quit','unload'):return
        if self.closing:
            return
        if self.process.state() == QProcess.ProcessState.NotRunning:
            self.pending_commands.clear()
            if not self.server.isListening():
                self.voice_log.error('Local voice control server unavailable')
                self.terminal_message='无法创建本机语音控制通道，请重启应用后重试。'
                self._force_reset()
                self._set_state('failed')
                return
            self.token = secrets.token_hex(32)
            args = ['--voice-worker'] if getattr(sys, 'frozen', False) else ['-m', 'qiaomi.voice_worker']
            args += [str(self.server.serverPort()), self.token, str(self.path.parent)]
            try:
                program=voice_worker_program()
            except Exception as exc:
                self.voice_log.exception('GUI voice interpreter unavailable')
                self.terminal_message=str(exc)
                self._force_reset()
                self._set_state('failed')
                return
            self.process.start(program, args)
        if self.authenticated and self.socket:
            self._write(command)
        else:
            self.pending_commands.append(command)

    def _read(self):
        if not self.socket:
            return
        self.buffer += bytes(self.socket.readAll())
        if len(self.buffer) > 128000:
            self.voice_log.error('Voice packet exceeds size limit')
            self._protocol_failure()
            return
        while b'\n' in self.buffer:
            line, self.buffer = self.buffer.split(b'\n', 1)
            try:
                data = json.loads(line)
            except (ValueError, TypeError):
                self.voice_log.exception('Invalid worker JSON packet')
                self._protocol_failure()
                return
            if not isinstance(data, dict):
                self.voice_log.error('Invalid worker packet shape')
                self._protocol_failure()
                return
            if not self.authenticated:
                if not secrets.compare_digest(str(data.get('token','')), self.token):
                    self.socket.abort()
                    return
                self.authenticated = True
                for command in self.pending_commands:
                    self._write(command)
                self.pending_commands.clear()
            else:
                self._event(data)

    def _event(self, data):
        event, value = data.get('event'), data.get('value', '')
        if self.closing:
            return
        rid = data.get('request_id')
        if rid is not None and rid != self.active_request:
            return  # Late packets cannot update a new recording or enter chat.
        if self.stopping and event not in ('done', 'error', 'state','log') and self.capture_state=='cancelled':
            return
        if event == 'log':
            self.voice_log.log(max(logging.DEBUG,min(logging.CRITICAL,int(data.get('level',logging.INFO)))), '%s', value)
            if getattr(self.voice_log,'write_failed',False) and not self._log_failure_shown:
                self._log_failure_shown=True
                self.status.emit('语音日志写入失败；录音仍可使用，请检查日志目录权限或磁盘空间。')
        elif event == 'devices':
            selected = self.settings['device']
            self.device_entries = {d['id']:d for d in value}
            self.mic.blockSignals(True)
            self.mic.clear()
            self.mic.addItem('系统默认麦克风', None)
            for device in value:
                self.mic.addItem(device['name']+' ['+device.get('hostapi','未知接口')+']', device['id'])
            name, api = self.settings['device_name'], self.settings['device_hostapi']
            matches = [d for d in value if d['name']==name and (not api or d.get('hostapi')==api)] if name else []
            if name:
                selected = matches[0]['id'] if len(matches)==1 else None
            index = self.mic.findData(selected)
            if selected is not None and index<0 or name and len(matches)!=1:
                self.mic.addItem('原麦克风不可用：请重新选择（禁止自动换设备）', -1)
                index=self.mic.count()-1
                self.mic.setCurrentIndex(index)
                self.mic.blockSignals(False)
                self.status.emit('原输入设备失效，请明确重新选择麦克风。')
            else:
                self.mic.setCurrentIndex(max(0,index))
                self.mic.blockSignals(False)
                self._device_changed()
                self.status.emit(f'检测到 {len(value)} 个输入设备；请选择可用麦克风。')
        elif event in ('warning', 'error', 'notice'):
            self.status.emit(value)
            if event in ('error','notice'):
                self.terminal_message=value
            if event=='error':
                self.voice_log.error('Worker reported failure request=%s; details in worker traceback',rid)
                self._set_state('failed')
                self.animation.emit('error')
                self.wake=False
                self.wake_box.blockSignals(True)
                self.wake_box.setChecked(False)
                self.wake_box.blockSignals(False)
                if data.get('fatal'):
                    self._force_reset(kill=True)
                    self._set_state('failed')
        elif event=='state' and self.listening:
            if self.stopping and self.capture_state=='stopping' and value in ('initializing','listening','recording'):
                return
            if self.capture_state=='cancelled':
                return
            self._set_state(value)
            if value in ('loading','transcribing'):
                self.stopping=False
                self._update_controls()
                self.watchdog.start(180000)
        elif event in ('level','summary','prepared') and self.listening:
            self.diagnostic_values.update(value)
            self._show_diagnostics()
            if event=='level':
                import math
                rms=max(float(value.get('rms',0)), 1e-8)
                self.level_bar.setValue(max(0,min(100,round((20*math.log10(rms)+70)/70*100))))
                self.duration_label.setText(f"录音时长：{value['duration']:.1f} 秒 · 已采集 {value['frames']} 帧")
        elif event=='test_result' and self.listening:
            self.diagnostic_values.update(value)
            self.test_result.setText(
                f"麦克风：{value['device_name']} (ID {value['device_id']})\n初始化：成功 · 实际采样率：{value['samplerate']:g} Hz · 声道：{value['channels']}\n"
                f"采集到音频数据：{'是' if value['has_audio'] else '否'} · 检测到有效声音：{'是' if value['has_sound'] else '否'}\n"
                f"RMS：{value['rms']:.7f} · 峰值：{value['peak']:.7f}\n"
                + ('音频采集：正常（不代表 ASR 已验证）' if value['has_sound'] else '已采集，但输入过低或静音；请检查设备、增益及静音。'))
            self._show_diagnostics()
        elif event=='text' and self.listening and not self.muted and self.capture_state!='cancelled':
            self.transcript.setText('识别结果：'+value)
            if self.mode=='wake':
                if self.detector.matches(value):
                    self.awaiting_command=True
                    self.animation.emit('awake')
                    self.wake_detected.emit()
            elif value:
                self.listening=False  # Audio device is already closed.
                self.text.emit(value)
        elif event=='done':
            self.watchdog.stop()
            self.cancel_deadline.stop()
            self.listening=False
            self.stopping=False
            self.active_request=None
            self.level_bar.setValue(0)
            outcome=data.get('outcome','completed')
            if self.capture_state=='cancelled' or outcome=='cancelled':
                self._set_state('cancelled')
            elif outcome=='error':
                self._set_state('failed')
            elif outcome=='timeout':
                self._set_state('timeout')
            elif outcome=='test_complete':
                self._set_state('tested')
            else:
                self._set_state('completed')
            if self.awaiting_command:
                self.awaiting_command=False
                self.speak('妈妈，我在！', follow=True)
            else:
                self._schedule()

    def listen(self, _checked=False, mode='manual'):
        if self.deep_sleep:
            self.status.emit('深度休眠：请先选择“唤醒敲咪”，不会开启麦克风。');return
        if self.closing or self.muted or self.busy or self.listening or self.speaking or self.stopping or self.active_request is not None:
            return
        if self.mic.currentData()==-1:
            self.status.emit('请先选择有效麦克风。')
            return
        self.activity_started.emit()
        self.retry.stop()
        self.mode=mode
        self.listening=True
        self.terminal_message=''
        self.diagnostic_values={}
        self.duration_label.setText('录音时长：0.0 秒 · 已采集 0 帧')
        self.level_bar.setValue(0)
        self.request_sequence+=1
        self.active_request=self.request_sequence
        settings=dict(self.settings)
        record_mode='test' if mode=='test' else ('auto' if mode in ('wake','command') else settings['record_mode'])
        self.active_record_mode=record_mode
        settings['record_mode']=record_mode
        settings['max_seconds']=3 if mode=='test' else (7 if mode=='wake' else (120 if record_mode=='manual' else 20))
        settings['wait_seconds']=5 if mode=='wake' else 8
        self.operation_started=time.monotonic()
        self._set_state('initializing')
        self.watchdog.start((settings['max_seconds']+15)*1000)
        self._command({'op':'listen','request_id':self.active_request,'settings':settings})

    def finish_recording(self):
        if not self.listening or self.stopping or self.active_record_mode!='manual' or self.capture_state not in ('initializing','listening','recording'):
            return
        self.stopping=True
        self._set_state('stopping')
        self.watchdog.start(15000)
        self._command({'op':'finish','request_id':self.active_request})

    def test_microphone(self):
        self.listen(mode='test')

    def _device_changed(self, *_):
        index=self.mic.currentData()
        if index==-1:
            return
        entry=self.device_entries.get(index,{})
        self.settings['device']=index
        self.settings['device_name']=entry.get('name','')
        self._set('device_hostapi',entry.get('hostapi',''))
        self._show_diagnostics()

    def open_voice_log(self):
        if not self.log_path.exists():
            self.status.emit('语音日志尚不存在或无法写入：'+str(self.log_path))
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.log_path))):
            self.status.emit('无法打开日志，请手动查看：'+str(self.log_path))

    def _show_diagnostics(self):
        d=self.diagnostic_values
        name=d.get('device_name',self.settings.get('device_name') or '系统默认（打开后显示实际设备）')
        self.diagnostics.setPlainText(
            f"麦克风：{name}\n输入设备 ID：{d.get('device_id',self.settings['device'])} · 接口：{d.get('hostapi',self.settings['device_hostapi'])}\n"
            f"实际采样率：{d.get('samplerate','—')} Hz · 输入声道：{d.get('channels','—')}\n"
            f"当前 RMS：{d.get('rms',0):.7f} · 峰值：{d.get('peak',0):.7f} （线性满量程 0–1）\n"
            f"检测阈值：{d.get('threshold',self.settings['threshold']):.7f} （同一单位；手动录音不以此门控）\n"
            f"录音状态：{self.STATE_LABELS.get(self.capture_state,self.capture_state)}\n"
            f"累计时长：{d.get('duration',0):.3f} 秒 · 音频帧数：{d.get('frames',0)}\n"
            f"能量检测触发：{d.get('speech',False)} · 结束原因：{d.get('reason','—')}\n"
            f"ASR 输入：{d.get('asr_samplerate','—')} Hz · 选择声道（从 0 开始）：{d.get('selected_channel','—')}")

    STATE_LABELS=dict(idle='空闲', initializing='正在初始化麦克风', listening='麦克风监听中（等待语音）',
        recording='正在录音', stopping='正在停止录音', loading='正在加载语音模型',
        transcribing='正在识别语音', completed='识别完成 · 麦克风已释放', timeout='录音超时 · 麦克风已释放',
        tested='麦克风自检完成 · 未调用语音模型 · 麦克风已释放',
        failed='识别失败 · 麦克风已释放', cancelled='已取消 · 麦克风已释放')

    def _set_state(self, state):
        if state not in self.STATE_LABELS:
            self.voice_log.error('Unknown voice state')
            self._protocol_failure()
            return
        self.capture_state=state
        self.voice_log.info('Voice UI state=%s request=%s',state,self.active_request)
        message=self.STATE_LABELS[state]
        if state in ('failed','completed','timeout') and self.terminal_message:
            message+=' · '+self.terminal_message
        self.status.emit(message)
        if state in ('initializing','listening','recording'):
            self.animation.emit('listening')
        elif state in ('loading','transcribing'):
            self.animation.emit('thinking')
        self._update_controls()
        self._show_diagnostics()

    def _update_controls(self):
        active=self.active_request is not None or self.listening or self.stopping
        available=not (active or self.busy or self.muted or self.speaking or self.closing or self.deep_sleep)
        self.start_button.setEnabled(available)
        self.test_button.setEnabled(available)
        self.refresh_button.setEnabled(not active and not self.closing and not self.deep_sleep)
        self.mic.setEnabled(not active)
        self.mode_input.setEnabled(not active)
        self.sensitivity.setEnabled(not active)
        self.finish_button.setEnabled(self.listening and not self.stopping and self.active_record_mode=='manual' and self.capture_state in ('initializing','listening','recording'))

    def _watchdog_expired(self):
        if self.active_request is None:
            return
        self.wake=False
        self.wake_box.blockSignals(True)
        self.wake_box.setChecked(False)
        self.wake_box.blockSignals(False)
        self.voice_log.error('Voice watchdog expired state=%s request=%s',self.capture_state,self.active_request)
        self.terminal_message='语音操作超时，已请求终止工作进程；请查看 voice.log。'
        self.capture_state='failed'
        self._force_reset(kill=True)
        self._set_state('failed')

    def _protocol_failure(self):
        self.wake=False
        self.wake_box.blockSignals(True)
        self.wake_box.setChecked(False)
        self.wake_box.blockSignals(False)
        self.terminal_message='语音通信异常，已终止本次操作，请重试并查看 voice.log。'
        self._force_reset(kill=True)
        self._set_state('failed')

    def _kill_cancelled_worker(self):
        if self.active_request is not None or self.stopping:
            self.voice_log.warning('Cancellation deadline reached; terminating worker')
            self._force_reset(kill=True)
            self._set_state('cancelled')

    def _force_reset(self, kill=False):
        self.watchdog.stop()
        self.cancel_deadline.stop()
        self.listening=False
        self.stopping=False
        self.active_request=None
        self.awaiting_command=False
        self.level_bar.setValue(0)
        if kill and self.process.state()!=QProcess.ProcessState.NotRunning:
            self.expected_exit=True
            self.process.kill()
            self.stopping=True  # Prevent a new worker until finished is received.
        self._update_controls()

    def _wake_listen(self):
        if self.wake and not self.background_suspended:
            self.listen(mode='wake')

    def _follow_listen(self):
        if self.background_suspended:return
        self.listen(mode='command')

    def _schedule(self):
        if self.deep_sleep:return
        if not (self.closing or self.busy or self.listening or self.speaking or self.stopping or self.active_request is not None):
            self.animation.emit('idle')
            if self.wake and not self.muted and not self.background_suspended:
                self.retry.start(700)  # Release mic during TTS and echo cooldown.
        self.activity_finished.emit()

    def set_deep_sleep(self, sleeping):
        self.deep_sleep=bool(sleeping)
        self.background_suspended=bool(sleeping)
        self.wake=False
        self.wake_box.blockSignals(True);self.wake_box.setChecked(False);self.wake_box.blockSignals(False)
        self.wake_box.setEnabled(not sleeping)
        self.retry.stop();self.follow.stop()
        if sleeping:
            self.stop_speech()
            self.capture_state='cancelled'
            self._force_reset(kill=True)
            self.pending_commands.clear()
            self.status.emit('深度休眠：麦克风、播报、自动唤醒及语音工作进程均已停止。')
        self._update_controls()

    def set_background_suspended(self, suspended):
        self.background_suspended=bool(suspended)
        self.wake_box.setEnabled(not suspended)
        if suspended:
            self.wake_box.setChecked(False)
            self.retry.stop();self.follow.stop()
            self.cancel_capture();self.stop_speech()
            if self.process.state()!=QProcess.ProcessState.NotRunning:
                self._command({'op':'unload'})
            self.status.emit('游戏模式：自动语音已暂停；手动语音仍可使用。')
        # Do not restore continuous listening automatically on game-mode exit.

    def set_wake(self, enabled):
        if enabled and self.background_suspended:
            self.wake_box.blockSignals(True);self.wake_box.setChecked(False);self.wake_box.blockSignals(False)
            return
        self.wake = enabled
        if enabled:
            self._schedule()
        else:
            self.retry.stop()
            if self.mode=='wake':
                self.cancel_capture()

    def set_muted(self, muted):
        self.muted = muted
        self._update_controls()
        if muted:
            self.retry.stop()
            self.follow.stop()
            self.cancel_capture()
            self.status.emit('麦克风已静音')
        else:
            self._schedule()

    def cancel_capture(self):
        self.awaiting_command=False
        self.retry.stop()
        if self.active_request is not None:
            self.stopping=True
            self.listening=False
            self._command({'op':'cancel','request_id':self.active_request})
            self.watchdog.stop()
            self.cancel_deadline.start(2000)
        self._set_state('cancelled')

    def set_busy(self, busy):
        self.busy = busy
        self._update_controls()
        if busy:
            self.retry.stop()
            self.follow.stop()
            if self.listening:
                self.cancel_capture()
        else:
            self._schedule()

    def speak(self, text, follow=False):
        if self.deep_sleep:return
        if self.settings['tts']:
            self._ensure_tts()
        self.retry.stop()
        if self.listening:
            self.cancel_capture()
        self.stop_speech()
        self._after_speech = follow
        if not self.settings['tts'] or not self.tts or not self.voices.count():
            if follow:
                self.follow.start(700)
            else:
                self._schedule()
            return
        self.tts.setVolume(self.settings['volume']/100)
        self.tts.setRate(self.settings['rate']/100)
        self.speaking = True
        self._update_controls()
        self.animation.emit('speaking')
        self.status.emit('本地语音播报中（麦克风暂停）')
        self.tts.say(text[:8000])

    def _tts_state(self, state):
        from PySide6.QtTextToSpeech import QTextToSpeech
        if state == QTextToSpeech.State.Ready and not self.voices.count():
            self._load_voices()
        if state in (QTextToSpeech.State.Ready, QTextToSpeech.State.Error) and self.speaking:
            self.speaking = False
            self._update_controls()
            if getattr(self, '_after_speech', False):
                self._after_speech = False
                self.follow.start(700)
            else:
                self._schedule()

    def stop_speech(self):
        self.speaking = False
        self._after_speech = False
        self.follow.stop()
        if self.tts:
            self.tts.stop()
        self._update_controls()

    def interrupt(self):
        self.retry.stop()
        self.cancel_capture()
        self.stop_speech()
        self.animation.emit('idle')
        self._schedule()

    def _process_error(self, error):
        if self.closing or self.expected_exit or (self.stopping and self.capture_state=='cancelled'):
            return
        self.voice_log.error('Voice process error enum=%s',error)
        self.pending_commands.clear()
        self.wake=False
        self.wake_box.blockSignals(True)
        self.wake_box.setChecked(False)
        self.wake_box.blockSignals(False)
        self.terminal_message='语音工作进程启动失败或异常终止，请查看 voice.log；可以重新开始。'
        self._force_reset()
        self._set_state('failed')

    def _process_finished(self, exit_code=0, exit_status=None):
        unexpected=(self.active_request is not None or self.listening) and not self.expected_exit and self.capture_state!='cancelled' and not self.closing
        was_cancelled=self.capture_state=='cancelled'
        self.pending_commands.clear()
        if self.socket:
            self.socket.abort()
        self._force_reset()
        self.expected_exit=False
        if unexpected:
            self.voice_log.error('Voice worker exited unexpectedly code=%s status=%s',exit_code,exit_status)
            self.wake=False
            self.wake_box.blockSignals(True)
            self.wake_box.setChecked(False)
            self.wake_box.blockSignals(False)
            self.terminal_message=f'语音进程意外退出（{exit_code}），请查看 voice.log 后重试。'
            self._set_state('failed')
        elif was_cancelled:
            self._set_state('cancelled')
        if not self.closing:
            self._schedule()

    def close(self):
        self.closing = True
        self.watchdog.stop()
        self.cancel_deadline.stop()
        self.retry.stop()
        self.follow.stop()
        self.stop_speech()
        self.panel.close()
        self.server.close()
        if self.process.state() != QProcess.ProcessState.NotRunning:
            if self.socket and self.authenticated:
                self._write({'op':'quit'})
            self.process.terminate()
            if not self.process.waitForFinished(1000):
                self.process.kill()
                self.process.waitForFinished(1000)
