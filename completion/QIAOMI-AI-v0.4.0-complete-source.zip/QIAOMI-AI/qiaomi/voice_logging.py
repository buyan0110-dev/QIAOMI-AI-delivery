"""Bounded local diagnostic logging. Never log commands, tokens or transcripts."""
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

class SafeRotatingHandler(RotatingFileHandler):
    def handleError(self, record):
        # Storage failure must not interrupt capture or the GUI.
        if hasattr(self,'owner_logger'):
            self.owner_logger.write_failed=True


def configure_voice_logging(folder):
    logger = logging.getLogger('qiaomi.voice')
    logger.setLevel(logging.INFO)
    logger.propagate = False
    logger.write_failed=False
    target = Path(folder) / 'logs' / 'voice.log'
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
        handler.close()
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        handler = SafeRotatingHandler(target, maxBytes=1_000_000, backupCount=3, encoding='utf-8')
        handler.owner_logger=logger
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(process)d %(message)s'))
        logger.addHandler(handler)
        return logger, None
    except Exception as exc:
        logger.write_failed=True
        logger.addHandler(logging.NullHandler())
        return logger, type(exc).__name__

class RelayHandler(logging.Handler):
    """Worker sends diagnostics to the sole GUI log writer to avoid rollover races."""
    def __init__(self, notify):
        super().__init__()
        self.notify=notify
        self.setFormatter(logging.Formatter('%(levelname)s worker=%(process)d %(message)s'))
    def emit(self, record):
        try:
            self.notify(event='log', value=self.format(record), level=record.levelno)
        except Exception:
            pass  # A broken parent connection must not keep an audio stream open.


def configure_relay(notify):
    logger=logging.getLogger('qiaomi.voice')
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
        handler.close()
    logger.setLevel(logging.INFO)
    logger.propagate=False
    logger.addHandler(RelayHandler(notify))
    return logger
