"""Windows GUI process paths, transparent HKCU Run startup, Explorer recovery."""
import ctypes
import logging
from pathlib import Path
import subprocess
import sys
from PySide6.QtCore import QAbstractNativeEventFilter, QTimer

log=logging.getLogger('qiaomi')
RUN_KEY=r'Software\Microsoft\Windows\CurrentVersion\Run'
RUN_NAME='QIAOMI AI'


def application_root():
    return Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parents[1]


def gui_python(executable=None, platform=None):
    executable=Path(executable or sys.executable)
    if (platform or sys.platform)!='win32':return str(executable)
    candidate=executable.with_name('pythonw.exe')
    if not candidate.is_file():
        raise RuntimeError('缺少 GUI 解释器 pythonw.exe，请先用 start.bat 修复虚拟环境，或使用 Windows GUI EXE。')
    return str(candidate)


def voice_worker_program():
    return sys.executable if getattr(sys,'frozen',False) else gui_python()


def grant_activation(process_id, *, platform=None, user32=None):
    if (platform or sys.platform)!='win32' or type(process_id) is not int or process_id<=0:
        return False
    try:
        api=user32 or ctypes.windll.user32
        return bool(api.AllowSetForegroundWindow(process_id))
    except Exception:
        log.exception('Foreground activation permission could not be granted')
        return False


class AutoStartManager:
    def __init__(self, folder, *, registry=None, platform=None, executable=None, frozen=None, root=None):
        self.folder=Path(folder).resolve()
        self.platform=platform or sys.platform
        self.registry=registry
        self.executable=Path(executable or sys.executable).resolve()
        self.frozen=getattr(sys,'frozen',False) if frozen is None else frozen
        self.root=Path(root) if root else application_root()

    @property
    def supported(self):return self.platform=='win32'

    def _registry(self):
        if not self.supported:raise RuntimeError('开机自启动仅适用于 Windows。')
        if self.registry is None:
            import winreg
            self.registry=winreg
        return self.registry

    def command(self):
        if self.frozen and not self.executable.is_file():raise RuntimeError('GUI EXE 不存在，无法注册自启动。')
        if not self.frozen and not (self.root/'scripts'/'gui_entry.pyw').is_file():raise RuntimeError('GUI 启动脚本缺失，无法注册自启动。')
        args=[str(self.executable)] if self.frozen else [gui_python(self.executable,self.platform),str(self.root/'scripts'/'gui_entry.pyw')]
        args+=['--autostart','--data-dir',str(self.folder)]
        return subprocess.list2cmdline(args)

    def current_command(self):
        registry=self._registry()
        try:
            with registry.OpenKey(registry.HKEY_CURRENT_USER,RUN_KEY,0,registry.KEY_READ) as key:
                value,kind=registry.QueryValueEx(key,RUN_NAME)
                if kind not in (registry.REG_SZ,registry.REG_EXPAND_SZ) or not isinstance(value,str):
                    raise RuntimeError('自启动条目格式异常，请在 Windows 启动应用中检查。')
                return value
        except FileNotFoundError:
            return None

    def enabled(self):return self.current_command() is not None

    def set_enabled(self, enabled):
        registry=self._registry()
        if enabled:
            command=self.command()  # Validate GUI interpreter before writing anything.
            with registry.CreateKeyEx(registry.HKEY_CURRENT_USER,RUN_KEY,0,registry.KEY_SET_VALUE) as key:
                registry.SetValueEx(key,RUN_NAME,0,registry.REG_SZ,command)
        else:
            try:
                with registry.OpenKey(registry.HKEY_CURRENT_USER,RUN_KEY,0,registry.KEY_SET_VALUE) as key:
                    registry.DeleteValue(key,RUN_NAME)
            except FileNotFoundError:
                pass


class ExplorerRestartFilter(QAbstractNativeEventFilter):
    """Only handles TaskbarCreated; no keyboard hooks, capture or process scanning."""
    def __init__(self, restore, *, platform=None, user32=None):
        super().__init__()
        self.restore=restore
        self.message_id=None
        self.pending=False
        if (platform or sys.platform)=='win32':
            user32=user32 or ctypes.windll.user32
            self.message_id=user32.RegisterWindowMessageW('TaskbarCreated')
            if not self.message_id:log.warning('Explorer restart message registration failed')

    def nativeEventFilter(self,event_type,message):
        if self.message_id:
            try:
                from ctypes.wintypes import MSG
                msg=MSG.from_address(int(message))
                if msg.message==self.message_id and not self.pending:
                    self.pending=True
                    QTimer.singleShot(250,self._restore)
            except Exception:
                log.exception('Explorer restart handling failed')
        return False,0

    def _restore(self):
        self.pending=False
        self.restore()
