"""One-click virtual environment setup; uses only Python's standard library."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import struct
import sys
import venv


ROOT = Path(__file__).resolve().parent.parent
VENV = ROOT / ".venv"
PYTHON = VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")
REQUIREMENTS = ROOT / "requirements.txt"
MARKER = VENV / ".qiaomi-requirements.json"
RUNTIME_HELP = (
    "This release requires 64-bit Python 3.11, 3.12, or 3.13. "
    "Install 64-bit Python 3.12 from python.org (recommended). "
    "Python 3.14+ is not supported by the pinned PySide6 version."
)


def run(command: list[str]) -> None:
    subprocess.run(command, cwd=ROOT, check=True)


def validate_interpreter(version=None, pointer_bits=None) -> None:
    """Reject unsupported runtimes before creating a venv or downloading wheels."""
    version = sys.version_info[:2] if version is None else version[:2]
    pointer_bits = struct.calcsize("P") * 8 if pointer_bits is None else pointer_bits
    if not (3, 11) <= version < (3, 14) or pointer_bits != 64:
        raise RuntimeError(RUNTIME_HELP)


def prepare_environment() -> None:
    validate_interpreter()
    if not PYTHON.is_file():
        print("[QIAOMI AI] Creating a local virtual environment...", flush=True)
        venv.EnvBuilder(with_pip=True).create(VENV)

    # Also check an existing venv: the launcher's interpreter may have changed.
    run([
        str(PYTHON), "-c",
        "import struct,sys; "
        "ok = (3,11) <= sys.version_info[:2] < (3,14) and struct.calcsize('P') == 8; "
        f"sys.exit(0 if ok else {RUNTIME_HELP!r})",
    ])
    requirements_hash = hashlib.sha256(REQUIREMENTS.read_bytes()).hexdigest()
    try:
        installed_hash = json.loads(MARKER.read_text(encoding="utf-8")).get("sha256")
    except (OSError, ValueError, AttributeError):
        installed_hash = None
    packages_ok = subprocess.run(
        [str(PYTHON), "-c", "from PySide6 import QtWidgets; import openai"],
        cwd=ROOT,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0
    if installed_hash != requirements_hash or not packages_ok:
        print("[QIAOMI AI] Installing dependencies. First launch needs internet access...", flush=True)
        run([str(PYTHON), "-m", "pip", "install", "-r", str(REQUIREMENTS)])
        run([str(PYTHON), "-m", "pip", "check"])
        MARKER.write_text(json.dumps({"sha256": requirements_hash}), encoding="utf-8")
    print("[QIAOMI AI] Ready.", flush=True)


def main() -> int:
    try:
        prepare_environment()
        arguments = sys.argv[1:]
        if arguments == ["--prepare-only"]:
            return 0
        return subprocess.run([str(PYTHON), "-m", "qiaomi", *arguments], cwd=ROOT).returncode
    except KeyboardInterrupt:
        print("\n[QIAOMI AI] Stopped.", file=sys.stderr)
        return 130
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print(f"[QIAOMI AI] Setup failed: {exc}", file=sys.stderr)
        print(
            "Check your internet connection and Python installation. "
            "If this folder was moved, delete its .venv folder and start again. "
            "Your chat and memories are stored separately; see README.md.",
            file=sys.stderr,
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
