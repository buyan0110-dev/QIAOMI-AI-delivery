"""Validate and zip a Windows PyInstaller onedir build using only the stdlib.

This creates a distributable archive, not an executable. Build the executable
with PyInstaller on Windows first; runtime validation belongs to Windows smoke
tests. No files outside the selected build directory are included.
"""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path, PurePosixPath
import stat
import tempfile
import zipfile


PACKAGE_NAME = "QIAOMI-AI"
ENTRY_NAME = "QIAOMI-AI.exe"


class ReleaseError(ValueError):
    """The proposed archive is incomplete or has unsafe paths."""


def _reject_link(path: Path) -> None:
    info = path.lstat()
    # Reparse points include Windows junctions, which is_symlink can miss.
    if stat.S_ISLNK(info.st_mode) or (
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    ):
        raise ReleaseError(f"Links and reparse points are not allowed: {path.name}")


def _archive_name(relative: Path) -> str:
    if relative.is_absolute() or any(
        part in {"", ".", ".."} or "\\" in part or ":" in part
        for part in relative.parts
    ):
        raise ReleaseError("Package contains an unsafe archive path.")
    name = (PurePosixPath(PACKAGE_NAME) / PurePosixPath(*relative.parts)).as_posix()
    if not name.startswith(f"{PACKAGE_NAME}/"):
        raise ReleaseError("Package entry escaped its archive root.")
    return name


def _walk_error(error: OSError) -> None:
    raise error


def collect_package_files(source: Path) -> list[tuple[Path, str]]:
    """Return every regular file in a complete onedir build, rejecting links."""
    source = Path(source)
    if not source.is_dir():
        raise ReleaseError("Build directory is missing. Run PyInstaller on Windows first.")
    _reject_link(source)
    source = source.resolve()
    entry = source / ENTRY_NAME
    if not entry.is_file():
        raise ReleaseError(f"Missing packaged entry point: {ENTRY_NAME}")
    _reject_link(entry)
    with entry.open("rb") as stream:
        if stream.read(2) != b"MZ":
            raise ReleaseError("The packaged entry does not have a Windows executable header.")
    internal = source / "_internal"
    if not internal.is_dir():
        raise ReleaseError("Missing _internal runtime directory; include the entire onedir build.")

    files = []
    for directory, names, filenames in os.walk(source, followlinks=False, onerror=_walk_error):
        directory = Path(directory)
        names.sort()
        for name in names:
            _reject_link(directory / name)
        for name in sorted(filenames):
            path = directory / name
            _reject_link(path)
            if not stat.S_ISREG(path.stat().st_mode):
                raise ReleaseError("Only regular files may be packaged.")
            try:
                relative = path.resolve().relative_to(source)
            except ValueError as exc:
                raise ReleaseError("Package file escaped its build directory.") from exc
            files.append((path, _archive_name(relative)))
    if not any(name.startswith(f"{PACKAGE_NAME}/_internal/") for _, name in files):
        raise ReleaseError("The _internal runtime directory is empty.")
    return sorted(files, key=lambda item: item[1])


def build_release(source: Path, output: Path) -> tuple[Path, Path]:
    """Atomically write a validated ZIP and a standard SHA-256 checksum file."""
    source, output = Path(source), Path(output)
    if output.suffix.lower() != ".zip" or any(c in output.name for c in "\r\n"):
        raise ReleaseError("Output must be a .zip filename without line breaks.")
    if output.resolve().is_relative_to(source.resolve()):
        raise ReleaseError("Output must be outside the build directory.")
    files = collect_package_files(source)
    output.parent.mkdir(parents=True, exist_ok=True)
    checksum = output.with_suffix(output.suffix + ".sha256")
    zip_temp = checksum_temp = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".qiaomi-release-", suffix=".tmp", delete=False) as stream:
            zip_temp = Path(stream.name)
        with zipfile.ZipFile(zip_temp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
            for path, name in files:
                archive.write(path, name)
        with zipfile.ZipFile(zip_temp) as archive:
            if archive.testzip() is not None:
                raise ReleaseError("Archive failed its CRC integrity check.")
            if archive.namelist() != [name for _, name in files]:
                raise ReleaseError("Archive file list did not match the build directory.")
        digest = hashlib.sha256()
        with zip_temp.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", dir=output.parent,
            prefix=".qiaomi-sha256-", suffix=".tmp", delete=False,
        ) as stream:
            checksum_temp = Path(stream.name)
            stream.write(f"{digest.hexdigest()}  {output.name}\n")
        os.replace(zip_temp, output)
        zip_temp = None
        os.replace(checksum_temp, checksum)
        checksum_temp = None
        return output, checksum
    finally:
        for path in (zip_temp, checksum_temp):
            if path is not None:
                path.unlink(missing_ok=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, default=Path("dist/QIAOMI-AI"))
    parser.add_argument("--output", type=Path, default=Path("dist/QIAOMI-AI-Windows-x64.zip"))
    options = parser.parse_args()
    try:
        archive, checksum = build_release(options.source, options.output)
    except (OSError, ReleaseError, zipfile.BadZipFile) as exc:
        parser.exit(1, f"Release packaging failed: {exc}\n")
    print(f"Archive: {archive}\nChecksum: {checksum}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
