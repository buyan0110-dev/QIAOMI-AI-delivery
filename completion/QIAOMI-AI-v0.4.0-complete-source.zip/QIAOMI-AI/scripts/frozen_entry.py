from qiaomi.launcher import launch
if __name__=='__main__':
    raise SystemExit(launch())
