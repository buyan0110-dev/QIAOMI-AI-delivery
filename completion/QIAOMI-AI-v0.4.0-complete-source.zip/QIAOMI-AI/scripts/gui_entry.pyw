"""Run with pythonw.exe; survives its WScript/shortcut launcher exiting."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from qiaomi.launcher import launch
if __name__=='__main__':
    raise SystemExit(launch())
