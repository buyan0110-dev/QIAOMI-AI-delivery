"""Build a multi-size ICO from the existing Qt cat renderer; no external assets."""
from pathlib import Path
import struct
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PySide6.QtCore import QBuffer,QIODevice,Qt
from PySide6.QtWidgets import QApplication
from qiaomi.ui.pet import make_cat_icon

def main():
    app=QApplication.instance() or QApplication([])
    icon=make_cat_icon()
    sizes=[16,32,48,256]
    payloads=[]
    for size in sizes:
        pixmap=icon.pixmap(96,96).scaled(size,size,Qt.AspectRatioMode.KeepAspectRatio,Qt.TransformationMode.SmoothTransformation)
        buffer=QBuffer();buffer.open(QIODevice.OpenModeFlag.WriteOnly)
        if not pixmap.save(buffer,'PNG'):raise RuntimeError('Icon encoding failed')
        payloads.append(bytes(buffer.data()))
    offset=6+16*len(sizes)
    directory=bytearray(struct.pack('<HHH',0,1,len(sizes)))
    for size,data in zip(sizes,payloads):
        directory.extend(struct.pack('<BBBBHHII',size if size<256 else 0,size if size<256 else 0,0,0,1,32,len(data),offset))
        offset+=len(data)
    path=Path(__file__).resolve().parents[1]/'assets'/'qiaomi.ico'
    path.write_bytes(bytes(directory)+b''.join(payloads))
    print('Cat icon written:',path)
if __name__=='__main__':main()
