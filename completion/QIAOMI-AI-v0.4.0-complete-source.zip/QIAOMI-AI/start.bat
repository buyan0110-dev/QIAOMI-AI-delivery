@echo off
setlocal
rem Do not let either Python launcher install a missing runtime automatically.
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=false"
set "PYLAUNCHER_ALLOW_INSTALL="
set "PYLAUNCHER_ALWAYS_INSTALL="
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
    for %%V in (3.12 3.11 3.13) do (
        py -%%V -c "import struct,sys; sys.exit(0 if struct.calcsize('P') == 8 else 1)" >nul 2>nul
        if not errorlevel 1 (
            py -%%V "%~dp0scripts\bootstrap.py" %*
            goto finished
        )
    )
)
where python >nul 2>nul
if not errorlevel 1 (
    python "%~dp0scripts\bootstrap.py" %*
    goto finished
)
echo Supported Python was not found. Install Python 3.12, 64-bit, from python.org.
echo This release supports Python 3.11, 3.12, and 3.13, 64-bit only.
echo Select "Add python.exe to PATH", then double-click start.bat again.
pause
exit /b 1
:finished
if errorlevel 1 (
    echo.
    echo QIAOMI AI could not start. See the error above and README.md.
    pause
    exit /b 1
)
endlocal
