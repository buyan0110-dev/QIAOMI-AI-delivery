Option Explicit
Dim shell, fso, root, target, command, result, q
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
q = Chr(34)
target = fso.BuildPath(root, "QIAOMI-AI.exe")
If Not fso.FileExists(target) Then
    target = fso.BuildPath(root, "dist\QIAOMI-AI\QIAOMI-AI.exe")
End If
If fso.FileExists(target) Then
    command = q & target & q
Else
    target = fso.BuildPath(root, ".venv\Scripts\pythonw.exe")
    If Not fso.FileExists(target) Then
        MsgBox "First run: use start.bat to install dependencies, then use this GUI launcher.", 48, "QIAOMI AI"
        WScript.Quit 1
    End If
    command = q & target & q & " " & q & fso.BuildPath(root, "scripts\gui_entry.pyw") & q
End If
shell.CurrentDirectory = root
On Error Resume Next
result = shell.Run(command, 1, False)
If Err.Number <> 0 Then
    MsgBox "QIAOMI AI could not launch. Use start.bat to inspect dependencies. Error: " & Err.Number, 16, "QIAOMI AI"
    WScript.Quit 1
End If
