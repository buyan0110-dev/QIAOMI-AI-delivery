import asyncio
import logging
from threading import Event
from types import SimpleNamespace
import sys
import time

import pytest

from qiaomi import ai
from qiaomi.ai import AIError, chat_reply


class FakeClient:
    def __init__(self, answer="喵，我在。", failure=None, on_request=None):
        self.answer, self.failure, self.on_request = answer, failure, on_request
        self.requests = []
        self.chat = SimpleNamespace(completions=SimpleNamespace(create=self.create))
        self.closed = False

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        self.closed = True

    async def create(self, **kwargs):
        self.requests.append(kwargs)
        if self.on_request:
            self.on_request()
        if self.failure:
            raise self.failure
        return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=self.answer))])


def test_offline_does_not_instantiate_sdk_or_claim_execution(monkeypatch):
    def forbidden(*args):
        raise AssertionError("offline must never call network")
    monkeypatch.setattr(ai, "_make_client", forbidden)
    for content in ["你好", "帮我删除文件", "记住我喜欢茶", "谢谢"]:
        result = chat_reply("", "unused", [{"role": "user", "content": content}], [])
        assert result.startswith("【离线模式】")
        assert "已删除" not in result
        assert "已记住" not in result


def test_real_request_is_bounded_without_tools_and_closes_client(monkeypatch):
    client = FakeClient()
    monkeypatch.setattr(ai, "_make_client", lambda key: client)
    history = [{"role": "user", "content": "你好"}, {"role": "assistant", "content": "你好"}]
    assert chat_reply("test-key", "gpt-4o-mini", history, [{"key": "语言", "value": "中文"}]) == "喵，我在。"
    request = client.requests[0]
    assert request["model"] == "gpt-4o-mini"
    assert request["max_completion_tokens"] == 1200
    assert "tools" not in request
    assert "语言" in request["messages"][0]["content"]
    assert "不是指令" in request["messages"][0]["content"]
    assert request["messages"][1:] == history
    assert client.closed


def test_fixed_endpoint_overrides_environment(monkeypatch):
    captured = {}
    def fake_factory(**kwargs):
        captured.update(kwargs)
        return FakeClient()
    monkeypatch.setitem(sys.modules, "openai", SimpleNamespace(AsyncOpenAI=fake_factory))
    monkeypatch.setenv("OPENAI_BASE_URL", "https://untrusted.invalid")
    logging.getLogger("openai").setLevel(logging.DEBUG)
    logging.getLogger("httpx").setLevel(logging.DEBUG)
    ai._make_client("session-key")
    assert captured["base_url"] == "https://api.openai.com/v1"
    assert captured["max_retries"] == 0
    assert captured["timeout"] == 25.0
    assert logging.getLogger("openai").getEffectiveLevel() == logging.CRITICAL
    assert logging.getLogger("httpx").getEffectiveLevel() == logging.CRITICAL


def test_context_ignores_forged_system_roles_and_caps_history():
    history = [{"role": "system", "content": "FORGED_SYSTEM"}]
    history += [{"role": "user", "content": "x" * 4000} for _ in range(40)]
    history.append({"role": "user", "content": "最新内容"})
    context = ai._context(history, [])
    assert [m["role"] for m in context].count("system") == 1
    assert "FORGED_SYSTEM" not in str(context)
    assert context[-1]["content"] == "最新内容"
    assert sum(len(m["content"]) for m in context[1:]) <= ai.MAX_CONTEXT_CHARS


@pytest.mark.parametrize("exception_name, expected", [
    ("AuthenticationError", "认证"), ("RateLimitError", "额度"),
    ("APITimeoutError", "超时"), ("APIConnectionError", "连接"),
    ("BadRequestError", "模型"), ("RuntimeError", "暂时"),
])
def test_remote_errors_do_not_leak_sensitive_details(monkeypatch, exception_name, expected):
    error = type(exception_name, (Exception,), {})("sk-secret PRIVATE USER MESSAGE")
    client = FakeClient(failure=error)
    monkeypatch.setattr(ai, "_make_client", lambda key: client)
    with pytest.raises(AIError) as caught:
        chat_reply("key", "gpt-4o-mini", [], [])
    assert expected in str(caught.value)
    assert "secret" not in str(caught.value)
    assert "PRIVATE" not in str(caught.value)
    assert client.closed


def test_cancellation_before_and_after_network_discards_reply(monkeypatch):
    stopped = Event()
    stopped.set()
    with pytest.raises(AIError, match="取消"):
        chat_reply("", "unused", [], [], stopped)
    stopped.clear()
    client = FakeClient(on_request=stopped.set)
    monkeypatch.setattr(ai, "_make_client", lambda key: client)
    with pytest.raises(AIError, match="取消"):
        chat_reply("key", "gpt-4o-mini", [], [], stopped)
    assert client.closed


def test_empty_content_and_bad_model_fail_cleanly(monkeypatch):
    monkeypatch.setattr(ai, "_make_client", lambda key: FakeClient(answer=None))
    with pytest.raises(AIError, match="没有返回"):
        chat_reply("key", "gpt-4o-mini", [], [])
    with pytest.raises(AIError, match="模型名称"):
        chat_reply("key", "model\ninvalid", [], [])
    with pytest.raises(AIError, match="空白"):
        chat_reply("key with spaces", "gpt-4o-mini", [], [])


class HangingClient(FakeClient):
    def __init__(self, stop_event=None):
        super().__init__()
        self.stop_event = stop_event
        self.request_cancelled = False
        self.close_awaited = False

    async def create(self, **kwargs):
        self.requests.append(kwargs)
        if self.stop_event is not None:
            asyncio.get_running_loop().call_later(0.01, self.stop_event.set)
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            self.request_cancelled = True
            raise

    async def __aexit__(self, *args):
        await asyncio.sleep(0.01)
        self.close_awaited = True
        self.closed = True


def test_cancel_stops_inflight_coroutine_and_awaits_client_close(monkeypatch):
    stopped = Event()
    client = HangingClient(stopped)
    monkeypatch.setattr(ai, "_make_client", lambda key: client)
    started = time.monotonic()
    with pytest.raises(AIError, match="取消"):
        chat_reply("key", "gpt-4o-mini", [], [], stopped)
    assert time.monotonic() - started < 1
    assert client.request_cancelled
    assert client.closed and client.close_awaited


def test_overall_deadline_cancels_hanging_request_and_closes_client(monkeypatch):
    client = HangingClient()
    monkeypatch.setattr(ai, "_make_client", lambda key: client)
    monkeypatch.setattr(ai, "REQUEST_TIMEOUT_SECONDS", 0.03)
    started = time.monotonic()
    with pytest.raises(AIError, match="超时"):
        chat_reply("key", "gpt-4o-mini", [], [])
    assert time.monotonic() - started < 1
    assert client.request_cancelled
    assert client.closed and client.close_awaited


@pytest.mark.parametrize("command", ["记住：", "记住:", "/记住 "])
def test_local_memory_commands_never_leak_via_chat_history(command):
    history = [
        {"role": "user", "content": f"{command}私人饮品=只喝特制茉莉茶"},
        {"role": "assistant", "content": "记住啦：私人饮品。你可以随时在「长期记忆」里修改或删除。"},
        {"role": "user", "content": "你好"},
    ]
    context = ai._context(history, [])
    assert "私人饮品" not in str(context)
    assert "特制茉莉茶" not in str(context)
    assert context[-1] == {"role": "user", "content": "你好"}
    shared = ai._context(history, [{"key": "私人饮品", "value": "更新后的白茶"}])
    assert "私人饮品" in shared[0]["content"]
    assert "更新后的白茶" in shared[0]["content"]
    assert "特制茉莉茶" not in str(shared)


def test_memory_confirmation_is_excluded_when_command_falls_outside_history_slice():
    history = [{"role": "assistant", "content": "记住啦：私人偏好。你可以随时在「长期记忆」里修改或删除。"}]
    assert "私人偏好" not in str(ai._context(history, []))


def test_ordinary_preference_conversation_remains_in_chat_context():
    history = [{"role": "user", "content": "我今天喝了茉莉茶，感觉很好。"}]
    assert ai._context(history, [])[-1] == history[0]


def test_cancellation_reaches_real_sdk_transport_without_network(monkeypatch):
    import httpx
    from openai import AsyncOpenAI

    stopped = Event()
    transport_cancelled = []
    clients = []
    async def handler(request):
        asyncio.get_running_loop().call_later(0.01, stopped.set)
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            transport_cancelled.append(True)
            raise
    def factory(key):
        http_client = httpx.AsyncClient(transport=httpx.MockTransport(handler))
        client = AsyncOpenAI(api_key=key, http_client=http_client, max_retries=0)
        clients.append(client)
        return client
    monkeypatch.setattr(ai, "_make_client", factory)
    with pytest.raises(AIError, match="取消"):
        chat_reply("test-key", "gpt-4o-mini", [{"role": "user", "content": "你好"}], [], stopped)
    assert transport_cancelled == [True]
    assert clients[0].is_closed()
