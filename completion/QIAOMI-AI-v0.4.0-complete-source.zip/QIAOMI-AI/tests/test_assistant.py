"""Input and rendering regressions that matter for Chinese desktop use."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
from PySide6.QtCore import Qt
from PySide6.QtGui import QInputMethodEvent
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from qiaomi.ui.assistant import MessageInput


def test_chinese_preedit_enter_does_not_send():
    app = QApplication.instance() or QApplication([])
    field = MessageInput()
    sent = []
    field.submitted.connect(lambda: sent.append(True))
    QApplication.sendEvent(field, QInputMethodEvent('qiao', []))
    QTest.keyClick(field, Qt.Key.Key_Return)
    assert sent == []
    event = QInputMethodEvent()
    event.setCommitString('敲咪')
    QApplication.sendEvent(field, event)
    assert '敲咪' in field.toPlainText()
    QTest.keyClick(field, Qt.Key.Key_Return)
    assert sent == [True]
    field.close()


def test_shift_enter_inserts_newline_without_submit():
    app = QApplication.instance() or QApplication([])
    field = MessageInput()
    sent = []
    field.submitted.connect(lambda: sent.append(True))
    field.setPlainText('你好')
    field.moveCursor(field.textCursor().MoveOperation.End)
    QTest.keyClick(field, Qt.Key.Key_Return, Qt.KeyboardModifier.ShiftModifier)
    assert field.toPlainText() == '你好\n'
    assert not sent
    field.close()
