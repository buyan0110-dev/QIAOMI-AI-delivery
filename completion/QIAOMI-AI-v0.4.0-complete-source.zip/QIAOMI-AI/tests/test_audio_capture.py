"""Synthetic audio and simulated PortAudio; no Windows/hardware claims."""
from threading import Event
from types import SimpleNamespace
import numpy as np
import pytest
from qiaomi.audio_capture import (AudioError, float_audio, levels, voiced, prepare_audio,
                                  enumerate_inputs, resolve_input, choose_format, record)

class FakeSD:
    def __init__(self, waveform=None, rate=48000, channels=2, on_read=None, fail=None):
        self.rate=rate
        self.channels=channels
        self.waveform=waveform or (lambda n,i: np.full((n,channels),.0005,dtype=np.float32))
        self.on_read=on_read
        self.fail=fail
        self.opened=[]
        self.checked=[]
        self.devices=[dict(name='Output',max_input_channels=0,hostapi=0,default_samplerate=rate),
                      dict(name='Test USB',max_input_channels=channels,hostapi=0,default_samplerate=rate)]
        self.default=SimpleNamespace(device=(1,0))
    def query_devices(self): return self.devices
    def query_hostapis(self): return [dict(name='Test WASAPI')]
    def check_input_settings(self,**kwargs): self.checked.append(kwargs)
    def InputStream(self,**kwargs):
        sd=self
        class Stream:
            samplerate=kwargs['samplerate']
            def __init__(self): self.closed=False; self.calls=0
            def __enter__(self): return self
            def __exit__(self,*args): self.closed=True
            def read(self,n):
                self.calls+=1
                if sd.fail: raise sd.fail
                audio=sd.waveform(n,self.calls)
                if sd.on_read: sd.on_read(self.calls)
                return audio,False
        stream=Stream()
        self.opened.append((kwargs,stream))
        return stream


def test_enumerate_only_input_and_real_metadata():
    devices=enumerate_inputs(FakeSD())
    assert len(devices)==1 and devices[0]['id']==1
    assert devices[0]['samplerate']==48000 and devices[0]['channels']==2
    assert devices[0]['hostapi']=='Test WASAPI'


def test_stale_device_id_relocates_by_name_and_hostapi():
    sd=FakeSD()
    d=resolve_input(sd,dict(device=9,device_name='Test USB',device_hostapi='Test WASAPI'))
    assert d['id']==1
    sd.devices.insert(1,dict(name='Other mic',max_input_channels=1,hostapi=0,default_samplerate=44100))
    assert resolve_input(sd,dict(device=1,device_name='Test USB',device_hostapi='Test WASAPI'))['id']==2


@pytest.mark.parametrize('settings',[dict(device=9),dict(device=0),dict(device=-1),dict(device=1,device_name='Gone'),dict(device=True)])
def test_invalid_or_output_device_never_silently_changes(settings):
    with pytest.raises(AudioError): resolve_input(FakeSD(),settings)


def test_ambiguous_identity_requires_user_choice():
    sd=FakeSD()
    sd.devices.append(dict(sd.devices[1]))
    with pytest.raises(AudioError): resolve_input(sd,dict(device=9,device_name='Test USB'))


def test_format_uses_native_rate_then_checked_fallback():
    sd=FakeSD()
    device=enumerate_inputs(sd)[0]
    assert choose_format(sd,device)==(48000,2)
    def check(**kwargs):
        if kwargs['samplerate']!=44100 or kwargs['channels']!=1:
            raise RuntimeError('unsupported format')
    sd.check_input_settings=check
    assert choose_format(sd,device)==(44100,1)


@pytest.mark.parametrize('dtype,values,expected',[(np.int16,[-32768,16384],[ -1,.5]),(np.uint8,[0,128,255],[-1,0,127/128]),(np.float64,[.25,-.5],[.25,-.5])])
def test_dtype_conversion_no_integer_overflow(dtype,values,expected):
    out=float_audio(np.array(values,dtype=dtype))
    assert out.dtype==np.float32 and out.shape==(len(values),1)
    np.testing.assert_allclose(out[:,0],expected)


@pytest.mark.parametrize('audio',[np.array([np.nan]),np.array([np.inf]),np.array([],dtype=float),np.zeros((2,2,2)),np.array(['x'])])
def test_invalid_arrays_are_explicit_errors(audio):
    with pytest.raises(AudioError): float_audio(audio)


def test_rms_peak_and_threshold_same_linear_units():
    rms,peak=levels(np.array([[.1,-.4],[.1,.4]],dtype=np.float32))
    assert rms==pytest.approx(.4) and peak==pytest.approx(.4)
    assert voiced(rms,.39) and not voiced(rms,.41)
    assert voiced(.012,.012)
    with pytest.raises(AudioError): voiced(0,0)


@pytest.mark.parametrize('rate',[44100,48000,16000])
def test_resampling_stereo_opposite_phase_cannot_cancel(rate):
    signal=(.1*np.sin(2*np.pi*440*np.arange(rate)/rate)).astype(np.float32)
    mono,channel=prepare_audio(np.column_stack([signal,-signal]),rate)
    assert mono.dtype==np.float32 and mono.flags.c_contiguous and len(mono)==16000
    assert channel in (0,1) and levels(mono)[0]>.06


def test_right_only_channel_selected():
    mono,channel=prepare_audio(np.column_stack([np.zeros(1600),np.full(1600,.1)]),16000)
    assert channel==1 and levels(mono)[0]==pytest.approx(.1)
    with pytest.raises(AudioError): prepare_audio(np.zeros(1600),16000)


def test_manual_low_energy_stop_keeps_all_captured_audio():
    finished=Event()
    sd=FakeSD(on_read=lambda n:finished.set() if n==3 else None)
    events=[]
    result=record(dict(record_mode='manual',threshold=.1),Event(),finished,lambda **d:events.append(d),sd)
    assert not result.speech and result.frames==14400 and result.reason=='stopped'
    assert result.duration==pytest.approx(.3) and result.rms>0
    assert len([e for e in events if e['event']=='level'])==3
    assert sd.opened[0][1].closed


def test_manual_maximum_duration_and_silence_still_return_recording():
    sd=FakeSD(waveform=lambda n,i:np.zeros((n,2),np.float32))
    result=record(dict(record_mode='manual',max_seconds=.3),Event(),Event(),lambda **d:None,sd)
    assert result.frames==14400 and result.rms==0 and result.reason=='limit'
    assert sd.opened[0][1].closed


def test_cancel_discards_audio_and_closes_device():
    cancel=Event()
    sd=FakeSD(on_read=lambda n:cancel.set())
    result=record({},cancel,Event(),lambda **d:None,sd)
    assert result is None and sd.opened[0][1].closed


def test_automatic_endpoint_and_no_voice_timeout():
    sd=FakeSD(waveform=lambda n,i:np.full((n,2),.1 if i<=3 else 0,dtype=np.float32))
    result=record(dict(record_mode='auto',threshold=.01,max_seconds=2),Event(),Event(),lambda **d:None,sd)
    assert result.speech and result.reason=='silence' and result.frames==12*4800
    silent=FakeSD(waveform=lambda n,i:np.zeros((n,2),np.float32))
    result=record(dict(record_mode='auto',wait_seconds=.3),Event(),Event(),lambda **d:None,silent)
    assert not result.speech and result.reason=='no_speech'


def test_stream_exception_and_nan_release_microphone():
    for sd in [FakeSD(fail=OSError('simulated device unplugged')),FakeSD(waveform=lambda n,i:np.full((n,2),np.nan))]:
        with pytest.raises((OSError,AudioError)): record({},Event(),Event(),lambda **d:None,sd)
        assert sd.opened[0][1].closed


def test_self_test_exact_three_seconds_no_model():
    sd=FakeSD()
    result=record(dict(record_mode='test'),Event(),Event(),lambda **d:None,sd)
    assert result.frames==3*48000 and result.duration==3 and result.reason=='test_complete'
    assert sd.opened[0][1].closed


def test_open_start_failure_explicitly_closes_constructed_stream():
    sd=FakeSD()
    class BrokenStream:
        samplerate=48000
        closed=False
        def __enter__(self):raise OSError('start failed')
        def __exit__(self,*a):pass
        def close(self):self.closed=True
    stream=BrokenStream()
    sd.InputStream=lambda **kwargs:stream
    with pytest.raises(OSError):record({},Event(),Event(),lambda **d:None,sd)
    assert stream.closed


def test_device_close_failure_is_fatal_and_skips_transcription():
    from qiaomi.audio_capture import DeviceReleaseError
    sd=FakeSD()
    original=sd.InputStream
    def stream_factory(**kwargs):
        stream=original(**kwargs)
        def close():raise OSError('close failed')
        stream.close=close
        return stream
    sd.InputStream=stream_factory
    with pytest.raises(DeviceReleaseError):record(dict(max_seconds=.1),Event(),Event(),lambda **d:None,sd)


def test_already_cancelled_does_not_open_microphone():
    cancelled=Event();cancelled.set()
    sd=FakeSD()
    assert record({},cancelled,Event(),lambda **d:None,sd) is None
    assert sd.opened==[]
