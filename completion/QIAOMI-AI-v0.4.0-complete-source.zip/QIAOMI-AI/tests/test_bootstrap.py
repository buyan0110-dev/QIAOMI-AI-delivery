"""Check launcher's install cache without downloading packages."""

import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import pytest


SPEC = importlib.util.spec_from_file_location(
    "qiaomi_bootstrap", Path(__file__).resolve().parents[1] / "scripts" / "bootstrap.py"
)
bootstrap = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(bootstrap)


@pytest.fixture
def launcher(tmp_path, monkeypatch):
    environment = tmp_path / ".venv"
    environment.mkdir()
    interpreter = environment / "python.exe"
    interpreter.touch()
    requirements = tmp_path / "requirements.txt"
    requirements.write_text("openai==1.109.1\n", encoding="utf-8")
    marker = environment / ".qiaomi-requirements.json"
    for name, value in {
        "ROOT": tmp_path,
        "VENV": environment,
        "PYTHON": interpreter,
        "REQUIREMENTS": requirements,
        "MARKER": marker,
    }.items():
        monkeypatch.setattr(bootstrap, name, value)
    calls = []
    monkeypatch.setattr(bootstrap, "run", lambda command: calls.append(command))
    monkeypatch.setattr(bootstrap.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(returncode=0))
    return marker, calls, requirements


def test_install_cache_skips_second_download(launcher):
    marker, calls, requirements = launcher
    bootstrap.prepare_environment()
    assert any("install" in command for command in calls)
    assert json.loads(marker.read_text()) == {
        "sha256": hashlib.sha256(requirements.read_bytes()).hexdigest()
    }
    calls.clear()
    bootstrap.prepare_environment()
    assert not any("install" in command for command in calls)


def test_changed_requirements_trigger_install(launcher):
    marker, calls, requirements = launcher
    bootstrap.prepare_environment()
    calls.clear()
    requirements.write_text("openai==1.109.1\nPySide6==6.8.3\n", encoding="utf-8")
    bootstrap.prepare_environment()
    assert any("install" in command for command in calls)


def test_failed_install_does_not_mark_requirements_ready(launcher, monkeypatch):
    marker, calls, requirements = launcher

    def fail_install(command):
        if "install" in command:
            raise subprocess.CalledProcessError(1, command)

    monkeypatch.setattr(bootstrap, "run", fail_install)
    with pytest.raises(subprocess.CalledProcessError):
        bootstrap.prepare_environment()
    assert not marker.exists()


def test_broken_import_reinstalls_even_with_matching_hash(launcher, monkeypatch):
    marker, calls, requirements = launcher
    bootstrap.prepare_environment()
    calls.clear()
    monkeypatch.setattr(bootstrap.subprocess, "run", lambda *args, **kwargs: SimpleNamespace(returncode=1))
    bootstrap.prepare_environment()
    assert any("install" in command for command in calls)


@pytest.mark.parametrize("version", [(3, 11), (3, 12), (3, 13)])
def test_supported_64bit_interpreters(version):
    bootstrap.validate_interpreter(version, 64)


@pytest.mark.parametrize("version,bits", [((3, 10), 64), ((3, 14), 64), ((3, 12), 32)])
def test_reject_unsupported_interpreter(version, bits):
    with pytest.raises(RuntimeError, match="64-bit Python 3.11, 3.12, or 3.13"):
        bootstrap.validate_interpreter(version, bits)


def test_unsupported_interpreter_stops_before_setup(launcher, monkeypatch):
    marker, calls, requirements = launcher

    def reject():
        raise RuntimeError(bootstrap.RUNTIME_HELP)

    monkeypatch.setattr(bootstrap, "validate_interpreter", reject)
    with pytest.raises(RuntimeError, match="Python 3.14"):
        bootstrap.prepare_environment()
    assert calls == []
    assert not marker.exists()
