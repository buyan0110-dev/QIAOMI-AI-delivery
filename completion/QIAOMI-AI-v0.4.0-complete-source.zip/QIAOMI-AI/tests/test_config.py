import json
from pathlib import Path

import pytest

from qiaomi import config
from qiaomi.config import Config, data_dir, load_config, save_config


def test_preferences_roundtrip_excludes_credentials(tmp_path):
    path = tmp_path / "nested" / "settings.json"
    preferences = Config("gpt-4o-mini", False, True)
    preferences.api_key = "a-user-might-attach-this"
    save_config(path, preferences)
    assert load_config(path) == Config("gpt-4o-mini", False, True)
    assert set(json.loads(path.read_text())) == {"model", "always_on_top", "share_memories", "provider"}
    assert "a-user-might" not in path.read_text()


@pytest.mark.parametrize("text", ["not json", "[]", '{"share_memories":"false"}', '{"model":""}', '{"always_on_top":1}'])
def test_corrupt_preferences_use_safe_defaults(tmp_path, text):
    path = tmp_path / "settings.json"
    path.write_text(text, encoding="utf-8")
    assert load_config(path) == Config()
    assert load_config(tmp_path / "missing.json") == Config()


def test_failed_atomic_replace_keeps_previous_settings(tmp_path, monkeypatch):
    path = tmp_path / "settings.json"
    save_config(path, Config())
    original = path.read_bytes()

    def fail_replace(*args):
        raise OSError("simulated failure")

    monkeypatch.setattr(config.os, "replace", fail_replace)
    with pytest.raises(OSError):
        save_config(path, Config(share_memories=True))
    assert path.read_bytes() == original
    assert list(tmp_path.glob("*.tmp")) == []


def test_invalid_save_does_not_replace_file(tmp_path):
    path = tmp_path / "settings.json"
    save_config(path, Config())
    with pytest.raises(ValueError):
        save_config(path, Config(model="bad\nmodel"))
    assert load_config(path) == Config()


def test_locations_do_not_create_files(tmp_path, monkeypatch):
    explicit = tmp_path / "test-data"
    monkeypatch.setenv("QIAOMI_DATA_DIR", str(explicit))
    assert data_dir() == explicit
    assert not explicit.exists()
    monkeypatch.delenv("QIAOMI_DATA_DIR")
    monkeypatch.setattr(config.sys, "platform", "win32")
    monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "local"))
    assert data_dir() == tmp_path / "local" / "QIAOMI AI"
    monkeypatch.setattr(config.sys, "platform", "linux")
    monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "xdg"))
    assert data_dir() == tmp_path / "xdg" / "qiaomi-ai"


def test_unknown_secret_fields_are_ignored(tmp_path, caplog):
    path = tmp_path / "settings.json"
    path.write_text('{"model": "invalid secret with spaces", "api_key": "do-not-log"}')
    assert load_config(path) == Config()
    assert "do-not-log" not in caplog.text
    assert "invalid secret" not in caplog.text


def test_deeply_nested_config_falls_back_without_crashing(tmp_path):
    from qiaomi.config import Config, load_config
    path = tmp_path / 'config.json'
    path.write_text('[' * 1500 + '0' + ']' * 1500, encoding='utf-8')
    assert load_config(path) == Config()


def test_upgrade_uses_local_model_and_preserves_user_preferences(tmp_path):
    path = tmp_path / 'config.json'
    path.write_text('{"model":"gpt-4o-mini","always_on_top":false,"share_memories":true}')
    upgraded = load_config(path)
    assert upgraded.model == 'qwen3:8b' and upgraded.provider == 'ollama'
    assert upgraded.always_on_top is False and upgraded.share_memories is True
    # Loading alone never mutates the original file.
    assert 'gpt-4o-mini' in path.read_text()


def test_explicit_provider_and_model_survive_restart(tmp_path):
    path = tmp_path / 'config.json'
    preferences = Config('custom-model:8b', True, False, 'ollama')
    save_config(path, preferences)
    assert load_config(path) == preferences
