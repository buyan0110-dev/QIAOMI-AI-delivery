import pytest

from qiaomi import extensions
from qiaomi.extensions import AutomationService, ConfirmationRequiredError


def test_cannot_confirm_without_matching_user_request():
    service = AutomationService()
    with pytest.raises(ConfirmationRequiredError):
        service.confirm("invented")
    request = service.propose_demo()
    with pytest.raises(ConfirmationRequiredError):
        service.confirm("invented")
    with pytest.raises(ConfirmationRequiredError):
        service.confirm("错误请求")
    assert "没有执行任何系统操作" in service.confirm(request.id)
    with pytest.raises(ConfirmationRequiredError):
        service.confirm(request.id)


def test_cancelled_and_superseded_requests_cannot_execute():
    service = AutomationService()
    first = service.propose_demo()
    second = service.propose_demo()
    with pytest.raises(ConfirmationRequiredError):
        service.confirm(first.id)
    assert not service.cancel(first.id)
    assert service.cancel(second.id)
    assert not service.cancel(second.id)
    with pytest.raises(ConfirmationRequiredError):
        service.confirm(second.id)


def test_confirmation_expires(monkeypatch):
    current = [10.0]
    monkeypatch.setattr(extensions.time, "monotonic", lambda: current[0])
    service = AutomationService()
    request = service.propose_demo()
    current[0] = 310.0
    with pytest.raises(ConfirmationRequiredError):
        service.confirm(request.id)
