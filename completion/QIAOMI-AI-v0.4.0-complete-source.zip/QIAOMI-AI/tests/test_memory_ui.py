"""Review and edit safeguards exercised with Qt's offscreen backend."""

import os

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QApplication

from qiaomi.storage import Store
from qiaomi.ui.memories import ImportReviewDialog, MemoryEditor, MemoryPage


@pytest.fixture(scope="module")
def app():
    return QApplication.instance() or QApplication([])


def test_import_requires_selection_then_explicit_review(app):
    dialog = ImportReviewDialog(
        [{"key": "称呼", "value": "小林"}, {"key": "风格", "value": "先给结论"}], {"称呼"}
    )
    assert not dialog.confirm_button.isEnabled()
    assert dialog.selected_items() == []
    dialog.reviewed.setChecked(True)
    assert not dialog.confirm_button.isEnabled()
    dialog.table.item(0, 0).setCheckState(Qt.CheckState.Checked)
    assert not dialog.reviewed.isChecked()
    assert not dialog.confirm_button.isEnabled()
    dialog.reviewed.setChecked(True)
    assert dialog.confirm_button.isEnabled()
    assert dialog.selected_items() == [{"key": "称呼", "value": "小林"}]
    assert dialog.table.item(0, 3).text() == "替换已有"
    assert dialog.table.item(1, 3).text() == "新增"
    dialog.table.item(1, 0).setCheckState(Qt.CheckState.Checked)
    assert not dialog.confirm_button.isEnabled()
    dialog.close()


def test_import_shows_full_content_as_plain_text(app):
    value = "<b>这不是 HTML</b>\n" + "完整内容" * 800
    dialog = ImportReviewDialog([{"key": "测试", "value": value}], set())
    assert dialog.detail.toPlainText() == f"测试\n\n{value}"
    assert len(dialog.table.item(0, 2).text()) < len(value)
    dialog.close()


def test_editor_rejects_empty_or_oversize_and_preserves_imported_key(app):
    key = "名" * 120
    dialog = MemoryEditor({"key": key, "value": "偏好"})
    assert dialog.values() == (key, "偏好")
    assert dialog.save_button.isEnabled()
    dialog.value_edit.setPlainText("字" * 4001)
    assert not dialog.save_button.isEnabled()
    dialog.value_edit.setPlainText("   ")
    assert not dialog.save_button.isEnabled()
    dialog.value_edit.setPlainText("可保存")
    dialog.key_edit.setText("  ")
    assert not dialog.save_button.isEnabled()
    dialog.close()


def test_page_refresh_and_selection_use_persisted_ids(app, tmp_path):
    store = Store(tmp_path / "memory.sqlite3")
    page = MemoryPage(store)
    assert page.table.rowCount() == 0
    assert not page.edit_button.isEnabled()
    assert not page.delete_button.isEnabled()
    store.upsert_memory("语言", "中文")
    page.refresh()
    assert page.table.rowCount() == 1
    page.table.selectRow(0)
    assert page.edit_button.isEnabled()
    assert page._selected()["key"] == "语言"
    store.delete_memory(page._selected()["id"])
    page.refresh()
    assert not page.delete_button.isEnabled()
    page.close()
    store.close()
