"""Exercise the real HTTPX protocol parser and cancellation without a local model."""
import asyncio
import json
from threading import Event
import time

import httpx
import pytest

from qiaomi import ollama
from qiaomi.ai import AIError


def install(monkeypatch, handler):
    clients = []
    def factory():
        client = httpx.AsyncClient(base_url=ollama.BASE_URL, trust_env=False,
                                   transport=httpx.MockTransport(handler))
        clients.append(client)
        return client
    monkeypatch.setattr(ollama, '_client', factory)
    return clients


def tags():
    return httpx.Response(200, json={'models': [{'name': 'qwen3:8b'}]})


def test_streaming_chinese_context_and_local_endpoint(monkeypatch):
    requests, chunks = [], []
    async def handler(request):
        assert str(request.url).startswith('http://127.0.0.1:11434/api/')
        assert 'authorization' not in request.headers
        if request.url.path == '/api/tags':
            return tags()
        requests.append(json.loads(request.content))
        data = [{'message': {'content': '你好'}}, {'message': {'content': '，主人。'}}, {'done': True}]
        return httpx.Response(200, text='\n'.join(json.dumps(i, ensure_ascii=False) for i in data))
    clients = install(monkeypatch, handler)
    history = [{'role': 'user', 'content': '我叫小乔'}, {'role': 'assistant', 'content': '你好小乔'},
               {'role': 'user', 'content': '我叫什么？'}]
    assert ollama.ollama_reply('qwen3:8b', history, [], on_chunk=chunks.append) == '你好，主人。'
    assert chunks == ['你好', '，主人。']
    assert requests[0]['messages'][1:] == history
    assert requests[0]['stream'] is True and requests[0]['think'] is False
    assert all(c.is_closed for c in clients)


def test_detection_missing_and_unreachable(monkeypatch):
    install(monkeypatch, lambda r: tags())
    assert '已安装' in ollama.check_ollama()
    install(monkeypatch, lambda r: httpx.Response(200, json={'models': []}))
    with pytest.raises(AIError, match='ollama pull qwen3:8b'):
        ollama.check_ollama()
    def failed(r):
        raise httpx.ConnectError('PRIVATE DETAIL', request=r)
    install(monkeypatch, failed)
    with pytest.raises(AIError, match='启动 Ollama') as error:
        ollama.check_ollama()
    assert 'PRIVATE' not in str(error.value)


@pytest.mark.parametrize('data', [
    '{bad json', '{"message":{"content":"半句"}}', '{"done":true}',
    '{"error":"PRIVATE DETAIL"}', '{"message":{"content":42}}',
])
def test_invalid_empty_or_incomplete_stream_does_not_succeed(monkeypatch, data):
    install(monkeypatch, lambda r: tags() if r.url.path == '/api/tags' else httpx.Response(200, text=data))
    with pytest.raises(AIError) as error:
        ollama.ollama_reply('qwen3:8b', [], [])
    assert 'PRIVATE' not in str(error.value)


def test_cancel_pending_stream_closes_transport(monkeypatch):
    stopped = Event()
    closed = []
    class Stream(httpx.AsyncByteStream):
        async def __aiter__(self):
            yield b'{"message":{"content":"hello"}}\n'
            asyncio.get_running_loop().call_later(.01, stopped.set)
            await asyncio.Event().wait()
        async def aclose(self):
            closed.append(True)
    install(monkeypatch, lambda r: tags() if r.url.path == '/api/tags' else httpx.Response(200, stream=Stream()))
    started = time.monotonic()
    with pytest.raises(AIError, match='取消'):
        ollama.ollama_reply('qwen3:8b', [], [], stopped)
    assert time.monotonic() - started < 1
    assert closed


def test_deadline_cancels_model_load(monkeypatch):
    cancelled = []
    async def handler(request):
        try:
            await asyncio.Event().wait()
        except asyncio.CancelledError:
            cancelled.append(True)
            raise
    install(monkeypatch, handler)
    monkeypatch.setattr(ollama, 'GENERATION_TIMEOUT', .02)
    with pytest.raises(AIError, match='超时'):
        ollama.ollama_reply('qwen3:8b', [], [])
    assert cancelled


def test_real_local_http_server_stream(monkeypatch):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    from threading import Thread
    received = []
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass
        def do_GET(self):
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b'{"models":[{"name":"qwen3:8b"}]}')
        def do_POST(self):
            received.append(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
            self.send_response(200)
            self.send_header('Content-Type', 'application/x-ndjson')
            self.end_headers()
            for word in ('你好', '小乔'):
                self.wfile.write((json.dumps({'message': {'content': word}}, ensure_ascii=False) + '\n').encode())
                self.wfile.flush()
                time.sleep(.01)
            self.wfile.write(b'{"done":true}\n')
    server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    monkeypatch.setattr(ollama, 'BASE_URL', f'http://127.0.0.1:{server.server_port}')
    try:
        chunks = []
        assert ollama.ollama_reply('qwen3:8b', [], [], on_chunk=chunks.append) == '你好小乔'
        assert chunks == ['你好', '小乔']
        assert received[0]['model'] == 'qwen3:8b'
    finally:
        server.shutdown()
        server.server_close()
        thread.join()
