"""Real Qt offscreen state/timer tests; not Windows hardware validation."""
import json
import os
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import pytest
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from qiaomi.personality import PersonalityEngine,PersonalityPreferences
from qiaomi.personality_assets import LazySkin
from qiaomi.personality_constants import REUNION_STATES,REUNION_STAGES,ATTENTION_STATES,CORE_LINE
from qiaomi.ui.pet import PetWindow
from test_desktop_lifecycle import controller,app

@pytest.fixture
def engine(app,tmp_path):
    p=PetWindow();p.show()
    prefs=PersonalityPreferences(tmp_path)
    e=PersonalityEngine(p,prefs,LazySkin,timings={**{s:5 for s,_ in REUNION_STAGES},'cuddle':5,'pout':5,'comfort':5,'action':5})
    yield e
    e.close();p.deleteLater();app.processEvents()


def test_finite_reunion_order_and_no_repeat(engine):
    e=engine;e.enter_sleep();seen=[]
    original=e.pet.play_clip
    def clip(state,ms):seen.append(state);original(state,ms)
    e.pet.play_clip=clip
    assert e.wake();assert not e.wake()
    for _ in range(30):QTest.qWait(10)
    assert seen==[s for s,_ in REUNION_STAGES]+['reunion_cuddle','reunion_pout','idle']
    assert e.reunion_count==1 and e.phase=='idle' and not e.phase_timer.isActive()


def test_dormant_constructor_never_loads_or_decodes(app,tmp_path):
    prefs=PersonalityPreferences(tmp_path);prefs.values['deep_sleep']=True
    p=PetWindow(dormant=True);loads=[]
    e=PersonalityEngine(p,prefs,lambda:loads.append(True))
    try:
        assert loads==[] and not p.timer.isActive()
        p.grab();QTest.qWait(30)
        assert loads==[] and not e.next_action.isActive() and not e.phase_timer.isActive()
    finally:e.close();p.deleteLater()


def test_sleep_releases_cache_and_only_explicit_wake_loads(engine):
    e=engine;e.pet.sprites.frame('reunion_hug',0);assert e.pet.sprites.cached_bytes>0
    e.enter_sleep();assert not e.pet.isVisible() and not e.pet.timer.isActive()
    assert not e.pet.sprites.animations and not e.next_action.isActive()
    e.interact('head');e.skip();e._autonomous();assert e.phase=='dormant'
    assert e.wake() and e.phase=='reunion'

@pytest.mark.parametrize('zone,state',[('head','reunion_cuddle'),('pad','pet_belly'),('body','reunion_hug')])
def test_touch_real_clip(engine,zone,state):
    engine.interact(zone);assert engine.pet.state==state and engine.phase=='comfort'
    QTest.qWait(30);assert engine.phase=='idle'


def test_triple_touch_roll_and_skip(engine):
    for _ in range(3):engine.interact('head')
    assert engine.pet.state=='reunion_happy'
    engine.skip();assert engine.phase=='idle' and not engine.phase_timer.isActive()


def test_disabled_reunion_and_bubbles(engine):
    e=engine;e.preferences.values.update(reunion_enabled=False,bubbles_enabled=False)
    e.enter_sleep();e.wake();assert e.reunion_count==0 and e.phase=='idle'

@pytest.mark.parametrize('appearance',['work','gaming'])
def test_glasses_roles_pause_autonomy(engine,appearance):
    e=engine;e.preferences.values['appearance']=appearance;e.settings_changed()
    assert not e.next_action.isActive()
    assert e.pet._visual_state() in ('working','game_preview')


def test_busy_task_blocks_touch_and_autonomy(engine):
    e=engine;e.busy=lambda:True;e.interact('head');e._autonomous()
    assert e.phase=='idle' and not e.phase_timer.isActive()


def test_disable_active_affection(engine):
    e=engine;e.preferences.values['daily_enabled']=False;e._autonomous();assert e.phase=='action'
    e.preferences.values['affection_enabled']=False;e.settings_changed()
    assert e.phase=='idle' and not e.next_action.isActive()


def test_hide_normalizes_pose_and_stops_scheduling(engine):
    e=engine;e.interact('head');e.pet.hide()
    assert e.phase=='idle' and e.pet.state=='idle' and not e.phase_timer.isActive()
    assert not e.next_action.isActive()


def test_preferences_unknown_fields_and_deep_persistence(tmp_path):
    p=PersonalityPreferences(tmp_path);p.values.update(deep_sleep=True,future='keep');p.save()
    q=PersonalityPreferences(tmp_path);assert q.values['deep_sleep'] and q.values['future']=='keep'


def test_corrupt_preferences_backed_up(tmp_path):
    path=tmp_path/'personality.json';path.write_text('{bad')
    p=PersonalityPreferences(tmp_path);assert p.read_error;p.save()
    assert list(tmp_path.glob('personality.invalid-*.json'))[0].read_text()=='{bad'


def test_regular_exit_does_not_turn_on_sleep(engine):
    engine.close();assert not engine.preferences.values['deep_sleep']


def test_all_required_frames_decode_unique_alpha_and_cache_budget(app):
    skin=LazySkin();assert skin.error is None and skin.frame_reads==0
    assert not skin.missing(REUNION_STATES) and not skin.missing(ATTENTION_STATES)
    paths={p for frames,_ in skin.animations.values() for p in frames};assert len(paths)==112
    for state in (*REUNION_STATES,'working','game_preview'):
        frames,fps=skin.animations[state]
        assert len(frames)==6 and len({p.read_bytes() for p in frames})==6
        for i in range(6):
            pix=skin.frame(state,i/fps+0.001)
            assert pix is not None and pix.hasAlphaChannel()
            assert pix.width()==256 and skin.cached_bytes<=skin.max_bytes
    skin.release();assert skin.cached_bytes==0 and not skin.cache


def test_bad_manifest_path_rejected(app,tmp_path):
    p=tmp_path/'manifest.json';p.write_text(json.dumps({'version':2,'states':{'idle':{'fps':6,'frames':['../secret.png']}}}))
    skin=LazySkin(p);assert skin.error and not skin.animations


def test_decode_failure_report_once(app,tmp_path):
    (tmp_path/'bad.png').write_bytes(b'bad')
    p=tmp_path/'manifest.json';p.write_text(json.dumps({'version':2,'states':{'idle':{'fps':6,'frames':['bad.png']}}}))
    skin=LazySkin(p);errors=[];skin.on_error=errors.append
    assert skin.frame('idle',0) is None and skin.frame('idle',1) is None
    assert len(errors)==1


def test_controller_deep_guards_and_explicit_wake(controller,monkeypatch):
    c=controller;c.set_game_mode(True)
    assert c.game_mode and c.personality.dormant and not c.pet.timer.isActive()
    c.set_game_mode(False);c.show_pet();c.voice.listen();c.check_connection()
    assert c.game_mode and not c.pet.isVisible() and not c.voice.listening and c.worker is None
    before=c.store.messages();c.on_reply('late');c.on_chunk('late');c.on_failure('late')
    assert c.store.messages()==before
    c.personality_preferences.values['reunion_enabled']=False
    c.wake_qiaomi();assert not c.game_mode and c.pet.isVisible() and not c.voice.listening
