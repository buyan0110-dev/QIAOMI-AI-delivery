"""Qt offscreen interaction tests; these do not validate Windows compositor behavior."""
import json
import os
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import pytest
from PySide6.QtCore import QEvent, QObject, QPoint, QRect, Qt, QTimer, Signal, SIGNAL
from PySide6.QtGui import QColor, QContextMenuEvent, QImage
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication, QMenu

from qiaomi.ui.pet import (PetWindow, SpriteLibrary, STATES, clamp_window_position,
                           make_cat_icon)


@pytest.fixture(scope="module")
def app():
    instance = QApplication.instance() or QApplication([])
    yield instance


@pytest.fixture
def pet(app):
    window = PetWindow()
    window.show()
    app.processEvents()
    yield window
    window.hide()
    window.deleteLater()
    app.processEvents()


def test_states_render_and_hidden_animation_stops(pet, app):
    assert not make_cat_icon().isNull()
    for state in STATES:
        pet.set_state(state)
        app.processEvents()
        assert not pet.grab().isNull()
    assert pet.timer.isActive()
    pet.hide()
    assert not pet.timer.isActive()
    pet.show()
    assert pet.timer.isActive()
    with pytest.raises(ValueError):
        pet.set_state("unsupported")


def test_head_belly_clicks_and_assistant_button(pet, app):
    QTest.mouseClick(pet, Qt.MouseButton.LeftButton, pos=QPoint(148, 130))
    assert pet.state == "pet_head"
    QTest.mouseClick(pet, Qt.MouseButton.LeftButton, pos=QPoint(148, 238))
    assert pet.state == "pet_belly"
    opened = []
    pet.open_assistant.connect(lambda: opened.append(True))
    QTest.mouseClick(pet.enter_button, Qt.MouseButton.LeftButton)
    assert opened == [True]


def test_drag_does_not_trigger_pet_interaction(pet, app):
    pet.set_state("idle")
    pet.move(40, 40)
    start = pet.pos()
    QTest.mousePress(pet, Qt.MouseButton.LeftButton, pos=QPoint(148, 130))
    QTest.mouseMove(pet, QPoint(175, 150), 10)
    QTest.mouseRelease(pet, Qt.MouseButton.LeftButton, pos=QPoint(175, 150))
    assert pet.state == "idle"
    assert pet.pos() != start


def test_state_timeout_returns_to_busy_or_idle(pet, app):
    pet.set_busy(True)
    pet.set_state("happy", 10)
    # Wait for the timer event, rather than assuming the host schedules it in 30 ms.
    for _ in range(100):
        if pet.state == "thinking":
            break
        QTest.qWait(10)
    assert pet.state == "thinking"
    pet.set_busy(False)
    assert pet.state == "idle"


def _manifest(path, states):
    path.write_text(json.dumps({"version": 1, "states": states}), encoding="utf-8")


def test_sprite_paths_are_bounded_and_invalid_art_falls_back(tmp_path, app):
    image = QImage(32, 32, QImage.Format.Format_ARGB32)
    image.fill(QColor("orange"))
    assert image.save(str(tmp_path / "outside.png"))
    root = tmp_path / "cat"
    root.mkdir()
    manifest = root / "manifest.json"
    _manifest(manifest, {"idle": {"fps": 10, "frames": ["../outside.png"]}})
    library = SpriteLibrary(manifest)
    assert not library.animations
    assert library.error is not None
    assert image.save(str(root / "frame.png"))
    _manifest(manifest, {"idle": {"fps": 10, "frames": ["frame.png"]}})
    library = SpriteLibrary(manifest)
    assert library.error is None
    assert not library.frame("idle", 0).isNull()
    assert library.frame("sleep", 0) is None
    _manifest(manifest, {"idle": {"fps": 1000, "frames": ["frame.png"]}})
    assert SpriteLibrary(manifest).error is not None


@pytest.mark.parametrize(("window", "areas", "pointer", "expected"), [
    # A monitor to the left and above the primary can have negative coordinates.
    (QRect(-1800, -100, 300, 350), [QRect(0, 0, 1920, 1040),
                                   QRect(-1920, -200, 1920, 1080)],
     None, QPoint(-1800, -100)),
    # The old secondary no longer exists: recover onto the remaining primary.
    (QRect(2240, 800, 300, 350), [QRect(0, 0, 1920, 1040)],
     None, QPoint(1620, 690)),
    # Entirely in a gap: use the nearest actual work area, not the primary.
    (QRect(1150, 150, 100, 100), [QRect(0, 0, 800, 800), QRect(1400, 0, 800, 800)],
     None, QPoint(1400, 150)),
    # Largest visible overlap wins when the window straddles two screens.
    (QRect(700, 100, 300, 350), [QRect(0, 0, 800, 800), QRect(800, 0, 800, 800)],
     None, QPoint(800, 100)),
    # While dragging, the mouse can choose a screen before the centre crosses.
    (QRect(650, 100, 300, 350), [QRect(0, 0, 800, 800), QRect(800, 0, 800, 800)],
     QPoint(810, 150), QPoint(800, 100)),
    # A taskbar at the left or top changes the usable origin.
    (QRect(0, 0, 300, 350), [QRect(50, 40, 1870, 1000)],
     None, QPoint(50, 40)),
    # A window larger than the display is anchored at the usable top-left.
    (QRect(-400, 100, 300, 350), [QRect(-200, -100, 150, 200)],
     None, QPoint(-200, -100)),
    # Display changes can briefly expose no valid work areas.
    (QRect(20, 30, 300, 350), [QRect(), QRect(0, 0, -1, -1)],
     None, QPoint(20, 30)),
])
def test_window_position_uses_current_monitor_geometry(window, areas, pointer, expected):
    assert clamp_window_position(window, areas, pointer) == expected


class FakeScreen(QObject):
    availableGeometryChanged = Signal(QRect)
    geometryChanged = Signal(QRect)

    def __init__(self, area):
        super().__init__()
        self.area = area

    def availableGeometry(self):
        return self.area


def test_work_area_changes_recover_without_moving_valid_manual_position(pet, app, monkeypatch):
    screen = FakeScreen(QRect(0, 0, 800, 800))
    pet.hide()
    monkeypatch.setattr(QApplication, "screens", lambda: [screen])
    pet.show()
    pet.move(450, 420)
    screen.availableGeometryChanged.emit(screen.area)
    app.processEvents()
    assert pet.pos() == QPoint(450, 420)

    # A growing taskbar/resolution change moves the pet only as far as necessary.
    screen.area = QRect(0, 0, 600, 600)
    screen.availableGeometryChanged.emit(screen.area)
    screen.geometryChanged.emit(screen.area)
    app.processEvents()
    assert pet.pos() == QPoint(300, 250)
    assert not pet.screen_recovery_timer.isActive()


def test_removed_display_recovers_and_refreshes_subscriptions(pet, app, monkeypatch):
    left = FakeScreen(QRect(-800, 0, 800, 800))
    right = FakeScreen(QRect(0, 0, 800, 800))
    screens = [left, right]
    pet.hide()
    monkeypatch.setattr(QApplication, "screens", lambda: list(screens))
    pet.show()
    pet.move(-700, 150)
    screens.remove(left)
    app.screenRemoved.emit(None)
    app.processEvents()
    assert pet.pos() == QPoint(0, 150)
    assert left.receivers(SIGNAL("availableGeometryChanged(QRect)")) == 0
    assert right.receivers(SIGNAL("availableGeometryChanged(QRect)")) == 1


def test_tracking_disconnects_when_hidden_and_on_destruction(app, monkeypatch):
    screen = FakeScreen(QRect(0, 0, 800, 800))
    monkeypatch.setattr(QApplication, "screens", lambda: [screen])
    app_signal = SIGNAL("screenRemoved(QScreen*)")
    baseline = app.receivers(app_signal)
    window = PetWindow()
    for _ in range(3):
        window.show()
        assert app.receivers(app_signal) == baseline + 1
        assert screen.receivers(SIGNAL("availableGeometryChanged(QRect)")) == 1
        screen.availableGeometryChanged.emit(screen.area)
        assert window.screen_recovery_timer.isActive()
        window.hide()
        assert not window.screen_recovery_timer.isActive()
        assert not window.timer.isActive()
        assert app.receivers(app_signal) == baseline
        assert screen.receivers(SIGNAL("availableGeometryChanged(QRect)")) == 0
    window.show()
    window.deleteLater()
    QApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
    assert app.receivers(app_signal) == baseline
    assert screen.receivers(SIGNAL("availableGeometryChanged(QRect)")) == 0


def test_repeated_context_menus_are_released(pet):
    event = QContextMenuEvent(QContextMenuEvent.Reason.Mouse, QPoint(150, 150),
                              pet.mapToGlobal(QPoint(150, 150)))
    for _ in range(3):
        QTimer.singleShot(10, lambda: QApplication.activePopupWidget().close())
        pet.contextMenuEvent(event)
        QApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        assert pet.findChildren(QMenu) == []


def test_deeply_nested_asset_manifest_falls_back(tmp_path):
    from qiaomi.ui.pet import SpriteLibrary
    path = tmp_path / 'manifest.json'
    path.write_text('[' * 1500 + '0' + ']' * 1500, encoding='utf-8')
    sprites = SpriteLibrary(path)
    assert not sprites.animations
    assert sprites.error
