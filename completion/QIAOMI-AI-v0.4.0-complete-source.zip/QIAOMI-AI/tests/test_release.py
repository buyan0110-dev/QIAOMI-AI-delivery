"""Exercise real ZIP creation, hashes, and package-boundary validation."""

import hashlib
import importlib.util
from pathlib import Path
import zipfile

import pytest


SPEC = importlib.util.spec_from_file_location(
    "qiaomi_release", Path(__file__).resolve().parents[1] / "scripts" / "build_release.py"
)
release = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(release)


@pytest.fixture
def package(tmp_path):
    source = tmp_path / "build" / "QIAOMI-AI"
    internal = source / "_internal"
    internal.mkdir(parents=True)
    (source / "QIAOMI-AI.exe").write_bytes(b"MZ" + b"test fixture, not a real executable")
    (internal / "python312.dll").write_bytes(b"runtime fixture")
    assets = internal / "assets"
    assets.mkdir()
    (assets / "说明.txt").write_text("猫咪素材", encoding="utf-8")
    return source, tmp_path / "release" / "QIAOMI-AI-Windows-x64.zip"


def test_release_contains_whole_build_and_matching_checksum(package):
    source, output = package
    archive, checksum = release.build_release(source, output)
    with zipfile.ZipFile(archive) as stream:
        assert stream.testzip() is None
        assert set(stream.namelist()) == {
            "QIAOMI-AI/QIAOMI-AI.exe",
            "QIAOMI-AI/_internal/python312.dll",
            "QIAOMI-AI/_internal/assets/说明.txt",
        }
        assert stream.read("QIAOMI-AI/_internal/assets/说明.txt").decode("utf-8") == "猫咪素材"
    assert checksum.read_text("ascii") == f"{hashlib.sha256(archive.read_bytes()).hexdigest()}  {archive.name}\n"


@pytest.mark.parametrize("problem", ["missing_entry", "wrong_entry", "missing_runtime", "empty_runtime"])
def test_incomplete_build_rejected_before_replacing_existing_archive(package, problem):
    source, output = package
    output.parent.mkdir()
    output.write_bytes(b"previous release")
    if problem == "missing_entry":
        (source / "QIAOMI-AI.exe").unlink()
    elif problem == "wrong_entry":
        (source / "QIAOMI-AI.exe").write_text("not a Windows program")
    else:
        for path in sorted((source / "_internal").rglob("*"), reverse=True):
            path.rmdir() if path.is_dir() else path.unlink()
        if problem == "missing_runtime":
            (source / "_internal").rmdir()
    with pytest.raises(release.ReleaseError):
        release.build_release(source, output)
    assert output.read_bytes() == b"previous release"
    assert not output.with_suffix(".zip.sha256").exists()


def test_output_cannot_be_inside_input_tree(package):
    source, _ = package
    with pytest.raises(release.ReleaseError, match="outside"):
        release.build_release(source, source / "release.zip")
    assert not (source / "release.zip").exists()


def test_link_outside_package_is_rejected(package, tmp_path):
    source, output = package
    external = tmp_path / "private.txt"
    external.write_text("not part of release")
    try:
        (source / "outside.txt").symlink_to(external)
    except (OSError, NotImplementedError):
        pytest.skip("Creating symlinks requires privileges on this Windows runner")
    with pytest.raises(release.ReleaseError, match="Links"):
        release.build_release(source, output)
    assert not output.exists()


@pytest.mark.parametrize("name", ["../outside.txt", "a/../../outside.txt", "..\\outside.txt", "C:private.txt", "/absolute.txt"])
def test_archive_paths_cannot_escape_root(name):
    with pytest.raises(release.ReleaseError):
        release._archive_name(Path(name))


def test_source_tree_is_not_modified(package):
    source, output = package
    before = {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()}
    release.build_release(source, output)
    after = {path.relative_to(source): path.read_bytes() for path in source.rglob("*") if path.is_file()}
    assert before == after
    assert not list(output.parent.glob(".qiaomi-*.tmp"))


def test_output_name_can_contain_chinese_characters(package):
    source, default_output = package
    output = default_output.parent / "敲咪 Windows.zip"
    archive, checksum = release.build_release(source, output)
    assert archive.is_file()
    assert checksum.read_text("utf-8").endswith("  敲咪 Windows.zip\n")
