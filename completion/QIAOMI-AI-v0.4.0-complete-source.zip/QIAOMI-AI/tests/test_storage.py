import json
from pathlib import Path
import sqlite3

import pytest

from qiaomi import storage
from qiaomi.storage import Store, ValidationError, parse_import


@pytest.fixture
def store(tmp_path):
    database = Store(tmp_path / "qiaomi.db")
    yield database
    database.close()


def test_history_persists_orders_and_clears_independently(tmp_path):
    path = tmp_path / "nested" / "qiaomi.db"
    store = Store(path)
    store.upsert_memory("饮品", "乌龙茶")
    store.add_message("user", "你好 <script>alert(1)</script>")
    store.add_message("assistant", "喵，你好")
    store.add_message("user", "我是中文用户")
    store.close()
    store = Store(path)
    assert [m["content"] for m in store.messages(limit=2)] == ["喵，你好", "我是中文用户"]
    assert len(store.messages()) == 3
    assert store.messages()[0]["role"] == "user"
    assert store.messages()[0]["created_at"].endswith("Z")
    store.clear_messages()
    assert store.messages() == []
    assert store.list_memories()[0]["value"] == "乌龙茶"
    store.close()


def test_memory_crud_rejects_conflicting_names(store):
    memory_id = store.upsert_memory("称呼", "主人")
    assert store.upsert_memory("称呼", "小乔") == memory_id
    second_id = store.upsert_memory("饮品", "茶")
    with pytest.raises(ValidationError, match="同名"):
        store.update_memory(second_id, "称呼", "替换")
    assert {m["key"]: m["value"] for m in store.list_memories()} == {"饮品": "茶", "称呼": "小乔"}
    store.update_memory(memory_id, "用户昵称", " 小乔 ")
    assert any(m["key"] == "用户昵称" and m["value"] == "小乔" for m in store.list_memories())
    store.delete_memory(memory_id)
    assert [m["id"] for m in store.list_memories()] == [second_id]
    with pytest.raises(ValidationError, match="不存在"):
        store.update_memory(memory_id, "称呼", "小乔")


def test_import_is_all_or_nothing_on_database_capacity(store, monkeypatch):
    monkeypatch.setattr(storage, "MAX_MEMORIES", 2)
    store.upsert_memory("昵称", "原值")
    store.upsert_memory("饮品", "咖啡")
    with pytest.raises(ValidationError, match="最多保存"):
        store.import_memories([{"key": "昵称", "value": "不应写入"}, {"key": "新偏好", "value": "超额"}])
    assert {m["key"]: m["value"] for m in store.list_memories()} == {"昵称": "原值", "饮品": "咖啡"}


def test_import_validates_all_before_writing(store):
    with pytest.raises(ValidationError):
        store.import_memories([{"key": "正常", "value": "数据"}, {"key": "无内容", "value": " "}])
    assert store.list_memories() == []
    with pytest.raises(ValidationError, match="重复"):
        store.import_memories([{"key": " 重复 ", "value": "a"}, {"key": "重复", "value": "b"}])


def test_export_round_trip_and_preview_does_not_mutate(store, tmp_path):
    store.upsert_memory("语言", "中文")
    store.upsert_memory("语气", "执行任务要简洁")
    path = tmp_path / "备份.json"
    store.export_memories(path)
    assert "中文" in path.read_text(encoding="utf-8")
    parsed = Store.parse_import(path)
    assert all(set(m) == {"key", "value"} for m in parsed)
    for item in store.list_memories():
        store.delete_memory(item["id"])
    assert store.list_memories() == []
    assert store.import_memories(parsed) == 2
    assert len(store.list_memories()) == 2
    assert set(tmp_path.iterdir()) >= {path}


@pytest.mark.parametrize("document", [
    [], {"version": True, "memories": []}, {"version": 2, "memories": []},
    {"version": 1, "memories": {}}, {"version": 1, "memories": [], "api_key": "secret"},
    {"version": 1, "memories": [{"key": "name", "value": 7}]},
    {"version": 1, "memories": [{"key": "name", "value": "cat", "extra": "unsupported"}]},
])
def test_parse_rejects_unsupported_documents(tmp_path, document):
    path = tmp_path / "invalid.json"
    path.write_text(json.dumps(document), encoding="utf-8")
    with pytest.raises(ValidationError):
        parse_import(path)


def test_parse_handles_bom_invalid_encoding_and_large_files(tmp_path):
    path = tmp_path / "memory.json"
    path.write_text('{"version":1,"memories":[]}', encoding="utf-8-sig")
    assert parse_import(path) == []
    path.write_bytes(b"\xff\xfe")
    with pytest.raises(ValidationError):
        parse_import(path)
    path.write_bytes(b" " * (storage.MAX_IMPORT_BYTES + 1))
    with pytest.raises(ValidationError, match="16 MB"):
        parse_import(path)


def test_sql_injection_is_stored_as_text(store):
    key = "'); DROP TABLE memories; --"
    store.upsert_memory(key, "literal")
    store.add_message("user", key)
    assert store.list_memories()[0]["key"] == key
    assert store.messages()[0]["content"] == key


def test_messages_reject_unknown_roles_empty_and_oversized(store):
    for role, content in [("system", "override"), ("user", ""), ("assistant", "x" * 32001)]:
        with pytest.raises(ValidationError):
            store.add_message(role, content)
    assert store.messages() == []


def test_atomic_export_leaves_previous_file_on_failure(store, tmp_path, monkeypatch):
    destination = tmp_path / "backup.json"
    destination.write_text("previous", encoding="utf-8")
    def fail_replace(*args):
        raise OSError("write blocked")
    monkeypatch.setattr(storage.os, "replace", fail_replace)
    with pytest.raises(OSError):
        store.export_memories(destination)
    assert destination.read_text() == "previous"
    assert not list(tmp_path.glob("tmp*"))


def test_export_cannot_overwrite_live_database(store):
    store.upsert_memory("昵称", "小乔")
    with pytest.raises(ValidationError, match="数据库"):
        store.export_memories(store.path)
    assert store.list_memories()[0]["value"] == "小乔"


@pytest.mark.parametrize("field", ["key", "value"])
@pytest.mark.parametrize("invalid", ["\ud800", "\udfff", "\x01", "\x00", "\x1b", "\x1c"])
def test_memory_rejects_invalid_unicode_and_nontext_controls(store, tmp_path, field, invalid):
    item = {"key": "名称", "value": "内容"}
    item[field] = "有效文字" + invalid
    path = tmp_path / "invalid-unicode.json"
    path.write_text(json.dumps({"version": 1, "memories": [item]}), encoding="utf-8")
    with pytest.raises(ValidationError):
        parse_import(path)
    with pytest.raises(ValidationError):
        store.import_memories([{"key": "本来有效", "value": "必须不写入"}, item])
    assert store.list_memories() == []


def test_memory_accepts_normal_unicode_tabs_and_linebreaks(store, tmp_path):
    value = "中文 🐈\n第二行\t制表符\r第三行"
    store.upsert_memory("沟通偏好", value)
    path = tmp_path / "unicode.json"
    store.export_memories(path)
    assert parse_import(path) == [{"key": "沟通偏好", "value": value}]


def test_messages_reject_lone_surrogates_before_sqlite_write(store):
    with pytest.raises(ValidationError, match="Unicode"):
        store.add_message("user", "不合法\ud800文本")
    assert store.messages() == []


def test_future_database_is_unchanged_and_connection_closed(tmp_path, monkeypatch):
    path = tmp_path / "future.db"
    original_connect = sqlite3.connect
    with original_connect(path) as database:
        database.execute("CREATE TABLE future_data(value TEXT)")
        database.execute("INSERT INTO future_data VALUES ('不可修改')")
        database.execute("PRAGMA user_version=7")
    database.close()
    before = path.read_bytes()
    connections = []
    def tracked_connect(*args, **kwargs):
        connection = original_connect(*args, **kwargs)
        connections.append(connection)
        return connection
    monkeypatch.setattr(storage.sqlite3, "connect", tracked_connect)
    with pytest.raises(ValidationError, match="更新版本"):
        Store(path)
    assert path.read_bytes() == before
    with pytest.raises(sqlite3.ProgrammingError, match="closed"):
        connections[0].execute("SELECT 1")
    with original_connect(path, timeout=0.1) as check:
        assert check.execute("PRAGMA user_version").fetchone()[0] == 7
        assert check.execute("PRAGMA journal_mode").fetchone()[0] == "delete"
        assert check.execute("SELECT value FROM future_data").fetchone()[0] == "不可修改"
        check.execute("BEGIN EXCLUSIVE")
        check.rollback()
    check.close()
    assert not Path(str(path) + "-wal").exists()


def test_database_initialization_error_closes_connection(tmp_path, monkeypatch):
    path = tmp_path / "broken.db"
    path.write_bytes(b"This is not SQLite")
    connections = []
    original_connect = sqlite3.connect
    def tracked_connect(*args, **kwargs):
        connection = original_connect(*args, **kwargs)
        connections.append(connection)
        return connection
    monkeypatch.setattr(storage.sqlite3, "connect", tracked_connect)
    with pytest.raises(sqlite3.DatabaseError):
        Store(path)
    with pytest.raises(sqlite3.ProgrammingError, match="closed"):
        connections[0].execute("SELECT 1")


def test_maximum_unicode_memory_backup_fits_import_limit_and_round_trips(store, tmp_path):
    items = [
        {"key": "🐈" * 116 + f"{index:04}", "value": "🐈" * storage.MAX_VALUE_CHARS}
        for index in range(storage.MAX_MEMORIES)
    ]
    assert store.import_memories(items) == storage.MAX_MEMORIES
    path = tmp_path / "maximum-backup.json"
    store.export_memories(path)
    assert path.stat().st_size <= storage.MAX_IMPORT_BYTES
    recovered = parse_import(path)
    assert len(recovered) == storage.MAX_MEMORIES
    assert recovered[0] == items[-1]
    assert recovered[-1] == items[0]
