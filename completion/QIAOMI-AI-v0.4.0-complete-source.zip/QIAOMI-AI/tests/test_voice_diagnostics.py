"""State/IPC tests with real Qt widgets and simulated audio/model failures."""
import logging
import sys
from threading import Event
from types import SimpleNamespace
import numpy as np
import pytest
from PySide6.QtTest import QTest
from test_voice_memory import controller, wait
from test_audio_capture import FakeSD
from qiaomi import audio_capture
from qiaomi import voice_worker as worker
from qiaomi.voice_logging import configure_voice_logging, SafeRotatingHandler, RelayHandler

@pytest.fixture
def model_dir(tmp_path):
    for name in ('model.bin','config.json','tokenizer.json','vocabulary.json'):
        (tmp_path/name).write_text('simulation')
    return tmp_path

@pytest.fixture
def clip():
    return audio_capture.Recording(np.full((4800,2),.0005,np.float32),48000,2,4800,.1,.0005,.0005,False,'stopped',
                                   dict(id=1,name='Simulated USB',hostapi='Test API'))


def run_request(monkeypatch, clip, model, settings, request_id=91):
    monkeypatch.setattr(audio_capture,'record',lambda *a:clip)
    worker.shutdown.clear()
    events=[]
    worker.execute_listen(dict(request_id=request_id,settings=settings),model,lambda **d:events.append(d))
    return events


def test_manual_bypasses_both_energy_and_silero_and_returns_complete_text(monkeypatch,model_dir,clip):
    calls=[]
    class Model:
        def __init__(self,*a,**kwargs):
            assert kwargs['device']=='cpu' and kwargs['compute_type']=='int8'
        def transcribe(self,audio,**kwargs):
            calls.append(kwargs)
            assert audio.dtype==np.float32 and len(audio)==1600 and audio.ndim==1
            return iter([SimpleNamespace(text='模拟中文'),SimpleNamespace(text='完整结果')]),None
    monkeypatch.setitem(sys.modules,'faster_whisper',SimpleNamespace(WhisperModel=Model))
    events=run_request(monkeypatch,clip,worker.LocalTranscriber(),dict(model_path=str(model_dir),record_mode='manual'))
    assert not calls[0]['vad_filter']
    assert [e['value'] for e in events if e['event']=='text']==['模拟中文完整结果']
    assert events[-1]==dict(event='done',outcome='completed')


def test_auto_no_voice_does_not_load_model(monkeypatch,clip):
    model=SimpleNamespace(transcribe=lambda *a:pytest.fail('No ASR should run'))
    events=run_request(monkeypatch,clip,model,dict(record_mode='auto'))
    assert events[-1]['outcome']=='timeout'
    assert any('自动监听超时' in e.get('value','') for e in events if e['event']=='notice')


def test_self_test_no_model_required_and_no_asr(monkeypatch,clip):
    model=SimpleNamespace(transcribe=lambda *a:pytest.fail('Self-test must not run ASR'))
    events=run_request(monkeypatch,clip,model,dict(record_mode='test',model_path=''))
    result=next(e['value'] for e in events if e['event']=='test_result')
    assert result['has_audio'] and result['has_sound'] and result['samplerate']==48000
    assert events[-1]['outcome']=='test_complete'


def test_empty_transcript_visible_notice(monkeypatch,clip):
    events=run_request(monkeypatch,clip,SimpleNamespace(transcribe=lambda *a:''),dict(record_mode='manual'))
    assert any('未识别到有效语音' in e.get('value','') for e in events if e['event']=='notice')
    assert not any(e['event']=='text' for e in events)


@pytest.mark.parametrize('failure',[RuntimeError('model load failed'),OSError('transcription failed')])
def test_pipeline_failure_explicit_error_and_done(monkeypatch,clip,failure):
    def fail(*a): raise failure
    events=run_request(monkeypatch,clip,SimpleNamespace(transcribe=fail),dict(record_mode='manual'))
    assert events[-1]['outcome']=='error'
    assert any(type(failure).__name__ in e['value'] for e in events if e['event']=='error')


def test_incomplete_model_and_load_failure_are_specific(model_dir,clip,monkeypatch):
    with pytest.raises(ValueError,match='缺少'):
        worker.validate_model(model_dir/'missing')
    def fail(*args,**kwargs): raise RuntimeError('model initialization failed')
    monkeypatch.setitem(sys.modules,'faster_whisper',SimpleNamespace(WhisperModel=fail))
    with pytest.raises(RuntimeError,match='initialization'):
        worker.LocalTranscriber().transcribe(clip,dict(model_path=str(model_dir)),Event(),lambda **d:None)


def test_segment_iterator_failure_caught(monkeypatch,model_dir,clip):
    def broken():
        yield SimpleNamespace(text='temporary data')
        raise RuntimeError('segment iteration failed')
    class Model:
        def __init__(self,*a,**kwargs):pass
        def transcribe(self,*a,**kwargs):return broken(),None
    monkeypatch.setitem(sys.modules,'faster_whisper',SimpleNamespace(WhisperModel=Model))
    events=run_request(monkeypatch,clip,worker.LocalTranscriber(),dict(model_path=str(model_dir)))
    assert events[-1]['outcome']=='error' and not any(e['event']=='text' for e in events)


def test_cancel_before_capture_no_submission(monkeypatch,clip):
    worker.cancelled_ids.add(91)
    model=SimpleNamespace(transcribe=lambda *a:pytest.fail('Cancelled input submitted'))
    events=run_request(monkeypatch,None,model,dict(record_mode='manual'))
    assert events[-1]['outcome']=='cancelled'
    assert 91 not in worker.cancelled_ids


def test_ui_manual_start_finish_state_and_no_duplicate_threads(controller,monkeypatch):
    voice=controller.voice
    sent=[]
    monkeypatch.setattr(voice,'_command',sent.append)
    QTest.mouseClick(voice.start_button, __import__('PySide6.QtCore',fromlist=['Qt']).Qt.MouseButton.LeftButton)
    rid=voice.active_request
    assert sent[0]['settings']['record_mode']=='manual'
    assert not voice.start_button.isEnabled() and voice.finish_button.isEnabled()
    voice.listen()
    assert len(sent)==1
    voice._event(dict(request_id=rid,event='state',value='recording'))
    voice.finish_recording()
    assert sent[-1]==dict(op='finish',request_id=rid)
    assert voice.capture_state=='stopping' and not voice.finish_button.isEnabled()
    voice._event(dict(request_id=rid,event='done',outcome='completed'))
    assert voice.start_button.isEnabled() and not voice.listening and not voice.stopping


def test_telemetry_updates_real_widgets_in_same_units(controller,monkeypatch):
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    packet=dict(device_name='Simulated USB',device_id=4,hostapi='Mock WASAPI',samplerate=48000,channels=2,
                rms=.005,peak=.02,threshold=.012,duration=1.2,frames=57600,speech=False)
    voice._event(dict(request_id=voice.active_request,event='level',value=packet))
    assert voice.level_bar.value()>0
    text=voice.diagnostics.toPlainText()
    for literal in ['0.0050000','0.0120000','48000','57600','Simulated USB']:
        assert literal in text
    assert '1.2 秒' in voice.duration_label.text()


def test_ui_cancel_and_late_result_cannot_enter_chat(controller,monkeypatch):
    voice=controller.voice
    sent=[]
    monkeypatch.setattr(voice,'_command',sent.append)
    voice.listen()
    old=voice.active_request
    voice.cancel_capture()
    assert sent[-1]==dict(op='cancel',request_id=old)
    voice._event(dict(request_id=old,event='text',value='late private transcript'))
    assert controller.store.messages()==[]
    voice._event(dict(request_id=old,event='done',outcome='cancelled'))
    voice.listen()
    assert voice.active_request!=old
    voice._event(dict(request_id=old,event='text',value='older transcript'))
    assert controller.store.messages()==[]


def test_failure_reset_preserves_error_and_reenables_controls(controller,monkeypatch):
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    rid=voice.active_request
    voice._event(dict(request_id=rid,event='error',value='specific simulated error'))
    voice._event(dict(request_id=rid,event='done',outcome='error'))
    assert not voice.listening and not voice.stopping
    assert voice.start_button.isEnabled() and voice.active_request is None
    assert 'specific simulated error' in voice.label.text()
    voice.listen()
    assert voice.listening


def test_multiple_start_stop_cycles_and_timeout_recovery(controller,monkeypatch):
    voice=controller.voice
    sent=[]
    monkeypatch.setattr(voice,'_command',sent.append)
    for _ in range(5):
        voice.listen()
        rid=voice.active_request
        voice.finish_recording()
        voice._event(dict(request_id=rid,event='done',outcome='completed'))
        assert voice.start_button.isEnabled()
    voice.listen()
    voice._watchdog_expired()
    assert not voice.listening and not voice.stopping and voice.start_button.isEnabled()
    assert voice.capture_state=='failed'


def test_refresh_missing_identity_does_not_switch_to_default(controller):
    voice=controller.voice
    voice.settings.update(device=3,device_name='Removed mic',device_hostapi='Mock API')
    voice._event(dict(event='devices',value=[dict(id=3,name='Other device',hostapi='Mock API')]))
    assert voice.mic.currentData()==-1
    voice.listen()
    assert not voice.listening
    assert voice.settings['device_name']=='Removed mic'


def test_log_write_failure_and_rollover_do_not_crash(tmp_path,monkeypatch):
    logger,error=configure_voice_logging(tmp_path)
    assert error is None
    handler=logger.handlers[0]
    handler.maxBytes=100
    for i in range(20):logger.info('diagnostic metric %s',i)
    assert len(list((tmp_path/'logs').glob('voice.log*')))<=4
    def fail(*args,**kwargs):raise PermissionError('simulated disk denied')
    monkeypatch.setattr(handler,'_open',fail)
    handler.stream.close()
    handler.stream=None
    logger.error('failure should not escape')
    (tmp_path/'bad').write_text('not a folder')
    failed_logger,error=configure_voice_logging(tmp_path/'bad')
    assert error is not None
    failed_logger.error('still safe')


def test_tracebacks_logged_but_success_transcript_never_logged(tmp_path,model_dir,clip,monkeypatch):
    logger,_=configure_voice_logging(tmp_path)
    events=[]
    def notify(**data):
        if data['event']=='log': logger.log(data['level'],'%s',data['value'])
        else:events.append(data)
    relay=RelayHandler(notify)
    worker_logger=logging.getLogger('qiaomi.voice.worker-test')
    worker_logger.propagate=False
    worker_logger.setLevel(logging.INFO)
    worker_logger.addHandler(relay)
    monkeypatch.setattr(worker,'log',worker_logger)
    monkeypatch.setattr(audio_capture,'record',lambda *a:clip)
    worker.shutdown.clear()
    model=SimpleNamespace(transcribe=lambda *a:'DO_NOT_LOG_TRANSCRIPT')
    worker.execute_listen(dict(request_id=300,settings={}),model,notify)
    def fail(*a):raise RuntimeError('simulated failure')
    worker.execute_listen(dict(request_id=301,settings={}),SimpleNamespace(transcribe=fail),notify)
    content=(tmp_path/'logs'/'voice.log').read_text()
    assert 'Traceback' in content and 'simulated failure' in content
    assert 'DO_NOT_LOG_TRANSCRIPT' not in content


def test_idle_unload_and_cache_no_microphone_polling():
    transcriber=worker.LocalTranscriber()
    transcriber.model=object()
    transcriber.key=('fixture','cpu')
    transcriber.unload()
    assert transcriber.model is None and transcriber.key is None


def test_control_channel_failure_does_not_leave_active_request(controller):
    voice=controller.voice
    voice.server.close()
    voice.listen()
    assert voice.active_request is None and not voice.listening
    assert voice.start_button.isEnabled() and voice.capture_state=='failed'


def test_finish_while_initializing_cannot_revert_to_recording(controller,monkeypatch):
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    rid=voice.active_request
    voice.finish_recording()
    voice._event(dict(request_id=rid,event='state',value='recording'))
    assert voice.capture_state=='stopping'


def test_real_worker_ipc_manual_finish_and_cancel(controller, model_dir, tmp_path, monkeypatch):
    # Inject synthetic hardware/model in a TEST-ONLY process bootstrap. Product
    # source has no fake-audio switch and always calls actual sounddevice.
    script=tmp_path/'synthetic_worker.py'
    script.write_text('''
import sys,time,types,os
sys.path.insert(0,os.getcwd())
import numpy as np
class Stream:
    def __init__(self,**kw): self.samplerate=kw['samplerate']; self.channels=kw['channels']
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def read(self,n):
        time.sleep(.04)
        return np.full((n,self.channels),.0005,np.float32),False
sd=types.SimpleNamespace(default=types.SimpleNamespace(device=(0,0)),
 query_devices=lambda:[dict(name='Synthetic USB',hostapi=0,max_input_channels=2,default_samplerate=48000)],
 query_hostapis=lambda:[dict(name='Synthetic API')],check_input_settings=lambda **kw:None,InputStream=Stream)
sys.modules['sounddevice']=sd
class Model:
    def __init__(self,*a,**kw):pass
    def transcribe(self,audio,**kw):
        assert audio.ndim==1 and audio.dtype==np.float32 and not kw['vad_filter']
        return iter([types.SimpleNamespace(text='模拟进程中文识别')]),None
sys.modules['faster_whisper']=types.SimpleNamespace(WhisperModel=Model)
from qiaomi.voice_worker import main
main()
''',encoding='utf-8')
    voice=controller.voice
    voice.settings['model_path']=str(model_dir)
    native_start=voice.process.start
    monkeypatch.setattr(voice.process,'start',lambda program,args:native_start(program,[str(script)]+args[-3:]))
    voice.listen()
    wait(lambda:voice.diagnostic_values.get('frames',0)>=4800)
    assert voice.level_bar.value()>0
    voice.finish_recording()
    wait(lambda:voice.active_request is None)
    assert voice.transcript.text()=='识别结果：模拟进程中文识别'
    wait(lambda:controller.worker is None)
    voice.listen()
    wait(lambda:voice.diagnostic_values.get('frames',0)>=4800)
    voice.cancel_capture()
    wait(lambda:voice.active_request is None)
    assert voice.capture_state=='cancelled' and voice.start_button.isEnabled()
    content=voice.log_path.read_text()
    assert 'actual_rate=48000' in content and 'Microphone released' in content
    assert '模拟进程中文识别' not in content
    voice.close()
    assert voice.process.processId()==0


def test_crash_after_finish_is_failure_not_intentional_exit(controller,monkeypatch):
    from PySide6.QtCore import QProcess
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    voice.finish_recording()
    voice._process_error(QProcess.ProcessError.Crashed)
    assert voice.capture_state=='failed' and voice.active_request is None
    assert voice.start_button.isEnabled()


def test_dynamic_logging_failure_is_reported_without_stopping_recording(controller,monkeypatch):
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    voice.voice_log.write_failed=True
    voice._event(dict(event='log',value='synthetic metric',level=logging.INFO))
    assert '日志写入失败' in voice.label.text()
    assert voice.listening


def test_cancel_ack_deadline_recovers_even_without_worker_ack(controller,monkeypatch):
    voice=controller.voice
    monkeypatch.setattr(voice,'_command',lambda *a:None)
    voice.listen()
    voice.cancel_capture()
    voice._kill_cancelled_worker()
    assert voice.active_request is None and not voice.listening and not voice.stopping
    assert voice.start_button.isEnabled() and voice.capture_state=='cancelled'
