"""Mock AI/audio, real Qt event loop/SQLite and ASR child control channel."""
import os
import time
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import pytest
from PySide6.QtWidgets import QApplication
from PySide6.QtTest import QTest
from qiaomi import app as application
from qiaomi.memory_intent import validate_proposal, has_memory_intent
from qiaomi.voice import TranscriptWakeDetector

@pytest.fixture
def controller(tmp_path):
    app = QApplication.instance() or QApplication([])
    c = application.Controller(app, tmp_path, smoke=True)
    yield c
    if c.worker:
        c.worker.cancel()
        c.worker.wait(2000)
        app.processEvents()
    app.aboutToQuit.disconnect(c.cleanup)
    c.cleanup()
    c.window._allow_close = True
    c.window.close()
    c.pet.hide()
    c.deleteLater()
    app.processEvents()

def wait(predicate):
    deadline = time.monotonic()+3
    while not predicate() and time.monotonic()<deadline:
        QTest.qWait(10)
    assert predicate()

@pytest.mark.parametrize('raw', ['{}','null','[]','{"type":"偏好","key":"","value":"x"}',
    '{"type":"偏好","key":"k","value":"v","execute":"delete"}',
    '```json\n{"type":"偏好","key":"k","value":"v"}\n```'])
def test_invalid_ai_output_is_rejected(raw):
    with pytest.raises(ValueError):
        validate_proposal(raw)

def test_natural_memory_only_saves_after_voice_confirmation(controller, monkeypatch):
    proposal = {'type':'个人偏好','key':'喜欢的电竞选手','value':'Chovy、Doran'}
    monkeypatch.setattr(application, 'extract_memory', lambda *a: proposal)
    controller.send('敲咪，记住我最喜欢的选手是 Chovy 和 Doran。')
    wait(lambda: controller.worker is None)
    assert controller.store.list_memories() == []
    assert controller.pending_memory == proposal
    controller.voice.text.emit('确认保存。')
    row = controller.store.list_memories()[0]
    assert row['value'] == 'Chovy、Doran'
    assert row['category'] == '个人偏好'
    controller.store.update_memory(row['id'], row['key'], 'Chovy')
    assert controller.store.list_memories()[0]['value'] == 'Chovy'
    controller.store.delete_memory(row['id'])
    assert controller.store.list_memories() == []

def test_denial_timeout_and_disabled_memory_never_write(controller):
    proposal = dict(type='偏好', key='饮品', value='茶')
    controller.propose_memory(proposal)
    controller.send('不保存')
    assert not controller.pending_memory
    assert controller.store.list_memories() == []
    controller.propose_memory(proposal)
    controller.memory_timer.timeout.emit()
    controller.accept_memory()
    assert controller.store.list_memories() == []
    controller.voice._set('memory_enabled', False)
    controller.send('记住：饮品=茶')
    assert controller.pending_memory is None
    assert controller.store.list_memories() == []

def test_parse_failure_never_saves_memory(controller, monkeypatch):
    def fail(*a):
        raise ValueError('bad model response')
    monkeypatch.setattr(application, 'extract_memory', fail)
    controller.send('记住我喜欢茶')
    wait(lambda: controller.worker is None)
    assert controller.store.list_memories() == []
    assert controller.pending_memory is None

def test_duplicate_and_overwrite_require_review(controller):
    controller.store.upsert_memory('饮品','茶')
    controller.propose_memory(dict(type='偏好',key='饮品',value='茶'))
    assert controller.pending_memory is None
    controller.propose_memory(dict(type='偏好',key='饮品',value='咖啡'))
    assert '将替换同名旧内容' in controller.window.memory_text.toPlainText()
    controller.reject_memory()
    assert controller.store.list_memories()[0]['value'] == '茶'

def test_no_microphone_at_start_mute_and_interrupt(controller, monkeypatch):
    voice = controller.voice
    assert not voice.wake and not voice.listening
    assert voice.process.processId() == 0
    commands = []
    monkeypatch.setattr(voice, '_command', commands.append)
    voice.set_muted(True)
    voice.listen()
    assert not commands and not voice.listening
    voice.set_muted(False)
    voice.listen()
    assert commands[0]['op']=='listen'
    voice.interrupt()
    assert not voice.listening and not voice.speaking
    voice._event({'event':'text','value':'过期语音不得保存'})
    assert controller.store.messages() == []

def test_experimental_wake_transition_and_timeout(controller, monkeypatch):
    voice = controller.voice
    detector = TranscriptWakeDetector()
    assert detector.matches('敲咪！')
    assert not detector.matches('今天天气')
    commands=[]
    monkeypatch.setattr(voice, '_command', commands.append)
    voice.wake_box.setChecked(True)
    voice.retry.stop()
    voice._wake_listen()
    assert voice.mode=='wake'
    voice._event({'event':'text','value':'敲咪'})
    assert voice.awaiting_command
    voice._event({'event':'done'})
    assert voice.follow.isActive()
    voice.follow.stop()
    voice._follow_listen()
    assert voice.mode=='command'
    voice._event({'event':'done'})
    assert voice.retry.isActive()
    voice.set_muted(True)
    assert not voice.retry.isActive()

def test_worker_loopback_control_and_dependency_error(controller):
    voice=controller.voice
    statuses=[]
    voice.status.connect(statuses.append)
    voice._command({'op':'devices'})
    wait(lambda: voice.authenticated)
    wait(lambda: bool(statuses) or voice.mic.count()>1)
    voice.close()
    assert voice.process.processId()==0

def test_intent_gate_does_not_capture_all_conversation():
    assert has_memory_intent('敲咪，记住我喜欢茶')
    assert not has_memory_intent('今天陪我聊聊天')

def test_speech_state_pauses_mic_and_interrupts(controller):
    from PySide6.QtTextToSpeech import QTextToSpeech
    class Speech:
        def __init__(self): self.calls=[]
        def setVoice(self, v): pass
        def setVolume(self, v): self.calls.append(('volume',v))
        def setRate(self, v): self.calls.append(('rate',v))
        def say(self, text): self.calls.append(('say',text))
        def stop(self): self.calls.append(('stop',))
    voice=controller.voice
    voice.tts=Speech()
    voice.settings['tts']=True
    voice.voices.addItem('模拟中文声音', 'simulation')
    voice.speak('妈妈，我在！')
    assert voice.speaking
    voice.listen()
    assert not voice.listening
    assert ('say','妈妈，我在！') in voice.tts.calls
    voice._tts_state(QTextToSpeech.State.Ready)
    assert not voice.speaking
    voice.speak('下一句')
    voice.interrupt()
    assert not voice.speaking
    assert voice.tts.calls[-1] == ('stop',)

def test_voice_never_sends_transcript_to_cloud(controller):
    controller.config.provider='openai'
    controller.voice.text.emit('不能上传的语音文本')
    assert controller.worker is None
    assert controller.store.messages() == []

def test_energy_endpoint_releases_audio_stream():
    from threading import Event
    import numpy as np
    from test_audio_capture import FakeSD
    from qiaomi.audio_capture import record
    sd=FakeSD(waveform=lambda n,i:np.full((n,2),.1 if i<=3 else 0,np.float32))
    result=record(dict(record_mode='auto',threshold=.01),Event(),Event(),lambda **d:None,sd)
    assert result.frames==12*4800 and sd.opened[0][1].closed


def test_memory_transport_uses_structured_local_request(monkeypatch):
    import httpx
    from threading import Event
    from qiaomi import memory_intent
    captured=[]
    def handler(request):
        import json
        assert request.url.host=='127.0.0.1'
        body=json.loads(request.content)
        captured.append(body)
        return httpx.Response(200,json={'message':{'content':'{"type":"个人偏好","key":"选手","value":"Chovy、Doran"}'}})
    monkeypatch.setattr(memory_intent, '_client', lambda: httpx.AsyncClient(base_url='http://127.0.0.1:11434',transport=httpx.MockTransport(handler),trust_env=False))
    result=memory_intent.extract_memory('qwen3:8b','记住我喜欢的选手',Event())
    assert result['value']=='Chovy、Doran'
    assert captured[0]['format']['additionalProperties'] is False
    assert not captured[0]['stream'] and not captured[0]['think']

def test_upgrade_preserves_existing_database_and_backup_format(tmp_path):
    import sqlite3
    import json
    from qiaomi.storage import Store
    path=tmp_path/'qiaomi.db'
    connection=sqlite3.connect(path)
    connection.executescript('''
    PRAGMA user_version=1;
    CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT NOT NULL UNIQUE,
    value TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT 'legacy', updated_at TEXT NOT NULL DEFAULT 'legacy');
    INSERT INTO memories(key,value) VALUES ('原有偏好','不可覆盖');
    ''')
    connection.close()
    store=Store(path)
    assert store.list_memories()[0]['value']=='不可覆盖'
    store.save_reviewed_memory('新偏好','茶','个人偏好')
    store.export_memories(tmp_path/'export.json')
    assert {'key':'原有偏好','value':'不可覆盖'} in json.loads((tmp_path/'export.json').read_text())['memories']
    store.close()
    reopened=Store(path)
    assert len(reopened.list_memories())==2
    reopened.close()

def test_single_instance_lock_and_window_close_are_separate(controller, tmp_path):
    from PySide6.QtCore import QLockFile
    lock1=QLockFile(str(tmp_path/'instance.lock'))
    lock2=QLockFile(str(tmp_path/'instance.lock'))
    assert lock1.tryLock(0)
    assert not lock2.tryLock(0)
    lock1.unlock()
    assert lock2.tryLock(0)
    lock2.unlock()
    controller.show_assistant()
    controller.window.close()
    assert not controller.closed and not controller.shutting_down

def test_windowless_entry_and_build_contract():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    launch=(root/'start.vbs').read_text()
    assert 'pythonw.exe' in launch and 'shell.Run' in launch
    assert 'cmd.exe' not in launch.lower()
    assert 'console=False' in (root/'qiaomi.spec').read_text()
    assert (root/'start.bat').is_file() and (root/'install_shortcut.vbs').is_file()

def test_asr_cuda_failure_falls_back_and_reuses_cpu_model(tmp_path, monkeypatch):
    import sys
    import numpy as np
    from threading import Event
    from types import SimpleNamespace
    from qiaomi.voice_worker import LocalTranscriber
    for name in ('model.bin','config.json','tokenizer.json','vocabulary.json'):
        (tmp_path/name).write_text('fixture')
    loads=[]
    class Model:
        def __init__(self,path,device,**kwargs):
            loads.append(device)
            assert kwargs['local_files_only']
            if device=='cuda': raise RuntimeError('simulated OOM')
        def transcribe(self,audio,**kwargs):
            assert kwargs['language']=='zh' and kwargs['vad_filter']
            return iter([SimpleNamespace(text='模拟中文识别')]),None
    monkeypatch.setitem(sys.modules,'faster_whisper',SimpleNamespace(WhisperModel=Model))
    recording=SimpleNamespace(audio=np.full(1600,.1,np.float32),samplerate=16000,frames=1600)
    settings=dict(model_path=str(tmp_path),compute='cuda',record_mode='auto')
    worker=LocalTranscriber()
    for _ in range(2):
        assert worker.transcribe(recording,settings,Event(),lambda **d:None)=='模拟中文识别'
    assert loads==['cuda','cpu']


def test_process_failure_can_be_retried_without_stuck_listening(controller):
    from PySide6.QtCore import QProcess
    voice=controller.voice
    voice.listening=True
    voice._process_error(QProcess.ProcessError.FailedToStart)
    assert not voice.listening and not voice.stopping and not voice.wake
